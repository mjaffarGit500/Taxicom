// ignore_for_file: deprecated_member_use, library_private_types_in_public_api, use_build_context_synchronously

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:ride_on/core/extensions/workspace.dart';

Future<Uint8List> createCustomMarkerImage(String imageUrl) async {
  ui.Image profileImage;
  final normalizedImageUrl = imageUrl.trim();
  final parsedUri = Uri.tryParse(normalizedImageUrl);

  try {
    if (normalizedImageUrl.isEmpty ||
        parsedUri == null ||
        !parsedUri.hasScheme ||
        !parsedUri.hasAuthority) {
      throw Exception("Invalid image URL");
    }

    final Completer<ui.Image> completer = Completer<ui.Image>();
    final Image image = Image.network(normalizedImageUrl, fit: BoxFit.cover);

    image.image.resolve(const ImageConfiguration()).addListener(
          ImageStreamListener((ImageInfo info, bool _) {
            completer.complete(info.image);
          }, onError: (error, stackTrace) {
            completer.completeError(error);
          }),
        );

    profileImage = await completer.future;
  } catch (e) {
    // Fallback: load default asset image
    final ByteData data = await rootBundle.load(appLogo);
    final codec = await ui.instantiateImageCodec(data.buffer.asUint8List());
    final frame = await codec.getNextFrame();
    profileImage = frame.image;
  }

  // Marker size setup
  const double circleSize = 100.0;
  const double pinHeight = 40.0;
  const double totalHeight = circleSize + pinHeight;

  final ui.PictureRecorder recorder = ui.PictureRecorder();
  final Canvas canvas = Canvas(recorder);
  final Paint whitePaint = Paint()..color = Colors.white;
  const double circleRadius = circleSize / 2;

  // Draw circular white background
  canvas.drawCircle(
      const Offset(circleRadius, circleRadius), circleRadius, whitePaint);

  // Clip only image part
  final Path imageClipPath = Path()
    ..addOval(Rect.fromCircle(
        center: const Offset(circleRadius, circleRadius),
        radius: circleRadius - 6));
  canvas.save();
  canvas.clipPath(imageClipPath);

  // Draw image
  paintImage(
    canvas: canvas,
    rect: const Rect.fromLTWH(6, 6, circleSize - 12, circleSize - 12),
    image: profileImage,
    fit: BoxFit.cover,
  );
  canvas.restore();

  // Draw pin triangle
  final Paint pinPaint = Paint()..color = Colors.red;
  final Path pinPath = Path()
    ..moveTo(circleRadius - 10, circleSize - 2)
    ..lineTo(circleRadius + 10, circleSize - 2)
    ..lineTo(circleRadius, totalHeight)
    ..close();

  canvas.drawPath(pinPath, pinPaint);

  // Final marker image
  final ui.Image finalImage = await recorder
      .endRecording()
      .toImage(circleSize.toInt(), totalHeight.toInt());

  final ByteData? byteData =
      await finalImage.toByteData(format: ui.ImageByteFormat.png);
  return byteData!.buffer.asUint8List();
}

int fileSizeThreshold = 1024 * 1024;

int goodQuality = 85;

int badQuality = 50;

int maxWidth = 800;

int maxHeight = 600;

Future<String> compressAndUploadImage(String imagePath) async {
  var imageFile = File(imagePath);
  int originalSize = await imageFile.length();
  int quality = originalSize > fileSizeThreshold ? badQuality : goodQuality;
  var compressedImage = await FlutterImageCompress.compressWithFile(
    imagePath,
    quality: quality,
    minWidth: maxWidth,
    minHeight: maxHeight,
  );

  int compressedSize = compressedImage!.length;
  // ignore: unused_local_variable
  double compressionRatio = originalSize / compressedSize;

  var base64Image = base64Encode(compressedImage);

  String format = '';
  if (compressedImage.length > 8) {
    if (compressedImage[0] == 0xFF && compressedImage[1] == 0xD8) {
      format = 'jpeg';
    } else if (compressedImage[0] == 0x89 && compressedImage[1] == 0x50) {
      format = 'png';
    }
  }

  String finalBase64 = "data:image/$format;base64,$base64Image";
  return finalBase64;
}

Future<Uint8List> getBytesFromAsset(String path, int width) async {
  ByteData data = await rootBundle.load(path);
  ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List(),
      targetWidth: width);
  ui.FrameInfo fi = await codec.getNextFrame();
  return (await fi.image.toByteData(format: ui.ImageByteFormat.png))!
      .buffer
      .asUint8List();
}
