// ignore_for_file: deprecated_member_use, library_private_types_in_public_api, use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:ride_on/core/utils/theme/project_color.dart';

 

Color getStatusColor(String status) {
  switch (status) {
    case 'Completed':
      return appgreen;
    case 'Cancelled':
      return redColor;
    case 'Declined':
      return redColor;
    case 'Pending':
      return orangeColor; // define if not yet
    case 'Accepted':
    case 'Arrived':
    case 'Live':
      return blueColor; // define as per your theme
    case 'Confirmed':
      return Colors.deepPurple; // custom if needed
    case 'Expired':
    case 'Refunded':
      return greyColor2; // soft grey maybe
    default:
      return Colors.black54;
  }
}

Color getStatusBackground(String status) {
  return getStatusColor(status).withOpacity(0.2);
}
