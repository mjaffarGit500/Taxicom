import 'dart:async';
import 'dart:math' as math;


const double carMarkerRotationOffsetDegrees = 180.0;

double normalizeCarMarkerRotation(double bearingDegrees) {
  final rotated = (bearingDegrees + carMarkerRotationOffsetDegrees) % 360.0;
  return rotated < 0 ? rotated + 360.0 : rotated;
}

class TrackedLatLng {
  final double lat;
  final double lng;
  const TrackedLatLng(this.lat, this.lng);
}

class DriverTrackingFrame {
  final double lat;
  final double lng;
  final double bearingDegrees;
  const DriverTrackingFrame({
    required this.lat,
    required this.lng,
    required this.bearingDegrees,
  });
}

class SmoothDriverTrackingController {
  SmoothDriverTrackingController({
    this.frameInterval = const Duration(milliseconds: 33),
    this.animationDuration = const Duration(milliseconds: 1000),
    this.deadZoneMeters = 2.5,
    this.implausibleSpeedMps = 55.0,
    this.bearingSmoothingFactor = 0.25,
  });

  final Duration frameInterval;
  final Duration animationDuration;
  final double deadZoneMeters;
  final double implausibleSpeedMps;
  final double bearingSmoothingFactor;

  TrackedLatLng? actualPosition;
  DateTime? _actualPositionTimestamp;

  double _animatedBearing = 0;
  bool _hasBearing = false;

  TrackedLatLng? _animationFrom;
  TrackedLatLng? _animationTo;
  DateTime? _animationStartTime;
  Timer? _ticker;

  bool isFollowing = true;

  void Function(DriverTrackingFrame frame)? onFrame;

  bool get hasPosition => actualPosition != null;

  void onNewLocation(double lat, double lng) {
    final next = TrackedLatLng(lat, lng);
    final now = DateTime.now();

    if (actualPosition == null) {
      // First valid fix: snap directly, no animation.
      actualPosition = next;
      _actualPositionTimestamp = now;
      _animationFrom = next;
      _animationTo = next;
      _animationStartTime = now;
      _emitImmediate(next);
      return;
    }

    final previousActual = actualPosition!;
    final previousTimestamp = _actualPositionTimestamp ?? now;
    final elapsedSeconds =
        now.difference(previousTimestamp).inMilliseconds / 1000.0;
    final distance = _distanceMeters(previousActual, next);

    actualPosition = next;
    _actualPositionTimestamp = now;

    if (elapsedSeconds > 0) {
      final impliedSpeed = distance / elapsedSeconds;
      if (impliedSpeed > implausibleSpeedMps) {
        _animationFrom = next;
        _animationTo = next;
        _animationStartTime = now;
        _emitImmediate(next);
        return;
      }
    }

    final currentRendered = _currentInterpolatedPosition() ?? previousActual;
    _animationFrom = currentRendered;
    _animationTo = next;
    _animationStartTime = now;
    _ensureTicker();
  }

  TrackedLatLng? _currentInterpolatedPosition() {
    final from = _animationFrom;
    final to = _animationTo;
    final start = _animationStartTime;
    if (from == null || to == null || start == null) return null;
    final fraction = _fractionElapsed(start);
    return TrackedLatLng(
      from.lat + (to.lat - from.lat) * fraction,
      from.lng + (to.lng - from.lng) * fraction,
    );
  }

  double _fractionElapsed(DateTime start) {
    final elapsedMs = DateTime.now().difference(start).inMilliseconds;
    final totalMs = animationDuration.inMilliseconds;
    if (totalMs <= 0) return 1.0;
    final fraction = elapsedMs / totalMs;
    if (fraction.isNaN) return 1.0;
    return fraction.clamp(0.0, 1.0);
  }

  void _ensureTicker() {
    _ticker ??= Timer.periodic(frameInterval, _tick);
  }

  void _tick(Timer timer) {
    final from = _animationFrom;
    final to = _animationTo;
    final start = _animationStartTime;
    if (from == null || to == null || start == null) {
      timer.cancel();
      _ticker = null;
      return;
    }

    final fraction = _fractionElapsed(start);
    final lat = from.lat + (to.lat - from.lat) * fraction;
    final lng = from.lng + (to.lng - from.lng) * fraction;
    final current = TrackedLatLng(lat, lng);

    final movedSinceFrom = _distanceMeters(from, current);
    if (movedSinceFrom >= deadZoneMeters || !_hasBearing) {
      final rawBearing = _initialBearing(from, to);
      if (!_hasBearing) {
        _animatedBearing = rawBearing;
        _hasBearing = true;
      } else {
        final delta = _shortestAngleDelta(_animatedBearing, rawBearing);
        _animatedBearing =
            (_animatedBearing + delta * bearingSmoothingFactor) % 360;
        if (_animatedBearing < 0) _animatedBearing += 360;
      }
    }

    onFrame?.call(DriverTrackingFrame(
      lat: lat,
      lng: lng,
      bearingDegrees: _animatedBearing,
    ));

    if (fraction >= 1.0) {
      timer.cancel();
      _ticker = null;
    }
  }

  void _emitImmediate(TrackedLatLng position) {
    onFrame?.call(DriverTrackingFrame(
      lat: position.lat,
      lng: position.lng,
      bearingDegrees: _animatedBearing,
    ));
  }

  void setFollowing(bool value) {
    isFollowing = value;
  }

  static double _distanceMeters(TrackedLatLng a, TrackedLatLng b) {
    const earthRadius = 6371000.0;
    final dLat = _degToRad(b.lat - a.lat);
    final dLng = _degToRad(b.lng - a.lng);
    final lat1 = _degToRad(a.lat);
    final lat2 = _degToRad(b.lat);
    final h = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.sin(dLng / 2) * math.sin(dLng / 2) * math.cos(lat1) * math.cos(lat2);
    final c = 2 * math.atan2(math.sqrt(h), math.sqrt(1 - h));
    return earthRadius * c;
  }

  static double _initialBearing(TrackedLatLng from, TrackedLatLng to) {
    final lat1 = _degToRad(from.lat);
    final lat2 = _degToRad(to.lat);
    final dLng = _degToRad(to.lng - from.lng);
    final y = math.sin(dLng) * math.cos(lat2);
    final x = math.cos(lat1) * math.sin(lat2) -
        math.sin(lat1) * math.cos(lat2) * math.cos(dLng);
    final bearing = _radToDeg(math.atan2(y, x));
    return (bearing + 360) % 360;
  }

  static double _shortestAngleDelta(double from, double to) {
    var delta = (to - from) % 360;
    if (delta > 180) delta -= 360;
    if (delta < -180) delta += 360;
    return delta;
  }

  static double _degToRad(double deg) => deg * math.pi / 180.0;
  static double _radToDeg(double rad) => rad * 180.0 / math.pi;

  void dispose() {
    _ticker?.cancel();
    _ticker = null;
  }
}
