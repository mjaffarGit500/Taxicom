import 'dart:async';
import 'dart:convert';
import 'package:ride_on/core/extensions/workspace.dart';
import 'package:flutter/material.dart' show BuildContext;
// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;
import '../../app/route_settings.dart';
import '../../presentation/cubits/logout_cubit.dart';
import '../../presentation/screens/auth/login_screen.dart';
import '../utils/common_widget.dart';
import 'config.dart';
import 'data_store.dart';

bool connectionLost = false;
String latitudeGlobal = '';
String longitudeGlobal = '';
bool shouldLogout = false;

Future<dynamic> httpPost(path, data, {required BuildContext context}) async {
  try {
    String apiBaseUrl = Config.baseUrl;
    var url = apiBaseUrl + path;
    if (bearerToken.isEmpty) {
      bearerToken = await generateToken() ?? "";
    }
    var headers = {
      'Content-Type': 'application/json',
      "Authorization": "Bearer $bearerToken",
    };

    data['module_id'] = "2";
    data['user_type'] = "user";
    data['latitude'] = latitudeGlobal;
    data['longitude'] = longitudeGlobal;
    data['lang'] = globalLocalization;

    data['token'] = token;

    var response = await http.post(
      Uri.parse(url),
      headers: headers,
      body: jsonEncode(data),
    );

    var responseData =
        json.decode(const Utf8Codec().decode(response.bodyBytes));


    if (response.statusCode == 498) {
      showErrorToastMessage("Session expired. Please log in again.");
      Future.delayed(const Duration(seconds: 1), () {
        clearData(navigatorKey.currentContext!,true);
        goToWithClear(const LoginScreen());
      });
    }

    if (response.statusCode == 419) {
      showErrorToastMessage("Session expired. Please log in again.");
      Future.delayed(const Duration(seconds: 1), () {
        clearData(navigatorKey.currentContext!,true);
        goToWithClear(const LoginScreen());
      });
    }

    return responseData;
  } catch (err) {
    return {"error": "Something went wrong"};
  }
}

Future<dynamic> httpGet(
  String path,
  Map<String, dynamic> data, {
  required BuildContext context,
}) async {
  dynamic responsegetData;

  try {
    String apiBaseUrl = Config.baseUrl;
    var url = apiBaseUrl + path;

    if (bearerToken.isEmpty) {
      bearerToken = await generateToken() ?? "";
    }

    var headers = {
      'Content-Type': 'application/json',
      'x-auth-token': token,
      'Authorization': "Bearer $bearerToken",
    };

    data['module_id'] = "2";
    data['user_type'] = "user";
    data['latitude'] = latitudeGlobal;
    data['longitude'] = longitudeGlobal;
    data['lang'] = globalLocalization;
    data['time_zone'] = "";

    String queryString = Uri(
      queryParameters: data.map(
        (key, value) => MapEntry(key, value.toString()),
      ),
    ).query;

    var fullUrl = "$url?$queryString";


    var response = await http.get(
      Uri.parse(fullUrl),
      headers: headers,
    );


    if (response.statusCode == 200) {
      responsegetData =
          json.decode(const Utf8Codec().decode(response.bodyBytes));
    } else if (response.statusCode == 498 || response.statusCode == 419) {
      showErrorToastMessage("Session expired. Please log in again.");

      Future.delayed(const Duration(seconds: 1), () {
        clearData(navigatorKey.currentContext!, true);
        goToWithClear(const LoginScreen());
      });
    } else {
      responsegetData =
          json.decode(const Utf8Codec().decode(response.bodyBytes));
    }
  } catch (e) {
    responsegetData = {
      'error': "Something went wrong. Please try again.",
    };
  }

  return responsegetData;
}

Future<String?>? _tokenFuture;
Future<String?> generateToken() async {
  if (_tokenFuture != null) {
    return _tokenFuture;
  }

  final completer = Completer<String?>();
  _tokenFuture = completer.future;

  try {
    const String url = '${Config.baseUrl}${Config.bootstrapToken}';
    const Map<String, String> headers = {
      "Content-Type": "application/json",
      "X-RideOn-Bootstrap-Publishable-Key": Config.publishableKey
    };

    Map<String, dynamic> body = {};

    final response = await http.post(
      Uri.parse(url),
      headers: headers,
      body: jsonEncode(body),
    );

    final data = json.decode(response.body);
    if (response.statusCode == 200) {
      final token = data['data']["access_token"].toString();
      bearerToken = token;

      box.put("bearerToken", token);
      completer.complete(token);
    } else if (response.statusCode == 419) {
      showErrorToastMessage("Session expired. Please log in again.");
      Future.delayed(const Duration(seconds: 1), () {
        clearData(navigatorKey.currentContext!,true);
        goToWithClear(const LoginScreen());
      });
    } else {
      completer.complete(null);
    }
  } catch (e) {
    completer.complete(null);
  } finally {
    _tokenFuture = null;
  }

  return await completer.future;
}
