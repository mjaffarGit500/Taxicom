


import 'dart:convert';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
import 'package:http/http.dart' as http;
import '../../../../core/services/config.dart';

abstract class GetPolylineMapBoxState extends Equatable {
  const GetPolylineMapBoxState();

  @override
  List<Object?> get props => [];
}

class GetPolylineMapBoxInitial extends GetPolylineMapBoxState {}

class GetPolylineMapBoxLoading extends GetPolylineMapBoxState {
  final Set<PolylineAnnotation> polylines;

  const GetPolylineMapBoxLoading(this.polylines);

  @override
  List<Object?> get props => [polylines];
}

class GetPolylineMapBoxUpdated extends GetPolylineMapBoxState {
  final Set<PolylineAnnotation> polylines;

  const GetPolylineMapBoxUpdated({required this.polylines});

  @override
  List<Object?> get props => [polylines];
}

class GetPolylineMapBoxError extends GetPolylineMapBoxState {
  final String message;

  const GetPolylineMapBoxError(this.message);

  @override
  List<Object?> get props => [message];
}

class GetPolylineMapBoxCubit extends Cubit<GetPolylineMapBoxState> {
  GetPolylineMapBoxCubit() : super(GetPolylineMapBoxInitial());

  final Map<String, PolylineAnnotation> _polylines = {};
  PolylineAnnotationManager? _annotationManager;
  static const String _mapboxBaseUrl =
      'https://api.mapbox.com/directions/v5/mapbox/driving';

  /// ✅ Set the map controller to enable adding annotations
  Future<void> setMapController(MapboxMap map) async {
    _annotationManager = await map.annotations.createPolylineAnnotationManager();
  }

  /// ✅ Fetch polyline route from Mapbox
  Future<void> getPolylineMapbox({
    required double sourcelat,
    required double sourcelng,
    required double destinationlat,
    required double destinationlng,
    required bool isPickupRoute, // true for pickup, false for dropoff
  }) async {
    try {
      if (sourcelat == 0.0 ||
          sourcelng == 0.0 ||
          destinationlat == 0.0 ||
          destinationlng == 0.0) {
        emit(const GetPolylineMapBoxError("Invalid coordinates"));
        return;
      }

      emit(GetPolylineMapBoxLoading(_polylines.values.toSet()));

      final coordinates =
          '$sourcelng,$sourcelat;$destinationlng,$destinationlat';
      final url = Uri.parse(
        '$_mapboxBaseUrl/$coordinates?geometries=geojson&overview=full&access_token=${Config.mapboxToken}',
      );

      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['code'] != 'Ok' ||
            data['routes'] == null ||
            data['routes'].isEmpty) {
          emit(const GetPolylineMapBoxError("Failed to get route"));
          return;
        }

        // ✅ Get GeoJSON geometry from Mapbox response
        final geometry = data['routes'][0]['geometry'];

        // ✅ Create polyline annotation for Mapbox
        final String polylineId =
        isPickupRoute ? "DriverPickupToUser" : "DriverDropoffToUser";

        // Remove opposite polyline type
        final String oppositePolylineId =
        isPickupRoute ? "DriverDropoffToUser" : "DriverPickupToUser";
        await _removePolylineById(oppositePolylineId);

        // Remove same polyline type if already exists
        await _removePolylineById(polylineId);

        await _addPolyLine(
          geometry: geometry,
          id: polylineId,
          color: isPickupRoute ? Colors.blue.value : Colors.green.value,
        );

        emit(GetPolylineMapBoxUpdated(polylines: _polylines.values.toSet()));
      } else {
        emit(GetPolylineMapBoxError(
            "Failed to fetch route (${response.statusCode})"));
      }
    } catch (e) {
      emit(GetPolylineMapBoxError("Exception: $e"));
    }
  }



  /// ✅ Helper to add a polyline to Mapbox map
  Future<void> _addPolyLine({
    required Map<String, dynamic> geometry,
    required String id,
    required int color,
  }) async {
    final lineString = _convertGeoJsonToLineString(geometry);
    if (lineString == null) {
       return;
    }

    if (_annotationManager == null) {
       return;
    }

    try {
      final polylineOptions = PolylineAnnotationOptions(
        geometry: lineString,
        lineColor: color,
        lineWidth: 5.0,
        lineOpacity: 1.0,
        lineJoin: LineJoin.ROUND,
      );
      final polylineAnnotation = await _annotationManager!.create(polylineOptions);
      _polylines[id] = polylineAnnotation;
    } catch (e) {
    }
  }

  /// ✅ Remove a specific polyline by ID
  Future<void> _removePolylineById(String id) async {
    final existing = _polylines[id];
    if (existing != null && _annotationManager != null) {
      await _annotationManager!.delete(existing);
      _polylines.remove(id);
    }
  }

  /// ✅ Convert GeoJSON geometry to LineString
  LineString? _convertGeoJsonToLineString(Map<String, dynamic> geometry) {
    try {
      if (geometry['type'] == 'LineString' && geometry['coordinates'] is List) {
        final coordinates = geometry['coordinates'] as List;
        final positions = coordinates.map((coord) {
          if (coord is List && coord.length >= 2) {
            return Position(coord[0].toDouble(), coord[1].toDouble());
          }
          return Position(0, 0);
        }).toList();

        return LineString(coordinates: positions);
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  /// ✅ Clear all polylines
  Future<void> resetPolylines() async {
    try {
      if (_annotationManager != null) {
        try {

          await _annotationManager!.deleteAll();
        } catch (e) {
        }
      }


      _annotationManager = null;
      _polylines.clear();

      if (!isClosed) {
        emit(GetPolylineMapBoxInitial());
      }
    } catch (e) {
    }
  }


  Set<PolylineAnnotation> get currentPolylines =>
      _polylines.values.toSet();






  ///for loading
  /// ✅ Fetch polyline route from Mapbox
  Future<void> getPolylineMapboxForLoading({
    required double sourcelat,
    required double sourcelng,
    required double destinationlat,
    required double destinationlng,
    required bool isPickupRoute, // true for pickup, false for dropoff
  }) async {
    try {
      if (sourcelat == 0.0 ||
          sourcelng == 0.0 ||
          destinationlat == 0.0 ||
          destinationlng == 0.0) {
        emit(const GetPolylineMapBoxError("Invalid coordinates"));
        return;
      }

      emit(GetPolylineMapBoxLoading(_polylines.values.toSet()));

      final coordinates =
          '$sourcelng,$sourcelat;$destinationlng,$destinationlat';
      final url = Uri.parse(
        '$_mapboxBaseUrl/$coordinates?geometries=geojson&overview=full&access_token=${Config.mapboxToken}',
      );

      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['code'] != 'Ok' ||
            data['routes'] == null ||
            data['routes'].isEmpty) {
          emit(const GetPolylineMapBoxError("Failed to get route"));
          return;
        }

        // ✅ Get GeoJSON geometry from Mapbox response
        final geometry = data['routes'][0]['geometry'];

        // ✅ Create polyline annotation for Mapbox
        final String polylineId =
        isPickupRoute ? "DriverPickupToUser" : "DriverDropoffToUser";

        // Remove opposite polyline type
        final String oppositePolylineId =
        isPickupRoute ? "DriverDropoffToUser" : "DriverPickupToUser";
        _polylines.remove(oppositePolylineId);

        // Remove same polyline type if already exists
        _polylines.remove(polylineId);

        _addPolyLineForLoading(
          geometry: geometry,
          id: polylineId,
          color: isPickupRoute ? Colors.blue.value : Colors.green.value,
        );

        emit(GetPolylineMapBoxUpdated(polylines: _polylines.values.toSet()));
      } else {
        emit(GetPolylineMapBoxError(
            "Failed to fetch route (${response.statusCode})"));
      }
    } catch (e) {
      emit(GetPolylineMapBoxError("Exception: $e"));
    }
  }

  /// ✅ Helper to add a polyline to Mapbox map
  void _addPolyLineForLoading({
    required Map<String, dynamic> geometry,
    required String id,
    required int color,
  }) {
    final lineString = _convertGeoJsonToLineStringForLoading(geometry);
    if (lineString == null) {
       return;
    }

    final polyline = PolylineAnnotation(
      id: id,
      geometry: lineString,
      lineColor: color,
      lineWidth: 5.0,
      lineJoin: LineJoin.ROUND,
    );

    _polylines[id] = polyline;
  }

  /// ✅ Convert GeoJSON geometry to LineString
  LineString? _convertGeoJsonToLineStringForLoading(Map<String, dynamic> geometry) {
    try {
      if (geometry['type'] == 'LineString' && geometry['coordinates'] is List) {
        final coordinates = geometry['coordinates'] as List;
        final positions = coordinates.map((coord) {
          if (coord is List && coord.length >= 2) {
            return Position(coord[0].toDouble(), coord[1].toDouble());
          }
          return Position(0, 0);
        }).toList();

        return LineString(coordinates: positions);
      }
      return null;
    } catch (e) {
       return null;
    }
  }
}