
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/services.dart';
import 'dart:ui' as ui;
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
import '../../../../core/utils/common_widget.dart';

// ------------------- MARKER DATA CLASS -------------------
class MarkerData {
  Point point;
  String title;
  Uint8List image;

  MarkerData({
    required this.point,
    required this.title,
    required this.image,
  });
}

// ------------------- STATES -------------------
abstract class UserMarkerStateMapbox extends Equatable {
  @override
  List<Object?> get props => [];
}
class UserMarkerInitialMapbox extends UserMarkerStateMapbox {}
class UserMarkerUpdatedMapbox extends UserMarkerStateMapbox {
  final Map<String, PointAnnotation> markers;
  UserMarkerUpdatedMapbox({required this.markers});
  @override
  List<Object?> get props => [markers];
}

// ------------------- CUBIT -------------------
class UserMarkerCubitMapbox extends Cubit<UserMarkerStateMapbox> {
  UserMarkerCubitMapbox() : super(UserMarkerInitialMapbox());
  final Map<String, PointAnnotation> _markers = {};
  final Map<String, MarkerData> _pending = {};
  PointAnnotationManager? _annotationManager;
  MapboxMap? _mapboxMap;

  Future<void> setMapController(MapboxMap map) async {
    _mapboxMap = map;
    _annotationManager = await map.annotations.createPointAnnotationManager();
    // Process any pending markers
    for (final entry in _pending.entries) {
      final markerId = entry.key;
      final data = entry.value;
      try {
        final pointAnnotationOptions = PointAnnotationOptions(
          geometry: data.point,
          image: data.image,
          textField: data.title,
          textOffset: [0, 2],
        );
        final pointAnnotation = await _annotationManager!.create(pointAnnotationOptions);
        _markers[markerId] = pointAnnotation;
      } catch (e) {
      }
    }
    _pending.clear();
    emit(UserMarkerUpdatedMapbox(markers: Map.from(_markers)));
  }

  // Add or Update Marker
  Future<void> addOrUpdateMarker({
    required Point point,
    required String title,
    required String markerId,
    required String iconPath,
    int size = 80,
  }) async {
    // Remove old marker first
    await _removeMarker(markerId);
    try {
      final Uint8List imageBytes = await _getMarkerImage(iconPath, title, size);
      final data = MarkerData(point: point, title: title, image: imageBytes);
      if (_annotationManager != null) {
        final pointAnnotationOptions = PointAnnotationOptions(
          geometry: point,
          image: imageBytes,
          textField: title,
          textOffset: [0, 2],
        );
        final pointAnnotation = await _annotationManager!.create(pointAnnotationOptions);
        _markers[markerId] = pointAnnotation;
        emit(UserMarkerUpdatedMapbox(markers: Map.from(_markers)));
      } else {
        _pending[markerId] = data;
      }
    } catch (e) {
    }
  }

  // Remove marker
  Future<void> _removeMarker(String markerId) async {
    if (_annotationManager != null) {
      final marker = _markers[markerId];
      if (marker != null) {
        await _annotationManager!.delete(marker);
        _markers.remove(markerId);
        emit(UserMarkerUpdatedMapbox(markers: Map.from(_markers)));
      }
    } else {
      _pending.remove(markerId);
    }
  }

  void removeMarker(String markerId) {
    _removeMarker(markerId);
  }

  // Update marker position (optionally with a bearing/rotation in degrees)
  Future<void> updateMarkerPosition(
    String markerId,
    Point newPosition, {
    double? bearingDegrees,
  }) async {
    if (_annotationManager != null) {
      final marker = _markers[markerId];
      if (marker != null) {
        marker.geometry = newPosition;
        if (bearingDegrees != null) {
          marker.iconRotate = bearingDegrees;
        }
        await _annotationManager!.update(marker);
        emit(UserMarkerUpdatedMapbox(markers: Map.from(_markers)));
      }
    } else {
      final pendingData = _pending[markerId];
      if (pendingData != null) {
        pendingData.point = newPosition;
      }
    }
  }

  Future<void> clear() async {
    try {
      if (_annotationManager != null) {
        try {
          await _annotationManager!.deleteAll();
        } catch (e) {
        }
      }

      // reset local data
      _annotationManager = null;
      _markers.clear();
      _pending.clear();

      // avoid emit after cubit is closed
      if (!isClosed) {
        emit(UserMarkerInitialMapbox());
      }
    } catch (e) {
    }
  }


  // ------------------- Helpers -------------------
  Future<Uint8List> _getMarkerImage(String iconPath, String title, int size) async {
    if (iconPath.startsWith('http')) {
      try {
        return await createCustomMarkerImage(iconPath);
      } catch (_) {
        return await _createIconImage(Icons.location_on, Colors.grey);
      }
    } else {
      return await getBytesFromAsset(iconPath, size);
    }
  }

  Future<Uint8List> getBytesFromAsset(String path, int width) async {
    final ByteData data = await rootBundle.load(path);
    final ui.Codec codec = await ui.instantiateImageCodec(
      data.buffer.asUint8List(),
      targetWidth: width,
    );
    final ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png))!.buffer.asUint8List();
  }

  Future<Uint8List> _createIconImage(IconData iconData, Color color) async {
    final pictureRecorder = ui.PictureRecorder();
    final canvas = Canvas(pictureRecorder);
    final paint = Paint()..color = color;
    const double radius = 20.0;
    canvas.drawCircle(const Offset(radius, radius), radius, paint);
    final textPainter = TextPainter(textDirection: TextDirection.ltr);
    final iconText = String.fromCharCode(iconData.codePoint);
    textPainter.text = TextSpan(
      text: iconText,
      style: TextStyle(
        fontSize: 24.0,
        fontFamily: iconData.fontFamily,
        color: Colors.white,
      ),
    );
    textPainter.layout();
    textPainter.paint(canvas, Offset(radius - textPainter.width / 2, radius - textPainter.height / 2));
    final picture = pictureRecorder.endRecording();
    final image = await picture.toImage((radius * 2).toInt(), (radius * 2).toInt());
    final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
    return byteData!.buffer.asUint8List();
  }
}


