import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

abstract class OSMGetPolylineState extends Equatable {
  @override
  List<Object?> get props => [];
}

class OSMGetPolylineInitial extends OSMGetPolylineState {}

class OSMGetPolylineLoading extends OSMGetPolylineState {
  final Set<Polyline> polylines;
  OSMGetPolylineLoading(this.polylines);

  @override
  List<Object?> get props => [polylines];
}

class OSMGetPolylineUpdated extends OSMGetPolylineState {
  final Set<Polyline> polylines;
  OSMGetPolylineUpdated({required this.polylines});

  @override
  List<Object?> get props => [polylines];
}

class OSMGetPolylineUpdatedError extends OSMGetPolylineState {
  final String error;
  OSMGetPolylineUpdatedError(this.error);

  @override
  List<Object?> get props => [error];
}

class OSMGetPolylineCubit extends Cubit<OSMGetPolylineState> {
  OSMGetPolylineCubit() : super(OSMGetPolylineInitial());

  final Map<String, Polyline> _polylines = {};

  Future<void> getPolyline({
    required double sourcelat,
    required double sourcelng,
    required double destinationlat,
    required double destinationlng,
    required bool isPickupRoute,
  }) async {
    try {
      if (sourcelat == 0.0 ||
          sourcelng == 0.0 ||
          destinationlat == 0.0 ||
          destinationlng == 0.0) {
        emit(OSMGetPolylineUpdatedError("Invalid coordinates"));
        return;
      }

      emit(OSMGetPolylineLoading(_polylines.values.toSet()));

      // OSRM public API URL
      final url = Uri.parse(
          "http://router.project-osrm.org/route/v1/driving/$sourcelng,$sourcelat;$destinationlng,$destinationlat?overview=full&geometries=geojson");

      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['code'] != 'Ok' || data['routes'] == null || data['routes'].isEmpty) {
          emit(OSMGetPolylineUpdatedError("Failed to get route"));
          return;
        }

        // Extract coordinates from geojson
        final coords = data['routes'][0]['geometry']['coordinates'] as List;
        final polylineCoordinates = coords
            .map<LatLng>((point) => LatLng(point[1].toDouble(), point[0].toDouble()))
            .toList();

        final String polylineId = isPickupRoute
            ? "DriverPickupToUser"
            : "DriverDropoffToUser";

        // Remove the opposite polyline
        final String oppositePolylineId = isPickupRoute
            ? "DriverDropoffToUser"
            : "DriverPickupToUser";
        _polylines.remove(oppositePolylineId);

        // Remove existing polyline of same type
        _polylines.remove(polylineId);

        _addPolyLine(
          coordinates: polylineCoordinates,
          id: polylineId,
          color: isPickupRoute ? Colors.blue : Colors.green,
        );

        emit(OSMGetPolylineUpdated(polylines: _polylines.values.toSet()));
      } else {
        emit(OSMGetPolylineUpdatedError("Failed to fetch route - Status: ${response.statusCode}"));
      }
    } catch (e) {
      emit(OSMGetPolylineUpdatedError("Exception: $e"));
    }
  }

  void _addPolyLine({
    required List<LatLng> coordinates,
    required String id,
    required Color color,
  }) {
    final polyline = Polyline(
      points: coordinates,
      strokeWidth: 4,
      color: color,
    );
    _polylines[id] = polyline;
  }

  // Alternative OSM routing with different service
  Future<void> getPolylineAlternative({
    required double sourcelat,
    required double sourcelng,
    required double destinationlat,
    required double destinationlng,
    required bool isPickupRoute,
  }) async {
    try {
      if (sourcelat == 0.0 ||
          sourcelng == 0.0 ||
          destinationlat == 0.0 ||
          destinationlng == 0.0) {
        emit(OSMGetPolylineUpdatedError("Invalid coordinates"));
        return;
      }

      emit(OSMGetPolylineLoading(_polylines.values.toSet()));

      // Using OpenRouteService API (you'll need an API key)
      final url = Uri.parse(
          "https://api.openrouteservice.org/v2/directions/driving-car?api_key=YOUR_OPENROUTESERVICE_KEY&start=$sourcelng,$sourcelat&end=$destinationlng,$destinationlat"
      );

      final response = await http.get(url, headers: {
        'Accept': 'application/json, application/geo+json, application/gpx+xml, img/png; charset=utf-8',
      });

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['features'] == null || data['features'].isEmpty) {
          emit(OSMGetPolylineUpdatedError("Failed to get route from alternative service"));
          return;
        }

        // Extract coordinates from geojson
        final coords = data['features'][0]['geometry']['coordinates'] as List;
        final polylineCoordinates = coords
            .map<LatLng>((point) => LatLng(point[1].toDouble(), point[0].toDouble()))
            .toList();

        final String polylineId = isPickupRoute
            ? "DriverPickupToUser"
            : "DriverDropoffToUser";

        // Remove the opposite polyline
        final String oppositePolylineId = isPickupRoute
            ? "DriverDropoffToUser"
            : "DriverPickupToUser";
        _polylines.remove(oppositePolylineId);

        // Remove existing polyline of same type
        _polylines.remove(polylineId);

        _addPolyLine(
          coordinates: polylineCoordinates,
          id: polylineId,
          color: isPickupRoute ? Colors.blue : Colors.green,
        );

        emit(OSMGetPolylineUpdated(polylines: _polylines.values.toSet()));
      } else {
        emit(OSMGetPolylineUpdatedError("Alternative service failed - Status: ${response.statusCode}"));
      }
    } catch (e) {
      emit(OSMGetPolylineUpdatedError("Exception in alternative service: $e"));
    }
  }

  // Get distance and duration information
  Future<Map<String, dynamic>?> getRouteInfo({
    required double sourcelat,
    required double sourcelng,
    required double destinationlat,
    required double destinationlng,
  }) async {
    try {
      final url = Uri.parse(
          "http://router.project-osrm.org/route/v1/driving/$sourcelng,$sourcelat;$destinationlng,$destinationlat?overview=false");

      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['code'] == 'Ok' && data['routes'] != null && data['routes'].isNotEmpty) {
          final route = data['routes'][0];
          return {
            'distance': route['distance'], // in meters
            'duration': route['duration'], // in seconds
          };
        }
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  // Clear specific polyline
  void clearPolyline(bool isPickupRoute) {
    final String polylineId = isPickupRoute
        ? "DriverPickupToUser"
        : "DriverDropoffToUser";

    _polylines.remove(polylineId);
    emit(OSMGetPolylineUpdated(polylines: _polylines.values.toSet()));
  }

  // Get current polylines
  Set<Polyline> get currentPolylines => _polylines.values.toSet();

  // Check if specific polyline exists
  bool hasPolyline(bool isPickupRoute) {
    final String polylineId = isPickupRoute
        ? "DriverPickupToUser"
        : "DriverDropoffToUser";
    return _polylines.containsKey(polylineId);
  }

  void resetPolylines() {
    _polylines.clear();
    emit(OSMGetPolylineInitial());
  }
}

