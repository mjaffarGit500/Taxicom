import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/services.dart';
import 'dart:ui' as ui;
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../../../../core/utils/common_widget.dart';

// OSM Marker State
abstract class UserMarkerStateOSM extends Equatable {
  @override
  List<Object?> get props => [];
}

class UserMarkerInitialOSM extends UserMarkerStateOSM {}

class UserMarkerUpdatedOSM extends UserMarkerStateOSM {
  final Set<Marker> markers;

  UserMarkerUpdatedOSM({required this.markers});

  @override
  List<Object?> get props => [markers];
}

// OSM Only Cubit
class UserMarkerCubitOSM extends Cubit<UserMarkerStateOSM> {
  UserMarkerCubitOSM() : super(UserMarkerInitialOSM());

  final Set<Marker> _markers = {};
  final Map<String, Widget> _markerWidgetCache = {};
  final Map<String, String> _iconPathByMarkerId = {};

  Future<void> addOrUpdateMarker(
      LatLng position,
      String title,
      String markerId,
      String iconPath,
      int size, {
        double? rotationDegrees,
      }) async {
    Widget? baseWidget = _markerWidgetCache[markerId];
    if (baseWidget == null || _iconPathByMarkerId[markerId] != iconPath) {
      if (title == "Driver Location" && iconPath.startsWith('http')) {
        // For driver image from URL - create custom marker
        final Uint8List markerBytes = await createCustomMarkerImage(iconPath);
        baseWidget = _buildCustomDriverMarker(markerBytes, size);
      } else if (iconPath.startsWith('http')) {
        // For other URL images
        baseWidget = SizedBox(
          width: size.toDouble(),
          height: size.toDouble(),
          child: Image.network(
            iconPath,
            fit: BoxFit.contain,
            errorBuilder: (_, __, ___) => _buildDefaultIcon(title, size),
          ),
        );
      } else {
        // For asset images
        baseWidget = _buildAssetMarker(iconPath, size, title);
      }
      _markerWidgetCache[markerId] = baseWidget;
      _iconPathByMarkerId[markerId] = iconPath;
    }

    final markerWidget = rotationDegrees != null
        ? Transform.rotate(
            angle: rotationDegrees * (3.1415926535897932 / 180.0),
            child: baseWidget,
          )
        : baseWidget;

    // Remove existing marker with same ID
    _markers.removeWhere((marker) {
      final key = marker.key;
      return key is ValueKey && key.value == markerId;
    });

    // Add new marker
    _markers.add(
      Marker(
        key: ValueKey(markerId),
        width: size.toDouble(),
        height: size.toDouble(),
        point: position,
        child: markerWidget,
      ),
    );

    emit(UserMarkerUpdatedOSM(markers: _markers));
  }

  Widget _buildCustomDriverMarker(Uint8List markerBytes, int size) {
    return SizedBox(
      width: size.toDouble(),
      height: size.toDouble(),
      child: Image.memory(
        markerBytes,
        fit: BoxFit.contain,
        errorBuilder: (_, __, ___) => _buildDefaultDriverIcon(size),
      ),
    );
  }

  Widget _buildDefaultDriverIcon(int size) {
    return Container(
      width: size.toDouble(),
      height: size.toDouble(),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.blue,
        border: Border.all(color: Colors.white, width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Icon(
        Icons.person,
        color: Colors.white,
        size: size * 0.5,
      ),
    );
  }

  Widget _buildDefaultIcon(String title, int size) {
    IconData iconData;
    Color color;

    switch (title) {
      case "User Location":
        iconData = Icons.location_on;
        color = Colors.green;
        break;
      case "Drop Location":
        iconData = Icons.flag;
        color = Colors.red;
        break;
      case "Driver Location":
        iconData = Icons.directions_car;
        color = Colors.blue;
        break;
      default:
        iconData = Icons.location_on;
        color = Colors.grey;
    }

    return Container(
      width: size.toDouble(),
      height: size.toDouble(),
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white, width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Icon(
        iconData,
        color: Colors.white,
        size: size * 0.6,
      ),
    );
  }

  Widget _buildAssetMarker(String iconPath, int size, String title) {
    return SizedBox(
      width: size.toDouble(),
      height: size.toDouble(),
      child: Image.asset(
        iconPath,
        fit: BoxFit.contain,
        errorBuilder: (_, __, ___) => _buildDefaultIcon(title, size),
      ),
    );
  }

  void removeMarker(String markerId) {
    _markers.removeWhere((marker) {
      final key = marker.key;
      return key is ValueKey && key.value == markerId;
    });
    _markerWidgetCache.remove(markerId);
    _iconPathByMarkerId.remove(markerId);
    emit(UserMarkerUpdatedOSM(markers: _markers));
  }

  void clear() {
    _markers.clear();
    _markerWidgetCache.clear();
    _iconPathByMarkerId.clear();
    emit(UserMarkerInitialOSM());
  }

  Set<Marker> get currentMarkers => _markers;

  // Your custom marker creation function


  // Utility method for asset images
  Future<Uint8List> getBytesFromAsset(String path, int width) async {
    ByteData data = await rootBundle.load(path);
    ui.Codec codec = await ui.instantiateImageCodec(
      data.buffer.asUint8List(),
      targetWidth: width,
    );
    ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png))!
        .buffer
        .asUint8List();
  }
}

// Enhanced version with additional marker types and animations
class AdvancedUserMarkerCubitOSM extends Cubit<UserMarkerStateOSM> {
  AdvancedUserMarkerCubitOSM() : super(UserMarkerInitialOSM());

  final Set<Marker> _markers = {};
  final Map<String, Timer> _animationTimers = {};

  Future<void> addOrUpdateMarker(
      LatLng position,
      String title,
      String markerId,
      String iconPath,
      int size, {
        bool animate = false,
        Duration animationDuration = const Duration(milliseconds: 500),
      }) async {
    // Cancel any existing animation for this marker
    _animationTimers[markerId]?.cancel();

    Widget markerWidget;

    if (title == "Driver Location" && iconPath.startsWith('http')) {
      final Uint8List markerBytes = await createCustomMarkerImage(iconPath);
      markerWidget = _buildCustomDriverMarker(markerBytes, size);
    } else if (iconPath.startsWith('http')) {
      markerWidget = SizedBox(
        width: size.toDouble(),
        height: size.toDouble(),
        child: Image.network(
          iconPath,
          fit: BoxFit.contain,
          errorBuilder: (_, __, ___) => _buildDefaultIcon(title, size),
        ),
      );
    } else {
      markerWidget = _buildAssetMarker(iconPath, size, title);
    }

    // Remove existing marker
    _markers.removeWhere((marker) {
      final key = marker.key;
      return key is ValueKey && key.value == markerId;
    });

    // Create new marker
    final newMarker = Marker(
      key: ValueKey(markerId),
      width: size.toDouble(),
      height: size.toDouble(),
      point: position,
      child: animate ? _buildAnimatedMarker(markerWidget, markerId) : markerWidget,
    );

    _markers.add(newMarker);
    emit(UserMarkerUpdatedOSM(markers: _markers));

    // Handle animation
    if (animate) {
      _startMarkerAnimation(markerId, animationDuration);
    }
  }

  Widget _buildAnimatedMarker(Widget child, String markerId) {
    return AnimatedMarkerContainer(
      markerId: markerId,
      child: child,
    );
  }

  void _startMarkerAnimation(String markerId, Duration duration) {
    _animationTimers[markerId] = Timer(duration, () {
      // Remove animation after duration
      _markers.removeWhere((marker) {
        final key = marker.key;
        return key is ValueKey && key.value == markerId;
      });

      // Re-add without animation
      final markerWithoutAnimation = Marker(
        key: ValueKey(markerId),
        width: 120.0,
        height: 120.0,
        point: _markers.firstWhere((m) {
          final key = m.key;
          return key is ValueKey && key.value == markerId;
        }).point,
        child: _markers.firstWhere((m) {
          final key = m.key;
          return key is ValueKey && key.value == markerId;
        }).child,
      );

      _markers.add(markerWithoutAnimation);
      emit(UserMarkerUpdatedOSM(markers: _markers));
      _animationTimers.remove(markerId);
    });
  }

  Widget _buildCustomDriverMarker(Uint8List markerBytes, int size) {
    return Container(
      width: size.toDouble(),
      height: size.toDouble(),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size.toDouble()),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(size.toDouble()),
        child: Image.memory(
          markerBytes,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => _buildDefaultDriverIcon(size),
        ),
      ),
    );
  }

  Widget _buildDefaultDriverIcon(int size) {
    return Container(
      width: size.toDouble(),
      height: size.toDouble(),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.blue,
        border: Border.all(color: Colors.white, width: 3),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Icon(
        Icons.person,
        color: Colors.white,
        size: size * 0.4,
      ),
    );
  }

  Widget _buildDefaultIcon(String title, int size) {
    IconData iconData;
    Color color;

    switch (title) {
      case "User Location":
        iconData = Icons.location_on;
        color = Colors.green;
        break;
      case "Drop Location":
        iconData = Icons.flag;
        color = Colors.red;
        break;
      case "Driver Location":
        iconData = Icons.directions_car;
        color = Colors.blue;
        break;
      default:
        iconData = Icons.location_on;
        color = Colors.grey;
    }

    return Container(
      width: size.toDouble(),
      height: size.toDouble(),
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white, width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Icon(
        iconData,
        color: Colors.white,
        size: size * 0.6,
      ),
    );
  }

  Widget _buildAssetMarker(String iconPath, int size, String title) {
    return Container(
      width: size.toDouble(),
      height: size.toDouble(),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Image.asset(
        iconPath,
        fit: BoxFit.contain,
        errorBuilder: (_, __, ___) => _buildDefaultIcon(title, size),
      ),
    );
  }

  void removeMarker(String markerId) {
    _animationTimers[markerId]?.cancel();
    _animationTimers.remove(markerId);

    _markers.removeWhere((marker) {
      final key = marker.key;
      return key is ValueKey && key.value == markerId;
    });
    emit(UserMarkerUpdatedOSM(markers: _markers));
  }

  void clear() {
    // Cancel all animations
    _animationTimers.forEach((key, timer) => timer.cancel());
    _animationTimers.clear();

    _markers.clear();
    emit(UserMarkerInitialOSM());
  }

  @override
  Future<void> close() {
    // Clean up all timers when cubit is closed
    _animationTimers.forEach((key, timer) => timer.cancel());
    _animationTimers.clear();
    return super.close();
  }

  Set<Marker> get currentMarkers => _markers;


  Future<Uint8List> getBytesFromAsset(String path, int width) async {
    ByteData data = await rootBundle.load(path);
    ui.Codec codec = await ui.instantiateImageCodec(
      data.buffer.asUint8List(),
      targetWidth: width,
    );
    ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png))!
        .buffer
        .asUint8List();
  }
}

// Animated marker container for smooth transitions
class AnimatedMarkerContainer extends StatefulWidget {
  final String markerId;
  final Widget child;

  const AnimatedMarkerContainer({
    super.key,
    required this.markerId,
    required this.child,
  });

  @override
  State<AnimatedMarkerContainer> createState() => _AnimatedMarkerContainerState();
}

class _AnimatedMarkerContainerState extends State<AnimatedMarkerContainer>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _opacityAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.elasticOut,
    ));

    _opacityAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeIn,
    ));

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnimation.value,
          child: Opacity(
            opacity: _opacityAnimation.value,
            child: widget.child,
          ),
        );
      },
    );
  }
}