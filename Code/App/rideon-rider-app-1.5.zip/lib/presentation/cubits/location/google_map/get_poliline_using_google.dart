import 'dart:convert';

import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;

import '../../../../core/services/config.dart';
abstract class GetPolylineState extends Equatable {
  @override
  List<Object?> get props => [];
}

class GetPolylineInitial extends GetPolylineState {}

class GetPolylineLoading extends GetPolylineState {
  final Set<Polyline> polylines;
  GetPolylineLoading(this.polylines);

  @override
  List<Object?> get props => [polylines];
}

class GetPolylineUpdated extends GetPolylineState {
  final Set<Polyline>? polylines;
  GetPolylineUpdated({this.polylines});

  @override
  List<Object?> get props => [polylines];
}

class GetPolylineUpdatedError extends GetPolylineState {
  final String error;
  GetPolylineUpdatedError(this.error);

  @override
  List<Object?> get props => [error];
}

class GetPolylineCubit extends Cubit<GetPolylineState> {
  GetPolylineCubit() : super(GetPolylineInitial());

  final Map<PolylineId, Polyline> _polylines = {};
  final PolylinePoints _polylinePoints = PolylinePoints();

  Future<void> getPolyline({
    required double sourcelat,
    required double sourcelng,
    required double destinationlat,
    required double destinationlng,
    required bool isPickupRoute, // true for pickup, false for dropoff
  }) async {
    try {
      if (sourcelat == 0.0 ||
          sourcelng == 0.0 ||
          destinationlat == 0.0 ||
          destinationlng == 0.0) {
        emit(GetPolylineUpdatedError("Invalid coordinates"));
        return;
      }

      emit(GetPolylineLoading(_polylines.values.toSet()));

      final result = await _polylinePoints.getRouteBetweenCoordinates(
        googleApiKey: Config.googleKey,
        request: PolylineRequest(
          origin: PointLatLng(sourcelat, sourcelng),
          destination: PointLatLng(destinationlat, destinationlng),
          mode: TravelMode.driving,
        ),
      );

      if (result.status == 'OK') {
        final polylineCoordinates = result.points
            .map((point) => LatLng(point.latitude, point.longitude))
            .toList();

        final PolylineId polylineId = isPickupRoute
            ? const PolylineId("DriverPickupToUser")
            : const PolylineId("DriverDropoffToUser");

        // Remove the polyline of the opposite route type
        final PolylineId oppositePolylineId = isPickupRoute
            ? const PolylineId("DriverDropoffToUser")
            : const PolylineId("DriverPickupToUser");
        _polylines.remove(oppositePolylineId);

        // Remove the current polyline (if any) for the same route type
        _polylines.remove(polylineId);

        _addPolyLine(
          coordinates: polylineCoordinates,
          id: polylineId,
          color: isPickupRoute ? Colors.blue : Colors.green,
        );

        emit(GetPolylineUpdated(polylines: _polylines.values.toSet()));
      } else {
        emit(GetPolylineUpdatedError(
            result.errorMessage ?? "Failed to get polyline"));
      }
    } catch (e) {
      emit(GetPolylineUpdatedError("Exception: $e"));
    }
  }

  void _addPolyLine({
    required List<LatLng> coordinates,
    required PolylineId id,
    required Color color,
  }) {
    final polyline = Polyline(
      polylineId: id,
      color: color,
      width: 5,
      points: coordinates,
    );
    _polylines[id] = polyline;
  }


  Future<void> getPolylineOSM({
    required double sourcelat,
    required double sourcelng,
    required double destinationlat,
    required double destinationlng,
    required bool isPickupRoute, // true for pickup, false for dropoff
  }) async {
    try {
      if (sourcelat == 0.0 ||
          sourcelng == 0.0 ||
          destinationlat == 0.0 ||
          destinationlng == 0.0) {
        emit(GetPolylineUpdatedError("Invalid coordinates"));
        return;
      }

      emit(GetPolylineLoading(_polylines.values.toSet()));

      // OSRM public API URL
      final url = Uri.parse(
          "http://router.project-osrm.org/route/v1/driving/$sourcelng,$sourcelat;$destinationlng,$destinationlat?overview=full&geometries=geojson");

      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['code'] != 'Ok' || data['routes'] == null || data['routes'].isEmpty) {
          emit(GetPolylineUpdatedError("Failed to get route"));
          return;
        }

        // Extract coordinates from geojson
        final coords = data['routes'][0]['geometry']['coordinates'] as List;
        final polylineCoordinates = coords
            .map<LatLng>((point) => LatLng(point[1], point[0]))
            .toList();

        final PolylineId polylineId = isPickupRoute
            ? const PolylineId("DriverPickupToUser")
            : const PolylineId("DriverDropoffToUser");

        // Remove the opposite polyline
        final PolylineId oppositePolylineId = isPickupRoute
            ? const PolylineId("DriverDropoffToUser")
            : const PolylineId("DriverPickupToUser");
        _polylines.remove(oppositePolylineId);

        // Remove existing polyline of same type
        _polylines.remove(polylineId);

        _addPolyLine(
          coordinates: polylineCoordinates,
          id: polylineId,
          color: isPickupRoute ? Colors.blue : Colors.green,
        );

        emit(GetPolylineUpdated(polylines: _polylines.values.toSet()));
      } else {
        emit(GetPolylineUpdatedError("Failed to fetch route"));
      }
    } catch (e) {
      emit(GetPolylineUpdatedError("Exception: $e"));
    }
  }




  Set<Polyline> get currentPolylines => _polylines.values.toSet();

  void resetPolylines() {
    _polylines.clear();
    emit(GetPolylineInitial());
  }
}

