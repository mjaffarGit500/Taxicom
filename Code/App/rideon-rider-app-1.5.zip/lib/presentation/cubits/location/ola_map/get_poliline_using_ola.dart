import 'dart:convert';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import '../../../../core/services/config.dart';

/// ---------- STATES ----------
abstract class GetPolylineOlaState extends Equatable {
  @override
  List<Object?> get props => [];
}

class GetPolylineOlaInitial extends GetPolylineOlaState {}

class GetPolylineOlaLoading extends GetPolylineOlaState {
  final Set<Polyline> polylines;
  GetPolylineOlaLoading(this.polylines);

  @override
  List<Object?> get props => [polylines];
}

class GetPolylineOlaUpdated extends GetPolylineOlaState {
  final Set<Polyline> polylines;
  GetPolylineOlaUpdated(this.polylines);

  @override
  List<Object?> get props => [polylines];
}

class GetPolylineOlaError extends GetPolylineOlaState {
  final String error;
  GetPolylineOlaError(this.error);

  @override
  List<Object?> get props => [error];
}

/// ---------- CUBIT ----------
class GetPolylineOlaCubit extends Cubit<GetPolylineOlaState> {
  GetPolylineOlaCubit() : super(GetPolylineOlaInitial());

  final Map<PolylineId, Polyline> _polylines = {};

  Future<void> getPolylineOla({
    required double sourcelat,
    required double sourcelng,
    required double destinationlat,
    required double destinationlng,
    required bool isPickupRoute,
  }) async {
    try {
      if (sourcelat == 0.0 ||
          sourcelng == 0.0 ||
          destinationlat == 0.0 ||
          destinationlng == 0.0) {
        emit(GetPolylineOlaError("Invalid coordinates"));
        return;
      }

      emit(GetPolylineOlaLoading(_polylines.values.toSet()));

      /// ✅ Correct Ola Maps Directions API URL
      final url = Uri.parse(
        "https://api.olamaps.io/routing/v1/directions?"
            "origin=$sourcelat,$sourcelng&destination=$destinationlat,$destinationlng"
            "&alternatives=false&steps=true&overview=full&api_key=${Config.olaMapKey}",
      );


      /// ✅ FIX: Use GET instead of POST
      final response = await http.post(url); // Changed from POST to GET

      if (response.statusCode != 200) {
        emit(GetPolylineOlaError("Failed to fetch route (Status ${response.statusCode})"));
        return;
      }

      final data = json.decode(response.body);

      // ✅ Check for API errors first
      if (data['error_msg'] != null) {
        emit(GetPolylineOlaError("API Error: ${data['error_msg']}"));
        return;
      }

      final routes = data["routes"] as List?;
      if (routes == null || routes.isEmpty) {
        emit(GetPolylineOlaError("No routes found"));
        return;
      }

      final route = routes.first;
      List<LatLng> polylineCoordinates = [];

      // ✅ FIX: Handle Ola Maps polyline format
      if (route["overview_polyline"] != null) {
        // Option 1: Use overview_polyline (encoded polyline string)
        final encodedPolyline = route["overview_polyline"] as String;
        polylineCoordinates = _decodePolyline(encodedPolyline);
      }
      // ✅ FIX: Alternative approach - extract coordinates from steps
      else if (route["legs"] != null && route["legs"].isNotEmpty) {
        final legs = route["legs"] as List;
        final firstLeg = legs.first;
        final steps = firstLeg["steps"] as List?;

        if (steps != null && steps.isNotEmpty) {
          // Extract coordinates from each step's start and end locations
          for (final step in steps) {
            final startLocation = step["start_location"];
            final endLocation = step["end_location"];

            if (startLocation != null) {
              polylineCoordinates.add(LatLng(
                startLocation["lat"] as double,
                startLocation["lng"] as double,
              ));
            }

            if (endLocation != null) {
              polylineCoordinates.add(LatLng(
                endLocation["lat"] as double,
                endLocation["lng"] as double,
              ));
            }
          }

          // Remove duplicates and ensure proper order
          polylineCoordinates = _removeDuplicateCoordinates(polylineCoordinates);
        }
      } else {
        emit(GetPolylineOlaError("No polyline data found in response"));
        return;
      }

      if (polylineCoordinates.isEmpty) {
        emit(GetPolylineOlaError("No coordinates extracted from response"));
        return;
      }

      final PolylineId polylineId = isPickupRoute
          ? const PolylineId("DriverPickupToUser")
          : const PolylineId("DriverDropoffToUser");

      final PolylineId oppositePolylineId = isPickupRoute
          ? const PolylineId("DriverDropoffToUser")
          : const PolylineId("DriverPickupToUser");

      _polylines.remove(oppositePolylineId);
      _polylines.remove(polylineId);

      final polyline = Polyline(
        polylineId: polylineId,
        color: isPickupRoute ? Colors.blue : Colors.green,
        width: 5,
        points: polylineCoordinates,
      );

      _polylines[polylineId] = polyline;
      emit(GetPolylineOlaUpdated(_polylines.values.toSet()));

 
    } catch (e) {
       emit(GetPolylineOlaError("Exception: $e"));
    }
  }

// ✅ Polyline decoding utility (for encoded overview_polyline)
  List<LatLng> _decodePolyline(String encoded) {
    List<LatLng> points = [];
    int index = 0, len = encoded.length;
    int lat = 0, lng = 0;

    while (index < len) {
      int b, shift = 0, result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lat += dlat;

      shift = 0;
      result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lng += dlng;

      points.add(LatLng(lat / 1E5, lng / 1E5));
    }
    return points;
  }

// ✅ Remove duplicate coordinates utility
  List<LatLng> _removeDuplicateCoordinates(List<LatLng> coordinates) {
    final uniqueCoordinates = <LatLng>[];
    LatLng? lastCoordinate;

    for (final coord in coordinates) {
      if (lastCoordinate == null ||
          coord.latitude != lastCoordinate.latitude ||
          coord.longitude != lastCoordinate.longitude) {
        uniqueCoordinates.add(coord);
        lastCoordinate = coord;
      }
    }

    return uniqueCoordinates;
  }

  Set<Polyline> get currentPolylines => _polylines.values.toSet();

  void resetPolylines() {
    _polylines.clear();
    emit(GetPolylineOlaInitial());
  }
}
