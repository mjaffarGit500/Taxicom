import 'dart:ui' as ui;
 import 'package:equatable/equatable.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../../../../core/utils/common_widget.dart';

abstract class UserMarkerOlaState extends Equatable {
  @override
  List<Object?> get props => [];
}

class UserMarkerOlaInitial extends UserMarkerOlaState {}

class UserMarkerOlaUpdated extends UserMarkerOlaState {
  final Set<Marker> markers;

  UserMarkerOlaUpdated({required this.markers});

  @override
  List<Object?> get props => [markers];
}

class UserMarkerOlaCubit extends Cubit<UserMarkerOlaState> {
  UserMarkerOlaCubit() : super(UserMarkerOlaInitial());

  final Set<Marker> _markers = {};
  final Map<String, BitmapDescriptor> _iconCache = {};
  final Map<String, String> _iconPathByMarkerId = {};

  Future<void> addOrUpdateMarker(
      LatLng position,
      String title,
      String markerId,
      String iconPath,
      int size, {
        double? rotationDegrees,
      }) async {
    BitmapDescriptor? cachedIcon = _iconCache[markerId];
    if (cachedIcon == null || _iconPathByMarkerId[markerId] != iconPath) {
      Uint8List markerIcon;
      if (title.toString() == "Driver Location" && iconPath.startsWith('http')) {
        markerIcon = await createCustomMarkerImage(iconPath);
      } else {
        markerIcon = await getBytesFromAsset(iconPath, size);
      }
      cachedIcon = BitmapDescriptor.fromBytes(markerIcon);
      _iconCache[markerId] = cachedIcon;
      _iconPathByMarkerId[markerId] = iconPath;
    }
    _markers.removeWhere((marker) => marker.markerId.value == markerId);
    _markers.add(
      Marker(
        markerId: MarkerId(markerId),
        position: position,
        rotation: rotationDegrees ?? 0.0,
        anchor: const Offset(0.5, 0.5),
        infoWindow: InfoWindow(title: title),
        icon: cachedIcon,
      ),
    );
    emit(UserMarkerOlaUpdated(markers: _markers));
  }

  void removeMarker(String markerId) {
    _markers.removeWhere((marker) => marker.markerId.value == markerId);
    _iconCache.remove(markerId);
    _iconPathByMarkerId.remove(markerId);
    emit(UserMarkerOlaUpdated(markers: _markers));
  }

  Future<Uint8List> getBytesFromAsset(String path, int width) async {
    ByteData data = await rootBundle.load(path);
    ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List(),
        targetWidth: width);
    ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png))!
        .buffer
        .asUint8List();
  }

  void clear() {
    _markers.clear();
    _iconCache.clear();
    _iconPathByMarkerId.clear();
    emit(UserMarkerOlaInitial());
  }
}
