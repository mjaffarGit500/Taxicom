import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ride_on/core/services/config.dart';

class OlaApiService {
  static const String _baseUrl = "https://api.olamaps.io/places/v1";
  static const String _apiKey = "YOUR_OLA_API_KEY"; // <-- replace with your key

  /// 🔍 Autocomplete API
  static Future<List<Map<String, dynamic>>> getPlaceSuggestions(String query) async {

    final url = Uri.parse("$_baseUrl/autocomplete?input=$query&api_key=${Config.olaMapKey}");
    final response = await http.get(url);
 
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final suggestions = data["predictions"] as List<dynamic>? ?? [];
      return suggestions.map((e) => {
        "description": e["description"],
        "place_id": e["place_id"],
      }).toList();
    } else {
      throw Exception("Failed to fetch Ola place suggestions");
    }
  }

  /// 📍 Get place details (lat/lng)
  static Future<Map<String, dynamic>?> getPlaceDetails(String placeId) async {
    final url = Uri.parse("$_baseUrl/details?place_id=$placeId&api_key=${Config.olaMapKey}");
    final response = await http.get(url);
 
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final location = data["result"]["geometry"]["location"];
      return {
        "lat": location["lat"],
        "lng": location["lng"],
        "address": data["result"]["formatted_address"],
      };
    } else {
      throw Exception("Failed to fetch Ola place details");
    }
  }

  /// 🧭 Reverse Geocode
  static Future<String?> getAddressFromLatLng(double lat, double lng) async {
    final url = Uri.parse("https://api.olamaps.io/places/v1/reverse?lat=$lat&lon=$lng&api_key=${Config.olaMapKey}");
    final response = await http.get(url);
 
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data["results"]?[0]?["formatted_address"];
    }
    return null;
  }
}
