// ignore_for_file: use_build_context_synchronously

import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on/presentation/cubits/profile/edit_profile_cubit.dart';

import '../../core/extensions/workspace.dart';
import '../../core/services/data_store.dart';
import '../../data/repositories/profile_repository.dart';
import '../../domain/entities/general_data.dart';

abstract class GeneralState extends Equatable {
  @override
  List<Object?> get props => [];
}

class GeneralInitial extends GeneralState {}

class GeneralLoading extends GeneralState {}

class GeneralSuccess extends GeneralState {
  final GeneralDataModel generalDataModel;

  GeneralSuccess(this.generalDataModel);

  @override
  List<Object?> get props => [generalDataModel];
}

class GeneralFailed extends GeneralState {
  final String error;

  GeneralFailed(this.error);

  @override
  List<Object?> get props => [error];
}

class GeneralCubit extends Cubit<GeneralState> {
  final ProfileRepository repositories;

  GeneralCubit(this.repositories) : super(GeneralInitial());

  Future<void> fetchGeneralSetting(BuildContext context) async {
    try {
      final response = await repositories.getGeneralData(postData: {});
      if (response['status'] == 200) {
        // Save full response
        box.put("generalSettings", response);

        GeneralDataModel generalModel = GeneralDataModel.fromJson(response);

        // Currency
        currency = generalModel.data?.metaData?.generalDefaultCurrency ?? "";
        box.put("currency", currency);

        // Use the root navigator context: the caller-passed context (e.g. a
        // screen popped right after calling this) may already be
        // deactivated by the time this await resolves.
        final rootContext = navigatorKey.currentContext!;

        // Existing cubits updates
        rootContext
            .read<FirebaseUpdateIntervalCubit>()
            .update(generalModel.data?.metaData?.firebaseUpdateInterval ?? "");
        rootContext.read<LocationAccuracyThresholdCubit>().update(
            generalModel.data?.metaData?.locationAccuracyThreshold ?? "3");
        rootContext.read<BackgroundLocationIntervalCubit>().update(
            generalModel.data?.metaData?.backgroundLocationInterval ?? "");
        rootContext
            .read<UseGoogleBeforePickupCubit>()
            .update(generalModel.data?.metaData?.useGoogleBeforePickup ?? "");
        rootContext
            .read<DriverSearchIntervalCubit>()
            .update(generalModel.data?.metaData?.driverSearchInterval ?? "60");
        rootContext
            .read<UseGoogleAfterPickupCubit>()
            .update(generalModel.data?.metaData?.useGoogleAfterPickup ?? "");
        rootContext.read<UseGoogleSourceDestination>().update(
            generalModel.data?.metaData?.useGoogleSourceDestination ?? "");
        rootContext
            .read<MinimumHitsTimeToUpdateTime>()
            .update(generalModel.data?.metaData?.minimumHitsTime ?? "");
        rootContext
            .read<LastActiveApp>()
            .update(generalModel.data?.metaData?.lastActiveApp ?? "");

        // ====================== STATIC PAGES ======================
        final staticPagesList = generalModel.data?.metaData?.staticPages ?? [];

        // Save to box
        box.put(
          "staticPages",
          staticPagesList.map((page) => page.toJson()).toList(),
        );

        // Update Cubit
        rootContext.read<StaticPagesCubit>().update(staticPagesList);
        // ==========================================================

        box.put("backgroundUpdatedLocation",
            rootContext.read<BackgroundLocationIntervalCubit>().state.value);
        box.put("firebaseUpdatedLocation",
            rootContext.read<FirebaseUpdateIntervalCubit>().state.value);

        updateMapTypeFromMetaData(
          metaData: generalModel.data?.metaData,
          mapTypeCubit: rootContext.read<MapTypeCubit>(),
        );

        emit(GeneralSuccess(generalModel));
      } else {
        emit(GeneralFailed(response['error'] ?? "Something went wrong"));
      }
    } catch (e) {
      emit(GeneralFailed("Something went wrong"));
    }
  }
}

// ============================================================
// Simple State
// ============================================================

abstract class SimpleState<T> extends Equatable {
  final T value;
  const SimpleState(this.value);

  @override
  List<Object?> get props => [value];
}

class SimpleInitial<T> extends SimpleState<T> {
  const SimpleInitial(super.value);
}

// ============================================================
// Existing Cubits
// ============================================================

class FirebaseUpdateIntervalCubit extends Cubit<SimpleState<String?>> {
  FirebaseUpdateIntervalCubit() : super(const SimpleInitial(null));

  void update(String? val) => emit(SimpleInitial(val));
}

class LocationAccuracyThresholdCubit extends Cubit<SimpleState<String?>> {
  LocationAccuracyThresholdCubit() : super(const SimpleInitial(null));

  void update(String? val) => emit(SimpleInitial(val));
}

class BackgroundLocationIntervalCubit extends Cubit<SimpleState<String?>> {
  BackgroundLocationIntervalCubit() : super(const SimpleInitial(null));

  void update(String? val) => emit(SimpleInitial(val));
}

class DriverSearchIntervalCubit extends Cubit<SimpleState<String?>> {
  DriverSearchIntervalCubit() : super(const SimpleInitial(null));

  void update(String? val) => emit(SimpleInitial(val));
}

class UseGoogleBeforePickupCubit extends Cubit<SimpleState<String?>> {
  UseGoogleBeforePickupCubit() : super(const SimpleInitial(null));

  void update(String? val) => emit(SimpleInitial(val));
}

class UseGoogleAfterPickupCubit extends Cubit<SimpleState<String?>> {
  UseGoogleAfterPickupCubit() : super(const SimpleInitial(null));

  void update(String? val) => emit(SimpleInitial(val));
}

class MinimumHitsTimeToUpdateTime extends Cubit<SimpleState<String?>> {
  MinimumHitsTimeToUpdateTime() : super(const SimpleInitial(null));

  void update(String? val) => emit(SimpleInitial(val));
}

class UseGoogleSourceDestination extends Cubit<SimpleState<String?>> {
  UseGoogleSourceDestination() : super(const SimpleInitial(null));

  void update(String? val) => emit(SimpleInitial(val));
}

class LastActiveApp extends Cubit<SimpleState<String?>> {
  LastActiveApp() : super(const SimpleInitial(null));

  void update(String? val) => emit(SimpleInitial(val));
}

class ServiceTypeId extends Cubit<SimpleState<String?>> {
  ServiceTypeId() : super(const SimpleInitial(null));

  void update(String? val) => emit(SimpleInitial(val));
}

// ============================================================
// NEW: StaticPagesCubit
// ============================================================

class StaticPagesCubit extends Cubit<SimpleState<List<StaticPage>>> {
  StaticPagesCubit() : super(SimpleInitial(_loadFromBox()));

  /// Load from box when cubit is created
  static List<StaticPage> _loadFromBox() {
    try {
      final rawList = box.get("staticPages");
      if (rawList != null && rawList is List) {
        return rawList
            .map((e) => StaticPage.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      }
    } catch (e) {
    }
    return [];
  }

  void update(List<StaticPage> pages) {
    // Also keep box updated
    box.put("staticPages", pages.map((e) => e.toJson()).toList());
    emit(SimpleInitial(pages));
  }

  /// Helper method if you want to clear
  void clear() {
    box.delete("staticPages");
    emit(const SimpleInitial([]));
  }
}