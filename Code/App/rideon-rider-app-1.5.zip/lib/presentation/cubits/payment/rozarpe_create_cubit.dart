import 'package:equatable/equatable.dart';

import 'package:flutter/cupertino.dart';

import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:ride_on/data/repositories/payment_repository.dart';

abstract class CreateRazorpayPaymentState extends Equatable {
  @override
  List<Object?> get props => [];
}

class CreateRazorpayPaymentInitial extends CreateRazorpayPaymentState {}

class CreateRazorpayPaymentLoading extends CreateRazorpayPaymentState {}

class CreateRazorpayPaymentSuccess extends CreateRazorpayPaymentState {
  final Map<String, dynamic> paymentData;

  CreateRazorpayPaymentSuccess(this.paymentData);

  @override
  List<Object?> get props => [paymentData];
}

class CreateRazorpayPaymentFailure extends CreateRazorpayPaymentState {
  final String message;

  CreateRazorpayPaymentFailure(this.message);

  @override
  List<Object?> get props => [message];
}

class CreateRazorpayPaymentCubit extends Cubit<CreateRazorpayPaymentState> {
  final PaymentRepository paymentRepository;

  CreateRazorpayPaymentCubit(this.paymentRepository)
      : super(CreateRazorpayPaymentInitial());

  Future<void> createPayment({
    required BuildContext context,
    required String bookingId,
  }) async {
    try {
      emit(CreateRazorpayPaymentLoading());

      final response = await paymentRepository.createRozerPePayment(postData: {
        "booking_id": bookingId,
      });

      if (response["status"] == 200) {
        emit(CreateRazorpayPaymentSuccess(response["data"]));
      } else {
        emit(CreateRazorpayPaymentFailure(
            response["message"] ?? "Something went wrong"));
      }
    } catch (e) {
      emit(CreateRazorpayPaymentFailure(e.toString()));
    }
  }

  void reset() {
    emit(CreateRazorpayPaymentInitial());
  }
}
