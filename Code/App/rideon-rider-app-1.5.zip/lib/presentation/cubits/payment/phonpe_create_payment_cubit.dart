import 'package:equatable/equatable.dart';

import 'package:flutter/cupertino.dart';

import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:ride_on/data/repositories/payment_repository.dart';

abstract class CreatePhonepePaymentState extends Equatable {
  @override
  List<Object?> get props => [];
}

class CreatePhonepePaymentInitial extends CreatePhonepePaymentState {}

class CreatePhonepePaymentLoading extends CreatePhonepePaymentState {}

class CreatePhonepePaymentSuccess extends CreatePhonepePaymentState {
  final Map<String, dynamic> paymentData;

  CreatePhonepePaymentSuccess(this.paymentData);

  @override
  List<Object?> get props => [paymentData];
}

class CreatePhonepePaymentFailure extends CreatePhonepePaymentState {
  final String message;

  CreatePhonepePaymentFailure(this.message);

  @override
  List<Object?> get props => [message];
}

class CreatePhonepePaymentCubit extends Cubit<CreatePhonepePaymentState> {
  final PaymentRepository paymentRepository;

  CreatePhonepePaymentCubit(this.paymentRepository)
      : super(CreatePhonepePaymentInitial());

  Future<void> createPayment({
    required BuildContext context,
    required String bookingId,
  }) async {
    try {
      emit(CreatePhonepePaymentLoading());

      final response = await paymentRepository.createPhonePePayment(postData: {
        "booking_id": bookingId,
      });

      if (response["status"] == 200) {
        emit(CreatePhonepePaymentSuccess(response["data"]));
      } else {
        emit(CreatePhonepePaymentFailure(
            response["message"] ?? "Something went wrong"));
      }
    } catch (e) {
      emit(CreatePhonepePaymentFailure(e.toString()));
    }
  }

  void reset() {
    emit(CreatePhonepePaymentInitial());
  }
}
