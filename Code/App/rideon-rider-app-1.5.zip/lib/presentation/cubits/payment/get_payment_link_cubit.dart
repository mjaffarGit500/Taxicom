import 'package:equatable/equatable.dart';

import 'package:flutter/cupertino.dart';

import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:ride_on/data/repositories/payment_repository.dart';

abstract class GetPaymentLinkState extends Equatable {
  @override
  List<Object?> get props => [];
}

class GetPaymentLinkInitial extends GetPaymentLinkState {}

class GetPaymentLinkLoading extends GetPaymentLinkState {}

class GetPaymentLinkSuccess extends GetPaymentLinkState {
  final Map<String, dynamic> paymentData;

  GetPaymentLinkSuccess(this.paymentData);

  @override
  List<Object?> get props => [paymentData];
}

class GetPaymentLinkFailure extends GetPaymentLinkState {
  final String message;

  GetPaymentLinkFailure(this.message);

  @override
  List<Object?> get props => [message];
}

class GetPaymentLinkCubit extends Cubit<GetPaymentLinkState> {
  final PaymentRepository paymentRepository;

  GetPaymentLinkCubit(this.paymentRepository) : super(GetPaymentLinkInitial());
  Future<void> getPayment({
    required BuildContext context,
    required String method,
    required String bookingId,
  }) async {
    try {
      emit(GetPaymentLinkLoading());
      final response = await paymentRepository.getPaymentLink(
        postData: {
          "method": method,
        },
        bookingId: bookingId,
      );
      if (response["status"] == 200) {
        emit(GetPaymentLinkSuccess(response["data"]));
      } else {
        emit(GetPaymentLinkFailure(
            response["message"] ?? "Something went wrong"));
      }
    } catch (e) {
      emit(GetPaymentLinkFailure(e.toString()));
    }
  }
  void reset() {
    emit(GetPaymentLinkInitial());
  }
}
