// ignore_for_file: deprecated_member_use, library_private_types_in_public_api, use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ride_on/core/utils/theme/project_color.dart';
import 'package:ride_on/core/utils/theme/theme_style.dart';
import 'package:ride_on/core/utils/translate.dart';

/// App bar widgets shared across screens.
///
/// Extracted verbatim from the original `lib/core/utils/common_widget.dart`.

class CustomAppBars extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final Color backgroundColor;
  final Color? iconColor;
  final Color titleColor;
  final VoidCallback? onBackButtonPressed;
  final List<Widget>? actions;
  final double elevation;
  final bool? centerTitle;

  const CustomAppBars(
      {super.key,
      required this.title,
      required this.backgroundColor,
      this.iconColor,
      required this.titleColor,
      this.onBackButtonPressed,
      this.actions,
      this.elevation = 0.0,
      this.centerTitle});

  @override
  Widget build(BuildContext context) {
    notifires = Provider.of<ColorNotifires>(context, listen: true);
    return AppBar(
      centerTitle: true,
      backgroundColor: backgroundColor,
      surfaceTintColor: backgroundColor,
      elevation: elevation,
      leadingWidth: 85,
      leading: GestureDetector(
        onTap: onBackButtonPressed ??
            () {
              Navigator.pop(context);
            },
        child: Padding(
          padding:
              const EdgeInsets.only(left: 20, top: 8, bottom: 8, right: 20),
          child: PhysicalModel(
            color: Colors.transparent,
            shadowColor: Colors.transparent,
            elevation: 1.0,
            borderRadius: BorderRadius.circular(8),
            child: Container(
              alignment: Alignment.center,
              height: 40,
              width: 40,
              decoration: BoxDecoration(
                  color: notifires.getblackwhiteColor,
                  borderRadius: BorderRadius.circular(30)),
              child: Icon(Icons.arrow_back_ios_new,
                  color: notifires.getGrey3whiteColor),
            ),
          ),
        ),
      ),
      title: Text(title,
          style: heading2Grey1(context).copyWith(color: titleColor)),
      actions: actions,
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}

// ignore: prefer_typing_uninitialized_variables

class CustomAppBarNew extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final VoidCallback? onBackTap;
  final List<Widget>? actions;
  final bool? isCenterTitle;
  final bool? isBackButton;
  final Color? backgroundColor;
  final Color? titleColor;
  final double? fontSize;
  const CustomAppBarNew({
    super.key,
    required this.title,
    this.titleColor,
    this.onBackTap,
    this.fontSize,
    this.backgroundColor,
    this.isCenterTitle,
    this.isBackButton,
    this.actions,
  });

  @override
  Widget build(BuildContext context) {
    return AppBar(
      elevation: 0,
      surfaceTintColor: backgroundColor ?? Colors.white,
      backgroundColor: backgroundColor ?? Colors.white,
      centerTitle: isCenterTitle ?? true,
      title: Text(title.translate(context),
          style: headingBlack(context).copyWith(
              fontSize: fontSize ?? 22, color: titleColor ?? blackColor)),
      leading: isBackButton == true
          ? const SizedBox()
          : Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              child: Transform.translate(
                offset: const Offset(0, 0),
                child: InkWell(
                  onTap: onBackTap ?? () => Navigator.of(context).pop(),
                  child: Container(
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: backgroundColor ?? notifires.getbgcolor,
                          border:
                              Border.all(color: notifires.getGrey3whiteColor)),
                      child: Icon(Icons.arrow_back,
                          size: 20, color: notifires.getwhiteblackColor)),
                ),
              ),
            ),
      actions: actions ?? [],
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(56);
}
