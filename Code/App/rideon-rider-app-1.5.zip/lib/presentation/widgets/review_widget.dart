import 'package:ride_on/app/route_settings.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/presentation/cubits/location/google_map/get_poliline_using_google.dart';
import 'package:ride_on/presentation/cubits/location/google_map/set_marker_cubit.dart';
import 'package:ride_on/presentation/widgets/thanku_screen.dart';
import '../../core/utils/common_widget.dart';
import '../../core/utils/theme/project_color.dart';
import '../../core/utils/theme/theme_style.dart';
import '../cubits/book_ride_cubit.dart';
import '../cubits/realtime/get_ride_request_status_cubit.dart';
import '../cubits/realtime/ride_request_cubit.dart';
import '../cubits/review/review_cubit.dart';
import '../screens/home/item_home_screen.dart';
import 'custom_text_form_field.dart';

class CustomReviewWidget extends StatefulWidget {
  final String? bookingId;
  const CustomReviewWidget({super.key, this.bookingId});

  @override
  State<CustomReviewWidget> createState() => _CustomReviewWidgetState();
}

class _CustomReviewWidgetState extends State<CustomReviewWidget> {
  String totalTime = "";

  @override
  void initState() {
    super.initState();
    fetchTotalTime(); // Call async method from initState
  }

  Future<void> fetchTotalTime() async {
    final rideId = context.read<RideRequestCubit>().state.rideId;
    final time = await getTotalTimeFromRideRequest(rideId);

    if (time != null) {
      setState(() {
        totalTime = time;
      });
    }
  }

  Future<String?> getTotalTimeFromRideRequest(String rideId) async {
    try {
      final DatabaseReference rideRequestRef =
          FirebaseDatabase.instance.ref('ride_requests/$rideId');
      final DataSnapshot snapshot = await rideRequestRef.get();

      if (snapshot.exists) {
        final data = snapshot.value as Map<dynamic, dynamic>;

        if (data.containsKey('totalTime')) {
          final totalTime = data['totalTime']?.toString();

          return totalTime;
        } else {
          return null;
        }
      } else {
        return null;
      }
    } catch (error) {
      return null;
    }
  }

  TextEditingController textEditingReviewController = TextEditingController();
  String ratingData = "";

  static const List<String> _ratingLabels = [
    "",
    "Poor",
    "Fair",
    "Good",
    "Great",
    "Excellent",
  ];

  void _onSkip() {
    goBack();
    setState(() {
      clearAllRiderData(context);
      goToWithClear(const ItemHomeScreen());
    });
  }

  @override
  Widget build(BuildContext context) {
    final rating = int.tryParse(ratingData) ?? 0;

    return PopScope(
      canPop: false,
      child: DraggableScrollableSheet(
        initialChildSize: 0.8,
        minChildSize: 0.8,
        maxChildSize: 0.8,
        builder: (context, scrollController) {
          return Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(28),
                topRight: Radius.circular(28),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.15),
                  blurRadius: 24,
                  spreadRadius: 0,
                  offset: const Offset(0, -4),
                ),
              ],
            ),
            child: ListView(
              controller: scrollController,
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
              children: [
                Center(
                  child: Container(
                    width: 44,
                    height: 5,
                    decoration: BoxDecoration(
                      color: Colors.grey[300],
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Align(
                  alignment: Alignment.centerRight,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: _onSkip,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 7),
                      decoration: BoxDecoration(
                        color: grey6,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text("Skip".translate(context),
                              style: regular3(context).copyWith(
                                fontSize: 13,
                                color: grey2,
                                fontWeight: FontWeight.w600,
                              )),
                          const SizedBox(width: 4),
                          Icon(Icons.arrow_forward_rounded,
                              size: 15, color: grey2),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                Center(
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [themeColor, yelloColor],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                    child: BlocBuilder<RideRequestCubit, RideRequestState>(
                        builder: (context, state) {
                      return CircleAvatar(
                        radius: 42,
                        backgroundColor: Colors.white,
                        child: ClipOval(
                          child: SizedBox(
                            width: 78,
                            height: 78,
                            child: state.acceptedDriverImageUrl.isNotEmpty
                                ? myNetworkImage(
                                    state.acceptedDriverImageUrl,
                                  )
                                : Image.asset(
                                    "assets/images/drower_person.png",
                                    fit: BoxFit.cover,
                                  ),
                          ),
                        ),
                      );
                    }),
                  ),
                ),
                const SizedBox(height: 14),
                Center(
                  child: BlocBuilder<RideRequestCubit, RideRequestState>(
                      builder: (context, state) {
                    return Text(
                        state.acceptedDriverName.isNotEmpty
                            ? state.acceptedDriverName
                            : "Dennis Oliver",
                        style: regularBlack(context).copyWith(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                        ));
                  }),
                ),
                const SizedBox(height: 6),
                Center(
                  child: Text("How was your trip?".translate(context),
                      style: regular2(context).copyWith(
                        fontSize: 15,
                        color: grey2,
                      )),
                ),
                const SizedBox(height: 22),
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  decoration: BoxDecoration(
                    color: grey6,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    children: [
                      RatingBar.builder(
                        initialRating: 0,
                        minRating: 1,
                        direction: Axis.horizontal,
                        allowHalfRating: false,
                        itemCount: 5,
                        itemSize: 36,
                        glowColor: themeColor,
                        unratedColor: Colors.grey.withOpacity(0.25),
                        itemPadding:
                            const EdgeInsets.symmetric(horizontal: 4.0),
                        itemBuilder: (context, _) => Icon(
                          Icons.star_rounded,
                          color: yelloColor,
                        ),
                        onRatingUpdate: (value) {
                          final intRating = value.toInt();
                          ratingData = intRating.toString();
                          setState(() {});
                        },
                      ),
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 200),
                        child: rating > 0
                            ? Padding(
                                key: ValueKey(rating),
                                padding: const EdgeInsets.only(top: 10),
                                child: Text(
                                  _ratingLabels[rating].translate(context),
                                  style: regular3(context).copyWith(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                    color: brownColor,
                                  ),
                                ),
                              )
                            : const SizedBox.shrink(),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 22),
                Text("Add a comment".translate(context),
                    style: regular3(context).copyWith(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: grey2,
                    )),
                const SizedBox(height: 8),
                TextFieldAdvance(
                    maxlines: 4,
                    backgroundColor: grey6,
                    txt: "Add a comment for the driver ...".translate(context),
                    textEditingControllerCommon: textEditingReviewController,
                    inputType: TextInputType.text,
                    textInputAction: TextInputAction.done,
                    inputAlignment: TextAlign.start),
                const SizedBox(height: 26),
                BlocConsumer<ReviewCubit, ReviewState>(
                    builder: (context, state) {
                  final isEnabled = ratingData.isNotEmpty;
                  return SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        gradient: isEnabled
                            ? LinearGradient(
                                colors: [themeColor, yelloColor],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                              )
                            : null,
                        color: isEnabled ? null : grey4,
                        boxShadow: isEnabled
                            ? [
                                BoxShadow(
                                  color: themeColor.withOpacity(0.4),
                                  blurRadius: 14,
                                  offset: const Offset(0, 6),
                                ),
                              ]
                            : null,
                      ),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          borderRadius: BorderRadius.circular(16),
                          onTap: () {
                            if (ratingData.isEmpty) {
                              return;
                            }
                            context.read<ReviewCubit>().resetState();
                            context.read<ReviewCubit>().submitReview(
                                context: context,
                                bookingId: widget.bookingId!,
                                rating: ratingData,
                                message: textEditingReviewController.text);
                          },
                          child: Center(
                            child: Text("Submit".translate(context),
                                style: regularBlack(context).copyWith(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                  color: isEnabled ? blackColor : grey3,
                                )),
                          ),
                        ),
                      ),
                    ),
                  );
                }, listener: (context, state) {
                  if (state is ReviewLoading) {
                    Widgets.showLoader(context);
                  }
                  if (state is ReviewSuceess) {
                    Widgets.hideLoder(context);

                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ThankuScreen(
                                  rating: int.parse(ratingData),
                                  msg: textEditingReviewController.text,
                                )));
                  }
                  if (state is ReviewFailure) {
                    Widgets.hideLoder(context);
                  }
                }),
                const SizedBox(height: 20),
              ],
            ),
          );
        },
      ),
    );
  }
}

void clearAllRiderData(BuildContext context) {
  context.read<RideRequestCubit>().resetState();
  context.read<GetRideRequestPaymentCubit>().resetStatus();
  context.read<UserMarkerCubit>().clear();
  context.read<GetPolylineCubit>().resetPolylines();

  context.read<BookRideRealTimeDataBaseCubit>().resetState();

  context.read<RideRequestCubit>().removeProgressIndicator();
  context.read<RideRequestCubit>().removeRideMessage();
}
