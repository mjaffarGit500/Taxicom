// ignore: file_names
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:ride_on/app/route_settings.dart';
import 'package:ride_on/core/extensions/workspace.dart';
import 'package:ride_on/core/utils/translate.dart';
import '../../core/utils/common_widget.dart';
import '../../core/utils/theme/project_color.dart';
import '../../core/utils/theme/theme_style.dart';
import '../../domain/entities/general_data.dart';
import '../cubits/book_ride_cubit.dart';
import '../cubits/logout_cubit.dart';
import '../cubits/profile/edit_profile_cubit.dart';
import '../cubits/realtime/update_ride_request_parameter.dart';
import '../cubits/general_cubit.dart';
import '../screens/account/profile_screen.dart';
import '../screens/account/setting_screen.dart';
import '../screens/account/static_screen.dart';
import '../screens/auth/login_screen.dart';
import '../screens/history/history_screen.dart';

class MyDrawer extends StatefulWidget {
  const MyDrawer({super.key});
  @override
  State<MyDrawer> createState() => _MyDrawerState();
}

class _MyDrawerState extends State<MyDrawer> {
  @override
  void initState() {
    context.read<MyImageCubit>().updateMyImage(myImage);
    context
        .read<BookRideRealTimeDataBaseCubit>()
        .updateUserImageUrl(userImageUrl: myImage);
    context.read<UpdateRideRequestParameterCubit>().updateFirebaseUserParameter(
        rideId: context.read<BookRideRealTimeDataBaseCubit>().state.rideId,
        userParameter: {"userImageUrl": myImage});
    context.read<NameCubit>().updateName(loginModel?.data?.firstName ?? "");
    context.read<EmailCubit>().updateEmail(loginModel?.data?.email ?? "");
    super.initState();
  }

  IconData _getIconForPage(String? name) {
    final pageName = (name ?? "").toLowerCase();

    if (pageName.contains("about")) {
      return Icons.info_outline;
    } else if (pageName.contains("help") || pageName.contains("support")) {
      return Icons.help_outline;
    } else if (pageName.contains("term") || pageName.contains("condition")) {
      return Icons.description_outlined;
    } else if (pageName.contains("privacy") || pageName.contains("policy")) {
      return Icons.privacy_tip_outlined;
    } else if (pageName.contains("cancel")) {
      return Icons.cancel_outlined;
    } else {
      return Icons.article_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return ClipRRect(
      borderRadius: const BorderRadius.horizontal(right: Radius.circular(32)),
      child: Drawer(
        width: screenWidth * 0.83,
        backgroundColor: whiteColor,
        elevation: 0,
        child: SafeArea(
          child: Column(
            children: [
              _ProfileHeader(getIconForPage: _getIconForPage),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.only(top: 6, bottom: 10),
                  physics: const BouncingScrollPhysics(),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const _SectionLabel(label: "MENU"),
                      _MenuRow(
                        iconAsset: "assets/images/history_image.svg",
                        title: "History",
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => const HistoryScreen()));
                        },
                      ),
                      _MenuRow(
                        iconAsset: "assets/images/Settings.svg",
                        title: "Settings",
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => const SettingScreen()));
                        },
                      ),
                      BlocBuilder<StaticPagesCubit,
                          SimpleState<List<StaticPage>>>(
                        builder: (context, state) {
                          final pages = state.value;

                          if (pages.isEmpty) {
                            return const SizedBox.shrink();
                          }

                          return Column(
                            children: pages.map((page) {
                              return _MenuRow(
                                iconData: _getIconForPage(page.name),
                                title: page.name ?? "",
                                onTap: () {
                                  goTo(StaticScreen(
                                    name: page.name ?? "",
                                    id: page.id.toString(),
                                    isBack: true,
                                  ));
                                },
                              );
                            }).toList(),
                          );
                        },
                      ),
                      const _SectionDivider(),
                      BlocConsumer<LogoutCubit, LogoutState>(
                        listener: (context, state) {
                          if (state is LogoutFailure) {
                            showErrorToastMessage(
                                "Logout Failed: ${state.error}");
                          } else if (state is LogoutSuccess) {
                            Navigator.pushAndRemoveUntil(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => const LoginScreen()),
                              (route) => false,
                            );
                          }
                        },
                        builder: (context, state) {
                          return _MenuRow(
                            iconAsset: "assets/images/Logout.svg",
                            title: "Logout",
                            isLogout: true,
                            onTap: () {
                              showDynamicBottomSheets(
                                context,
                                title: "Logout".translate(context),
                                description: "Are you sure you want to logout?"
                                    .translate(context),
                                firstButtontxt: "Cancel".translate(context),
                                secondButtontxt: "Yes".translate(context),
                                onpressed: () => Navigator.pop(context),
                                onpressed1: () {
                                  token = "";
                                  context.read<LogoutCubit>().logout(context);
                                },
                              );
                            },
                          );
                        },
                      ),
                      const SizedBox(height: 18),
                      const _AppVersionLabel(),
                      const SizedBox(height: 8),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AppVersionLabel extends StatelessWidget {
  const _AppVersionLabel();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<PackageInfo>(
      future: PackageInfo.fromPlatform(),
      builder: (context, snapshot) {
        final info = snapshot.data;
        if (info == null) {
          return const SizedBox.shrink();
        }
        return Center(
          child: Text(
            "${"App Version".translate(context)} ${info.version}",
            style: regular3(context).copyWith(
              fontSize: 11,
              color: blackColor.withOpacity(0.35),
            ),
          ),
        );
      },
    );
  }
}

class _ProfileHeader extends StatelessWidget {
  final IconData Function(String?) getIconForPage;

  const _ProfileHeader({required this.getIconForPage});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 22),
      decoration: BoxDecoration(
        color: themeColor.withOpacity(0.06),
        borderRadius: const BorderRadius.only(
          bottomRight: Radius.circular(32),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: () => Navigator.of(context).pop(),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: whiteColor,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: blackColor.withOpacity(0.05),
                        blurRadius: 6,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Icon(Icons.arrow_back_ios_new,
                      size: 16, color: blackColor),
                ),
              ),
              Text(
                "MENU".translate(context),
                style: heading3Grey1(context).copyWith(
                  fontSize: 11,
                  letterSpacing: 1.4,
                  color: blackColor.withOpacity(0.38),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 22),
          InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: () {
              Navigator.of(context).pop();
              goTo(const EditProfile());
            },
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(2.5),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: themeColor.withOpacity(0.55),
                          width: 1.4,
                        ),
                      ),
                      child: BlocBuilder<MyImageCubit, dynamic>(
                        builder: (context, state) {
                          return myImage.isEmpty
                              ? CircleAvatar(
                                  radius: 30,
                                  backgroundColor: grey6,
                                  child: Icon(CupertinoIcons.person_fill,
                                      size: 30, color: greycolor2),
                                )
                              : SizedBox(
                                  height: 70,
                                  width: 70,
                                  child: ClipOval(
                                    child: myNetworkImage(
                                        context.read<MyImageCubit>().state),
                                  ),
                                );
                        },
                      ),
                    ),
                    Positioned(
                      right: -2,
                      bottom: -2,
                      child: Container(
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                          color: orangeColor,
                          shape: BoxShape.circle,
                          border: Border.all(color: whiteColor, width: 2),
                        ),
                        child: Icon(Icons.edit, color: whiteColor, size: 12),
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      BlocBuilder<NameCubit, dynamic>(
                        builder: (context, state) {
                          return Text(
                            context.read<NameCubit>().state,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: headingBlack(context).copyWith(
                              fontSize: 17,
                              fontWeight: FontWeight.w700,
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 3),
                      BlocBuilder<EmailCubit, dynamic>(
                        builder: (context, state) {
                          return Text(
                            context.read<EmailCubit>().state,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: regular3(context).copyWith(
                              fontSize: 12.5,
                              color: greycolor2,
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 6),
                      Text(
                        "Edit Profile".translate(context),
                        style: regular3(context).copyWith(
                          fontSize: 12,
                          color: orangeColor,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 18, 22, 8),
      child: Text(
        label.translate(context),
        style: heading3Grey1(context).copyWith(
          fontSize: 11.5,
          letterSpacing: 1.2,
          color: blackColor.withOpacity(0.35),
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

class _SectionDivider extends StatelessWidget {
  const _SectionDivider();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
      child:
          Divider(height: 1, thickness: 1, color: blackColor.withOpacity(0.06)),
    );
  }
}

class _MenuRow extends StatefulWidget {
  final String? iconAsset;
  final IconData? iconData;
  final String title;
  final VoidCallback onTap;
  final bool isLogout;

  const _MenuRow({
    this.iconAsset,
    this.iconData,
    required this.title,
    required this.onTap,
    this.isLogout = false,
  }) : assert(iconAsset != null || iconData != null);

  @override
  State<_MenuRow> createState() => _MenuRowState();
}

class _MenuRowState extends State<_MenuRow> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final Color iconContainerColor = widget.isLogout
        ? redColor.withOpacity(0.10)
        : (_pressed ? themeColor.withOpacity(0.16) : grey6);
    final Color iconColor = widget.isLogout
        ? redColor
        : (_pressed ? orangeColor : blackColor.withOpacity(0.72));
    final Color titleColor =
        widget.isLogout ? redColor : (_pressed ? orangeColor : blackColor);
    final Color rowBg = widget.isLogout
        ? redColor.withOpacity(0.055)
        : (_pressed ? themeColor.withOpacity(0.07) : Colors.transparent);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: widget.onTap,
          onHighlightChanged: (v) => setState(() => _pressed = v),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 160),
            curve: Curves.easeOut,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: rowBg,
              borderRadius: BorderRadius.circular(16),
            ),
            constraints: const BoxConstraints(minHeight: 60),
            child: Row(
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 160),
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    color: iconContainerColor,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Center(
                    child: widget.iconAsset != null
                        ? SvgPicture.asset(
                            widget.iconAsset!,
                            width: 21,
                            height: 21,
                            colorFilter:
                                ColorFilter.mode(iconColor, BlendMode.srcIn),
                          )
                        : Icon(widget.iconData, size: 22, color: iconColor),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Text(
                    widget.title.translate(context),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: heading3Grey1(context).copyWith(
                      fontSize: 15,
                      color: titleColor,
                      fontWeight:
                          widget.isLogout ? FontWeight.w600 : FontWeight.w500,
                    ),
                  ),
                ),
                if (!widget.isLogout)
                  Icon(Icons.chevron_right_rounded,
                      size: 18, color: blackColor.withOpacity(0.28)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
