import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/utils/theme/project_color.dart';
import '../../core/utils/theme/theme_style.dart';

/// A 6-box OTP input that stays backed by a single [TextEditingController],
/// so existing auto-fill (`textEditingOtpController.text = otp`), resend,
/// and verify logic elsewhere keep working untouched — this widget only
/// changes how that controller's value is displayed/edited.
class OtpBoxField extends StatefulWidget {
  final TextEditingController controller;
  final int length;
  final ValueChanged<String>? onChanged;
  final VoidCallback? onTap;

  const OtpBoxField({
    super.key,
    required this.controller,
    this.length = 6,
    this.onChanged,
    this.onTap,
  });

  @override
  State<OtpBoxField> createState() => _OtpBoxFieldState();
}

class _OtpBoxFieldState extends State<OtpBoxField> {
  late FocusNode _hiddenFocusNode;

  @override
  void initState() {
    super.initState();
    _hiddenFocusNode = FocusNode();
    widget.controller.addListener(_onControllerChanged);
  }

  void _onControllerChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onControllerChanged);
    _hiddenFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    notifires = Provider.of<ColorNotifires>(context, listen: true);
    final String value = widget.controller.text;

    return GestureDetector(
      onTap: () {
        widget.onTap?.call();
        _hiddenFocusNode.requestFocus();
      },
      child: Stack(
        children: [
          // Real input, invisible, drives keyboard/paste/backspace/autofill.
          Opacity(
            opacity: 0,
            child: SizedBox(
              height: 1,
              child: TextField(
                controller: widget.controller,
                focusNode: _hiddenFocusNode,
                keyboardType: TextInputType.number,
                autofillHints: const [AutofillHints.oneTimeCode],
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(widget.length),
                ],
                onChanged: widget.onChanged,
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(widget.length, (index) {
              final bool filled = index < value.length;
              final bool isActive = index == value.length;
              final String char = filled ? value[index] : '';

              return Padding(
                padding: EdgeInsets.only(
                    right: index == widget.length - 1 ? 0 : Dimensions.space8),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  width: Dimensions.otpBoxSize,
                  height: Dimensions.otpBoxSize,
                  decoration: BoxDecoration(
                    color: whiteColor,
                    borderRadius: BorderRadius.circular(Dimensions.radiusField),
                    border: Border.all(
                      color: isActive ? themeColor : appBorderColor,
                      width: isActive ? 1.5 : 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.03),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    char,
                    style: TextStyle(
                      fontSize: 20,
                      fontFamily: "Poppins SemiBold",
                      fontWeight: FontWeight.w600,
                      color: notifires.getwhiteblackColor,
                    ),
                  ),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }
}
