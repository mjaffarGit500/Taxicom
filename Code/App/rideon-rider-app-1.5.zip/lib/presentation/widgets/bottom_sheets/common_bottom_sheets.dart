// ignore_for_file: deprecated_member_use, library_private_types_in_public_api, use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:ride_on/core/utils/theme/project_color.dart';
import 'package:ride_on/core/utils/theme/theme_style.dart';
import 'package:ride_on/core/utils/translate.dart';

/// Modal bottom sheets shared across screens.
///
/// Extracted verbatim from the original `lib/core/utils/common_widget.dart`.

void showDynamicBottomSheets(BuildContext context,
    {required String title,
    required String description,
    required String firstButtontxt,
    required String secondButtontxt,
    required final VoidCallback onpressed,
    required final VoidCallback onpressed1}) {
  showModalBottomSheet(
    isScrollControlled: false,
    constraints:
        const BoxConstraints.expand(width: double.infinity, height: 240),
    context: context,
    builder: (context) {
      return DynamicBottomSheetContent(
        title: title,
        description: description,
        firstButtontxt: firstButtontxt,
        secondButtontxt: secondButtontxt,
        onpressed: onpressed,
        onpressed1: onpressed1,
      );
    },
  );
}

class DynamicBottomSheetContent extends StatefulWidget {
  final String title;
  final String description;
  final String firstButtontxt;
  final String secondButtontxt;
  final VoidCallback onpressed;
  final VoidCallback onpressed1;

  const DynamicBottomSheetContent(
      {super.key,
      required this.title,
      required this.description,
      required this.firstButtontxt,
      required this.secondButtontxt,
      required this.onpressed,
      required this.onpressed1});

  @override
  State<DynamicBottomSheetContent> createState() =>
      _DynamicBottomSheetContentState();
}

class _DynamicBottomSheetContentState extends State<DynamicBottomSheetContent> {
  bool isCancelSelected = true; // Initially, the "Cancel" button is selected
  bool isDeleteSelected = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
          color: notifires.getblackwhiteColor,
          borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(0), topRight: Radius.circular(0))),
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Flexible(
              child: Text(widget.title.translate(context),
                  style: heading2Grey1(context).copyWith())),
          const SizedBox(height: 20),
          Divider(
            height: 1,
            color: notifires.getGrey3whiteColor,
          ),
          const SizedBox(height: 15),
          Flexible(
              child: Text(widget.description.translate(context),
                  style: heading3Grey1(context))),
          const SizedBox(height: 30),
          Expanded(
            child: SizedBox(
              width: double.infinity,
              // height: 20,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Flexible(
                    child: ConstrainedBox(
                      constraints: BoxConstraints.expand(
                          height: 60,
                          width: MediaQuery.of(context).size.width * 0.38),
                      child: ElevatedButton(
                        onPressed: widget.onpressed,
                        style: ElevatedButton.styleFrom(
                          elevation: 0,
                          backgroundColor: notifires.getBoxColor,
                          shape: RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.circular(Dimensions.radiusLarge),
                          ),
                        ),
                        child: Text(widget.firstButtontxt.translate(context),
                            style: heading3(context)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 25),
                  Flexible(
                    child: ConstrainedBox(
                      constraints: BoxConstraints.expand(
                          height: 60,
                          width: MediaQuery.of(context).size.width * 0.38),
                      child: ElevatedButton(
                        onPressed: widget.onpressed1,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: themeColor,
                          // onPrimary: WhiteColor, // Customize the text color
                          shape: RoundedRectangleBorder(
                            side: BorderSide(width: 1.0, color: themeColor),
                            borderRadius:
                                BorderRadius.circular(Dimensions.radiusLarge),
                          ),
                        ),
                        child: Text(widget.secondButtontxt.translate(context),
                            style: heading3(context)
                                .copyWith(color: Colors.black)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}

void showCancelRideBottomSheet({
  required BuildContext context,
  required VoidCallback onCancelRide,
  required VoidCallback onKeepRide,
}) {
  showModalBottomSheet(
    context: context,
    backgroundColor: notifires.getbgcolor,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
    ),
    builder: (BuildContext context) {
      return Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Icon(Icons.warning_amber, color: blackColor, size: 35),
            const SizedBox(height: 10),
            Text(
              "Are you sure you want to cancel your ride?",
              style: heading2Grey1(context),
              textAlign: TextAlign.center,
            ),
            Text(
              "If you cancel now, your current ride request will be aborted.",
              style: regular(context),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                  onTap: onCancelRide, // Use callback for Cancel Ride
                  child: Container(
                    alignment: Alignment.center,
                    height: 50,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    decoration: BoxDecoration(
                      color: blackColor,
                      borderRadius: BorderRadius.circular(40),
                    ),
                    child: Text(
                      "Cancel Ride",
                      style: regular2(context).copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 25),
                InkWell(
                  onTap: onKeepRide, // Use callback for Keep Ride
                  child: Container(
                    alignment: Alignment.center,
                    height: 50,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    decoration: BoxDecoration(
                      color: notifires.getBoxColor,
                      borderRadius: BorderRadius.circular(40),
                    ),
                    child: Text(
                      "Keep Ride",
                      style: regular2(context).copyWith(
                        color: grey1,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
          ],
        ),
      );
    },
  );
}

Widget buildLocationRow({
  required IconData icon,
  required Color color,
  required Color bgColor,
  required String text,
  required BuildContext context,
}) {
  return Row(
    children: [
      ClipOval(
        child: Container(
          height: 25,
          width: 25,
          color: bgColor,
          child: Icon(icon, color: color, size: 16),
        ),
      ),
      const SizedBox(width: 10),
      Expanded(
        child: Text(
          text,
          style: regular(context).copyWith(color: grey1),
        ),
      ),
    ],
  );
}
