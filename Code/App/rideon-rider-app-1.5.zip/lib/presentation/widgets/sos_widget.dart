import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on/core/utils/theme/project_color.dart';
import 'package:ride_on/core/utils/theme/theme_style.dart';
import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/domain/entities/sos_data.dart';
import 'package:ride_on/presentation/cubits/sos_cubit.dart';
import 'package:url_launcher/url_launcher.dart';

class SosButtonWidget extends StatefulWidget {
  const SosButtonWidget({super.key});

  @override
  State<SosButtonWidget> createState() => _SosButtonWidgetState();
}

class _SosButtonWidgetState extends State<SosButtonWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);

    _animation = Tween<double>(begin: 1.0, end: 1.25).animate(
      CurvedAnimation(parent: _controller, curve: Curves.fastOutSlowIn),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _makePhoneCall(String number) async {
    final Uri launchUri = Uri(scheme: 'tel', path: number);
    await launchUrl(launchUri);
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Padding(
          padding: const EdgeInsets.only(right: 18, bottom: 18, left: 15),
          child: ScaleTransition(
            scale: _animation,
            child: GestureDetector(
              onTap: () {
                context.read<SosCubit>().getSosList(context);
                _showSosDialog(context);
              },
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xffFF3B30), Color(0xffFF5E57)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.redAccent.withValues(alpha: .50),
                      blurRadius: 25,
                      spreadRadius: 3,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.sos_rounded,
                  color: Colors.white,
                  size: 20,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _showSosDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) {
        final screenH = MediaQuery.sizeOf(context).height;
        final isSmall = screenH < 700;
        final iconSize = isSmall ? 38.0 : 55.0;
        final iconPad = isSmall ? 10.0 : 12.0;
        final vPad = isSmall ? 18.0 : 28.0;
        final hPad = isSmall ? 16.0 : 22.0;
        final gap1 = isSmall ? 10.0 : 16.0;
        final gap2 = isSmall ? 4.0 : 6.0;
        final gap3 = isSmall ? 14.0 : 22.0;
        final gap4 = isSmall ? 12.0 : 20.0;

        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: EdgeInsets.symmetric(
            horizontal: isSmall ? 16 : 20,
            vertical: isSmall ? 16 : 24,
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(isSmall ? 24 : 30),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
              child: Container(
                constraints: BoxConstraints(
                  maxHeight: screenH * 0.82,
                ),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: .92),
                  borderRadius: BorderRadius.circular(isSmall ? 24 : 30),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withValues(alpha: 0.2),
                        blurRadius: 20)
                  ],
                ),
                padding: EdgeInsets.symmetric(horizontal: hPad, vertical: vPad),
                child: BlocBuilder<SosCubit, SosState>(
                  builder: (context, state) {
                    if (state is SosLoading) {
                      return SizedBox(
                        height: isSmall ? 140 : 200,
                        child: Center(
                          child: CircularProgressIndicator(
                            color: Colors.redAccent.shade200,
                          ),
                        ),
                      );
                    }

                    if (state is SosFailed) {
                      return _errorDialog(context, state.error);
                    }

                    List<Sos> sosList = [];
                    if (state is SosSuccess) {
                      sosList = state.sosData.sos ?? [];
                    }

                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          padding: EdgeInsets.all(iconPad),
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              colors: [Color(0xffFF3B30), Color(0xffFF6B6B)],
                            ),
                          ),
                          child: Icon(Icons.sos_rounded,
                              size: iconSize, color: Colors.white),
                        ),
                        SizedBox(height: gap1),
                        Text(
                          "Emergency Support".translate(context),
                          style: heading1Grey1(context).copyWith(
                            color: redColor,
                            fontSize: isSmall ? 20 : null,
                          ),
                        ),
                        SizedBox(height: gap2),
                        Text(
                          "Choose a contact to call instantly"
                              .translate(context),
                          style: regular2(context).copyWith(
                            fontSize: isSmall ? 12 : null,
                          ),
                        ),
                        SizedBox(height: gap3),
                        if (sosList.isEmpty)
                          Text(
                            "No SOS contacts available!".translate(context),
                            style: regular2(context),
                          )
                        else
                          Flexible(
                            child: SingleChildScrollView(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: sosList.map((e) {
                                  return _modernSosCard(
                                    name: e.name ?? "Unknown",
                                    number: e.sosNumber ?? "",
                                    isSmall: isSmall,
                                    onCall: () {
                                      Navigator.pop(context);
                                      _makePhoneCall(e.sosNumber ?? "");
                                    },
                                  );
                                }).toList(),
                              ),
                            ),
                          ),
                        SizedBox(height: gap4),
                        _cancelButton(context, isSmall: isSmall),
                      ],
                    );
                  },
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _errorDialog(BuildContext context, String msg) {
    return SizedBox(
      height: 200,
      child: Center(
        child: Text(
          msg,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
        ),
      ),
    );
  }

  Widget _modernSosCard({
    required String name,
    required String number,
    required VoidCallback onCall,
    bool isSmall = false,
  }) {
    final cardPad = isSmall ? 12.0 : 16.0;
    final iconPad = isSmall ? 10.0 : 13.0;
    final callIconSize = isSmall ? 20.0 : 24.0;
    final gap = isSmall ? 10.0 : 14.0;
    final arrowSize = isSmall ? 14.0 : 16.0;
    final bottomMargin = isSmall ? 10.0 : 14.0;

    return Container(
      margin: EdgeInsets.only(bottom: bottomMargin),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(isSmall ? 14 : 18),
        color: whiteColor,
        boxShadow: [
          BoxShadow(
            color: blackColor.withValues(alpha: .07),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(isSmall ? 14 : 18),
        onTap: onCall,
        child: Padding(
          padding: EdgeInsets.all(cardPad),
          child: Row(
            children: [
              Container(
                padding: EdgeInsets.all(iconPad),
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [Color(0xffFF5A5A), Color(0xffFF7E7E)],
                  ),
                ),
                child: Icon(Icons.call, color: whiteColor, size: callIconSize),
              ),
              SizedBox(width: gap),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: heading3(context).copyWith(
                        color: blackColor,
                        fontSize: isSmall ? 13 : null,
                      ),
                    ),
                    SizedBox(height: isSmall ? 2 : 4),
                    Text(
                      number,
                      style: regular(context).copyWith(
                        fontSize: isSmall ? 12 : null,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.arrow_forward_ios_rounded,
                size: arrowSize,
                color: blackColor,
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _cancelButton(BuildContext context, {bool isSmall = false}) {
    return SizedBox(
      width: double.infinity,
      child: TextButton(
        onPressed: () => Navigator.pop(context),
        style: TextButton.styleFrom(
          backgroundColor: Colors.grey.shade200,
          padding: EdgeInsets.symmetric(
            horizontal: isSmall ? 24 : 40,
            vertical: isSmall ? 10 : 12,
          ),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(isSmall ? 12 : 14)),
        ),
        child: Text(
          "Close".translate(context),
          style: heading3(context).copyWith(
            fontSize: isSmall ? 13 : null,
          ),
        ),
      ),
    );
  }
}
