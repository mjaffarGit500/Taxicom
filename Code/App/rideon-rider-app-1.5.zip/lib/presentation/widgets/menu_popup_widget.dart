import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/presentation/cubits/profile/edit_profile_cubit.dart';
import 'package:ride_on/presentation/screens/search_and_ride/google_map/search_map_screen.dart';
import 'package:ride_on/presentation/screens/search_and_ride/map_box/search_map_screen_map_box.dart';
import 'package:ride_on/presentation/screens/search_and_ride/ola_map/search_map_screen_ola.dart';
import 'package:ride_on/presentation/screens/search_and_ride/osm/search_map_screen_osm.dart';
import '../../core/utils/theme/project_color.dart';

Widget _mapMenuIcon(IconData icon, Color color) {
  return Container(
    height: 28,
    width: 28,
    decoration: BoxDecoration(
      color: color.withValues(alpha: .12),
      shape: BoxShape.circle,
    ),
    child: Icon(icon, color: color, size: 14),
  );
}

Widget selectWithLocation({BuildContext? context}) {
  return PopupMenuButton<int>(
      color: whiteColor,
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      itemBuilder: (context) => [
            PopupMenuItem(
              height: 40,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
              onTap: () async {
                FocusScope.of(context).unfocus();
                final mapCubit = context.read<MapTypeCubit>().state;
                if (mapCubit.selectedMap.toString() == "google") {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          const SearchMapScreen(checkStatus: true),
                    ),
                  );
                } else if (mapCubit.selectedMap.toString() == "osm") {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          const SearchMapScreenOSM(checkStatus: true),
                    ),
                  );
                } else if (mapCubit.selectedMap.toString() == "mapBox") {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          const SearchMapScreenMapbox(checkStatus: true),
                    ),
                  );
                } else if (mapCubit.selectedMap.toString() == "ola") {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          const SearchMapScreenOla(checkStatus: true),
                    ),
                  );
                }
              },
              child: Row(
                children: [
                  _mapMenuIcon(Icons.location_on_rounded, Colors.green),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Text(
                      "Select Pickup Location".translate(context),
                      style: const TextStyle(
                        color: Color(0xFF1E2530),
                        fontWeight: FontWeight.w600,
                        fontSize: 12.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            PopupMenuItem(
              height: 40,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
              onTap: () async {
                FocusScope.of(context).unfocus();
                final mapCubit = context.read<MapTypeCubit>().state;
                if (mapCubit.selectedMap.toString() == "google") {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          const SearchMapScreen(checkStatus: false),
                    ),
                  );
                } else if (mapCubit.selectedMap.toString() == "osm") {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          const SearchMapScreenOSM(checkStatus: false),
                    ),
                  );
                } else if (mapCubit.selectedMap.toString() == "mapBox") {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          const SearchMapScreenMapbox(checkStatus: false),
                    ),
                  );
                } else if (mapCubit.selectedMap.toString() == "ola") {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          const SearchMapScreenOla(checkStatus: false),
                    ),
                  );
                }
              },
              child: Row(
                children: [
                  _mapMenuIcon(Icons.flag_rounded, Colors.redAccent),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Text(
                      "Select Drop-off Location".translate(context),
                      style: const TextStyle(
                        color: Color(0xFF1E2530),
                        fontWeight: FontWeight.w600,
                        fontSize: 12.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
      offset: const Offset(40, 44),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              themeColor,
              themeColor.withValues(alpha: .85),
            ],
          ),
          borderRadius: BorderRadius.circular(22),
          boxShadow: [
            BoxShadow(
              color: themeColor.withValues(alpha: .45),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Container(
            height: 20,
            width: 20,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: .35),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.map_rounded,
              color: Color(0xFF3A2900),
              size: 12,
            ),
          ),
          const SizedBox(width: 7),
          Text("Select From Map".translate(context!),
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: Color(0xFF3A2900),
                letterSpacing: 0.1,
              )),
        ]),
      ));
}
