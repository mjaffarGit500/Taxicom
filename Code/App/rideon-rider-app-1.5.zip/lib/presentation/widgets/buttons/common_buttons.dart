// ignore_for_file: deprecated_member_use, library_private_types_in_public_api, use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:ride_on/core/utils/theme/project_color.dart';
import 'package:ride_on/core/utils/theme/theme_style.dart';
import 'package:ride_on/core/utils/translate.dart';

import '../../cubits/localizations_cubit.dart';



class CustomsButtons extends StatelessWidget {
  final String text;
  final Color? textColor;
  final Color backgroundColor;
  final IconData? icon;
  final VoidCallback onPressed;

  const CustomsButtons(
      {super.key,
      required this.text,
      required this.backgroundColor,
      required this.onPressed,
      this.icon,
      this.textColor});

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints:
          const BoxConstraints.expand(width: double.infinity, height: 50.0),
      child: ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
              padding:
                  const EdgeInsets.only(left: 5, right: 5, top: 10, bottom: 10),
              backgroundColor: backgroundColor,
              elevation: 0,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8))),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                text.translate(context),
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
                style: largeHeadingMedium.copyWith(
                    color: textColor,
                    fontSize: 14,
                    fontWeight: FontWeight.normal),
              ),
              if (icon != null) const SizedBox(width: 10),
              if (icon != null) Icon(icon, color: bgcolor),
            ],
          )),
    );
  }
}

Widget socialButton(String iconPath, VoidCallback onTap) {
  return InkWell(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 10,
            spreadRadius: 1,
          ),
        ],
      ),
      child: SvgPicture.asset(iconPath, height: 26),
    ),
  );
}

 
Widget languageButton({
  required VoidCallback onTap,
}) {
  return InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(8),
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 10),
      decoration: BoxDecoration(
        border: Border.all(color: themeColor.withOpacity(0.4)),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.language, color: themeColor, size: 18),
          const SizedBox(width: 6),
          BlocBuilder<LCodeCubit, String>(builder: (context, state) {
            return Text(
              state.toUpperCase(),
              style: TextStyle(
                color: themeColor,
                fontWeight: FontWeight.w600,
              ),
            );
          }),
          Icon(Icons.keyboard_arrow_down_rounded, color: themeColor, size: 18),
        ],
      ),
    ),
  );
}
