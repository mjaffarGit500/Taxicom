import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:ride_on/core/utils/common_widget.dart';
import 'package:ride_on/core/utils/theme/project_color.dart';
import 'package:ride_on/core/utils/theme/theme_style.dart';
import 'package:ride_on/core/utils/translate.dart';

/// Shared spacing scale for the auth flow (Sign In / Sign Up / OTP), so all
/// three screens use identical vertical rhythm instead of ad-hoc values.
class AuthSpacing {
  static const double xs = 4;
  static const double small = 8;
  static const double medium = 12;
  static const double large = 16;
  static const double xl = 20;
  static const double xxl = 24;
  static const double xxxl = 32;
}

/// Shared metrics for the field/button family so every input and CTA across
/// the three auth screens has identical height/radius.
class AuthMetrics {
  static const double fieldRadius = 16;
  static const double buttonHeight = 56;
  static const double buttonRadius = 16;
  static const double maxContentWidth = 460;
}

/// Compact rounded-square brand mark used at the top of every auth screen,
/// replacing the old oversized circular logo treatment with a smaller,
/// premium card-style presentation. Wraps the existing [commonlyUserLogo]
/// asset -- the logo itself is never replaced, only its container.
class AuthBrandMark extends StatelessWidget {
  final double size;

  const AuthBrandMark({super.key, this.size = 72});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: size,
      width: size,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: notifires.getIsDark ? boxcolor : whiteColor,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: themeColor.withOpacity(notifires.getIsDark ? 0.12 : 0.22),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: FittedBox(fit: BoxFit.contain, child: commonlyUserLogo()),
    );
  }
}

/// Compact logo + title + subtitle block reused by Sign In, Sign Up and OTP,
/// so the top of every auth screen looks and behaves identically.
class AuthHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget logo;
  final double logoHeight;
  final double topSpacerFraction;

  const AuthHeader({
    super.key,
    required this.title,
    required this.subtitle,
    required this.logo,
    this.logoHeight = 60,
    this.topSpacerFraction = 0.07,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        SizedBox(
            height: MediaQuery.of(context).size.height * topSpacerFraction),
        AuthBrandMark(size: logoHeight + 12),
        const SizedBox(height: AuthSpacing.large),
        Text(
          title.translate(context),
          textAlign: TextAlign.center,
          style: heading1(context).copyWith(
            color: notifires.getwhiteblackColor,
            fontSize: 26,
            fontWeight: FontWeight.w700,
            letterSpacing: -0.3,
          ),
        ),
        const SizedBox(height: AuthSpacing.small),
        Text(
          subtitle.translate(context),
          textAlign: TextAlign.center,
          style: regular2(context).copyWith(
            color: notifires.getGrey2whiteColor,
            fontSize: 14,
            height: 1.3,
          ),
        ),
      ],
    );
  }
}

/// The single primary call-to-action button shape used by all three auth
/// screens (Sign In / Sign Up / Continue). Adds a subtle press-scale
/// animation on top of the existing brand-yellow, rounded CTA shape so the
/// button feels responsive without changing its onPressed contract.
class AuthPrimaryButton extends StatefulWidget {
  final String text;
  final VoidCallback onPressed;

  const AuthPrimaryButton({
    super.key,
    required this.text,
    required this.onPressed,
  });

  @override
  State<AuthPrimaryButton> createState() => _AuthPrimaryButtonState();
}

class _AuthPrimaryButtonState extends State<AuthPrimaryButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapCancel: () => setState(() => _pressed = false),
      onTapUp: (_) => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.98 : 1,
        duration: const Duration(milliseconds: 120),
        curve: Curves.easeOut,
        child: SizedBox(
          height: AuthMetrics.buttonHeight,
          width: double.infinity,
          child: ElevatedButton(
            onPressed: widget.onPressed,
            style: ElevatedButton.styleFrom(
              backgroundColor: themeColor,
              elevation: 0,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(AuthMetrics.buttonRadius),
              ),
            ),
            child: Text(
              widget.text.translate(context),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
              style: regular2(context).copyWith(
                color: blackColor,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// "── or continue with ──" divider, identical across all three auth screens.
class AuthDivider extends StatelessWidget {
  final String label;

  const AuthDivider({super.key, this.label = "or continue with"});

  @override
  Widget build(BuildContext context) {
    final lineColor = notifires.getGrey4whiteColor.withOpacity(0.5);
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Expanded(child: Container(height: 1, color: lineColor)),
        const SizedBox(width: AuthSpacing.medium),
        Text(
          label.translate(context),
          style: regular(context).copyWith(
            color: notifires.getGrey3whiteColor,
            fontSize: 12.5,
          ),
        ),
        const SizedBox(width: AuthSpacing.medium),
        Expanded(child: Container(height: 1, color: lineColor)),
      ],
    );
  }
}

/// One slim, bordered social-login button shape shared by Google and Apple
/// across all three auth screens.
class AuthSocialButton extends StatelessWidget {
  final String iconPath;
  final VoidCallback onTap;

  const AuthSocialButton({
    super.key,
    required this.iconPath,
    required this.onTap,
  });

  static const double _height = 52;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(AuthMetrics.buttonRadius),
      child: Container(
        height: _height,
        width: _height,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color:
              notifires.getIsDark ? Colors.white.withOpacity(0.04) : whiteColor,
          borderRadius: BorderRadius.circular(AuthMetrics.buttonRadius),
          border: Border.all(
            color: notifires.getGrey4whiteColor.withOpacity(0.4),
          ),
        ),
        child: SvgPicture.asset(iconPath, height: 20),
      ),
    );
  }
}

/// Row of social-login buttons (Google always, Apple only on iOS), laid out
/// identically wherever it's used across the auth flow.
class AuthSocialRow extends StatelessWidget {
  final VoidCallback onGoogleTap;
  final VoidCallback onAppleTap;

  const AuthSocialRow({
    super.key,
    required this.onGoogleTap,
    required this.onAppleTap,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        AuthSocialButton(
          iconPath: "assets/images/google_icon.svg",
          onTap: onGoogleTap,
        ),
        if (Platform.isIOS) const SizedBox(width: AuthSpacing.medium),
        if (Platform.isIOS)
          AuthSocialButton(
            iconPath: "assets/images/apple_icon.svg",
            onTap: onAppleTap,
          ),
      ],
    );
  }
}

/// "Don't have an account? Sign Up" style bottom switch-link, identical
/// across Sign In / Sign Up.
class AuthBottomLink extends StatelessWidget {
  final String question;
  final String actionText;
  final VoidCallback onTap;

  const AuthBottomLink({
    super.key,
    required this.question,
    required this.actionText,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          question.translate(context),
          style: regular(context).copyWith(
            color: notifires.getGrey2whiteColor,
            fontSize: 13.5,
          ),
        ),
        const SizedBox(width: 5),
        InkWell(
          onTap: onTap,
          child: Text(
            actionText.translate(context),
            style: regular(context).copyWith(
              color: themeColor,
              fontSize: 13.5,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    );
  }
}

/// Subtle, low-opacity decorative background SVG shared by all auth screens
/// -- kept behind content, never interfering with input/keyboard.
class AuthBackgroundDecoration extends StatelessWidget {
  final String assetPath;
  final Alignment alignment;
  final double opacity;

  const AuthBackgroundDecoration({
    super.key,
    required this.assetPath,
    this.alignment = Alignment.topLeft,
    this.opacity = 0.35,
  });

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: alignment == Alignment.topLeft || alignment == Alignment.bottomLeft
          ? 0
          : null,
      right:
          alignment == Alignment.topRight || alignment == Alignment.bottomRight
              ? 0
              : null,
      top: alignment == Alignment.topLeft || alignment == Alignment.topRight
          ? 0
          : null,
      bottom: alignment == Alignment.bottomLeft ||
              alignment == Alignment.bottomRight
          ? -20
          : null,
      child: IgnorePointer(
        child: Opacity(
          opacity: opacity,
          child: SvgPicture.asset(assetPath),
        ),
      ),
    );
  }
}

class AuthLanguagePill extends StatelessWidget {
  final VoidCallback onTap;
  final Widget child;

  const AuthLanguagePill({super.key, required this.onTap, required this.child});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          decoration: BoxDecoration(
            color: notifires.getIsDark
                ? Colors.white.withOpacity(0.06)
                : whiteColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: notifires.getGrey4whiteColor.withOpacity(0.35),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(notifires.getIsDark ? 0 : 0.04),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }
}

/// Six-box OTP entry UI. Purely presentational: it mirrors keystrokes into
/// and out of the existing [controller] so all downstream Cubit/validation/
/// autofill/resend logic in [OtpScreen] keeps working completely unchanged
/// -- this widget never owns OTP state itself.
class AuthOtpBoxInput extends StatefulWidget {
  final TextEditingController controller;
  final int length;
  final ValueChanged<bool>? onTapAny;
  final String? errorText;

  const AuthOtpBoxInput({
    super.key,
    required this.controller,
    this.length = 6,
    this.onTapAny,
    this.errorText,
  });

  @override
  State<AuthOtpBoxInput> createState() => _AuthOtpBoxInputState();
}

class _AuthOtpBoxInputState extends State<AuthOtpBoxInput> {
  late final FocusNode _hiddenFocusNode;

  @override
  void initState() {
    super.initState();
    _hiddenFocusNode = FocusNode();
    widget.controller.addListener(_onControllerChanged);
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onControllerChanged);
    _hiddenFocusNode.dispose();
    super.dispose();
  }

  void _onControllerChanged() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final value = widget.controller.text;
    final hasError = widget.errorText != null && widget.errorText!.isNotEmpty;

    return GestureDetector(
      onTap: () {
        widget.onTapAny?.call(true);
        _hiddenFocusNode.requestFocus();
      },
      child: Stack(
        alignment: Alignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: List.generate(widget.length, (index) {
              final filled = index < value.length;
              final isCursor =
                  index == value.length && _hiddenFocusNode.hasFocus;
              final char = filled ? value[index] : "";

              Color borderColor;
              if (hasError) {
                borderColor = pC1;
              } else if (isCursor) {
                borderColor = themeColor;
              } else if (filled) {
                borderColor = notifires.getGrey4whiteColor;
              } else {
                borderColor = notifires.getGrey4whiteColor.withOpacity(0.6);
              }

              return AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                curve: Curves.easeOut,
                height: 54,
                width: 46,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: notifires.getIsDark
                      ? Colors.white.withOpacity(0.04)
                      : const Color(0xFFF7F7F8),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: borderColor,
                    width: (isCursor || hasError) ? 1.6 : 1,
                  ),
                ),
                child: Text(
                  char,
                  style: regular3(context).copyWith(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    color: notifires.getwhiteblackColor,
                  ),
                ),
              );
            }),
          ),
          // Invisible field that owns real keyboard input/focus/paste while
          // the boxes above render its current value.
          Opacity(
            opacity: 0,
            child: SizedBox(
              height: 54,
              width: double.infinity,
              child: TextField(
                controller: widget.controller,
                focusNode: _hiddenFocusNode,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                maxLength: widget.length,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                showCursor: false,
                decoration: const InputDecoration(
                  counterText: "",
                  border: InputBorder.none,
                ),
                onTap: () => widget.onTapAny?.call(true),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
