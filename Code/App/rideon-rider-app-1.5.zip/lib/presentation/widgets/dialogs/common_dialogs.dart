// ignore_for_file: deprecated_member_use, library_private_types_in_public_api, use_build_context_synchronously

import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on/core/utils/theme/project_color.dart';
import 'package:ride_on/core/utils/theme/theme_style.dart';
import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/core/utils/widget_helpers.dart';

import '../../cubits/logout_cubit.dart';
import '../../cubits/profile/delete_account_cubit.dart';
import '../../screens/auth/login_screen.dart';

/// Toasts, loaders and confirmation dialogs.
///
/// Extracted verbatim from the original `lib/core/utils/common_widget.dart`.

// ignore: prefer_typing_uninitialized_variables
var closeLoading;

showLoading() {
  closeLoading = BotToast.showLoading();
}

showErrorToastMessage(String message) {
  late CancelFunc closeToast;
  closeToast = BotToast.showCustomText(
    duration: const Duration(milliseconds: 1800),
    align: Alignment.bottomCenter.add(const Alignment(0, -0.12)),
    toastBuilder: (context) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 15),
        child: CustomToastMessages(
          message: message.toString(),
          error: true,
          onClose: closeToast,
        ),
      );
    },
  );
}

showToastMessage(String message) {
  late CancelFunc closeToast;
  closeToast = BotToast.showCustomText(
    align: Alignment.bottomCenter.add(const Alignment(0, -0.12)),
    toastBuilder: (_) => Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: CustomToastMessages(
        message: message,
        error: false,
        onClose: closeToast,
      ),
    ),
    duration: const Duration(milliseconds: 1800),
  );
}

class CustomToastMessages extends StatefulWidget {
  final String message;
  final bool? error;
  final VoidCallback? onClose;

  const CustomToastMessages({
    super.key,
    required this.message,
    this.error,
    this.onClose,
  });

  @override
  _CustomToastMessagesState createState() => _CustomToastMessagesState();
}

class _CustomToastMessagesState extends State<CustomToastMessages> {
  @override
  Widget build(BuildContext context) {
    final bool isError = widget.error ?? false;
    final Color accent = isError ? redColor : greenColor;
    final Color surface = notifires.getcardcolor;
    final Color textColor = notifires.getGrey1whiteColor;

    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0.96, end: 1.0),
      duration: const Duration(milliseconds: 280),
      curve: Curves.easeOutCubic,
      builder: (context, scale, child) {
        return Transform.scale(scale: scale, child: child);
      },
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 350),
        child: Material(
          color: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
            decoration: BoxDecoration(
              color: surface,
              borderRadius: BorderRadius.circular(13),
              border: Border.all(
                color: accent.withOpacity(0.18),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.08),
                  blurRadius: 10,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Subtle accent indicator
                Container(
                  width: 3,
                  height: 28,
                  margin: const EdgeInsets.only(right: 8),
                  decoration: BoxDecoration(
                    color: accent,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Container(
                  width: 30,
                  height: 30,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: accent.withOpacity(0.12),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    isError ? Icons.error_outline_rounded : Icons.check_rounded,
                    size: 17,
                    color: accent,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    widget.message.translate(context),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600,
                      color: textColor,
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: widget.onClose,
                  child: Container(
                    width: 28,
                    height: 28,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: accent.withOpacity(0.10),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.close_rounded,
                      color: accent,
                      size: 16,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

buildShowDialog(BuildContext context) {
  return showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: blackColor.withOpacity(0.1),
      builder: (BuildContext context) {
        return Center(
            child:
                CircularProgressIndicator(color: yelloColor2, strokeWidth: 3));
      });
}

dialogExit(BuildContext context) {
  return showDialog<void>(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        backgroundColor: notifires.getboxcolor,
        content: SingleChildScrollView(
          child: ListBody(
            children: <Widget>[
              Icon(
                Icons.error,
                size: 75,
                color: redColor,
              ),
              Text(
                'Do you want to exit?'.translate(context),
                textAlign: TextAlign.center,
                style: headingBlack(context)
                    .copyWith(color: notifires.getwhiteblackColor),
              )
            ],
          ),
        ),
        actions: <Widget>[
          Column(
            children: [
              Row(
                children: [
                  Expanded(
                      child: InkWell(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: Container(
                              margin: const EdgeInsets.only(left: 8, right: 8),
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                  border: Border.all(color: grey5),
                                  color: grey4,
                                  borderRadius: BorderRadius.circular(10)),
                              child: Center(
                                  child: Text(
                                "Cancel".translate(context),
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold),
                              ))))),
                  Expanded(
                      child: InkWell(
                          onTap: () {
                            Navigator.pop(context);

                            SystemNavigator.pop();
                          },
                          child: Container(
                              margin: const EdgeInsets.only(left: 8, right: 8),
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                  border: Border.all(color: blackColor),
                                  color: blackColor,
                                  borderRadius: BorderRadius.circular(10)),
                              child: Center(
                                  child: Text(
                                "Exit".translate(context),
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold),
                              ))))),
                ],
              ),
              const SizedBox(
                height: 8,
              )
            ],
          )
        ],
      );
    },
  );
}

class PaymentConfirmationDialogs extends StatefulWidget {
  final String? desc;
  final String? firstButtontext;
  final String? secondButtontext;
  final String? text;
  final Function()? onPressed;

  const PaymentConfirmationDialogs(
      {super.key,
      this.desc,
      this.firstButtontext,
      this.secondButtontext,
      this.text,
      this.onPressed});

  @override
  _PaymentConfirmationDialogsState createState() =>
      _PaymentConfirmationDialogsState();
}

class _PaymentConfirmationDialogsState
    extends State<PaymentConfirmationDialogs> {
  bool isCancelSelected = true;
  bool isDeleteSelected = false;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.0),
      ),
      elevation: 0,
      backgroundColor: Colors.transparent,
      child: Container(
        width: double.infinity,
        height: MediaQuery.of(context).size.height * 0.26,
        decoration: BoxDecoration(
          color: notifires.getboxcolor,
          borderRadius: BorderRadius.circular(16.0),
        ),
        child: Column(
          children: [
            const SizedBox(height: 10),
            Icon(Icons.payment_rounded,
                size: 70, color: blackColor), // Customize the icon
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Text('${widget.text}'.translate(context),
                  textAlign: TextAlign.center,
                  style: regular(context).copyWith(
                      fontSize: 16, color: notifires.getwhiteblackColor)),
            ), // Customize the text style
            Expanded(
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
                // height: 20,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Flexible(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints.expand(height: 40),
                        child: ElevatedButton(
                          onPressed: () {
                            setState(() {
                              Navigator.pop(context);
                              isCancelSelected = true;
                              isDeleteSelected =
                                  false; // Mark "Cancel" as selected
                            });
                          },
                          style: ElevatedButton.styleFrom(
                            elevation: 0,
                            backgroundColor: notifires.getBoxColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          child: Text('Cancel'.translate(context),
                              style: heading3Grey1(context)),
                        ),
                      ),
                    ),
                    const SizedBox(width: 15),
                    Flexible(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints.expand(height: 40),
                        child: InkWell(
                          onTap: widget.onPressed,
                          child: Container(
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                                color: blackColor,
                                borderRadius: BorderRadius.circular(10)),
                            child: Text('Confirm'.translate(context),
                                style: heading3Grey1(context)
                                    .copyWith(color: whiteColor)),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

logout(BuildContext context) async {
  await clearData(context,true);
  Navigator.pushAndRemoveUntil(
    context,
    MaterialPageRoute(builder: (context) => const LoginScreen()),
    (Route<dynamic> route) => false,
  );
}

class DeleteConfirmationDialogs extends StatelessWidget {
  final String? desc;
  final String? firstButtontext;
  final String? secondButtontext;

  const DeleteConfirmationDialogs({
    super.key,
    this.desc,
    this.firstButtontext,
    this.secondButtontext,
  });

  @override
  Widget build(BuildContext context) {
    return BlocListener<DeleteAccountCubit, DeleteAccountState>(
      listener: (context, state) {
        if (state is DeleteAccountLoading) {
          Widgets.showLoader(context); // Your custom loader
        } else {
          Widgets.hideLoder(context);
          if (state is DeleteAccountSuccess) {
            showToastMessage(state.message);
            Navigator.pop(context);
            logout(context);
            // Close dialog
          } else if (state is DeleteAccountFailed) {
            showToastMessage(state.error);
          }
        }
      },
      child: Dialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        backgroundColor: Colors.transparent,
        elevation: 6,
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: notifires.getboxcolor,
            borderRadius: BorderRadius.circular(20.0),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.15),
                blurRadius: 20,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.warning_amber_rounded, size: 80, color: themeColor),
              const SizedBox(height: 16),
              Text(
                "Are you sure you want to delete your account?"
                    .translate(context),
                textAlign: TextAlign.center,
                style: regular(context).copyWith(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: notifires.getGrey2whiteColor,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                "This action is permanent and cannot be undone."
                    .translate(context),
                textAlign: TextAlign.center,
                style: regular(context).copyWith(
                  fontSize: 14,
                  color: notifires.getGrey2whiteColor.withOpacity(0.7),
                ),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: notifires.getBoxColor,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                          side: BorderSide(
                            color:
                                notifires.getGrey2whiteColor.withOpacity(0.4),
                          ),
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        child: Text(
                          "Cancel".translate(context),
                          style: heading3Grey1(context),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        context
                            .read<DeleteAccountCubit>()
                            .deleteAccount(context);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: themeColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        child: Text(
                          "Yes, Delete".translate(context),
                          style: heading3Grey1(context).copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
