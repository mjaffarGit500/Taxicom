import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:ride_on/presentation/cubits/location/ola_map/get_poliline_using_ola.dart';
import 'package:ride_on/presentation/cubits/location/ola_map/set_marker_using_ola.dart';

class PersistentGoogleMap extends StatefulWidget {
  final LatLng initialPosition;
  final Set<Marker> markers;
  final Set<Polyline> polylines;
  final bool myLocationEnabled;
  final Function(GoogleMapController) onMapCreated;
  final bool Function()? shouldFitCamera;
  final VoidCallback? onCameraFitted;
  final VoidCallback? onUserCameraMove;

  const PersistentGoogleMap({
    super.key,
    required this.initialPosition,
    required this.markers,
    required this.polylines,
    required this.myLocationEnabled,
    required this.onMapCreated,
    this.shouldFitCamera,
    this.onCameraFitted,
    this.onUserCameraMove,
  });

  @override
  PersistentGoogleMapState createState() => PersistentGoogleMapState();
}

class PersistentGoogleMapState extends State<PersistentGoogleMap> {
  GoogleMapController? _mapController;
  bool _isProgrammaticCameraMove = false;
  Set<Marker> markers = {};
  Set<Polyline> polyline = {};

  @override
  void initState() {
    super.initState();
    markers = widget.markers;
    polyline = widget.polylines;
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<GetPolylineOlaCubit, GetPolylineOlaState>(
      builder: (context, polylineState) {
        if (polylineState is GetPolylineOlaUpdated) {
          polyline = polylineState.polylines;
          if (polyline.isNotEmpty && (widget.shouldFitCamera?.call() ?? true)) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              _moveCameraToFitPolylineAndMarkers();
              widget.onCameraFitted?.call();
            });
          }
          context.read<GetPolylineOlaCubit>().resetPolylines();
        }

        return BlocBuilder<UserMarkerOlaCubit, UserMarkerOlaState>(
            builder: (context, markerState) {
          if (markerState is UserMarkerOlaUpdated) {
            markers = markerState.markers;
          }
          return GoogleMap(
            initialCameraPosition: CameraPosition(
              target: widget.initialPosition,
              zoom: 15,
            ),
            myLocationEnabled: widget.myLocationEnabled,
            markers: markers,
            polylines: polyline,
            onMapCreated: (controller) {
              if (_mapController == null) {
                _mapController = controller;
                widget.onMapCreated(controller);
              }
            },
            onCameraMoveStarted: () {
              if (!_isProgrammaticCameraMove) {
                widget.onUserCameraMove?.call();
              }
            },
          );
        });
      },
    );
  }

  void _moveCameraToFitPolylineAndMarkers() {
    if (_mapController == null || polyline.isEmpty) return;

    LatLngBounds bounds;
    final points = polyline.expand((p) => p.points).toList();

    if (points.isEmpty) return;

    final southwestLat =
        points.map((p) => p.latitude).reduce((a, b) => a < b ? a : b);
    final southwestLng =
        points.map((p) => p.longitude).reduce((a, b) => a < b ? a : b);
    final northeastLat =
        points.map((p) => p.latitude).reduce((a, b) => a > b ? a : b);
    final northeastLng =
        points.map((p) => p.longitude).reduce((a, b) => a > b ? a : b);

    bounds = LatLngBounds(
      southwest: LatLng(southwestLat, southwestLng),
      northeast: LatLng(northeastLat, northeastLng),
    );

    _isProgrammaticCameraMove = true;
    _mapController!
        .animateCamera(
          CameraUpdate.newLatLngBounds(bounds, 150), // 150 = padding
        )
        .whenComplete(() => _isProgrammaticCameraMove = false);
  }

  Future<void> recenterOn(LatLng target) async {
    if (_mapController == null) return;
    _isProgrammaticCameraMove = true;
    await _mapController!.animateCamera(
      CameraUpdate.newLatLngZoom(target, 16),
    );
    _isProgrammaticCameraMove = false;
  }

  @override
  void dispose() {
    _mapController?.dispose();
    super.dispose();
  }
}
