import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:ride_on/core/extensions/workspace.dart';

import '../../../../../../core/utils/theme/project_color.dart';
import '../ride_request_palette.dart';

/// Vehicle summary row (image, name, duration chip, fare) shown on the ride
/// details section while the ride is not yet ongoing.
///
/// Extracted verbatim from `_buildVehicleDetails` in `ola_map/send_ride_request_screen_ola.dart`.
class VehicleDetailsSection extends StatelessWidget {
  final Map<String, dynamic> selectedVehicleData;

  const VehicleDetailsSection({
    super.key,
    required this.selectedVehicleData,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: themeColor.withValues(alpha: 0.30)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                width: 62,
                height: 42,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: themeColor.withValues(alpha: 0.25)),
                ),
                padding: const EdgeInsets.all(6),
                child: Builder(
                  builder: (context) {
                    final imageUrl =
                        (selectedVehicleData["image"] ?? "").toString().trim();

                    if (imageUrl.isEmpty) {
                      return SvgPicture.asset("assets/images/car.svg");
                    }

                    return Image.network(
                      imageUrl,
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) =>
                          SvgPicture.asset("assets/images/car.svg"),
                    );
                  },
                ),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    selectedVehicleData["vehicleName"] ?? "Unknown",
                    style: const TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: kOlaRideDarkText,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                    decoration: BoxDecoration(
                      color: themeColor.withValues(alpha: 0.18),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      selectedVehicleData["duration"] ?? "00",
                      style: const TextStyle(
                        fontSize: 8,
                        color: kOlaRideAccentBrown,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                "$currency ${selectedVehicleData["fare"] ?? ""}",
                style: const TextStyle(
                  fontSize: 12,
                  color: kOlaRideDarkText,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(
                "${selectedVehicleData["duration"] ?? "00"} (${selectedVehicleData["distance"] ?? "00"} Km)",
                style: const TextStyle(fontSize: 8, color: kOlaRideAccentBrown),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
