import 'package:flutter/material.dart';


const Color kOlaRideDarkText = Color(0xFF2A1E1A);
const Color kOlaRideAccentBrown = Color(0xFF8A5A10);
