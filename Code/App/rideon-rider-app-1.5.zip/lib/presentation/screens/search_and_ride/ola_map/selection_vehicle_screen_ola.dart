import 'dart:async';
import 'dart:typed_data';
import 'package:ride_on/app/route_settings.dart';
import 'package:ride_on/core/extensions/workspace.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/presentation/screens/search_and_ride/ola_map/send_ride_request/send_ride_request_screen_ola.dart';
import '../../../../core/services/data_store.dart';
import '../../../../core/utils/common_widget.dart';
import '../../../../core/utils/theme/project_color.dart';
import '../../../cubits/book_ride_cubit.dart';
import '../../../cubits/location/get_item_price_cubit.dart';
import '../../../cubits/location/get_nearby_drivers_cubit.dart';
import '../../../cubits/realtime/ride_request_cubit.dart';
import '../../../cubits/vehicle_data/get_vehicle_cetgegory_cubit.dart';
import '../ride_custom_widget.dart' as shared;

class SelectionVehicleScreenOla extends StatefulWidget {
  final Set<Polyline> polylines;
  final List<Map<String, dynamic>> fareList;

  const SelectionVehicleScreenOla({
    super.key,
    required this.polylines,
    required this.fareList,
  });

  @override
  State<SelectionVehicleScreenOla> createState() =>
      _SelectionVehicleScreenOlaState();
}

class _SelectionVehicleScreenOlaState extends State<SelectionVehicleScreenOla> {
  String selectedLat = "$defaultLat";
  String selectedLong = "$defaultLng";
  GoogleMapController? mapController;
  bool isLoadingOnMap = false;
  int selectedIdIndex = -1;
  double traveCharge = 0.0;
  int setIndex = -1;

  Map<String, dynamic> selectedVehicleData = {};

  Set<Polyline> _polylines = {};
  final Completer<GoogleMapController> _controller = Completer();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  bool isRequestInProgress = false;

  @override
  void initState() {
    super.initState();
    _polylines = widget.polylines;
    selectedIdIndex =
        context.read<VehicleDataUpdateCubit>().state.vehicleSelectedId;
    addMarkers();
  }

  Future<void> addMarkers() async {
    final Uint8List markerIconDropOff =
        await getBytesFromAsset("assets/images/dropmarker.png", 15);
    Uint8List markerIconPickUp =
        await getBytesFromAsset("assets/images/pickupmarker.png", 15);
    // ignore: use_build_context_synchronously
    final bookRideState = context.read<BookRideRealTimeDataBaseCubit>().state;
    markers.add(Marker(
      markerId: const MarkerId('pickup'),
      position: LatLng(double.parse(bookRideState.pickupAddressLatitude),
          double.parse(bookRideState.pickupAddressLongitude)),
      icon: BitmapDescriptor.bytes(markerIconPickUp),
      infoWindow: const InfoWindow(title: 'Pickup Location'),
    ));

    markers.add(Marker(
      markerId: const MarkerId('dropoff'),
      position: LatLng(double.parse(bookRideState.dropoffAddressLatitude),
          double.parse(bookRideState.dropoffAddressLongitude)),
      icon: BitmapDescriptor.bytes(markerIconDropOff),
      infoWindow: const InfoWindow(title: 'Dropoff Location'),
    ));
    moveMapAccordingPoline();

    setState(() {});
  }

  void moveMapAccordingPoline() async {
    final controller = await _controller.future;

    final polylinePoints =
        _polylines.expand((polyline) => polyline.points).toList();

    // ignore: use_build_context_synchronously
    final markerPositions =
        context.read<DriverMapCubit>().state is DriverMapUpdated
            // ignore: use_build_context_synchronously
            ? (context.read<DriverMapCubit>().state as DriverMapUpdated)
                .markers
                .map((m) => m.position)
                .toList()
            : [];

    final List<LatLng> allPoints = [...polylinePoints, ...markerPositions];

    if (allPoints.isNotEmpty) {
      LatLngBounds bounds = _createBounds(allPoints);

      controller.animateCamera(CameraUpdate.newLatLngBounds(bounds, 100));
    }
  }

  LatLngBounds _createBounds(List<LatLng> points) {
    double? x0, x1, y0, y1;
    for (LatLng latLng in points) {
      if (x0 == null) {
        x0 = x1 = latLng.latitude;
        y0 = y1 = latLng.longitude;
      } else {
        if (latLng.latitude < x0) x0 = latLng.latitude;
        if (latLng.latitude > x1!) x1 = latLng.latitude;
        if (latLng.longitude < y0!) y0 = latLng.longitude;
        if (latLng.longitude > y1!) y1 = latLng.longitude;
      }
    }
    return LatLngBounds(
      southwest: LatLng(x0!, y0!),
      northeast: LatLng(x1!, y1!),
    );
  }

  void zoomIn() {
    mapController?.animateCamera(CameraUpdate.zoomIn());
  }

  void zoomOut() {
    mapController?.animateCamera(CameraUpdate.zoomOut());
  }

  @override
  void dispose() {
    mapController?.dispose();
    super.dispose();
  }

  Set<Marker> markers = {};


  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    return PopScope(
      canPop: true,
      child: Scaffold(
        key: _scaffoldKey,
        backgroundColor: cream,
        body: Stack(
          children: [
            // ── Map ───────────────────────────────────────────────────────
            SizedBox(
              height: MediaQuery.of(context).size.height / 1.65,
              child: Stack(
                children: [
                  GoogleMap(
                    key: const ValueKey('google_map'),
                    initialCameraPosition: CameraPosition(
                      target: LatLng(
                        double.parse(context
                            .read<BookRideRealTimeDataBaseCubit>()
                            .state
                            .pickupAddressLatitude),
                        double.parse(context
                            .read<BookRideRealTimeDataBaseCubit>()
                            .state
                            .pickupAddressLongitude),
                      ),
                      zoom: 12,
                    ),
                    markers: markers,
                    polylines: _polylines,
                    onMapCreated: (GoogleMapController controller) {
                      mapController = controller;
                      if (!_controller.isCompleted) {
                        _controller.complete(controller);
                      }
                    },
                  ),
                  Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: Container(
                      height: 80,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.transparent,
                            cream.withOpacity(0.92),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 52,
                    left: 16,
                    child: GestureDetector(
                      onTap: goBack,
                      child: Container(
                        height: 42,
                        width: 42,
                        decoration: BoxDecoration(
                          color: themeColor,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child:   Icon(
                          Icons.arrow_back_ios_new_rounded,
                          size: 16,
                          color: darkBrown,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 52,
                    right: 16,
                    child: Column(
                      children: [
                        shared.buildMapZoomBtn(Icons.add, zoomIn),
                        const SizedBox(height: 6),
                        shared.buildMapZoomBtn(Icons.remove, zoomOut),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // ── Bottom Draggable Sheet ────────────────────────────────────
            DraggableScrollableSheet(
              initialChildSize: 0.52,
              minChildSize: 0.42,
              maxChildSize: 0.88,
              builder: (context, scrollController) {
                return Container(
                  decoration: BoxDecoration(
                    color: notifires.getbgcolor,
                    borderRadius:
                        const BorderRadius.vertical(top: Radius.circular(28)),
                  ),
                  child: ListView(
                    controller: scrollController,
                    padding: EdgeInsets.zero,
                    children: [
                      shared.buildDragHandle(),
                      _buildSheetHeader(context),
                      const SizedBox(height: 10),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: shared.bookingDetailsCard(context),
                      ),
                      const SizedBox(height: 16),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 18),
                        child: Row(
                          children: [
                            Container(
                              width: 4,
                              height: 16,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [themeColor, themeColor],
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                ),
                                borderRadius: BorderRadius.circular(4),
                              ),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              "Available Rides".translate(context),
                              style:   TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: darkBrown,
                                letterSpacing: 0.2,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),
                      ListView.builder(
                        padding: EdgeInsets.zero,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: widget.fareList.length,
                        itemBuilder: (context, index) =>
                            _buildVehicleCard(context, index),
                      ),
                      // Extra space so content is not hidden behind Book Now + system nav
                      SizedBox(
                        height:
                            selectedIdIndex != -1 ? 130 + bottomPadding : 40,
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
        bottomNavigationBar:
            selectedIdIndex != -1 ? _buildBookNowBar(context) : null,
      ),
    );
  }

  Widget _buildSheetHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 0),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [themeColor, themeColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: themeColor.withOpacity(0.26),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child:   Icon(Icons.local_taxi_rounded,
                size: 15, color: darkBrown),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Choose Your Ride".translate(context),
                style:   TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: darkBrown,
                  letterSpacing: 0.1,
                ),
              ),
              Text(
                "Select a vehicle for your trip".translate(context),
                style:   TextStyle(
                  fontSize: 10,
                  color: accentBrown,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildVehicleCard(BuildContext context, int index) {
    final data = widget.fareList[index];
    final isSelected = selectedIdIndex == data["id"];

    final fares = context.watch<GetDistanceRouteCubit>().state.vehicleFares;
    final hasFares = fares.length > index && fares[index].isNotEmpty;

    final fare = hasFares ? fares[index]["fare"] ?? "NA" : "NA";
    final duration = hasFares ? fares[index]["duration"] ?? "NA" : "NA";
    final distance = hasFares ? fares[index]["distance"] ?? "0" : "0";

    if (isSelected) {
      setIndex = index;
      traveCharge = double.tryParse(fare.toString()) ?? 0.0;
    }

    return GestureDetector(
      onTap: () {
        if (!isSelected) {
          setState(() {
            setIndex = index;
            selectedIdIndex = data["id"]!;
            context
                .read<VehicleDataUpdateCubit>()
                .updateVehicleTypeSelectedId(data["id"]);
          });
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        margin: EdgeInsets.fromLTRB(16, index == 0 ? 2 : 6, 16, 0),
        decoration: BoxDecoration(
          gradient: isSelected
              ?   LinearGradient(
                  colors: [darkBrown, medBrown, accentBrown],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : const LinearGradient(
                  colors: [Colors.white, Color(0xFFFFFBF1)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? themeColor : themeColor.withValues(alpha: .24),
            width: isSelected ? 1.3 : 1.0,
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
        child: Row(
          children: [
            Container(
              width: 58,
              height: 40,
              decoration: BoxDecoration(
                color: isSelected
                    ? Colors.white.withOpacity(0.12)
                    : const Color(0xFFFFF7DC),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isSelected
                      ? Colors.white.withOpacity(0.18)
                      : themeColor.withOpacity(0.22),
                ),
              ),
              padding: const EdgeInsets.all(6),
              child: Builder(builder: (ctx) {
                final imageUrl = (data["image"] ?? "").toString().trim();
                final fallback = SvgPicture.asset(
                  "assets/images/car.svg",
                  colorFilter: ColorFilter.mode(
                    isSelected ? themeColor : accentBrown,
                    BlendMode.srcIn,
                  ),
                );
                if (imageUrl.isEmpty) return fallback;
                return Image.network(
                  imageUrl,
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => fallback,
                );
              }),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    data["vehicleName"] ?? "Unknown".translate(context),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      color: isSelected ? Colors.white : darkBrown,
                    ),
                  ),
                  const SizedBox(height: 3),
                  if (hasFares)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 3),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? Colors.white.withValues(alpha: .10)
                            : themeColor.withValues(alpha: .12),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.schedule_rounded,
                              size: 10,
                              color: isSelected ? softYellow : accentBrown),
                          const SizedBox(width: 3),
                          Flexible(
                            child: Text(
                              "$duration · $distance ${"Km".translate(context)}",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 9,
                                color: isSelected ? softYellow : accentBrown,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(width: 6),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                if (hasFares)
                  Text(
                    "$currency $fare",
                    style: TextStyle(
                      fontSize: 13,
                      color: isSelected ? themeColor : darkBrown,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                if (isSelected) ...[
                  const SizedBox(height: 3),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: themeColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child:   Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.check_circle_rounded,
                            size: 9, color: darkBrown),
                        const SizedBox(width: 2),
                        Text(
                          "Selected",
                          style: TextStyle(
                            fontSize: 9,
                            color: darkBrown,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBookNowBar(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [cream, Colors.white.withOpacity(0.95)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        boxShadow: [
          BoxShadow(
            color: themeColor.withOpacity(0.18),
            blurRadius: 16,
            offset: const Offset(0, -3),
          ),
        ],
      ),
      padding: EdgeInsets.fromLTRB(16, 8, 16, 10 + bottomPadding),
      child: GestureDetector(
        onTap: isRequestInProgress
            ? null
            : () {
                if (selectedIdIndex == -1) {
                  showErrorToastMessage(
                      "Please select a vehicle type.".translate(context));
                  return;
                }
                context.read<BookRideUserCubit>().removeBookRideState();
                context.read<DriverNearByCubit>().resetNearByDriverState();
                context.read<RideRequestCubit>().resetState();
                box.delete("rideId");
                goTo(SendRideRequestOlaScreen(
                  selectedVehicleData: widget.fareList[setIndex],
                  statusOfRide: "",
                ));
              },
        child: Container(
          height: 44,
          decoration: BoxDecoration(
            gradient: isRequestInProgress
                ? const LinearGradient(
                    colors: [Color(0xFFB0A09A), Color(0xFF9E8880)])
                : LinearGradient(
                    colors: [themeColor, themeColor],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isRequestInProgress ? Colors.transparent : themeColor,
            ),
          ),
          alignment: Alignment.center,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                isRequestInProgress
                    ? Icons.hourglass_top_rounded
                    : Icons.emoji_transportation_rounded,
                color: isRequestInProgress ? Colors.white : darkBrown,
                size: 16,
              ),
              const SizedBox(width: 6),
              Text(
                isRequestInProgress
                    ? "Requesting...".translate(context)
                    : "Book Now".translate(context),
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: isRequestInProgress ? Colors.white : darkBrown,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void updateRide({String? rideId, String? bookingId}) {
    final rideRequestRef =
        FirebaseDatabase.instance.ref().child("ride_requests");
    if (rideId != null &&
        rideId.isNotEmpty &&
        bookingId != null &&
        bookingId.isNotEmpty) {
      rideRequestRef.child(rideId).update({
        'bookingId': bookingId,
        'status': 'Confirmed',
      }).then((_) {
      }).catchError((error) {
        showErrorToastMessage("Failed to update ride.");
      });
    }
  }
}
