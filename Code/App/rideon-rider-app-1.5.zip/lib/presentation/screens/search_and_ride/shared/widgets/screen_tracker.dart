
class ScreenTracker {
  static String? currentScreen;

  static void setCurrentScreen(String screenName) {
    currentScreen = screenName;
  }

  static bool isScreenActive(String screenName) {
    return currentScreen == screenName;
  }
}
