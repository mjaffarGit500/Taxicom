import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/presentation/cubits/location/google_map/get_poliline_using_google.dart';
import 'package:ride_on/presentation/cubits/location/map_box/get_poliline_using_map_box.dart';
import 'package:ride_on/presentation/cubits/location/ola_map/get_poliline_using_ola.dart';
import 'package:ride_on/presentation/cubits/location/osm_map/get_poliline_using_osm.dart';
import 'package:ride_on/presentation/cubits/profile/edit_profile_cubit.dart';
import 'package:ride_on/presentation/screens/search_and_ride/google_map/selection_vehicle_screen.dart';
import 'package:ride_on/presentation/screens/search_and_ride/map_box/selection_vehicle_screen_map_box.dart';
import 'package:ride_on/presentation/screens/search_and_ride/ola_map/selection_vehicle_screen_ola.dart';
import 'package:ride_on/presentation/screens/search_and_ride/osm/selection_vehicle_screen_osm.dart';
import '../../../app/route_settings.dart';
import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../cubits/book_ride_cubit.dart';
import '../../cubits/location/get_item_price_cubit.dart';
import '../../cubits/location/get_nearby_drivers_cubit.dart';
import 'package:flutter_map/flutter_map.dart' as OSM;

class LoadingNearbySearchScreen extends StatefulWidget {
  const LoadingNearbySearchScreen({super.key});

  @override
  State<LoadingNearbySearchScreen> createState() =>
      _LoadingNearbySearchScreenState();
}

class _LoadingNearbySearchScreenState extends State<LoadingNearbySearchScreen> {
  Set<Polyline> _polylines = {};
  String? _errorMessage;
  Set<PolylineAnnotation> _polylinesMapbox = {};
  Set<OSM.Polyline> _polylinesOsm = {};

  @override
  void initState() {
    super.initState();
    context.read<GetDistanceRouteCubit>().removeDistanceState();
    context.read<GetDistanceRouteCubit>().getDistanceAndFares(
          context: context,
          pickupLat: context
              .read<BookRideRealTimeDataBaseCubit>()
              .state
              .pickupAddressLatitude,
          pickupLng: context
              .read<BookRideRealTimeDataBaseCubit>()
              .state
              .pickupAddressLongitude,
          dropOffLat: context
              .read<BookRideRealTimeDataBaseCubit>()
              .state
              .dropoffAddressLatitude,
          dropOffLng: context
              .read<BookRideRealTimeDataBaseCubit>()
              .state
              .dropoffAddressLongitude,
        );
    _fetchAllDataWithSetState();
  }

  bool get _hasError => _errorMessage != null;

  Future<void> _fetchAllDataWithSetState() async {
    try {
      final rideState = context.read<BookRideRealTimeDataBaseCubit>().state;

      // Parse coordinates safely
      final pickupLat = double.tryParse(rideState.pickupAddressLatitude);
      final pickupLng = double.tryParse(rideState.pickupAddressLongitude);
      final dropoffLat = double.tryParse(rideState.dropoffAddressLatitude);
      final dropoffLng = double.tryParse(rideState.dropoffAddressLongitude);

      // Validate coordinates
      if (pickupLat == null ||
          pickupLng == null ||
          dropoffLat == null ||
          dropoffLng == null ||
          pickupLat == 0.0 ||
          pickupLng == 0.0 ||
          dropoffLat == 0.0 ||
          dropoffLng == 0.0) {
        setState(() => _errorMessage = 'Invalid coordinates provided');
        return;
      }

      final mapState = context.read<MapTypeCubit>().state;

      // Fetch polyline if empty
      if (_polylines.isEmpty &&
          _polylinesOsm.isEmpty &&
          _polylinesMapbox.isEmpty) {
        if (mapState.selectedMap.toString() == "google") {
          context.read<GetPolylineCubit>().getPolyline(
                isPickupRoute: false,
                sourcelat: pickupLat,
                sourcelng: pickupLng,
                destinationlat: dropoffLat,
                destinationlng: dropoffLng,
              );
        } else if (mapState.selectedMap.toString() == "osm") {
          context.read<OSMGetPolylineCubit>().getPolyline(
                isPickupRoute: false,
                sourcelat: pickupLat,
                sourcelng: pickupLng,
                destinationlat: dropoffLat,
                destinationlng: dropoffLng,
              );
        } else if (mapState.selectedMap.toString() == "mapBox") {
          context.read<GetPolylineMapBoxCubit>().getPolylineMapboxForLoading(
                isPickupRoute: false,
                sourcelat: pickupLat,
                sourcelng: pickupLng,
                destinationlat: dropoffLat,
                destinationlng: dropoffLng,
              );
        } else if (mapState.selectedMap.toString() == "ola") {
          context.read<GetPolylineOlaCubit>().getPolylineOla(
                isPickupRoute: false,
                sourcelat: pickupLat,
                sourcelng: pickupLng,
                destinationlat: dropoffLat,
                destinationlng: dropoffLng,
              );
        }
      }

      bool polylineFetched = false;
      bool distanceFetched = false;
      double? distance;
      List<Map<String, dynamic>> vehicleFares = [];
      const int timeoutMs = 20000;
      int elapsed = 0;

      // --- LISTEN FOR POLYLINE ---
      late final StreamSubscription polylineSub;
      if (mapState.selectedMap.toString() == "google") {
        polylineSub = context.read<GetPolylineCubit>().stream.listen((state) {
          if (state is GetPolylineUpdated && state.polylines != null) {
            _polylines = state.polylines!;
            polylineFetched = true;
          } else if (state is GetPolylineUpdatedError) {
            _errorMessage = state.error;
          }
        });
      } else if (mapState.selectedMap.toString() == "osm") {
        polylineSub =
            context.read<OSMGetPolylineCubit>().stream.listen((state) {
          if (state is OSMGetPolylineUpdated) {
            _polylinesOsm = state.polylines;
            polylineFetched = true;
          } else if (state is OSMGetPolylineUpdatedError) {
            _errorMessage = state.error;
          }
        });
      } else if (mapState.selectedMap.toString() == "mapBox") {
        polylineSub =
            context.read<GetPolylineMapBoxCubit>().stream.listen((state) {
          if (state is GetPolylineMapBoxUpdated) {
            _polylinesMapbox = state.polylines;
            polylineFetched = true;
          } else if (state is GetPolylineMapBoxError) {
            _errorMessage = state.message;
          }
        });
      } else if (mapState.selectedMap.toString() == "ola") {
        polylineSub =
            context.read<GetPolylineOlaCubit>().stream.listen((state) {
          if (state is GetPolylineOlaUpdated) {
            _polylines = state.polylines;
            polylineFetched = true;
          } else if (state is GetPolylineOlaError) {
            _errorMessage = state.error;
          }
        });
      }

      // --- LISTEN FOR DISTANCE ---
      final distanceSub =
          context.read<GetDistanceRouteCubit>().stream.listen((state) {
         if (state.vehicleFares.isNotEmpty && state.distance != null) {
          distance = state.distance;
          vehicleFares = state.vehicleFares;
          distanceFetched = true;
        }
      });

      // --- WAIT UNTIL BOTH DONE OR TIMEOUT ---
      while (mounted &&
          !_hasError &&
          (!polylineFetched || !distanceFetched) &&
          elapsed < timeoutMs) {
        await Future.delayed(const Duration(milliseconds: 200));
        elapsed += 200;
      }

      // --- CLEANUP ---
      await polylineSub.cancel();
      await distanceSub.cancel();

      if (_errorMessage != null) {
        setState(() {});
        return;
      }

      if (elapsed >= timeoutMs && (!_hasError)) {
        setState(() => _errorMessage = "Request timed out");
        return;
      }

      if (distance != null && distance! <= 0.1) {
        setState(() => _errorMessage =
            'Distance is too short (≤ 0.1 km). Please select a farther drop-off location.');
        return;
      }

      // --- NAVIGATION ---
      if (!mounted) return;

      if (mapState.selectedMap.toString() == "google") {
        goToWithReplacement(SelectionVehicleScreen(
          polylines: _polylines,
          fareList: vehicleFares,
        ));
      } else if (mapState.selectedMap.toString() == "osm") {
        goToWithReplacement(SelectionVehicleScreenOSM(
          polylines: _polylinesOsm,
          fareList: vehicleFares,
        ));
      } else if (mapState.selectedMap.toString() == "mapBox") {
        goToWithReplacement(SelectionVehicleScreenMapBox(
          polylines: _polylinesMapbox,
          fareList: vehicleFares,
        ));
      } else if (mapState.selectedMap.toString() == "ola") {
        goToWithReplacement(SelectionVehicleScreenOla(
          polylines: _polylines,
          fareList: vehicleFares,
        ));
      }
    } catch (e) {
      setState(() => _errorMessage = 'Failed to load data: $e');
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final isSmallPhone = size.height < 750 || size.width < 380;
    final contentMaxWidth = size.width > 520 ? 430.0 : double.infinity;

    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: const Color(0xFFF5F7FB),
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              "assets/images/basemap_image.png",
              fit: BoxFit.cover,
            ),
          ),
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.white.withValues(alpha: 0.84),
                    Colors.white.withValues(alpha: 0.62),
                    const Color(0xFFF7F9FD),
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Center(
              child: ConstrainedBox(
                constraints: BoxConstraints(maxWidth: contentMaxWidth),
                child: Padding(
                  padding: EdgeInsets.fromLTRB(
                    isSmallPhone ? 14 : 18,
                    isSmallPhone ? 10 : 14,
                    isSmallPhone ? 14 : 18,
                    isSmallPhone ? 14 : 18,
                  ),
                  child: Column(
                    children: [
                      _buildTopBar(context, isSmallPhone),
                      SizedBox(height: isSmallPhone ? 12 : 16),
                      _buildStatusCard(context, isSmallPhone),
                      SizedBox(height: isSmallPhone ? 12 : 16),
                      Expanded(
                        child: SingleChildScrollView(
                          child: BlocBuilder<BookRideRealTimeDataBaseCubit,
                              BookRideState>(
                            builder: (context, state) => _buildRouteCard(
                              context,
                              state,
                              isSmallPhone,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: isSmallPhone ? 12 : 16),
                      _buildActionButton(context, isSmallPhone),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopBar(BuildContext context, bool isSmallPhone) {
    return Row(
      children: [
        GestureDetector(
          onTap: _errorMessage != null ? _handleCancel : null,
          child: Container(
            height: isSmallPhone ? 38 : 44,
            width: isSmallPhone ? 38 : 44,
            decoration: BoxDecoration(
              color: themeColor,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: themeColor.withValues(alpha: 0.28),
                  blurRadius: 18,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Icon(
              Icons.arrow_back_rounded,
              color: blackColor,
              size: isSmallPhone ? 20 : 24,
            ),
          ),
        ),
        const Spacer(),
        Container(
          padding: EdgeInsets.symmetric(
            horizontal: isSmallPhone ? 10 : 12,
            vertical: isSmallPhone ? 7 : 8,
          ),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(100),
            border: Border.all(color: const Color(0xFFE5EAF3)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                _errorMessage == null
                    ? Icons.radar_rounded
                    : Icons.error_outline_rounded,
                color: _errorMessage == null
                    ? const Color(0xFF1AAE9F)
                    : Colors.deepOrange,
                size: isSmallPhone ? 14 : 16,
              ),
              SizedBox(width: isSmallPhone ? 6 : 8),
              Text(
                _errorMessage == null
                    ? "Finding route".translate(context)
                    : "Route issue".translate(context),
                style: TextStyle(
                  fontSize: isSmallPhone ? 10 : 11,
                  fontWeight: FontWeight.w700,
                  color: const Color(0xFF2B3340),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildStatusCard(BuildContext context, bool isSmallPhone) {
    final hasError = _errorMessage != null;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(
        horizontal: isSmallPhone ? 14 : 16,
        vertical: isSmallPhone ? 12 : 14,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: const [
          BoxShadow(
            color: Color(0x140C1523),
            blurRadius: 28,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            height: isSmallPhone ? 36 : 42,
            width: isSmallPhone ? 36 : 42,
            decoration: BoxDecoration(
              color: hasError
                  ? const Color(0xFFFFF0EA)
                  : themeColor.withValues(alpha: 0.18),
              shape: BoxShape.circle,
            ),
            child: hasError
                ? Icon(
                    Icons.error_outline_rounded,
                    color: Colors.deepOrange,
                    size: isSmallPhone ? 18 : 20,
                  )
                : Padding(
                    padding: EdgeInsets.all(isSmallPhone ? 9 : 10),
                    child: SvgPicture.asset(
                      "assets/images/tabler_loader.svg",
                    ),
                  ),
          ),
          SizedBox(width: isSmallPhone ? 10 : 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  hasError
                      ? "Route update failed".translate(context)
                      : "Preparing route details".translate(context),
                  style: TextStyle(
                    fontSize: isSmallPhone ? 12 : 13,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF202733),
                  ),
                ),
                SizedBox(height: isSmallPhone ? 2 : 4),
                Text(
                  (_errorMessage ??
                          "Please wait while we verify pickup, drop-off and trip route.")
                      .translate(context),
                  style: TextStyle(
                    fontSize: isSmallPhone ? 10 : 11,
                    height: 1.35,
                    color: const Color(0xFF6F7A89),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRouteCard(
    BuildContext context,
    BookRideState state,
    bool isSmallPhone,
  ) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(isSmallPhone ? 14 : 18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: const [
          BoxShadow(
            color: Color(0x140C1523),
            blurRadius: 28,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(isSmallPhone ? 8 : 9),
                decoration: BoxDecoration(
                  color: const Color(0xFFF5FAF9),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(
                  Icons.route_rounded,
                  color: const Color(0xFF1AAE9F),
                  size: isSmallPhone ? 16 : 18,
                ),
              ),
              SizedBox(width: isSmallPhone ? 10 : 12),
              Expanded(
                child: Text(
                  "Trip preview".translate(context),
                  style: TextStyle(
                    fontSize: isSmallPhone ? 13 : 14,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF1E2530),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: isSmallPhone ? 14 : 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                children: [
                  _buildIconCircle(
                    icon: Icons.my_location_rounded,
                    color: greentext,
                    isSmallPhone: isSmallPhone,
                  ),
                  Container(
                    margin:
                        EdgeInsets.symmetric(vertical: isSmallPhone ? 6 : 8),
                    height: isSmallPhone ? 34 : 42,
                    width: 2,
                    color: const Color(0xFFE0E5EC),
                  ),
                  _buildIconCircle(
                    icon: Icons.location_on_rounded,
                    color: Colors.redAccent,
                    isSmallPhone: isSmallPhone,
                  ),
                ],
              ),
              SizedBox(width: isSmallPhone ? 10 : 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildAddressTile(
                      context,
                      label: "PICKUP".translate(context),
                      address: state.pickupAddress,
                      isSmallPhone: isSmallPhone,
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: isSmallPhone ? 10 : 12),
                      child: const Divider(
                        height: 1,
                        color: Color(0xFFE8ECF2),
                      ),
                    ),
                    _buildAddressTile(
                      context,
                      label: "DROP-OFF".translate(context),
                      address: state.dropoffAddress,
                      isSmallPhone: isSmallPhone,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton(BuildContext context, bool isSmallPhone) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: themeColor.withValues(alpha: 0.24),
            blurRadius: 22,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: SizedBox(
        width: double.infinity,
        height: isSmallPhone ? 48 : 52,
        child: CustomsButtons(
          text: "Cancel".translate(context),
          backgroundColor: themeColor,
          textColor: blackColor,
          onPressed: _handleCancel,
        ),
      ),
    );
  }

  Widget _buildIconCircle({
    required IconData icon,
    required Color color,
    required bool isSmallPhone,
  }) {
    return Container(
      padding: EdgeInsets.all(isSmallPhone ? 6 : 7),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .1),
        shape: BoxShape.circle,
      ),
      child: Icon(icon, color: color, size: isSmallPhone ? 15 : 17),
    );
  }

  Widget _buildAddressTile(
    BuildContext context, {
    required String label,
    required String address,
    required bool isSmallPhone,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: isSmallPhone ? 10 : 11,
            color: const Color(0xFF7C8696),
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: isSmallPhone ? 4 : 6),
        Text(
          address,
          style: boldstyle(context).copyWith(
            fontSize: isSmallPhone ? 11 : 12,
            color: const Color(0xFF293241),
            height: 1.35,
          ),
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
  }

  void _handleCancel() {
    context.read<DriverNearByCubit>().resetNearByDriverState();
    context.read<GetPolylineCubit>().resetPolylines();
    context.read<DriverMapCubit>().resetState();
    context.read<GetDistanceRouteCubit>().removeDistanceState();
    goBack();
  }
}
