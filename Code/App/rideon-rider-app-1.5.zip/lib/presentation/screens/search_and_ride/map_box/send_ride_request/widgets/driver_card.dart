import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on/core/utils/translate.dart';

import '../../../../../../core/utils/common_widget.dart';
import '../../../../../../core/utils/theme/project_color.dart';
import '../../../../../../core/utils/theme/theme_style.dart';
import '../../../../../cubits/realtime/ride_request_cubit.dart';
import '../../../ride_custom_widget.dart' as shared;

/// Dark gradient card showing the accepted driver plus the chat and call
/// actions. Navigation, the call intent and the unread-message stream stay on
/// the screen and arrive via [onChatTap], [onCallTap] and [unreadCountStream].
///
/// Extracted verbatim from `_buildDriverCard` in `map_box/send_ride_request_screen_map_box.dart`.
class DriverCard extends StatelessWidget {
  final Stream<int> Function() unreadCountStream;
  final void Function(RideRequestState state) onChatTap;
  final Future<void> Function(String phone) onCallTap;

  const DriverCard({
    super.key,
    required this.unreadCountStream,
    required this.onChatTap,
    required this.onCallTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF241914), Color(0xFF3F291F), Color(0xFF6A4312)],
        ),
        borderRadius: BorderRadius.circular(24),
      ),
      padding: const EdgeInsets.all(14),
      child: BlocBuilder<RideRequestCubit, RideRequestState>(
        builder: (context, state) {
          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              state.acceptedDriverImageUrl.isEmpty
                  ? Container(
                      height: 58,
                      width: 58,
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.14),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: const Icon(
                        CupertinoIcons.profile_circled,
                        color: Colors.white,
                        size: 36,
                      ),
                    )
                  : Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.18),
                            blurRadius: 18,
                            offset: const Offset(0, 8),
                          )
                        ],
                      ),
                      height: 45,
                      width: 45,
                      child: ClipRRect(
                          borderRadius: BorderRadius.circular(32),
                          child: myNetworkImage(state.acceptedDriverImageUrl)),
                    ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            state.acceptedDriverName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: regularBlack(context).copyWith(
                              fontSize: 15,
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.12),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.star_rounded,
                                  color: themeColor, size: 15),
                              const SizedBox(width: 4),
                              Text(
                                state.driverRating,
                                style: regularBlack(context).copyWith(
                                  fontSize: 12,
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              shared.buildDriverMetaRow(
                                icon: Icons.call_outlined,
                                text: state.accepteDriverPhoneNumber,
                              ),
                              const SizedBox(height: 4),
                              shared.buildDriverMetaRow(
                                icon: Icons.directions_car_filled_rounded,
                                text: state.acceptedDriverVechileNumber,
                              ),
                            ],
                          ),
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            shared.buildDriverActionButton(
                              icon: Icons.chat_bubble_rounded,
                              label: "Chat".translate(context),
                              onTap: () async {
                                onChatTap(state);
                              },
                              trailing: StreamBuilder<int>(
                                stream: unreadCountStream(),
                                builder: (context, snapshot) {
                                  final unread = snapshot.data ?? 0;
                                  if (unread <= 0) {
                                    return const SizedBox.shrink();
                                  }

                                  return Container(
                                    margin: const EdgeInsets.only(left: 6),
                                    height: 8,
                                    width: 8,
                                    decoration: BoxDecoration(
                                      color: greentext,
                                      shape: BoxShape.circle,
                                    ),
                                  );
                                },
                              ),
                            ),
                            const SizedBox(width: 8),
                            shared.buildDriverActionButton(
                              icon: Icons.call_rounded,
                              label: "Call".translate(context),
                              onTap: () async {
                                await onCallTap(state.accepteDriverPhoneNumber);
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
