import 'package:flutter/material.dart';
import 'package:ride_on/core/utils/translate.dart';

import '../../../../../../core/utils/theme/theme_style.dart';
import '../../../ride_custom_widget.dart' as shared;

/// Red "Cancel Ride" pill shown while the ride is not yet ongoing. The
/// cancellation side effects stay on the screen and arrive via [onConfirmCancel].
///
/// Extracted verbatim from `_buildCancelRideButton` in `map_box/send_ride_request_screen_map_box.dart`.
class CancelRideButton extends StatelessWidget {
  final VoidCallback onConfirmCancel;

  const CancelRideButton({
    super.key,
    required this.onConfirmCancel,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        GestureDetector(
          onTap: () => shared.showCancelRideBottomSheet(
            context,
            onConfirmCancel: onConfirmCancel,
          ),
          child: Container(
            alignment: Alignment.center,
            height: 42,
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 5),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFB84D4A), Color(0xFF8F2E2B)],
              ),
              borderRadius: BorderRadius.circular(40),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF7C2926).withValues(alpha: 0.32),
                  blurRadius: 16,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.close_rounded, color: Colors.white, size: 18),
                const SizedBox(width: 8),
                Text(
                  "Cancel Ride".translate(context),
                  style: regular2(context).copyWith(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
