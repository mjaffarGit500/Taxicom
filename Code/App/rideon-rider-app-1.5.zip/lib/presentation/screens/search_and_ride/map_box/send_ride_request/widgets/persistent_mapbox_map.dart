import 'package:flutter/material.dart';
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
import 'package:ride_on/presentation/screens/search_and_ride/ride_custom_widget.dart'
    as shared;

// FIXED: Updated PersistentMapboxMap Widget (Fix White Screen)
class PersistentMapboxMap extends StatefulWidget {
  final Function(MapboxMap) onMapCreated;
  final void Function(CameraChangedEventData)? onCameraChangeListener;
  final Position initialCenter;
  final double initialZoom;

  const PersistentMapboxMap({
    super.key,
    required this.onMapCreated,
    this.onCameraChangeListener,
    required this.initialCenter,
    required this.initialZoom,
  });

  @override
  State<PersistentMapboxMap> createState() => _PersistentMapboxMapState();
}

class _PersistentMapboxMapState extends State<PersistentMapboxMap> {
  MapboxMap? _mapboxMap;
  bool _mapLoaded = false; // FIXED: Track loading state

  @override
  Widget build(BuildContext context) {
    return Stack(
      // FIXED: Wrap in Stack for loading overlay
      children: [
        MapWidget(
          key: const ValueKey("mapWidget"),
          onMapCreated: _onMapCreated,
          onCameraChangeListener: widget.onCameraChangeListener,
          styleUri: MapboxStyles.MAPBOX_STREETS,
          cameraOptions: CameraOptions(
            center: Point(coordinates: widget.initialCenter),
            zoom: widget.initialZoom,
          ),
        ),
        // FIXED: Loading overlay until map is ready (prevents white screen)
        if (!_mapLoaded)
          Container(
            color: Colors.white, // Or your app's bg color
            child: const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(
                      color: Colors.blue), // Customize color
                  SizedBox(height: 16),
                  shared.PulsingCircle(), // Reuse your existing pulsing widget
                  Text("Loading map...", style: TextStyle(color: Colors.grey)),
                ],
              ),
            ),
          ),
      ],
    );
  }

  void _onMapCreated(MapboxMap mapboxMap) async {
    _mapboxMap = mapboxMap;
    setState(() => _mapLoaded = true); // FIXED: Hide loading
    widget.onMapCreated(mapboxMap);
  }

  @override
  void dispose() {
    super.dispose();
  }
}
