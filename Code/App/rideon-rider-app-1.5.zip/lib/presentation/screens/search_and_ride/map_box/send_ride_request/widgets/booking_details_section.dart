import 'package:flutter/material.dart';
import 'package:ride_on/core/services/data_store.dart';
import 'package:ride_on/core/utils/translate.dart';

import '../../../shared/widgets/parcel_info_widget.dart';
import '../../../ride_custom_widget.dart' as shared;

/// "Booking Details" block: the pickup/drop card plus the parcel summary read
/// from the local `current_parcel_data` box entry.
///
/// Extracted verbatim from `_buildBookingDetails` in `map_box/send_ride_request_screen_map_box.dart`.
class BookingDetailsSection extends StatelessWidget {
  const BookingDetailsSection({super.key});

  @override
  Widget build(BuildContext context) {
    final dynamic rawParcel = box.get('current_parcel_data');

    final Map<String, dynamic>? parcelData =
        rawParcel != null ? Map<String, dynamic>.from(rawParcel as Map) : null;

    final String name = parcelData?['name']?.toString() ?? '';
    final String weight = parcelData?['weight']?.toString() ?? '';
    final String receiverName = parcelData?['receiverName']?.toString() ?? '';
    final String receiverPhone = parcelData?['receiverPhone']?.toString() ?? '';
    final String pickupInstructions =
        parcelData?['pickupInstructions']?.toString() ?? '';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        shared.buildSectionLabel(
          context,
          title: "Booking Details".translate(context),
          icon: Icons.pin_drop_rounded,
        ),
        const SizedBox(height: 10),
        shared.bookingDetailsCard(context),
        const SizedBox(height: 14),
        ParcelInfoWidget(
          name: name,
          weight: weight,
          receiverName: receiverName,
          receiverPhone: receiverPhone,
          pickupInstructions: pickupInstructions,
        ),
      ],
    );
  }
}
