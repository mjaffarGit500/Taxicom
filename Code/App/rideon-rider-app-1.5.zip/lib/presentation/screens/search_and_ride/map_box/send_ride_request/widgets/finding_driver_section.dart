import 'package:flutter/material.dart';
import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/presentation/screens/search_and_ride/google_map/send_ride_request/widgets/countdown_segmented_bar.dart';

import '../../../../../../core/utils/theme/project_color.dart';
import '../../../ride_custom_widget.dart' as shared;

/// "Matching your ride" card with the driver-search countdown, shown while no
/// driver has accepted yet.
///
/// Extracted verbatim from `_buildFindingDriverSection` in `map_box/send_ride_request_screen_map_box.dart`.
class FindingDriverSection extends StatelessWidget {
  final String statusOfRide;

  const FindingDriverSection({
    super.key,
    required this.statusOfRide,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: themeColor.withValues(alpha: 0.30)),
        boxShadow: [
          BoxShadow(
            color: themeColor.withValues(alpha: 0.10),
            blurRadius: 16,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          shared.buildSectionHeader(
            context,
            title: "Matching your ride".translate(context),
            subtitle:
                "We’re checking nearby drivers and sending your request instantly."
                    .translate(context),
            icon: Icons.radar_rounded,
            gradient: [themeColor, themeColor],
          ),
          const SizedBox(height: 12),
          CountdownSegmentedBar(
            statusOfRide: statusOfRide,
          ),
        ],
      ),
    );
  }
}
