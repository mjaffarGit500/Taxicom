import 'dart:async';
import 'dart:convert';
import 'package:geolocator/geolocator.dart' hide Position;
import 'package:ride_on/app/route_settings.dart';
import 'package:ride_on/core/extensions/helper/push_notifications.dart';
import 'package:ride_on/core/services/config.dart';
import 'package:ride_on/core/services/data_store.dart';
import 'package:ride_on/core/extensions/workspace.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import 'package:ride_on/core/utils/common_widget.dart';
import 'package:ride_on/core/utils/smooth_driver_tracking_controller.dart';
import 'package:ride_on/core/utils/theme/project_color.dart';
import 'package:ride_on/presentation/cubits/book_ride_cubit.dart';
import 'package:ride_on/presentation/cubits/general_cubit.dart';
import 'package:ride_on/presentation/cubits/location/get_nearby_drivers_cubit.dart';
import 'package:ride_on/presentation/cubits/location/map_box/get_poliline_using_map_box.dart';
import 'package:ride_on/presentation/cubits/location/map_box/set_marker_using_map_box.dart';
import 'package:ride_on/presentation/cubits/realtime/get_ride_request_status_cubit.dart';
import 'package:ride_on/presentation/cubits/realtime/ride_request_cubit.dart';
import 'package:ride_on/presentation/cubits/vehicle_data/get_vehicle_cetgegory_cubit.dart';
import 'package:ride_on/presentation/screens/home/item_home_screen.dart';
import 'package:ride_on/presentation/screens/payment/rider_payment_screen.dart';
import 'package:ride_on/presentation/screens/search_and_ride/chat_screen.dart';
import 'package:ride_on/presentation/screens/search_and_ride/shared/widgets/screen_tracker.dart';
import 'package:ride_on/presentation/screens/search_and_ride/ride_custom_widget.dart'
    as shared;
import 'package:ride_on/presentation/widgets/sos_widget.dart';
import 'widgets/booking_details_section.dart';
import 'widgets/driver_info_section.dart';
import 'widgets/finding_driver_section.dart';
import 'widgets/persistent_mapbox_map.dart';
import 'widgets/ride_details_section.dart';
import 'package:url_launcher/url_launcher.dart';

class SendRideRequestScreenMapbox extends StatefulWidget {
  final Map<String, dynamic> selectedVehicleData;

  final String statusOfRide;
  final String? pickUpOtp, dropotp, rideId, bookingId, paymentUrl;

  const SendRideRequestScreenMapbox(
      {super.key,
      required this.selectedVehicleData,
      required this.statusOfRide,
      this.rideId,
      this.pickUpOtp,
      this.dropotp,
      this.bookingId,
      this.paymentUrl});

  @override
  State<SendRideRequestScreenMapbox> createState() =>
      _SendRideRequestScreenMapboxState();
}

class _SendRideRequestScreenMapboxState
    extends State<SendRideRequestScreenMapbox> {

  double dropLat = 0.0;
  double dropLng = 0.0;
  double pickLat = 0.0;
  double pickLng = 0.0;
  double driverLat = 0.0;
  double driverLng = 0.0;
  String fetchDistance = "";
  String fetchDuration = "";
  String otp = "";
  String dropotp = "";
  String rideId = "";
  String bookingId = "";
  String rideStatus = "";
  String paymentUrl = '';
  bool isSuccessFirst = false;
  bool isCurrentScreenActive = true;
  List<Position> polylineCoordinates = [];
  int currentPolylineIndex = 0;
  Timer? locationUpdateTimer;
  Timer? fetchTimer;
  MapboxMap? mapboxMap;

  // FIXED: Flags to control map fitting (only 2 times total)
  bool _fitOnAccepted = true;
  bool _fitOnOngoing = true;

  // Smooth driver marker animation + bearing (no per-frame setState).
  final SmoothDriverTrackingController _trackingController =
      SmoothDriverTrackingController();
  bool _isFollowingDriver = true;
  bool _isProgrammaticCameraMove = false;

  @override
  void initState() {
    super.initState();

    ScreenTracker.setCurrentScreen("RideTrackingScreen");
    isManuallyCancelled = false;
    isCurrentScreenActive = true;

    context.read<UserMarkerCubitMapbox>().clear();
    context.read<GetPolylineMapBoxCubit>().resetPolylines();

    _trackingController.onFrame = (frame) {
      driverLat = frame.lat;
      driverLng = frame.lng;
      _updateDriverMarkerPosition(frame.lat, frame.lng,
          bearingDegrees: normalizeCarMarkerRotation(frame.bearingDegrees));
    };

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _handleRideByStatus();
    });
  }

  void _handleRideByStatus() {
    final status = widget.statusOfRide;

    if (status.isEmpty) {
      _handleFreshRide();
    } else if (status == "pending") {
      _resumePendingRide();
    } else if (status == "accepted" || status == "pick_up") {
      _handleAcceptedRide();
    } else if (status == "ongoing") {
      _handleOngoingRide();
    }
  }

  void _handleFreshRide() {
    getNearByDrivers();
    box.put('selected_vehicle', jsonEncode(widget.selectedVehicleData));
  }

  void _resumePendingRide() {
    final rawRideRequestData = box.get("activeRide");
    final rawRideData = box.get("ride_data");
    final rawDriverIds = box.get("driverIds");
    final rawNearbyDrivers = box.get("nearbyDrivers");
    context
        .read<VehicleDataUpdateCubit>()
        .updateVehicleTypeSelectedId(widget.selectedVehicleData["id"]);

    final Map<String, dynamic>? rideRequestData = rawRideRequestData is Map
        ? Map<String, dynamic>.from(rawRideRequestData)
        : null;

    final Map<String, dynamic>? rideData =
        rawRideData is Map ? Map<String, dynamic>.from(rawRideData) : null;

    final List<String> driverIds =
        rawDriverIds is List ? rawDriverIds.whereType<String>().toList() : [];

    final List<Map<String, dynamic>> nearbyDrivers = rawNearbyDrivers is List
        ? rawNearbyDrivers
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList()
        : [];

    if (rideRequestData == null || rideData == null || driverIds.isEmpty) {
      return;
    }
    context.read<RideRequestCubit>().listenForDriverResponses(
          currentRequestId: widget.rideId ?? "",
          pickupAddress: rideData["pickAddress"] ?? "",
          dropoffAddress: rideData["dropAddress"] ?? "",
          pickupLat: (rideData["pickLat"] ?? 0).toDouble(),
          dropoffLat: (rideData["dropLat"] ?? 0).toDouble(),
          pickupLng: (rideData["pickLng"] ?? 0).toDouble(),
          dropoffLng: (rideData["dropLng"] ?? 0).toDouble(),
          durationForSearch: int.tryParse(
                context.read<DriverSearchIntervalCubit>().state.value ?? "60",
              ) ??
              60,
          driverIds: driverIds,
          rideId: widget.rideId ?? "",
          context: context,
          rideRequestData: rideRequestData,
          nearbyDrivers: nearbyDrivers,
        );
  }

  void _handleAcceptedRide() {
    setAllLatLang();
    _handleBookRideSuccess(
      context,
      widget.pickUpOtp.toString(),
      widget.dropotp.toString(),
      widget.rideId.toString(),
      widget.bookingId.toString(),
    );
    paymentUrl = widget.paymentUrl ?? "";
    rideStatus = widget.statusOfRide;
  }

  void _handleOngoingRide() {
    setAllLatLang();
    otp = widget.pickUpOtp.toString();
    dropotp = widget.dropotp.toString();
    rideId = widget.rideId.toString();
    bookingId = widget.bookingId.toString();
    rideStatus = widget.statusOfRide;
    paymentUrl = widget.paymentUrl ?? "";
    context
        .read<GetRideRequestStatusCubit>()
        .listenToRouteStatus(rideId: rideId);
    _handleLiveRideSuccess(context);
  }

  Future<void> getNearByDrivers() async {
    final stateData = context.read<BookRideRealTimeDataBaseCubit>().state;
    await context.read<DriverNearByCubit>().getNearbyDrivers(
        checkRestart: false,
        pickupLat: double.parse(stateData.pickupAddressLatitude),
        pickupLng: double.parse(stateData.pickupAddressLongitude),
        vehicleTypeId: widget.selectedVehicleData["id"].toString(),
        distance: double.parse(
            context.read<LocationAccuracyThresholdCubit>().state.value ?? "3"));
  }

  bool isInilize = false;
  Future<void> _initializeRideRequest(
      {required List<Map<String, dynamic>> nearbyDrivers,
      required bool checkRestart}) async {
    final stateData = context.read<BookRideRealTimeDataBaseCubit>().state;
    final rideRequestData = context.read<RideRequestCubit>().state;
    if (checkRestart == true) {
      rideId = rideRequestData.rideId;
    } else {
      if (isInilize) return;
      isInilize = true;
      rideId = FirebaseFirestore.instance.collection('temp').doc().id;
    }
    try {
      await context.read<RideRequestCubit>().createDriverData(
          rideId: rideId,
          checkRestart: checkRestart,
          durationForSearch: int.parse(
              context.read<DriverSearchIntervalCubit>().state.value ?? "60"),
          routeDistance: widget.selectedVehicleData["distance"].toString(),
          context: context,
          nearbyDrivers: nearbyDrivers,
          userId: stateData.userId.toString(),
          userName: stateData.userName,
          pickupLat: double.parse(stateData.pickupAddressLatitude),
          pickupLng: double.parse(stateData.pickupAddressLongitude),
          pickupAddress: stateData.pickupAddress,
          dropoffLat: double.parse(stateData.dropoffAddressLatitude),
          dropoffLng: double.parse(stateData.dropoffAddressLongitude),
          userPhoneNumber: loginModel!.data!.phone!,
          dropoffAddress: stateData.dropoffAddress,
          travelCharges: widget.selectedVehicleData["fare"].toString(),
          routeStatus: "pending",
          userImageUrl: myImage,
          totalTime: widget.selectedVehicleData["duration"].toString());
      setState(() {
        pickLat = double.parse(stateData.pickupAddressLatitude);
        pickLng = double.parse(stateData.pickupAddressLongitude);
        dropLat = double.parse(stateData.dropoffAddressLatitude);
        dropLng = double.parse(stateData.dropoffAddressLongitude);
        driverLat = stateData.acceptedDriverLat;
        driverLng = stateData.acceptedDriverLng;
      });
    } catch (e) {
      showErrorToastMessage("Failed to send ride request.");
    }
  }

  void setAllLatLang() {
    final stateData = context.read<BookRideRealTimeDataBaseCubit>().state;
    setState(() {
      pickLat = double.parse(stateData.pickupAddressLatitude);
      pickLng = double.parse(stateData.pickupAddressLongitude);
      dropLat = double.parse(stateData.dropoffAddressLatitude);
      dropLng = double.parse(stateData.dropoffAddressLongitude);
      driverLat = context.read<RideRequestCubit>().state.acceptedDriverLat;
      driverLng = context.read<RideRequestCubit>().state.acceptedDriverLng;
    });
  }

  Future<void> _updateRide(
      {required String updatedRideId, required String upDatedBookingId}) async {
    if (updatedRideId.isEmpty || upDatedBookingId.isEmpty) {
      return;
    }

    final rideRequestRef =
        FirebaseDatabase.instance.ref().child("ride_requests");
    try {
      await rideRequestRef.child(updatedRideId).update({
        'bookingId': upDatedBookingId,
        'status': 'accepted',
      });
    } catch (error) {
      // showErrorToastMessage("Failed to update ride.");
    }
  }

  // MARKER MANAGEMENT
  void _addUserMarker() {
    if (pickLat != 0.0 && pickLng != 0.0) {
      context.read<UserMarkerCubitMapbox>().addOrUpdateMarker(
            point: Point(
                coordinates: Position(pickLng, pickLat)), // ✅ Correct syntax
            title: 'User Location',
            markerId: 'user_marker',
            iconPath: 'assets/images/pickupmarker.png', // ✅ Local image path
            size: 50,
          );
    }
  }

  void _addDropMarker() {
    if (dropLat != 0.0 && dropLng != 0.0) {
      context.read<UserMarkerCubitMapbox>().addOrUpdateMarker(
            point: Point(
                coordinates: Position(dropLng, dropLat)), // ✅ Correct syntax
            title: 'Drop Location',
            markerId: 'drop_marker',
            iconPath: 'assets/images/dropmarker.png',
            size: 50,
          );
    }
  }

  void _addDriverMarker() {
    final rideRequestState = context.read<RideRequestCubit>().state;
    final lat = rideRequestState.acceptedDriverLat;
    final lng = rideRequestState.acceptedDriverLng;
    context.read<UserMarkerCubitMapbox>().addOrUpdateMarker(
          point:
              Point(coordinates: Position(lng, lat)), // ✅ (longitude, latitude)
          title: 'Driver Location',
          markerId: 'driver_marker',
          iconPath: 'assets/images/car_marker.png',
          size: 120,
        );
  }

  // POLYLINE MANAGEMENT
  void _fetchPolylines() {
    final rideRequestState = context.read<RideRequestCubit>().state;
    final sourceLat = rideRequestState.acceptedDriverLat;
    final sourceLng = rideRequestState.acceptedDriverLng;
    if (pickLat != 0.0 && pickLng != 0.0) {
      context.read<GetPolylineMapBoxCubit>().getPolylineMapbox(
            sourcelat: sourceLat,
            sourcelng: sourceLng,
            destinationlat: pickLat,
            destinationlng: pickLng,
            isPickupRoute: true,
          );
    }
  }

  // DISTANCE AND TIME CALCULATION (Same as before)
  Future<void> _fetchDistanceAndTime({
    required double fromLat,
    required double fromLng,
    required double toLat,
    required double toLng,
    required bool beforePickUp,
  }) async {
    if (fromLat == 0.0 || fromLng == 0.0 || toLat == 0.0 || toLng == 0.0) {
      return;
    }
    bool useGoogleApi = false;
    if (beforePickUp &&
        context.read<UseGoogleBeforePickupCubit>().state.value.toString() ==
            "1") {
      useGoogleApi = true;
    } else if (beforePickUp == false &&
        context.read<UseGoogleAfterPickupCubit>().state.value.toString() ==
            "1") {
      useGoogleApi = true;
    }
    if (useGoogleApi) {
      final url =
          'https://maps.googleapis.com/maps/api/distancematrix/json?origins=$toLat,$toLng&destinations=$fromLat,$fromLng&key=${Config.googleKey}';
      try {
        final response = await http.get(Uri.parse(url));
        if (response.statusCode == 200) {
          final data = json.decode(response.body);
          if (data['rows']?.isNotEmpty == true &&
              data['rows'][0]['elements'][0]['status'] == 'OK') {
            setState(() {
              fetchDistance =
                  data['rows'][0]['elements'][0]['distance']['text'];
              fetchDuration =
                  data['rows'][0]['elements'][0]['duration']['text'];
            });
          }
        }
      } catch (e) {
      }
    } else {
      final meters = Geolocator.distanceBetween(fromLat, fromLng, toLat, toLng);
      final pretty = _formatDistanceAndEta(meters, avgSpeedKmph: 40);
      setState(() {
        fetchDistance = pretty['distanceText'] ?? "";
        fetchDuration = pretty['durationText'] ?? "";
      });
    }
  }

  Map<String, String> _formatDistanceAndEta(double meters,
      {double avgSpeedKmph = 40}) {
    final km = meters / 1000.0;
    final hours = km / avgSpeedKmph;
    final mins = (hours * 60).round().clamp(1, 999);
    final distanceText = km >= 1
        ? '${km.toStringAsFixed(km < 10 ? 1 : 0)} km'
        : '${meters.toStringAsFixed(0)} m';
    final durationText =
        mins >= 60 ? '${(mins ~/ 60)} hr ${mins % 60} min' : '$mins min';
    return {
      'distanceText': distanceText,
      'durationText': durationText,
    };
  }

  // TIMER MANAGEMENT (Same as before)
  Timer? _distanceTimer;
  double updatedDriverLat = 0.0;
  double updatedDriverLng = 0.0;

  void startAutoDistanceTimer() {
    _distanceTimer?.cancel();
    _distanceTimer = Timer.periodic(
        Duration(
            seconds: int.parse(
                context.read<MinimumHitsTimeToUpdateTime>().state.value ??
                    "60")), (timer) {
      if (rideStatus == "ongoing") {
        stopAutoDistanceTimer();
        return;
      }
      _fetchDistanceAndTime(
        fromLat: double.parse(context
            .read<BookRideRealTimeDataBaseCubit>()
            .state
            .pickupAddressLatitude),
        fromLng: double.parse(context
            .read<BookRideRealTimeDataBaseCubit>()
            .state
            .pickupAddressLongitude),
        toLat: updatedDriverLat,
        toLng: updatedDriverLng,
        beforePickUp: true,
      );
    });
  }

  void startAutoDistanceTimerForDropOff() {
    _distanceTimer?.cancel();
    _distanceTimer = Timer.periodic(
        Duration(
            seconds: int.parse(
                context.read<MinimumHitsTimeToUpdateTime>().state.value ??
                    "60")), (timer) {
      if (rideStatus == "complete") {
        stopAutoDistanceTimer();
        return;
      }
      _fetchDistanceAndTime(
        fromLat: updatedDriverLat,
        fromLng: updatedDriverLng,
        toLat: double.parse(context
            .read<BookRideRealTimeDataBaseCubit>()
            .state
            .dropoffAddressLatitude),
        toLng: double.parse(context
            .read<BookRideRealTimeDataBaseCubit>()
            .state
            .dropoffAddressLongitude),
        beforePickUp: false,
      );
    });
  }

  void stopAutoDistanceTimer() {
    _distanceTimer?.cancel();
  }

  // DRIVER LOCATION TRACKING
  void _fetchDriverLocationFromRealtimeDB(String rideId) async {
    try {
      if (rideId.isEmpty) return;
      final snapshot = await FirebaseDatabase.instance
          .ref()
          .child('ride_requests')
          .child(rideId)
          .child('driverLocation')
          .once();
      final locationData = snapshot.snapshot.value as Map?;
      if (locationData == null) return;
      final newLat = locationData['lat']?.toDouble();
      final newLng = locationData['lng']?.toDouble();
      updatedDriverLat = newLat ?? updatedDriverLat;
      updatedDriverLng = newLng ?? updatedDriverLng;
      if (newLat == null || newLng == null) return;
      _trackingController.onNewLocation(newLat, newLng);
    } catch (e) {
    }
  }

  void _updateDriverMarkerPosition(double lat, double lng,
      {double? bearingDegrees}) {
    final markerCubit = context.read<UserMarkerCubitMapbox>();
    markerCubit.updateMarkerPosition(
      'driver_marker',
      Point(coordinates: Position(lng, lat)),
      bearingDegrees: bearingDegrees,
    );
  }

  void _onMapCreated(MapboxMap mapboxMap) async {
    this.mapboxMap = mapboxMap;
    context.read<GetPolylineMapBoxCubit>().setMapController(mapboxMap);
    context.read<UserMarkerCubitMapbox>().setMapController(mapboxMap);
    final bookRideState = context.read<BookRideRealTimeDataBaseCubit>().state;
    final double pickupLng =
        double.tryParse(bookRideState.pickupAddressLongitude) ?? 0.0;
    final double pickupLat =
        double.tryParse(bookRideState.pickupAddressLatitude) ?? 0.0;
    _isProgrammaticCameraMove = true;
    if (pickupLat == 0.0 || pickupLng == 0.0) {
      await mapboxMap.easeTo(
        CameraOptions(
          center: Point(coordinates: Position(77.2090, 28.6139)),
          zoom: 15.0,
          pitch: 0,
          bearing: 0,
        ),
        MapAnimationOptions(duration: 1500, startDelay: 0),
      );
      _isProgrammaticCameraMove = false;
      return;
    }
    await mapboxMap.easeTo(
      CameraOptions(
        center: Point(coordinates: Position(pickupLng, pickupLat)),
        zoom: 15.0,
        pitch: 0,
        bearing: 0,
      ),
      MapAnimationOptions(duration: 1500, startDelay: 0),
    );
    _isProgrammaticCameraMove = false;
    if (otp.isNotEmpty || rideStatus.isNotEmpty) {
      await Future.delayed(const Duration(milliseconds: 1000));
      await _fitCameraToRoute();
    }
  }

  Future<void> _fitCameraToRoute() async {
    if (mapboxMap == null) return;

    if (rideStatus != "ongoing" && _fitOnAccepted) {
      _fitOnAccepted = false;
      await Future.delayed(const Duration(milliseconds: 500));
      await moveMapAccordingPoline();
      setState(() {});
    } else if (rideStatus == "ongoing" && _fitOnOngoing && otp.isNotEmpty) {
      _fitOnOngoing = false;
      await Future.delayed(const Duration(milliseconds: 500));
      await moveMapAccordingPoline();
    }
  }

  Future<void> moveMapAccordingPoline() async {
    if (mapboxMap == null) return;

    try {
      final polyState = context.read<GetPolylineMapBoxCubit>().state;
      final Set<PolylineAnnotation> polylines;
      if (polyState is GetPolylineMapBoxUpdated) {
        polylines = polyState
            .polylines; // Adjust field name if different (e.g., state.polylines)
      } else {
        polylines = {};
      }

      final polylinePoints = <Point>[];
      for (var polyline in polylines) {
        final lineString = polyline.geometry;
        for (final coord in lineString.coordinates) {
          polylinePoints.add(Point(coordinates: coord));
        }
      }

      final markerPositions = <Point>[];
      final firstPolyline = polylines.first;
      final coords = firstPolyline.geometry.coordinates;
      if (coords.isNotEmpty) {
        markerPositions.add(Point(coordinates: coords.first));
        markerPositions.add(Point(coordinates: coords.last));
      }

      final allPoints = [...polylinePoints, ...markerPositions];

      if (allPoints.isNotEmpty) {
        final bounds = _createBounds(allPoints);
        final camera = await mapboxMap!.cameraForCoordinateBounds(
          bounds,
          MbxEdgeInsets(
            top: 150,
            bottom: 300,
            left: 100,
            right: 100,
          ),
          0,
          25,
          140,
          ScreenCoordinate(x: 0, y: 0),
        );
        _isProgrammaticCameraMove = true;
        await mapboxMap!.flyTo(
          camera,
          MapAnimationOptions(duration: 1000),
        );
        _isProgrammaticCameraMove = false;
      }
    } catch (e) {
      // Silent error handling
    }
  }

  void _onMapboxCameraChange(CameraChangedEventData data) {
    if (!_isProgrammaticCameraMove && _isFollowingDriver) {
      setState(() {
        _isFollowingDriver = false;
      });
    }
  }

  Future<void> _recenterOnDriver() async {
    if (mapboxMap == null || !_trackingController.hasPosition) return;
    final pos = _trackingController.actualPosition!;
    _isProgrammaticCameraMove = true;
    await mapboxMap!.easeTo(
      CameraOptions(
        center: Point(coordinates: Position(pos.lng, pos.lat)),
        zoom: 16.0,
      ),
      MapAnimationOptions(duration: 800),
    );
    _isProgrammaticCameraMove = false;
    setState(() {
      _isFollowingDriver = true;
    });
  }

  CoordinateBounds _createBounds(List<Point> points) {
    double? x0, x1, y0, y1; // x0=minLat, x1=maxLat, y0=minLng, y1=maxLng

    for (Point point in points) {
      final lat = point.coordinates.lat.toDouble();
      final lng = point.coordinates.lng.toDouble();

      if (x0 == null) {
        x0 = x1 = lat;
        y0 = y1 = lng;
      } else {
        if (lat < x0) x0 = lat;
        if (lat > x1!) x1 = lat;
        if (lng < y0!) y0 = lng;
        if (lng > y1!) y1 = lng;
      }
    }

    // Add small padding for better visibility
    const padding = 0.001; // ~100m
    x0 = (x0! - padding).clamp(-90.0, 90.0);
    x1 = (x1! + padding).clamp(-90.0, 90.0);
    y0 = (y0! - padding).clamp(-180.0, 180.0);
    y1 = (y1! + padding).clamp(-180.0, 180.0);

    return CoordinateBounds(
        southwest: Point(
          coordinates: Position(y0, x0), // lng, lat
        ),
        northeast: Point(
          coordinates: Position(y1, x1), // lng, lat
        ),
        infiniteBounds: false);
  }

  CoordinateBounds calculateBounds(List<Position> coordinates) {
    double minLng = coordinates.first.lng.toDouble();
    double maxLng = coordinates.first.lng.toDouble();
    double minLat = coordinates.first.lat.toDouble();
    double maxLat = coordinates.first.lat.toDouble();
    for (final coord in coordinates) {
      if (coord.lng < minLng) minLng = coord.lng.toDouble();
      if (coord.lng > maxLng) maxLng = coord.lng.toDouble();
      if (coord.lat < minLat) minLat = coord.lat.toDouble();
      if (coord.lat > maxLat) maxLat = coord.lat.toDouble();
    }
    return CoordinateBounds(
        southwest: Point(coordinates: Position(minLng, minLat)),
        northeast: Point(coordinates: Position(maxLng, maxLat)),
        infiniteBounds: false);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        backgroundColor: notifires.getbgcolor,
        body: Stack(
          children: [
            _buildMapSection(),
            MultiBlocListener(
              listeners: [
                BlocListener<GetRideRequestStatusCubit, String>(
                    listener: (context, status) {
                  if (status == "rejected") {
                    box.delete("rideId");
                    shared.showDriverCancelledRideDialog(context);
                    return;
                  }
                  setState(() => rideStatus = status);

                  if (rideStatus.toString() == "ongoing") {
                    _handleLiveRideSuccess(context);
                  } else if (status == "completed") {
                    stopAutoDistanceTimer();
                    fetchTimer?.cancel();
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => RiderPaymentScreen(
                          bookingId: bookingId,
                          rideId: rideId,
                          fare: widget.selectedVehicleData["fare"] ?? 00,
                          paymentUrl: paymentUrl,
                        ),
                      ),
                    );
                  }
                }),
                BlocListener<DriverNearByCubit, DriverNearByState>(
                    listener: (context, state) {
                  if (state is DriverUpdated) {
                    if (state.nearbyDrivers!.isEmpty) {
                      context
                          .read<DriverNearByCubit>()
                          .resetNearByDriverState();
                      return;
                    }

                    context.read<RideRequestCubit>().updateNearByDrivers(
                        nearbyDrivers: state.nearbyDrivers);
                    _initializeRideRequest(
                        nearbyDrivers: state.nearbyDrivers!,
                        checkRestart: state.checkRestart!);

                    context.read<DriverNearByCubit>().resetNearByDriverState();
                  }

                  if (state is DriverError) {}
                }),
                // FIXED: Polyline listener - only fit if flagged
                BlocListener<GetPolylineMapBoxCubit, GetPolylineMapBoxState>(
                  listener: (context, state) {
                    if (state is GetPolylineMapBoxUpdated) {
                      _fitCameraToRoute(); // Will check flags internally
                    }
                  },
                ),
              ],
              child: BlocBuilder<RideRequestCubit, RideRequestState>(
                builder: (context, rideRequestState) {
                  if (rideRequestState.isSubmitting &&
                      // ignore: unrelated_type_equality_checks
                      rideRequestState.selectedDriverId != 0) {
                    _handleRideBooking(context, rideRequestState);
                  }
                  if (rideRequestState.rideMessage.isNotEmpty) {
                    showErrorToastMessage(rideRequestState.rideMessage);
                    context.read<RideRequestCubit>().removeRideMessage();
                  }

                  return BlocBuilder<BookRideUserCubit, BookRideUserState>(
                    builder: (context, bookRideState) {
                      if (bookRideState is BookRideUserSuccess &&
                          bookRideState.pikupOtp != null) {
                        context
                            .read<GetRideRequestStatusCubit>()
                            .listenToRouteStatus(
                                rideId: bookRideState.rideId.toString());
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          paymentUrl = bookRideState.paymentUrl ?? "";
                          box.put("payment_url", paymentUrl);
                          _handleBookRideSuccess(
                              context,
                              bookRideState.pikupOtp.toString(),
                              bookRideState.dropOtp.toString(),
                              bookRideState.rideId.toString(),
                              bookRideState.bookingId.toString());
                        });
                        context.read<BookRideUserCubit>().removeBookRideState();
                      } else if (bookRideState is BookRideUserFailure) {
                        showErrorToastMessage(
                            bookRideState.error ?? "Failed to book ride.");
                        context.read<BookRideUserCubit>().removeBookRideState();
                        box.delete("ride_data");
                        cancelRideRequest(
                            rideId:
                                context.read<RideRequestCubit>().state.rideId);
                      }

                      return _buildDraggableSheet(context);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // MAP SECTION - UPDATED FOR MAPBOX
  Widget _buildMapSection() {
    final rideState = context.read<BookRideRealTimeDataBaseCubit>().state;

    // Safely parse latitude and longitude
    final double latitude = double.tryParse(rideState.pickupAddressLatitude) ??
        28.6139; // default Delhi
    final double longitude =
        double.tryParse(rideState.pickupAddressLongitude) ?? 77.2090;

    return Positioned(
      bottom: 300,
      left: 0,
      right: 0,
      top: 0,
      child: Stack(
        alignment: Alignment.center,
        children: [
          PersistentMapboxMap(
            onMapCreated: _onMapCreated,
            onCameraChangeListener: _onMapboxCameraChange,
            initialCenter:
                Position(longitude, latitude), // ✅ Fixed: (lng, lat) order
            initialZoom: 15.0,
          ),
          if (otp.isEmpty) const shared.PulsingCircle(),
          if (!_isFollowingDriver && _trackingController.hasPosition)
            Positioned(
              bottom: 16,
              right: 16,
              child: shared.buildMapActionButton(
                icon: Icons.my_location_rounded,
                onTap: _recenterOnDriver,
              ),
            ),
        ],
      ),
    );
  }

  final DraggableScrollableController _draggableController =
      DraggableScrollableController();

  Widget _buildDraggableSheet(BuildContext context) {
    return DraggableScrollableSheet(
      controller: _draggableController,
      initialChildSize: 0.55,
      minChildSize: 0.55,
      maxChildSize: 0.80,
      builder: (context, scrollController) {
        return SafeArea(
          bottom: false,
          child: Stack(
            children: [
              rideStatus == "ongoing"
                  ? const SosButtonWidget()
                  : const SizedBox(),
              Positioned.fill(
                top: 55,
                child: Container(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 40),
                  decoration: BoxDecoration(
                    color: notifires.getbgcolor,
                    borderRadius:
                        const BorderRadius.vertical(top: Radius.circular(32)),
                    boxShadow: [
                      BoxShadow(
                        color: themeColor.withValues(alpha: 0.14),
                        blurRadius: 24,
                        spreadRadius: 2,
                        offset: const Offset(0, -6),
                      ),
                    ],
                  ),
                  child: ListView(
                    controller: scrollController,
                    padding: const EdgeInsets.only(bottom: 26),
                    children: [
                      shared.buildDragHandleCompact(),
                      const SizedBox(height: 10),
                      if (rideStatus == "accepted")
                        _buildDriverInfoSection(context)
                      else if (otp.isEmpty)
                        _buildFindingDriverSection(context)
                      else
                        _buildDriverInfoSection(context),
                      const SizedBox(height: 14),
                      _buildBookingDetails(context),
                      _buildRideDetails(context),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildFindingDriverSection(BuildContext context) {
    return FindingDriverSection(statusOfRide: widget.statusOfRide);
  }

  Widget _buildDriverInfoSection(BuildContext context) {
    return DriverInfoSection(
      rideStatus: rideStatus,
      fetchDistance: fetchDistance,
      fetchDuration: fetchDuration,
      otp: otp,
      dropotp: dropotp,
      unreadCountStream: () =>
          getUnreadCount(rideId, loginModel?.data?.id.toString() ?? ""),
      onChatTap: (state) {
        goTo(
          RideChatScreen(
            myId: loginModel?.data?.id.toString() ?? "",
            myType: "user",
            rideId: rideId,
            driverImage: state.acceptedDriverImageUrl,
            driverName: state.acceptedDriverName,
            driverPlayerId: state.accepteDriverPlayerId.isEmpty
                ? context
                    .read<BookRideRealTimeDataBaseCubit>()
                    .state
                    .driverPlayerId
                : state.accepteDriverPlayerId,
          ),
        );
      },
      onCallTap: (phone) async {
        final Uri launchUri = Uri(scheme: 'tel', path: phone);

        if (await canLaunchUrl(launchUri)) {
          await launchUrl(launchUri);
        }
      },
    );
  }

  Widget _buildBookingDetails(BuildContext context) {
    return const BookingDetailsSection();
  }

  Widget _buildRideDetails(BuildContext context) {
    return RideDetailsSection(
      rideStatus: rideStatus,
      selectedVehicleData: widget.selectedVehicleData,
      onConfirmCancel: () async {
        isManuallyCancelled = true;
        box.delete("ride_data");
        if (bookingId.isNotEmpty) {
          context.read<UpdateRideStatusInDatabaseCubit>().updateRideStatus(
                context: context,
                bookingId: bookingId,
                rideStatus: "Cancelled",
              );
        }
        cancelRideRequest(
            rideId: context.read<RideRequestCubit>().state.rideId);
        if (widget.statusOfRide.isEmpty) {
          Navigator.pop(context);
          Navigator.pop(context);
        } else {
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (context) => const ItemHomeScreen()),
            (Route<dynamic> route) => false,
          );
          stopAutoDistanceTimer();
        }
      },
    );
  }

  bool isRideBooking = false;

  void _handleRideBooking(BuildContext context, RideRequestState state) {
    if (isRideBooking) return;
    isRideBooking = true;
    final stateData = context.read<BookRideRealTimeDataBaseCubit>().state;
    final selectedItemTypeId = widget.selectedVehicleData["id"];
    final formattedDate = DateFormat('yyyy-MM-dd').format(DateTime.now());
    context.read<BookRideUserCubit>().bookRide(
          context: context,
          itemId: state.itemId,
          serviceTypeId: widget.selectedVehicleData["serviceTypeId"].toString(),
          totalFare: widget.selectedVehicleData["fare"].toString(),
          rideId: state.rideId,
          date: formattedDate,
          itemTypeId: selectedItemTypeId,
          estimatedDistance: widget.selectedVehicleData["distance"].toString(),
          pickupAddress: stateData.pickupAddress,
          pickupLat: stateData.pickupAddressLatitude,
          pickupLng: stateData.pickupAddressLongitude,
          dropOffAddress: stateData.dropoffAddress,
          dropOffLat: stateData.dropoffAddressLatitude,
          dropOffLng: stateData.dropoffAddressLongitude,
          driverId: state.selectedDriverId.toString(),
          paymentMethod: "Cash",
        );
  }

  // FIXED: Updated handlers to remove redundant fit calls (flags handle it)
  void _handleBookRideSuccess(BuildContext context, String pikupOtp,
      String dropOtp, String rideID, String bookingID) {
    context
        .read<GetRideRequestStatusCubit>()
        .listenToRouteStatus(rideId: rideID.toString());
    _fetchDriverLocationFromRealtimeDB(rideID);

    if (isSuccessFirst) return;

    isSuccessFirst = true;
    fetchTimer?.cancel();
    fetchTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      _fetchDriverLocationFromRealtimeDB(rideID);
    });
    _updateRide(updatedRideId: rideID, upDatedBookingId: bookingID.toString());

    box.put("PickOtp", pikupOtp);
    box.put("DropOtp", dropOtp);
    box.put("bookingId", bookingID);

    if (widget.statusOfRide == "accepted" || widget.statusOfRide == "pick_up") {
      paymentUrl = box.get("payment_url") ?? "";
    }

    otp = pikupOtp;
    dropotp = dropOtp;
    bookingId = bookingID.toString();
    rideId = rideID.toString();
    _addUserMarker();
    _addDriverMarker();
    _fetchDistanceAndTime(
        fromLat: double.parse(context
            .read<BookRideRealTimeDataBaseCubit>()
            .state
            .pickupAddressLatitude),
        fromLng: double.parse(context
            .read<BookRideRealTimeDataBaseCubit>()
            .state
            .pickupAddressLongitude),
        toLat: context.read<RideRequestCubit>().state.acceptedDriverLat,
        toLng: context.read<RideRequestCubit>().state.acceptedDriverLng,
        beforePickUp: true);
    startAutoDistanceTimer();
    _fetchPolylines();
    getUnreadCount(rideId, loginModel?.data?.id.toString() ?? "");
    setState(() {});
    context.read<BookRideUserCubit>().removeBookRideState();
  }

  Stream<int> getUnreadCount(String rideId, String myId) {
    return FirebaseDatabase.instance
        .ref("ride_requests/$rideId/chat/messages")
        .onValue
        .map((event) {
      if (event.snapshot.value == null) return 0;

      Map data = event.snapshot.value as Map;
      int count = 0;

      data.forEach((key, value) {
        if (value["senderId"] != myId && value["seen"] != true) {
          count++;
        }
      });

      return count;
    });
  }

  bool isLiveRide = false;

  // FIXED: Updated handlers to remove redundant fit calls (flags handle it)
  void _handleLiveRideSuccess(BuildContext context) {
    _fetchDriverLocationFromRealtimeDB(rideId);
    if (isLiveRide) return;
    fetchTimer?.cancel();
    fetchTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      _fetchDriverLocationFromRealtimeDB(rideId);
    });
    isLiveRide = true;

    context.read<UserMarkerCubitMapbox>().removeMarker('user_marker');
    _addDropMarker();
    _addDriverMarker();
    _fetchDistanceAndTime(
      fromLat: context.read<RideRequestCubit>().state.acceptedDriverLat,
      fromLng: context.read<RideRequestCubit>().state.acceptedDriverLng,
      toLat: double.parse(context
          .read<BookRideRealTimeDataBaseCubit>()
          .state
          .dropoffAddressLatitude),
      toLng: double.parse(context
          .read<BookRideRealTimeDataBaseCubit>()
          .state
          .dropoffAddressLongitude),
      beforePickUp: false,
    );
    context.read<GetPolylineMapBoxCubit>().getPolylineMapbox(
          sourcelat: context.read<RideRequestCubit>().state.acceptedDriverLat,
          sourcelng: context.read<RideRequestCubit>().state.acceptedDriverLng,
          isPickupRoute: false,
          destinationlat: double.parse(context
              .read<BookRideRealTimeDataBaseCubit>()
              .state
              .dropoffAddressLatitude),
          destinationlng: double.parse(context
              .read<BookRideRealTimeDataBaseCubit>()
              .state
              .dropoffAddressLongitude),
        );
    setState(() {});

    startAutoDistanceTimerForDropOff();
  }

  Future<void> cancelRideRequest({
    required String rideId,
  }) async {
    try {
      if (rideId.isEmpty) {
        throw Exception('Ride ID cannot be empty');
      }

      final DatabaseReference rideRequestsRef =
          FirebaseDatabase.instance.ref().child('ride_requests');

      final rideRef = rideRequestsRef.child(rideId);

      final snapshot = await rideRef.get();

      if (snapshot.exists) {
        final data = snapshot.value as Map;

        String playerId = '';

        if (data["driverPlayerId"] != null &&
            data["driverPlayerId"].toString().trim().isNotEmpty &&
            data["driverPlayerId"].toString() != "null") {
          playerId = data["driverPlayerId"].toString();
        } else if (navigatorKey.currentContext!
            .read<RideRequestCubit>()
            .state
            .accepteDriverPlayerId
            .toString()
            .trim()
            .isNotEmpty) {
          playerId = navigatorKey.currentContext!
              .read<RideRequestCubit>()
              .state
              .accepteDriverPlayerId
              .toString();
        } else {
          playerId = navigatorKey.currentContext!
              .read<BookRideRealTimeDataBaseCubit>()
              .state
              .driverPlayerId
              .toString();
        }

        if (playerId.isNotEmpty && playerId != "null") {
          sendNotificationDirect(
            playerId: playerId,
            title: "❌ Ride Cancelled",
            message: "Rider has cancelled the ride.",
          );
        }
      }

      await rideRef.update({
        'status': 'cancelled',
      });
      final driversRef = FirebaseFirestore.instance.collection('drivers');
      final driverQuery =
          driversRef.where('ride_request.rideId', isEqualTo: rideId);
      final driverSnapshots = await driverQuery.get();

      final matchingDriverCount = driverSnapshots.docs.length;
      for (var doc in driverSnapshots.docs) {
        final driverId = doc.id;
        try {
          await driversRef.doc(driverId).update({
            'ride_request': {}, // Clear ride_request
            'rideStatus': 'available',
          });

          // ignore: empty_catches
        } catch (e) {}
      }

      await rideRef.remove();

      if (matchingDriverCount == 0) {}
    } catch (e) {
      // throw Exception('Failed to cancel ride request: $e');
    }
  }

  @override
  void dispose() {
    fetchTimer?.cancel();
    locationUpdateTimer?.cancel();
    _distanceTimer?.cancel();
    _trackingController.dispose();
    locationUpdateTimer = null;
    fetchTimer = null;
    isCurrentScreenActive = true;
    super.dispose();
  }
}
