import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:http/http.dart' as http;
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
import 'package:ride_on/core/extensions/workspace.dart';
import 'package:ride_on/core/services/config.dart';
import 'package:ride_on/core/utils/common_widget.dart';
import 'package:ride_on/core/utils/theme/project_color.dart';
import 'package:ride_on/core/utils/theme/theme_style.dart';
import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/presentation/cubits/book_ride_cubit.dart';
import 'package:ride_on/presentation/cubits/location/user_current_location_cubit.dart';

class MapBoxPrediction {
  final String id;
  final String description;
  final double lat;
  final double lng;

  MapBoxPrediction({
    required this.id,
    required this.description,
    required this.lat,
    required this.lng,
  });
}

class SearchMapScreenMapbox extends StatefulWidget {
  final String? selectedAddressTitle;
  final bool? checkStatus;
  const SearchMapScreenMapbox(
      {super.key, this.selectedAddressTitle, this.checkStatus});

  @override
  State<SearchMapScreenMapbox> createState() => _SearchMapScreenMapboxState();
}

class _SearchMapScreenMapboxState extends State<SearchMapScreenMapbox> {
  double selectedMapLat = defaultLat;
  double selectedMapLng = defaultLng;
  MapboxMap? mapController;
  TextEditingController textEditingAddressSearchController =
      TextEditingController();
  FocusNode focusNode1 = FocusNode();
  List<MapBoxPrediction> _suggestions = [];
  Timer? _searchDebounce;
  Timer? _debounce;
  String accessToken = Config.mapboxToken;

  PolygonAnnotationManager? _polygonAnnotationManager;
  PolygonAnnotation? _serviceAreaCircle;

  bool _isMapMoving = false;
  bool _isResolvingAddress = false;
  bool _searchFocused = false;

  @override
  void initState() {
    MapboxOptions.setAccessToken(accessToken);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      selectedMapLat = double.parse(context
          .read<BookRideRealTimeDataBaseCubit>()
          .state
          .pickupAddressLatitude);
      selectedMapLng = double.parse(context
          .read<BookRideRealTimeDataBaseCubit>()
          .state
          .pickupAddressLongitude);

      textEditingAddressSearchController.clear();
    });
    focusNode1.addListener(() {
      if (!mounted) return;
      setState(() {
        _searchFocused = focusNode1.hasFocus;
      });
    });
    super.initState();
  }

  Future<void> _onMapCreated(MapboxMap controller) async {
    mapController = controller;
  }

  Future<void> _zoomIn() async {
    if (mapController == null) return;

    final cameraState = await mapController!.getCameraState();
    final newZoom = (cameraState.zoom) + 1.0;

    await mapController!.flyTo(
      CameraOptions(
        center: cameraState.center,
        zoom: newZoom,
      ),
      MapAnimationOptions(duration: 500),
    );
  }

  Future<void> _zoomOut() async {
    if (mapController == null) return;

    final cameraState = await mapController!.getCameraState();
    final newZoom = (cameraState.zoom) - 1.0;

    await mapController!.flyTo(
      CameraOptions(
        center: cameraState.center,
        zoom: newZoom,
      ),
      MapAnimationOptions(duration: 500),
    );
  }

  Future<void> _performSearch(String query) async {
    if (query.isEmpty) {
      setState(() => _suggestions = []);
      return;
    }
    final encodedQuery = Uri.encodeComponent(query);
    final url = Uri.parse(
        'https://api.mapbox.com/geocoding/v5/mapbox.places/$encodedQuery.json?access_token=$accessToken&limit=5&types=address');
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body) as Map<String, dynamic>;
        final features = data['features'] as List<dynamic>? ?? [];
        setState(() {
          _suggestions = features.map<MapBoxPrediction>((feature) {
            final coordinates =
                feature['geometry']['coordinates'] as List<dynamic>;
            final placeName = feature['place_name'] ?? '';
            return MapBoxPrediction(
              id: feature['id'] ?? '',
              description: placeName,
              lat: coordinates[1] as double,
              lng: coordinates[0] as double,
            );
          }).toList();
        });
      } else {
        setState(() => _suggestions = []);
      }
    } catch (e) {
      setState(() => _suggestions = []);
    }
  }

  void moveToMapboxLocation(double lat, double lon) {
    if (mapController == null) return;

    mapController!.flyTo(
      CameraOptions(
        center: Point(
          coordinates: Position(lon, lat),
        ),
        zoom: 14.0,
      ),
      MapAnimationOptions(duration: 1500, startDelay: 0),
    );
  }

  void _onSearchChanged(String query) {
    if (_searchDebounce?.isActive ?? false) _searchDebounce!.cancel();
    _searchDebounce = Timer(const Duration(milliseconds: 500), () {
      _performSearch(query);
    });
  }

  @override
  void dispose() {
    _searchDebounce?.cancel();
    _debounce?.cancel();
    mapController = null;
    focusNode1.dispose();
    textEditingAddressSearchController.dispose();
    super.dispose();
  }

  void _handleSetAddress(BuildContext context) {
    if (textEditingAddressSearchController.text.isNotEmpty) {
      if (widget.checkStatus == true) {
        context
            .read<SelectedAddressCubit>()
            .updateIsSelectePickupdAddress(isCheckedSelectedPickup: true);
        context
            .read<SelectedAddressCubit>()
            .updateIsSelectedDropOffAddress(isCheckedSelectedDropOff: false);
        context
            .read<SelectedAddressCubit>()
            .updateIsCrossIconSelectePickup(icheckedCrossIconPickup: true);
        context.read<SelectedAddressCubit>().pickupAddressController.text =
            textEditingAddressSearchController.text.toString();
        context.read<GetCordinatesCubit>().getCoordinatesUsingMapBox(
            address: textEditingAddressSearchController.text.toString());

        Navigator.of(context).pop();
      } else {
        context
            .read<SelectedAddressCubit>()
            .updateIsSelectePickupdAddress(isCheckedSelectedPickup: false);
        context
            .read<SelectedAddressCubit>()
            .updateIsSelectedDropOffAddress(isCheckedSelectedDropOff: true);
        context
            .read<SelectedAddressCubit>()
            .updateIsCrossIconSelectedDropOff(ischeckedCrossIconDropOff: true);

        context.read<SelectedAddressCubit>().dropOffAddressController.text =
            textEditingAddressSearchController.text.toString();
        context.read<GetCordinatesCubit>().getCoordinatesUsingMapBox(
            address: textEditingAddressSearchController.text.toString());

        if (context
                .read<SelectedAddressCubit>()
                .dropOffAddressController
                .text ==
            context.read<SelectedAddressCubit>().pickupAddressController.text) {
          showErrorToastMessage(
              "Please select different address".translate(context));
          return;
        }
        Navigator.of(context).pop();
      }
    } else {
      showErrorToastMessage("please selected the address".translate(context));
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool isPickup = widget.checkStatus == true;
    final bottomSafe = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: notifires.getbgcolor,
      body: Stack(
        children: [
          // ---- Map ----
          BlocBuilder<UpdateSearchMapAddressCubit, UpdateSearchMapAddressState>(
              builder: (context, state) {
            if (state is UpdateSearchMapAddresSuccess) {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                textEditingAddressSearchController.text =
                    state.currentAddress.toString();
                context.read<UpdateSearchMapAddressCubit>().removeAddress();
                if (_isResolvingAddress && mounted) {
                  setState(() => _isResolvingAddress = false);
                }
              });
            }
            return MapWidget(
              onMapCreated: _onMapCreated,
              cameraOptions: CameraOptions(
                center: Point(
                    coordinates: Position(selectedMapLng, selectedMapLat)),
                zoom: 14,
              ),
              onCameraChangeListener: (CameraChangedEventData data) {
                final cameraState = data.cameraState;
                selectedMapLat = cameraState.center.coordinates.lat.toDouble();
                selectedMapLng = cameraState.center.coordinates.lng.toDouble();

                if (!_isMapMoving) {
                  setState(() => _isMapMoving = true);
                }

                if (_debounce?.isActive ?? false) _debounce!.cancel();

                _debounce = Timer(const Duration(milliseconds: 700), () {
                  if (mounted) {
                    setState(() {
                      _isMapMoving = false;
                      _isResolvingAddress = true;
                    });
                  }
                  context.read<UpdateSearchMapAddressCubit>().removeAddress();
                  context
                      .read<UpdateSearchMapAddressCubit>()
                      .getAddressFromLatLngMapBox(
                          latitude: selectedMapLat, longitude: selectedMapLng);
                });
              },
              mapOptions: MapOptions(
                viewportMode: ViewportMode.DEFAULT,
                pixelRatio: 2,
              ),
            );
          }),

          // ---- Center pin ----
          Positioned.fill(
            child: IgnorePointer(
              child: Align(
                alignment: Alignment.center,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 40),
                  child: AnimatedSlide(
                    duration: const Duration(milliseconds: 180),
                    curve: Curves.easeOut,
                    offset: _isMapMoving ? const Offset(0, -0.08) : Offset.zero,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      margin: EdgeInsets.only(bottom: _isMapMoving ? 6 : 0),
                      child: Image.asset(
                        "assets/images/dropmarker.png",
                        height: 34,
                        width: 34,
                        alignment: Alignment.bottomCenter,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),

          // ---- Floating search header ----
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 16, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        InkWell(
                          onTap: () => Navigator.of(context).pop(),
                          borderRadius: BorderRadius.circular(12),
                          child: Container(
                            height: 46,
                            width: 46,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: whiteColor,
                              borderRadius: BorderRadius.circular(12),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.08),
                                  blurRadius: 12,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Icon(Icons.arrow_back,
                                size: 20, color: blackColor),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            curve: Curves.easeOut,
                            decoration: BoxDecoration(
                              color: whiteColor,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: _searchFocused
                                    ? themeColor
                                    : Colors.transparent,
                                width: 1.3,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(
                                      _searchFocused ? 0.12 : 0.08),
                                  blurRadius: _searchFocused ? 18 : 12,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: TextField(
                              controller: textEditingAddressSearchController,
                              focusNode: focusNode1,
                              onChanged: _onSearchChanged,
                              style: regularBlack(context)
                                  .copyWith(fontSize: 14.5),
                              decoration: InputDecoration(
                                isDense: true,
                                prefixIcon: Icon(
                                  Icons.search_rounded,
                                  color: notifires.getGrey3whiteColor,
                                  size: 21,
                                ),
                                suffixIcon: textEditingAddressSearchController
                                        .text.isNotEmpty
                                    ? InkWell(
                                        onTap: () {
                                          textEditingAddressSearchController
                                              .clear();
                                          setState(() => _suggestions = []);
                                        },
                                        child: Icon(Icons.close_rounded,
                                            size: 18,
                                            color:
                                                notifires.getGrey3whiteColor),
                                      )
                                    : null,
                                hintStyle: regular3(context).copyWith(
                                    color: notifires.getGrey3whiteColor,
                                    fontSize: 14.5),
                                hintText: "Search Address".translate(context),
                                border: InputBorder.none,
                                contentPadding:
                                    const EdgeInsets.symmetric(vertical: 16),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    // ---- Suggestions dropdown ----
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 200),
                      child: _suggestions.isEmpty
                          ? const SizedBox.shrink(key: ValueKey("empty-list"))
                          : Padding(
                              key: const ValueKey("suggestions"),
                              padding: const EdgeInsets.only(top: 8, left: 56),
                              child: Container(
                                constraints:
                                    const BoxConstraints(maxHeight: 280),
                                decoration: BoxDecoration(
                                  color: whiteColor,
                                  borderRadius: BorderRadius.circular(16),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.10),
                                      blurRadius: 16,
                                      offset: const Offset(0, 6),
                                    ),
                                  ],
                                ),
                                child: ListView.separated(
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 6),
                                  shrinkWrap: true,
                                  itemCount: _suggestions.length,
                                  separatorBuilder: (context, index) =>
                                      Container(
                                    height: 1,
                                    margin: const EdgeInsets.symmetric(
                                        horizontal: 14),
                                    color: notifires.getGrey4whiteColor
                                        .withOpacity(0.35),
                                  ),
                                  itemBuilder: (context, index) {
                                    final prediction = _suggestions[index];
                                    return InkWell(
                                      onTap: () {
                                        textEditingAddressSearchController
                                            .text = prediction.description;
                                        setState(() => _suggestions = []);
                                        moveToMapboxLocation(
                                            prediction.lat, prediction.lng);
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 14, vertical: 10),
                                        child: Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Icon(
                                              Icons.location_on_outlined,
                                              color: themeColor,
                                              size: 20,
                                            ),
                                            const SizedBox(width: 10),
                                            Expanded(
                                              child: Text(
                                                prediction.description,
                                                style:
                                                    regular2(context).copyWith(
                                                  color: notifires
                                                      .getwhiteblackColor,
                                                  fontSize: 14,
                                                ),
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // ---- Zoom control ----
          Positioned(
            right: 16,
            bottom: 240 + bottomSafe,
            child: Container(
              decoration: BoxDecoration(
                color: whiteColor,
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.10),
                    blurRadius: 14,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _MapboxControlButton(
                    icon: Icons.add,
                    onTap: _zoomIn,
                  ),
                  Container(
                    height: 1,
                    width: 28,
                    color: notifires.getGrey4whiteColor.withOpacity(0.4),
                  ),
                  _MapboxControlButton(
                    icon: Icons.remove,
                    onTap: _zoomOut,
                  ),
                ],
              ),
            ),
          ),

          // ---- Bottom confirmation panel ----
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              padding: EdgeInsets.fromLTRB(20, 10, 20, 20 + bottomSafe),
              decoration: BoxDecoration(
                color: whiteColor,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(26),
                  topRight: Radius.circular(26),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.10),
                    blurRadius: 24,
                    offset: const Offset(0, -6),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      height: 4,
                      width: 40,
                      margin: const EdgeInsets.only(bottom: 16),
                      decoration: BoxDecoration(
                        color: notifires.getGrey4whiteColor.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  Text(
                    (isPickup ? "Pickup Location" : "Drop-off Location")
                        .translate(context),
                    style: headingBlack(context)
                        .copyWith(fontSize: 15, color: blackColor),
                  ),
                  const SizedBox(height: 10),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 200),
                    child: _isResolvingAddress
                        ? Row(
                            key: const ValueKey("resolving"),
                            children: [
                              SizedBox(
                                height: 15,
                                width: 15,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: themeColor,
                                ),
                              ),
                              const SizedBox(width: 10),
                              Text(
                                "Finding address...".translate(context),
                                style: heading3Grey1(context)
                                    .copyWith(fontSize: 13.5),
                              ),
                            ],
                          )
                        : textEditingAddressSearchController.text.isEmpty
                            ? Column(
                                key: const ValueKey("empty"),
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Choose your location".translate(context),
                                    style: regular2(context).copyWith(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14.5,
                                      color: notifires.getwhiteblackColor,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    "Move the map or search for an address"
                                        .translate(context),
                                    style: heading3Grey1(context)
                                        .copyWith(fontSize: 13),
                                  ),
                                ],
                              )
                            : Row(
                                key: const ValueKey("address"),
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Icon(Icons.location_on,
                                      color: themeColor, size: 20),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      textEditingAddressSearchController.text,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: regular2(context).copyWith(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14.5,
                                        color: notifires.getwhiteblackColor,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                  ),
                  const SizedBox(height: 18),
                  CustomsButtons(
                    text: "Set Address",
                    backgroundColor: themeColor,
                    onPressed: () => _isResolvingAddress
                        ? () {}
                        : _handleSetAddress(context),
                    textColor: blackColor,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MapboxControlButton extends StatefulWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _MapboxControlButton({required this.icon, required this.onTap});

  @override
  State<_MapboxControlButton> createState() => _MapboxControlButtonState();
}

class _MapboxControlButtonState extends State<_MapboxControlButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapCancel: () => setState(() => _pressed = false),
      onTapUp: (_) => setState(() => _pressed = false),
      child: InkWell(
        onTap: widget.onTap,
        child: AnimatedScale(
          duration: const Duration(milliseconds: 120),
          scale: _pressed ? 0.9 : 1,
          child: SizedBox(
            height: 44,
            width: 44,
            child: Icon(widget.icon, size: 20, color: blackColor),
          ),
        ),
      ),
    );
  }
}