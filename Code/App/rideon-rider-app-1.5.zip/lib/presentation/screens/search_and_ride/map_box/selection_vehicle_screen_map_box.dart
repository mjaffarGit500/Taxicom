import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on/app/route_settings.dart';
import 'package:ride_on/core/extensions/workspace.dart';
import 'package:ride_on/core/services/data_store.dart';
 import 'package:ride_on/core/utils/theme/project_color.dart';
import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/presentation/cubits/book_ride_cubit.dart';
import 'package:ride_on/presentation/cubits/location/get_item_price_cubit.dart';
import 'package:ride_on/presentation/cubits/location/get_nearby_drivers_cubit.dart';
import 'package:ride_on/presentation/cubits/realtime/ride_request_cubit.dart';
import 'package:ride_on/presentation/cubits/vehicle_data/get_vehicle_cetgegory_cubit.dart';
import 'package:ride_on/presentation/screens/search_and_ride/map_box/send_ride_request/send_ride_request_screen_map_box.dart';
import 'package:ride_on/presentation/widgets/dialogs/common_dialogs.dart';
import '../ride_custom_widget.dart' as shared;

class SelectionVehicleScreenMapBox extends StatefulWidget {
  final Set<PolylineAnnotation> polylines;
  final List<Map<String, dynamic>> fareList;

  const SelectionVehicleScreenMapBox({
    super.key,
    required this.polylines,
    required this.fareList,
  });

  @override
  State<SelectionVehicleScreenMapBox> createState() =>
      _SelectionVehicleScreenMapBoxState();
}

class _SelectionVehicleScreenMapBoxState
    extends State<SelectionVehicleScreenMapBox> {
  MapboxMap? mapboxMap;
  PolylineAnnotationManager? lineAnnotationManager;
  PointAnnotationManager? pointAnnotationManager;
  double currentZoom = 12;
  int? selectedIdIndex;
  double traveCharge = 0.0;
  int setIndex = -1;
  Map<String, dynamic> selectedVehicleData = {};
  bool isRequestInProgress = false;

 

  @override
  void initState() {
    super.initState();
    selectedIdIndex =
        context.read<VehicleDataUpdateCubit>().state.vehicleSelectedId;
  }

  Future<void> _onMapCreated(MapboxMap mapboxMap) async {
    this.mapboxMap = mapboxMap;
    lineAnnotationManager =
        await mapboxMap.annotations.createPolylineAnnotationManager();
    pointAnnotationManager =
        await mapboxMap.annotations.createPointAnnotationManager();

    await _drawPolyline();
    await _addMarkers();

    await Future.delayed(const Duration(milliseconds: 500));
    await _fitCameraToRoute();
  }

  Future<void> _drawPolyline() async {
    if (lineAnnotationManager == null || widget.polylines.isEmpty) return;
    await lineAnnotationManager!.deleteAll();
    for (var polyline in widget.polylines) {
      final line = PolylineAnnotationOptions(
        geometry: polyline.geometry,
        lineColor: 0xFF0000FF,
        lineWidth: polyline.lineWidth ?? 5.0,
        lineJoin: polyline.lineJoin ?? LineJoin.ROUND,
      );
      await lineAnnotationManager!.create(line);
    }
  }

  Future<void> _addMarkers() async {
    if (mapboxMap == null ||
        widget.polylines.isEmpty ||
        pointAnnotationManager == null) {
      return;
    }

    await pointAnnotationManager!.deleteAll();

    final firstPolyline = widget.polylines.first;
    final geometry = firstPolyline.geometry;
    final coords = geometry.coordinates;

    if (coords.isEmpty) return;

    final pickup = coords.first;
    final drop = coords.last;

    final pickupBytes = await rootBundle.load("assets/images/pickupmarker.png");
    final dropBytes = await rootBundle.load("assets/images/dropmarker.png");

    await pointAnnotationManager!.create(
      PointAnnotationOptions(
        geometry: Point(coordinates: pickup),
        image: pickupBytes.buffer.asUint8List(),
        iconSize: 1.2,
      ),
    );

    await pointAnnotationManager!.create(
      PointAnnotationOptions(
        geometry: Point(coordinates: drop),
        image: dropBytes.buffer.asUint8List(),
        iconSize: 1.2,
      ),
    );
  }

  Future<void> _fitCameraToRoute() async {
    if (widget.polylines.isEmpty || mapboxMap == null) return;
    await moveMapAccordingPoline();
  }

  Future<void> moveMapAccordingPoline() async {
    if (mapboxMap == null || widget.polylines.isEmpty) return;

    try {
      final polylinePoints = <Point>[];
      for (var polyline in widget.polylines) {
        final lineString = polyline.geometry;
        for (final coord in lineString.coordinates) {
          polylinePoints.add(Point(coordinates: coord));
        }
      }

      final markerPositions = <Point>[];
      final firstPolyline = widget.polylines.first;
      final coords = firstPolyline.geometry.coordinates;
      if (coords.isNotEmpty) {
        markerPositions.add(Point(coordinates: coords.first));
        markerPositions.add(Point(coordinates: coords.last));
      }

      final allPoints = [...polylinePoints, ...markerPositions];

      if (allPoints.isNotEmpty) {
        final bounds = _createBounds(allPoints);

        final camera = await mapboxMap!.cameraForCoordinateBounds(
          bounds,
          MbxEdgeInsets(
            top: 150,
            bottom: 300,
            left: 100,
            right: 100,
          ),
          0,
          25,
          140,
          ScreenCoordinate(x: 0, y: 0),
        );

        await mapboxMap!.flyTo(
          camera,
          MapAnimationOptions(duration: 1000),
        );
      }
    } catch (e) {
      // Silent error handling
    }
  }

  CoordinateBounds _createBounds(List<Point> points) {
    double? x0, x1, y0, y1;

    for (Point point in points) {
      final lat = point.coordinates.lat.toDouble();
      final lng = point.coordinates.lng.toDouble();

      if (x0 == null) {
        x0 = x1 = lat;
        y0 = y1 = lng;
      } else {
        if (lat < x0) x0 = lat;
        if (lat > x1!) x1 = lat;
        if (lng < y0!) y0 = lng;
        if (lng > y1!) y1 = lng;
      }
    }

    return CoordinateBounds(
        southwest: Point(
          coordinates: Position(y0!, x0!),
        ),
        northeast: Point(
          coordinates: Position(y1!, x1!),
        ),
        infiniteBounds: false);
  }

  Future<void> _zoomIn() async {
    if (mapboxMap == null) return;
    currentZoom = (currentZoom + 1).clamp(5.0, 18.0);
    await mapboxMap?.setCamera(CameraOptions(zoom: currentZoom));
  }

  Future<void> _zoomOut() async {
    if (mapboxMap == null) return;
    currentZoom = (currentZoom - 1).clamp(5.0, 18.0);
    await mapboxMap?.setCamera(CameraOptions(zoom: currentZoom));
  }

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      body: Stack(
        children: [
          Positioned(
            left: 0,
            right: 0,
            top: 0,
            bottom: 130,
            child: MapWidget(
              key: const ValueKey("mapbox_map"),
              onMapCreated: _onMapCreated,
              styleUri: MapboxStyles.MAPBOX_STREETS,
            ),
          ),
          Positioned(
            top: 60,
            left: 20,
            child: GestureDetector(
              onTap: () {
                Navigator.pop(context);
              },
              child: Container(
                height: 34,
                width: 34,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(9),
                  color: notifires.getbgcolor,
                  border: Border.all(color: notifires.getGrey3whiteColor),
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 4),
                  child: Icon(
                    Icons.arrow_back,
                    size: 15,
                    color: notifires.getwhiteblackColor,
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            top: 60,
            right: 20,
            child: Column(
              children: [
                _zoomButton(Icons.add, _zoomIn),
                const SizedBox(height: 8),
                _zoomButton(Icons.remove, _zoomOut),
              ],
            ),
          ),
          DraggableScrollableSheet(
            initialChildSize: 0.52,
            minChildSize: 0.42,
            maxChildSize: 0.88,
            builder: (context, scrollController) {
              return Container(
                decoration: BoxDecoration(
                  color: notifires.getbgcolor,
                  borderRadius:
                      const BorderRadius.vertical(top: Radius.circular(28)),
                ),
                child: ListView(
                  controller: scrollController,
                  padding: EdgeInsets.zero,
                  children: [
                    _buildDragHandle(),
                    _buildSheetHeader(context),
                    const SizedBox(height: 10),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: shared.bookingDetailsCard(context),
                    ),
                    const SizedBox(height: 16),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 18),
                      child: Row(
                        children: [
                          Container(
                            width: 4,
                            height: 16,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [themeColor, themeColor],
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                              ),
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            "Available Rides".translate(context),
                            style:   TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: darkBrown,
                              letterSpacing: 0.2,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    ListView.builder(
                      padding: EdgeInsets.zero,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: widget.fareList.length,
                      itemBuilder: (context, index) =>
                          _buildVehicleCard(context, index),
                    ),
                    // Extra space so content is not hidden behind Book Now + system nav
                    SizedBox(
                      height: selectedIdIndex != -1 ? 130 + bottomPadding : 40,
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
      bottomNavigationBar:
          selectedIdIndex != -1 ? _buildBookNowBar(context) : null,
    );
  }

  Widget _buildDragHandle() {
    return Padding(
      padding: const EdgeInsets.only(top: 10, bottom: 5),
      child: Center(
        child: Container(
          width: 44,
          height: 5,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [themeColor, themeColor],
            ),
            borderRadius: BorderRadius.circular(9),
            boxShadow: [
              BoxShadow(
                color: themeColor.withOpacity(0.35),
                blurRadius: 5,
                offset: const Offset(0, 1),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSheetHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 0),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [themeColor, themeColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: themeColor.withOpacity(0.26),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child:   Icon(Icons.local_taxi_rounded,
                size: 15, color: darkBrown),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Choose Your Ride".translate(context),
                style:   TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: darkBrown,
                  letterSpacing: 0.1,
                ),
              ),
              Text(
                "Select a vehicle for your trip".translate(context),
                style:   TextStyle(
                  fontSize: 10,
                  color: accentBrown,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildVehicleCard(BuildContext context, int index) {
    final data = widget.fareList[index];
    final isSelected = selectedIdIndex == data["id"];

    final fares = context.watch<GetDistanceRouteCubit>().state.vehicleFares;
    final hasFares = fares.length > index && fares[index].isNotEmpty;

    final fare = hasFares ? fares[index]["fare"] ?? "NA" : "NA";
    final duration = hasFares ? fares[index]["duration"] ?? "NA" : "NA";
    final distance = hasFares ? fares[index]["distance"] ?? "0" : "0";

    if (isSelected) {
      setIndex = index;
      traveCharge = double.tryParse(fare.toString()) ?? 0.0;
    }

    return GestureDetector(
      onTap: () {
        if (!isSelected) {
          setState(() {
            setIndex = index;
            selectedIdIndex = data["id"]!;
            context
                .read<VehicleDataUpdateCubit>()
                .updateVehicleTypeSelectedId(data["id"]);
          });
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        margin: EdgeInsets.fromLTRB(16, index == 0 ? 2 : 6, 16, 0),
        decoration: BoxDecoration(
          gradient: isSelected
              ?   LinearGradient(
                  colors: [darkBrown, medBrown, accentBrown],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : const LinearGradient(
                  colors: [Colors.white, Color(0xFFFFFBF1)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? themeColor : themeColor.withValues(alpha: .24),
            width: isSelected ? 1.3 : 1.0,
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
        child: Row(
          children: [
            Container(
              width: 58,
              height: 40,
              decoration: BoxDecoration(
                color: isSelected
                    ? Colors.white.withOpacity(0.12)
                    : const Color(0xFFFFF7DC),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isSelected
                      ? Colors.white.withOpacity(0.18)
                      : themeColor.withOpacity(0.22),
                ),
              ),
              padding: const EdgeInsets.all(6),
              child: Builder(builder: (ctx) {
                final imageUrl = (data["image"] ?? "").toString().trim();
                final fallback = SvgPicture.asset(
                  "assets/images/car.svg",
                  colorFilter: ColorFilter.mode(
                    isSelected ? themeColor : accentBrown,
                    BlendMode.srcIn,
                  ),
                );
                if (imageUrl.isEmpty) return fallback;
                return Image.network(
                  imageUrl,
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => fallback,
                );
              }),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    data["vehicleName"] ?? "Unknown".translate(context),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      color: isSelected ? Colors.white : darkBrown,
                    ),
                  ),
                  const SizedBox(height: 3),
                  if (hasFares)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 3),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? Colors.white.withValues(alpha: .10)
                            : themeColor.withValues(alpha: .12),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.schedule_rounded,
                              size: 10,
                              color: isSelected ? softYellow : accentBrown),
                          const SizedBox(width: 3),
                          Flexible(
                            child: Text(
                              "$duration · $distance ${"Km".translate(context)}",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 9,
                                color: isSelected ? softYellow : accentBrown,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(width: 6),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                if (hasFares)
                  Text(
                    "$currency $fare",
                    style: TextStyle(
                      fontSize: 13,
                      color: isSelected ? themeColor : darkBrown,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                if (isSelected) ...[
                  const SizedBox(height: 3),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: themeColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child:  Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.check_circle_rounded,
                            size: 9, color: darkBrown),
                        const SizedBox(width: 2),
                        Text(
                          "Selected",
                          style: TextStyle(
                            fontSize: 9,
                            color: darkBrown,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBookNowBar(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [cream, Colors.white.withOpacity(0.95)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        boxShadow: [
          BoxShadow(
            color: themeColor.withOpacity(0.18),
            blurRadius: 16,
            offset: const Offset(0, -3),
          ),
        ],
      ),
      padding: EdgeInsets.fromLTRB(16, 8, 16, 10 + bottomPadding),
      child: GestureDetector(
        onTap: isRequestInProgress
            ? null
            : () {
                if (selectedIdIndex == -1) {
                  showErrorToastMessage(
                      "Please select a vehicle type.".translate(context));
                  return;
                }
                context.read<BookRideUserCubit>().removeBookRideState();
                context.read<DriverNearByCubit>().resetNearByDriverState();
                context.read<RideRequestCubit>().resetState();
                box.delete("rideId");
                goTo(SendRideRequestScreenMapbox(
                  selectedVehicleData: widget.fareList[setIndex],
                  statusOfRide: "",
                ));
              },
        child: Container(
          height: 44,
          decoration: BoxDecoration(
            gradient: isRequestInProgress
                ? const LinearGradient(
                    colors: [Color(0xFFB0A09A), Color(0xFF9E8880)])
                : LinearGradient(
                    colors: [themeColor, themeColor],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isRequestInProgress ? Colors.transparent : themeColor,
            ),
          ),
          alignment: Alignment.center,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                isRequestInProgress
                    ? Icons.hourglass_top_rounded
                    : Icons.emoji_transportation_rounded,
                color: isRequestInProgress ? Colors.white : darkBrown,
                size: 16,
              ),
              const SizedBox(width: 6),
              Text(
                isRequestInProgress
                    ? "Requesting...".translate(context)
                    : "Book Now".translate(context),
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: isRequestInProgress ? Colors.white : darkBrown,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _zoomButton(IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 37,
        height: 37,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          boxShadow: const [
            BoxShadow(
              color: Colors.black26,
              blurRadius: 5,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Icon(icon, color: themeColor, size: 20),
      ),
    );
  }
}
