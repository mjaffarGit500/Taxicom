import 'package:flutter/material.dart';

const Color kMapboxRideDarkText = Color(0xFF2A1E1A);
const Color kMapboxRideAccentBrown = Color(0xFF8A5A10);
