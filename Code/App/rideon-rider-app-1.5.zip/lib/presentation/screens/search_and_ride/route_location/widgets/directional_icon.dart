import 'package:flutter/material.dart';


class DirectionalIcon extends StatelessWidget {
  final IconData icon;
  final double size;
  final Color color;

  const DirectionalIcon({
    super.key,
    required this.icon,
    required this.size,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final isRtl = Directionality.of(context) == TextDirection.rtl;
    final child = Icon(icon, size: size, color: color);
    if (!isRtl) return child;
    return Transform.flip(flipX: true, child: child);
  }
}
