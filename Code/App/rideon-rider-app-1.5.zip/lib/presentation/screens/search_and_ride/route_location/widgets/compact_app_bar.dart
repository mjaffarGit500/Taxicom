import 'package:flutter/material.dart';
import 'package:ride_on/core/utils/translate.dart';

import 'directional_icon.dart';


class CompactAppBar extends StatelessWidget {
  final bool isSmallPhone;

  const CompactAppBar({
    super.key,
    required this.isSmallPhone,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
        isSmallPhone ? 14 : 18,
        isSmallPhone ? 10 : 14,
        isSmallPhone ? 14 : 18,
        isSmallPhone ? 6 : 8,
      ),
      child: Row(
        children: [
          InkWell(
            borderRadius: BorderRadius.circular(24),
            onTap: () => Navigator.pop(context),
            child: Container(
              height: isSmallPhone ? 36 : 40,
              width: isSmallPhone ? 36 : 40,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Color(0x140C1523),
                    blurRadius: 14,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: const DirectionalIcon(
                icon: Icons.arrow_back_ios_new,
                size: 16,
                color: Color(0xFF202733),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "Choose Location".translate(context),
                  style: TextStyle(
                    fontSize: isSmallPhone ? 15.5 : 17,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF1E2530),
                  ),
                ),
                Text(
                  "Where are you going?".translate(context),
                  style: TextStyle(
                    fontSize: isSmallPhone ? 10.5 : 11.5,
                    color: const Color(0xFF7C8696),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
