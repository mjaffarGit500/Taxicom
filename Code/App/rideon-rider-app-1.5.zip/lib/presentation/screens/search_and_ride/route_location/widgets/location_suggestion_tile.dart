import 'package:flutter/material.dart';

import '../../../../../core/utils/theme/project_color.dart';


List<TextSpan> formatSuggestion(String suggestion) {
  final parts = suggestion.split(',');
  return [
    TextSpan(
      text: parts.first.trim(),
      style: const TextStyle(
        fontSize: 13.5,
        fontWeight: FontWeight.w600,
        color: Color(0xFF1E2530),
      ),
    ),
    if (parts.length > 1)
      TextSpan(
        text: "\n${parts.sublist(1).join(',').trim()}",
        style: const TextStyle(fontSize: 11.5, color: Color(0xFF7C8696)),
      ),
  ];
}


class LocationSuggestionTile extends StatelessWidget {
  final String address;
  final VoidCallback onTap;
  final bool isSmallPhone;

  const LocationSuggestionTile({
    super.key,
    required this.address,
    required this.onTap,
    required this.isSmallPhone,
  });

  @override
  Widget build(BuildContext context) {
    final spans = formatSuggestion(address);
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: 14,
          vertical: isSmallPhone ? 8 : 10,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: isSmallPhone ? 36 : 40,
              width: isSmallPhone ? 36 : 40,
              decoration: BoxDecoration(
                color: themeColor.withOpacity(0.16),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.location_on_rounded,
                color: Color(0xFFB8860B),
                size: 18,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(top: 2),
                child: RichText(
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  text: TextSpan(children: spans),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
