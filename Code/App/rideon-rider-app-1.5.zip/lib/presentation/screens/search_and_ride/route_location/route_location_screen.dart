import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on/app/route_settings.dart';
import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/presentation/cubits/profile/edit_profile_cubit.dart';
import '../../../../core/services/data_store.dart';
import '../../../../core/utils/common_widget.dart';
import '../../../../core/utils/theme/project_color.dart';
import '../../../cubits/book_ride_cubit.dart';
import '../../../cubits/location/user_current_location_cubit.dart';
import '../../../widgets/menu_popup_widget.dart';
import '../loading_nearby_search_screen.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'widgets/compact_app_bar.dart';
import 'widgets/directional_icon.dart';
import 'widgets/location_suggestion_tile.dart';

class UserSearchLocation extends StatefulWidget {
  final String? currentAddress;
  const UserSearchLocation({super.key, this.currentAddress});

  @override
  State<UserSearchLocation> createState() => _UserSearchLocationState();
}

class _UserSearchLocationState extends State<UserSearchLocation> {
  final focusNode1 = FocusNode();
  final focusNode2 = FocusNode();
  bool isPickUp = true;
  bool _isNavigating = false;
  Timer? _debounce;
  @override
  void dispose() {
    _debounce?.cancel();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    final cubit = context.read<SelectedAddressCubit>();
    cubit.pickupAddressController.text = widget.currentAddress ?? "";
    cubit.dropOffAddressController.text = "";
    // box.delete("recent_drop_locations");
    _loadRecentDropLocations();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final cubit = context.read<MapTypeCubit>().state;
      if (cubit.selectedMap.toString() == "google") {
        context.read<GetSuggestionAddressCubit>().getSuggestions("");
      } else if (cubit.selectedMap.toString() == "osm") {
        context.read<GetSuggestionAddressCubit>().getSuggestionUsingOSM("");
      } else if (cubit.selectedMap.toString() == "mapbox") {
        context.read<GetSuggestionAddressCubit>().getSuggestionUsingMapbox("");
      } else if (cubit.selectedMap.toString() == "ola") {
        context.read<GetSuggestionAddressCubit>().getSuggestionUsingOla("");
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final isSmallPhone = size.height < 750 || size.width < 380;
    final contentMaxWidth = size.width > 520 ? 460.0 : double.infinity;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: MultiBlocListener(
            listeners: [
              BlocListener<GetCordinatesCubit, GetCordinatesState>(
                listener: _handleCoordinateUpdate,
              )
            ],
            child: Center(
              child: ConstrainedBox(
                constraints: BoxConstraints(maxWidth: contentMaxWidth),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildCompactAppBar(isSmallPhone),
                    _buildRouteCard(isSmallPhone),
                    Expanded(child: _buildSuggestionsList(isSmallPhone)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _handleCoordinateUpdate(BuildContext context, GetCordinatesState state) {
    final addressCubit = context.read<SelectedAddressCubit>();
    final bookRideCubit = context.read<BookRideRealTimeDataBaseCubit>();

    if (state is GetCordinatesSuccess) {
      final isPickup = addressCubit.state.isCheckedSelectedPickup;

      if (isPickup) {
        bookRideCubit.updatePickupLatAndLng(
          pickupAddressLatitude: state.lattiude.toString(),
          pickupAddressLongitude: state.longitude.toString(),
        );
        focusNode1.unfocus();
      } else {
        bookRideCubit.updateDropOffLatAndLng(
          dropoffAddressLatitude: state.lattiude.toString(),
          dropoffAddressLongitude: state.longitude.toString(),
        );
        focusNode2.unfocus();
      }

      context.read<GetSuggestionAddressCubit>().removeAddress();
      setState(() {
        showButton = true;
      });
      _tryAutoProceed();
    }
  }

  void _tryAutoProceed() {
    if (_isNavigating) return;

    final selected = context.read<SelectedAddressCubit>();
    final bookRide = context.read<BookRideRealTimeDataBaseCubit>();

    final hasPickupText =
        selected.pickupAddressController.text.trim().isNotEmpty;
    final hasDropText =
        selected.dropOffAddressController.text.trim().isNotEmpty;
    final hasPickupLatLng = bookRide.state.pickupAddressLatitude.isNotEmpty &&
        bookRide.state.pickupAddressLongitude.isNotEmpty;
    final hasDropLatLng = bookRide.state.dropoffAddressLatitude.isNotEmpty &&
        bookRide.state.dropoffAddressLongitude.isNotEmpty;

    if (hasPickupText && hasDropText && hasPickupLatLng && hasDropLatLng) {
      _isNavigating = true;
      _proceedToNearbyDrivers();
    }
  }

  Future<void> getCurrentLocationAndAddress() async {
    try {
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        permission = await Geolocator.requestPermission();

        if (permission != LocationPermission.always &&
            permission != LocationPermission.whileInUse) {
          await Geolocator.openAppSettings(); // Prompt user to open settings
          return;
        }
      }

      final position = await Geolocator.getCurrentPosition(
          // ignore: deprecated_member_use
          desiredAccuracy: LocationAccuracy.high);
      final lat = position.latitude;
      final lng = position.longitude;

      List<Placemark> placemarks = await placemarkFromCoordinates(lat, lng);
      Placemark place = placemarks.first;

      String fullAddress = [
        if (place.subThoroughfare != null &&
            place.subThoroughfare!.trim().isNotEmpty)
          place.subThoroughfare,
        if (place.thoroughfare != null && place.thoroughfare!.trim().isNotEmpty)
          place.thoroughfare,
        if (place.subLocality != null && place.subLocality!.trim().isNotEmpty)
          place.subLocality,
        if (place.locality != null && place.locality!.trim().isNotEmpty)
          place.locality,
        if (place.subAdministrativeArea != null &&
            place.subAdministrativeArea!.trim().isNotEmpty)
          place.subAdministrativeArea,
        if (place.administrativeArea != null &&
            place.administrativeArea!.trim().isNotEmpty)
          place.administrativeArea,
        if (place.postalCode != null && place.postalCode!.trim().isNotEmpty)
          place.postalCode,
        if (place.country != null && place.country!.trim().isNotEmpty)
          place.country,
      ].join(", ");

      // ignore: use_build_context_synchronously
      final selectedCubit = context.read<SelectedAddressCubit>();
      // ignore: use_build_context_synchronously
      final bookRide = context.read<BookRideRealTimeDataBaseCubit>();

      selectedCubit.pickupAddressController.text = fullAddress;
      bookRide.updatePickupLatAndLng(
        pickupAddressLatitude: lat.toString(),
        pickupAddressLongitude: lng.toString(),
      );
      bookRide.updatePickupAddress(pickupAddress: fullAddress);

      setState(() {});
      _tryAutoProceed();
    } catch (e) {
      // showErrorToastMessage("Unable to fetch location: $e");
    }
  }

  List<Map<String, String>> recentDropLocations = [];

  void _loadRecentDropLocations() {
    final storedList = box.get('recent_drop_locations', defaultValue: []);
    if (storedList is List) {
      recentDropLocations =
          storedList.map((e) => Map<String, String>.from(e)).toList();
    }
    setState(() {});
  }

  void _addRecentDropLocation(String address, String lat, String lng) {
    recentDropLocations.removeWhere((item) => item['address'] == address);
    recentDropLocations.insert(0, {
      "address": address,
      "lat": lat,
      "lng": lng,
    });

    if (recentDropLocations.length > 5) {
      recentDropLocations = recentDropLocations.sublist(0, 5);
    }

    box.put('recent_drop_locations', recentDropLocations);
  }

  // ==================== UI: Compact AppBar ====================
  Widget _buildCompactAppBar(bool isSmallPhone) {
    return CompactAppBar(isSmallPhone: isSmallPhone);
  }

  // ==================== UI: Route Card (Pickup + Drop) ====================
  Widget _buildRouteCard(bool isSmallPhone) {
    final cubit = context.read<SelectedAddressCubit>();
    bool dropTextFilled = cubit.dropOffAddressController.text.isNotEmpty;

    return Padding(
      padding: EdgeInsets.fromLTRB(
        isSmallPhone ? 14 : 18,
        isSmallPhone ? 6 : 8,
        isSmallPhone ? 14 : 18,
        isSmallPhone ? 10 : 12,
      ),
      child: BlocBuilder<SelectedAddressCubit, SelectedAddressState>(
        builder: (context, state) {
          return Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: const Color(0xFFEFF1F6), width: 1),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF0C1523).withOpacity(0.06),
                  blurRadius: 30,
                  offset: const Offset(0, 14),
                ),
                BoxShadow(
                  color: themeColor.withOpacity(0.08),
                  blurRadius: 40,
                  offset: const Offset(0, 18),
                  spreadRadius: -14,
                ),
              ],
            ),
            padding: EdgeInsets.symmetric(
              horizontal: isSmallPhone ? 8 : 10,
              vertical: isSmallPhone ? 10 : 12,
            ),
            child: Column(
              children: [
                Stack(
                  children: [
                    // Route connector rail, aligned to the field centers.
                    PositionedDirectional(
                      start: isSmallPhone ? 24 : 27,
                      top: isSmallPhone ? 34 : 38,
                      bottom: isSmallPhone ? 34 : 38,
                      child: Container(
                        width: 2,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(2),
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              greentext.withOpacity(0.55),
                              greentext.withOpacity(0.15),
                              Colors.redAccent.withOpacity(0.15),
                              Colors.redAccent.withOpacity(0.55),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Column(
                      children: [
                        _buildPickupField(isSmallPhone),
                        Padding(
                          padding: EdgeInsets.symmetric(
                            horizontal: isSmallPhone ? 8 : 10,
                            vertical: isSmallPhone ? 4 : 6,
                          ),
                          child: Row(
                            children: [
                              SizedBox(width: isSmallPhone ? 40 : 44),
                              Expanded(
                                child: Container(
                                  height: 1,
                                  color: const Color(0xFFF0F2F6),
                                ),
                              ),
                            ],
                          ),
                        ),
                        _buildDropField(
                          dropTextFilled: dropTextFilled,
                          isSmallPhone: isSmallPhone,
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Align(
                  alignment: AlignmentDirectional.centerEnd,
                  child: Padding(
                    padding:
                        const EdgeInsetsDirectional.only(bottom: 4, end: 2),
                    child: selectWithLocation(context: context),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildPickupField(bool isSmallPhone) {
    final cubit = context.read<SelectedAddressCubit>();
    final isActive = isPickUp;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOut,
      padding: EdgeInsets.symmetric(
        horizontal: isSmallPhone ? 8 : 10,
        vertical: isSmallPhone ? 9 : 11,
      ),
      decoration: BoxDecoration(
        color: isActive ? greentext.withOpacity(0.07) : Colors.transparent,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isActive ? greentext.withOpacity(0.28) : Colors.transparent,
          width: 1.2,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Pickup marker badge
          AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            height: isSmallPhone ? 30 : 34,
            width: isSmallPhone ? 30 : 34,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isActive
                  ? greentext.withOpacity(0.16)
                  : const Color(0xFFF3F6F4),
              border: Border.all(
                color: isActive
                    ? greentext.withOpacity(0.4)
                    : const Color(0xFFE3E8E4),
                width: 1.4,
              ),
            ),
            child: Icon(
              Icons.circle,
              size: isSmallPhone ? 9 : 10,
              color: greentext,
            ),
          ),
          SizedBox(width: isSmallPhone ? 10 : 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "PICKUP".translate(context),
                  style: TextStyle(
                    fontSize: isSmallPhone ? 10 : 11,
                    color: const Color(0xFF7C8696),
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.3,
                  ),
                ),
                const SizedBox(height: 2),
                TextFormField(
                  controller: cubit.pickupAddressController,
                  focusNode: focusNode1,
                  maxLines: 1,
                  style: TextStyle(
                    fontSize: isSmallPhone ? 13 : 14,
                    fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
                    color: const Color(0xFF1E2530),
                  ),
                  decoration: InputDecoration(
                    isDense: true,
                    hintText: "Enter pickup location".translate(context),
                    hintStyle: TextStyle(
                      fontSize: isSmallPhone ? 12.5 : 13.5,
                      color: const Color(0xFFA7AEC1),
                    ),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.zero,
                  ),
                  onTap: () {
                    setState(() => isPickUp = true);
                    cubit.updateIsSelectePickupdAddress(
                        isCheckedSelectedPickup: true);
                    cubit.updateIsSelectedDropOffAddress(
                        isCheckedSelectedDropOff: false);
                    context.read<GetSuggestionAddressCubit>().removeAddress();
                  },
                  onChanged: (query) {
                    setState(() {});
                    _onQueryChanged(query);
                  },
                ),
              ],
            ),
          ),
          InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: getCurrentLocationAndAddress,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              padding: EdgeInsets.all(isSmallPhone ? 7 : 8),
              decoration: BoxDecoration(
                color: themeColor.withOpacity(0.18),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: themeColor.withOpacity(0.28),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: const Icon(Icons.my_location_rounded,
                  color: Color(0xFFAD7A00), size: 17),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDropField({
    required bool dropTextFilled,
    required bool isSmallPhone,
  }) {
    final cubit = context.read<SelectedAddressCubit>();
    final isActive = !isPickUp;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOut,
      padding: EdgeInsets.symmetric(
        horizontal: isSmallPhone ? 8 : 10,
        vertical: isSmallPhone ? 9 : 11,
      ),
      decoration: BoxDecoration(
        color:
            isActive ? Colors.redAccent.withOpacity(0.06) : Colors.transparent,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isActive
              ? Colors.redAccent.withOpacity(0.28)
              : Colors.transparent,
          width: 1.2,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Drop-off marker badge
          AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            height: isSmallPhone ? 30 : 34,
            width: isSmallPhone ? 30 : 34,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isActive
                  ? Colors.redAccent.withOpacity(0.14)
                  : const Color(0xFFF6F1F1),
              border: Border.all(
                color: isActive
                    ? Colors.redAccent.withOpacity(0.4)
                    : const Color(0xFFEBE0E0),
                width: 1.4,
              ),
            ),
            child: const Icon(
              Icons.location_on_rounded,
              size: 16,
              color: Colors.redAccent,
            ),
          ),
          SizedBox(width: isSmallPhone ? 10 : 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "DROP-OFF".translate(context),
                  style: TextStyle(
                    fontSize: isSmallPhone ? 10 : 11,
                    color: const Color(0xFF7C8696),
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.3,
                  ),
                ),
                const SizedBox(height: 2),
                TextFormField(
                  controller: cubit.dropOffAddressController,
                  focusNode: focusNode2,
                  maxLines: 1,
                  style: TextStyle(
                    fontSize: isSmallPhone ? 13 : 14,
                    fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
                    color: const Color(0xFF1E2530),
                  ),
                  decoration: InputDecoration(
                    isDense: true,
                    hintText: "Enter drop location".translate(context),
                    hintStyle: TextStyle(
                      fontSize: isSmallPhone ? 12.5 : 13.5,
                      color: const Color(0xFFA7AEC1),
                    ),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.zero,
                  ),
                  onTap: () {
                    setState(() => isPickUp = false);
                    cubit.updateIsSelectePickupdAddress(
                        isCheckedSelectedPickup: false);
                    cubit.updateIsSelectedDropOffAddress(
                        isCheckedSelectedDropOff: true);
                    context.read<GetSuggestionAddressCubit>().removeAddress();
                  },
                  onChanged: (query) {
                    setState(() {});
                    _onQueryChanged(query);
                  },
                ),
              ],
            ),
          ),
          if (dropTextFilled)
            InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: () {
                cubit.dropOffAddressController.clear();
                setState(() {});
                context.read<GetSuggestionAddressCubit>().removeAddress();
              },
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: const BoxDecoration(
                  color: Color(0xFFF1F3F8),
                  shape: BoxShape.circle,
                ),
                child:
                    const Icon(Icons.close, size: 15, color: Color(0xFF7C8696)),
              ),
            ),
        ],
      ),
    );
  }

  void _onQueryChanged(String query) {
    if (_debounce?.isActive ?? false) _debounce!.cancel();
    _debounce = Timer(const Duration(milliseconds: 800), () {
      if (query.length >= 2) {
        final mapCubit = context.read<MapTypeCubit>().state;
        if (mapCubit.selectedMap.toString() == "google") {
          context.read<GetSuggestionAddressCubit>().getSuggestions(query);
        } else if (mapCubit.selectedMap.toString() == "osm") {
          context
              .read<GetSuggestionAddressCubit>()
              .getSuggestionUsingOSM(query);
        } else if (mapCubit.selectedMap.toString() == "mapBox") {
          context
              .read<GetSuggestionAddressCubit>()
              .getSuggestionUsingMapbox(query);
        } else if (mapCubit.selectedMap.toString() == "ola") {
          context
              .read<GetSuggestionAddressCubit>()
              .getSuggestionUsingOla(query);
        }
      }
    });
  }

  bool showButton = true;

  Widget _buildSuggestionsList(bool isSmallPhone) {
    return BlocBuilder<GetSuggestionAddressCubit, GetSuggestionAddressState>(
      builder: (context, state) {
        final suggestions = (state is GetSuggestionAddressSuccess)
            ? state.suggestions ?? []
            : [];

        if (suggestions.isEmpty) {
          return _buildNearbyDriverButton(isSmallPhone);
        }

        return Container(
          margin: EdgeInsets.fromLTRB(
            isSmallPhone ? 14 : 18,
            0,
            isSmallPhone ? 14 : 18,
            isSmallPhone ? 10 : 14,
          ),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: const [
              BoxShadow(
                color: Color(0x140C1523),
                blurRadius: 24,
                offset: Offset(0, 8),
              ),
            ],
          ),
          clipBehavior: Clip.antiAlias,
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(vertical: 6),
            itemCount: suggestions.length,
            separatorBuilder: (_, __) =>
                const Divider(height: 1, indent: 62, color: Color(0xFFF0F2F6)),
            itemBuilder: (_, index) {
              final address = suggestions[index];
              return _buildLocationSuggestion(
                address: address,
                isSmallPhone: isSmallPhone,
                onTap: () {
                  final selectedCubit = context.read<SelectedAddressCubit>();
                  final isPickup = selectedCubit.state.isCheckedSelectedPickup;

                  if (isPickup) {
                    selectedCubit.pickupAddressController.text = address;
                  } else {
                    selectedCubit.dropOffAddressController.text = address;
                  }

                  context.read<GetSuggestionAddressCubit>().removeAddress();
                  context
                      .read<GetCordinatesCubit>()
                      .getCoordinates(address: address);

                  // Refresh UI
                  setState(() {});
                },
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildLocationSuggestion({
    required String address,
    required VoidCallback onTap,
    required bool isSmallPhone,
  }) {
    return LocationSuggestionTile(
      address: address,
      onTap: onTap,
      isSmallPhone: isSmallPhone,
    );
  }

  bool isClicked = false;
  Widget _buildNearbyDriverButton(bool isSmallPhone) {
    final showFindDrivers = context
            .read<SelectedAddressCubit>()
            .pickupAddressController
            .text
            .isNotEmpty &&
        context
            .read<SelectedAddressCubit>()
            .dropOffAddressController
            .text
            .isNotEmpty &&
        showButton;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              if (context
                      .read<SelectedAddressCubit>()
                      .dropOffAddressController
                      .text
                      .isEmpty &&
                  recentDropLocations.isNotEmpty) ...[
                Padding(
                  padding: EdgeInsets.fromLTRB(
                    isSmallPhone ? 20 : 24,
                    isSmallPhone ? 6 : 10,
                    isSmallPhone ? 20 : 24,
                    isSmallPhone ? 4 : 6,
                  ),
                  child: Text(
                    "Recent searches".translate(context),
                    style: TextStyle(
                      fontSize: isSmallPhone ? 12 : 13,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF7C8696),
                      letterSpacing: 0.2,
                    ),
                  ),
                ),
                Container(
                  margin:
                      EdgeInsets.symmetric(horizontal: isSmallPhone ? 14 : 18),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x0F0C1523),
                        blurRadius: 18,
                        offset: Offset(0, 6),
                      ),
                    ],
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    itemCount: recentDropLocations.length,
                    separatorBuilder: (_, __) => const Divider(
                        height: 1, indent: 58, color: Color(0xFFF0F2F6)),
                    itemBuilder: (context, index) {
                      final item = recentDropLocations[index];
                      return _buildRecentLocationItem(item, isSmallPhone);
                    },
                  ),
                ),
              ],
            ],
          ),
        ),
        if (showFindDrivers) _buildFindDriversButton(isSmallPhone),
      ],
    );
  }

  Widget _buildRecentLocationItem(Map<String, String> item, bool isSmallPhone) {
    return InkWell(
      onTap: () {
        showButton = false;
        context.read<SelectedAddressCubit>().dropOffAddressController.text =
            item['address'] ?? "";
        context.read<BookRideRealTimeDataBaseCubit>().updateDropOffLatAndLng(
              dropoffAddressLatitude: item['lat'] ?? "",
              dropoffAddressLongitude: item['lng'] ?? "",
            );

        final selected = context.read<SelectedAddressCubit>();
        final bookRide = context.read<BookRideRealTimeDataBaseCubit>();

        if (selected.pickupAddressController.text.isEmpty ||
            selected.dropOffAddressController.text.isEmpty) {
          showButton = true;
          setState(() {});
          return;
        }

        bookRide.updatePickupAddress(
          pickupAddress: selected.pickupAddressController.text,
        );
        bookRide.updateDropOffAddress(
          dropoffAddress: selected.dropOffAddressController.text,
        );

        if (bookRide.state.pickupAddress.isNotEmpty &&
            bookRide.state.dropoffAddress.isNotEmpty &&
            bookRide.state.pickupAddressLatitude.isNotEmpty &&
            bookRide.state.pickupAddressLongitude.isNotEmpty &&
            bookRide.state.dropoffAddressLatitude.isNotEmpty &&
            bookRide.state.dropoffAddressLongitude.isNotEmpty) {
          showButton = true;
          _tryAutoProceed();
        }

        setState(() {});
      },
      child: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: 14,
          vertical: isSmallPhone ? 8 : 10,
        ),
        child: Row(
          children: [
            Container(
              height: isSmallPhone ? 32 : 36,
              width: isSmallPhone ? 32 : 36,
              decoration: const BoxDecoration(
                color: Color(0xFFF1F3F8),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.history_rounded,
                  color: Color(0xFF7C8696), size: 16),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                item['address'] ?? "",
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: isSmallPhone ? 12 : 13,
                  color: const Color(0xFF3A4250),
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFindDriversButton(bool isSmallPhone) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
        isSmallPhone ? 14 : 18,
        8,
        isSmallPhone ? 14 : 18,
        isSmallPhone ? 12 : 16,
      ),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: themeColor.withOpacity(0.32),
              blurRadius: 22,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Material(
          color: themeColor,
          borderRadius: BorderRadius.circular(16),
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: _proceedToNearbyDrivers,
            child: Container(
              height: isSmallPhone ? 48 : 52,
              alignment: Alignment.center,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Find nearby drivers".translate(context),
                    style: TextStyle(
                      fontSize: isSmallPhone ? 13.5 : 14.5,
                      fontWeight: FontWeight.w700,
                      color: blackColor,
                    ),
                  ),
                  const SizedBox(width: 8),
                  DirectionalIcon(
                    icon: Icons.arrow_forward_rounded,
                    size: 18,
                    color: blackColor,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _proceedToNearbyDrivers() {
    final selected = context.read<SelectedAddressCubit>();
    final bookRide = context.read<BookRideRealTimeDataBaseCubit>();

    if (selected.pickupAddressController.text.isEmpty ||
        selected.dropOffAddressController.text.isEmpty) {
      showErrorToastMessage("Please select both addresses".translate(context));
      return;
    }

    bookRide.updatePickupAddress(
      pickupAddress: selected.pickupAddressController.text,
    );
    bookRide.updateDropOffAddress(
      dropoffAddress: selected.dropOffAddressController.text,
    );

    if (bookRide.state.pickupAddress.isNotEmpty &&
        bookRide.state.dropoffAddress.isNotEmpty &&
        bookRide.state.pickupAddressLatitude.isNotEmpty &&
        bookRide.state.pickupAddressLongitude.isNotEmpty &&
        bookRide.state.dropoffAddressLatitude.isNotEmpty &&
        bookRide.state.dropoffAddressLongitude.isNotEmpty) {
      _addRecentDropLocation(
        selected.dropOffAddressController.text,
        bookRide.state.dropoffAddressLatitude.toString(),
        bookRide.state.dropoffAddressLongitude.toString(),
      );
      showButton = true;
      goTo(const LoadingNearbySearchScreen());
      setState(() {});
      return;
    }

    _isNavigating = false;
  }
}
