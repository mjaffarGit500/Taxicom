import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on/app/route_settings.dart';
import 'package:ride_on/core/services/data_store.dart';
import 'package:ride_on/core/utils/translate.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../cubits/realtime/get_ride_request_status_cubit.dart';
import '../../cubits/realtime/ride_request_cubit.dart';
import '../home/item_home_screen.dart';
import '../../cubits/book_ride_cubit.dart';

const Color kRideDarkText = Color(0xFF2A1E1A);
const Color kRideAccentBrown = Color(0xFF8A5A10);

Widget buildSectionHeader(
  BuildContext context, {
  required String title,
  required String subtitle,
  required IconData icon,
  required List<Color> gradient,
}) {
  return Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Container(
        height: 34,
        width: 34,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: gradient),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(icon, color: kRideDarkText, size: 16),
      ),
      const SizedBox(width: 8),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: heading2Grey1(context).copyWith(fontSize: 11),
            ),
            const SizedBox(height: 1),
            Text(
              subtitle,
              style: regular(context).copyWith(
                fontSize: 8,
                color: kRideAccentBrown,
              ),
            ),
          ],
        ),
      ),
    ],
  );
}

Widget buildSectionLabel(
  BuildContext context, {
  required String title,
  required IconData icon,
}) {
  return Row(
    children: [
      Container(
        height: 28,
        width: 28,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [themeColor, themeColor],
          ),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: blackColor, size: 15),
      ),
      const SizedBox(width: 8),
      Text(
        title,
        style: heading2Grey1(context)
            .copyWith(fontSize: 12, fontWeight: FontWeight.w600),
      ),
    ],
  );
}

Widget buildInfoPill({
  required IconData icon,
  required String label,
  required List<Color> colors,
  Color foreground = Colors.white,
}) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
    decoration: BoxDecoration(
      gradient: LinearGradient(colors: colors),
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: themeColor.withValues(alpha: 0.25)),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: foreground, size: 12),
        const SizedBox(width: 5),
        Text(
          label,
          style: TextStyle(
            color: foreground,
            fontSize: 9,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    ),
  );
}

Widget buildOtpCard(
  BuildContext context, {
  required String title,
  required String value,
  required IconData icon,
  required List<Color> gradient,
}) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(14),
      border: Border.all(
        color: themeColor,
      ),
    ),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        // Icon badge
        Container(
          height: 28,
          width: 28,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: gradient),
            borderRadius: BorderRadius.circular(9),
            boxShadow: [
              BoxShadow(
                color: gradient.last.withValues(alpha: 0.32),
                blurRadius: 8,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Icon(icon, color: kRideDarkText, size: 13),
        ),
        const SizedBox(width: 8),
        // Label
        Expanded(
          child: Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: regular(context).copyWith(
              fontWeight: FontWeight.w700,
              fontSize: 8,
              color: kRideAccentBrown,
            ),
          ),
        ),
        const SizedBox(width: 6),
        // OTP digits inline
        Directionality(
          textDirection: ui.TextDirection.ltr,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: List.generate(value.length, (index) {
              return Container(
                margin: const EdgeInsets.only(left: 3),
                width: 24,
                height: 28,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: gradient),
                  borderRadius: BorderRadius.circular(7),
                  boxShadow: [
                    BoxShadow(
                      color: gradient.last.withValues(alpha: 0.22),
                      blurRadius: 6,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Text(
                  value[index],
                  style:   TextStyle(
                    color: blackColor,
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.4,
                  ),
                ),
              );
            }),
          ),
        ),
      ],
    ),
  );
}

Widget buildDriverMetaRow({
  required IconData icon,
  required String text,
}) {
  return Row(
    children: [
      Icon(icon, size: 12, color: Colors.white.withValues(alpha: 0.8)),
      const SizedBox(width: 5),
      Expanded(
        child: Text(
          text,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 9,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    ],
  );
}

Widget buildDriverActionButton({
  required IconData icon,
  required String label,
  required VoidCallback onTap,
  Widget? trailing,
}) {
  return InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(30),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: Colors.white),
          const SizedBox(width: 5),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 9,
              fontWeight: FontWeight.w600,
            ),
          ),
          if (trailing != null) trailing,
        ],
      ),
    ),
  );
}

Widget buildCompactLocationTile(
  BuildContext context, {
  required String title,
  required String address,
  required IconData icon,
  required List<Color> colors,
}) {
  return Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Container(
        height: 28,
        width: 28,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: colors),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: Colors.white, size: 14),
      ),
      const SizedBox(width: 8),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: regular(context).copyWith(
                fontSize: 8,
                fontWeight: FontWeight.w700,
                color: kRideAccentBrown,
              ),
            ),
            const SizedBox(height: 1),
            Text(
              address,
              style: regularBlack(context).copyWith(fontSize: 10),
            ),
          ],
        ),
      ),
    ],
  );
}

 
Widget bookingDetailsCard(
  BuildContext context, {
  String? pickupAddress,
  String? dropoffAddress,
  EdgeInsetsGeometry margin = EdgeInsets.zero,
}) {
  final state = context.read<BookRideRealTimeDataBaseCubit>().state;
  final pickup = pickupAddress ?? state.pickupAddress;
  final dropoff = dropoffAddress ?? state.dropoffAddress;

  return Container(
    margin: margin,
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: themeColor.withValues(alpha: .28), width: 1.0),
    ),
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
    child: IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
           Column(
            children: [
              // Pickup Icon
              Container(
                width: 25,
                height: 25,
                decoration: BoxDecoration(
                  color: appgreen,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.my_location_rounded,
                  size: 13,
                  color: Colors.white,
                ),
              ),

              const SizedBox(height: 3),

              Expanded(
                child: Container(
                  width: 2,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        appgreen.withValues(alpha: 0.45),
                        themeColor.withValues(alpha: 0.55),
                      ],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),

              const SizedBox(height: 3),

              Container(
                width: 25,
                height: 25,
                decoration: BoxDecoration(
                  color: themeColor,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  Icons.location_on_rounded,
                  size: 13,
                  color: whiteColor,
                ),
              ),
            ],
          ),

          const SizedBox(width: 12),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // PICKUP
                Text(
                  "PICKUP".translate(context),
                  style: TextStyle(
                    fontSize: 11,
                    color: appgreen,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.8,
                  ),
                ),

                const SizedBox(height: 2),

                Text(
                  state.pickupAddress,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: Colors.black,
                  ),
                ),

                const SizedBox(height: 14),

                // DROP-OFF
                Text(
                  "DROP-OFF".translate(context),
                  style: const TextStyle(
                    fontSize: 11,
                    color: kRideAccentBrown,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.8,
                  ),
                ),

                const SizedBox(height: 2),

                Text(
                  state.dropoffAddress,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: Colors.black,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

 Widget buildMapActionButton({
  required IconData icon,
  required VoidCallback onTap,
}) {
  return InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(16),
    child: Container(
      height: 36,
      width: 36,
      decoration: BoxDecoration(
        color: whiteColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Icon(icon, color: kRideAccentBrown, size: 19),
    ),
  );
}


Widget buildMapZoomBtn(IconData icon, VoidCallback onTap) {
  return GestureDetector(
    onTap: onTap,
    child: Container(
      width: 38,
      height: 38,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: themeColor),
      ),
      child: Icon(icon, size: 18, color: kRideAccentBrown),
    ),
  );
}


Widget buildDragHandle() {
  return Padding(
    padding: const EdgeInsets.only(top: 12, bottom: 6),
    child: Center(
      child: Container(
        width: 52,
        height: 6,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [themeColor, themeColor],
          ),
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: themeColor.withOpacity(0.35),
              blurRadius: 6,
              offset: const Offset(0, 1),
            ),
          ],
        ),
      ),
    ),
  );
}

 
Widget buildDragHandleCompact() {
  return Center(
    child: Container(
      width: 52,
      height: 6,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [themeColor.withValues(alpha: 0.72), themeColor],
        ),
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: themeColor.withValues(alpha: 0.36),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
    ),
  );
}


class PulsingCircle extends StatefulWidget {
  const PulsingCircle({super.key});

  @override
  State<PulsingCircle> createState() => _PulsingCircleState();
}

class _PulsingCircleState extends State<PulsingCircle>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> scaleAnimation;
  late Animation<double> opacityAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat();

    scaleAnimation = Tween<double>(begin: 1.0, end: 2.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );

    opacityAnimation = Tween<double>(begin: 0.4, end: 0.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 300,
      height: 300,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Outer pulse
          AnimatedBuilder(
            animation: _controller,
            builder: (context, child) {
              return Transform.scale(
                scale: scaleAnimation.value,
                child: Opacity(
                  opacity: opacityAnimation.value,
                  child: Container(
                    width: 130,
                    height: 130,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: themeColor,
                    ),
                  ),
                ),
              );
            },
          ),
          // Inner static dot
          Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFFB57C00),
              border: Border.all(color: Colors.white, width: 2),
            ),
          ),
        ],
      ),
    );
  }
}

 
void showDriverCancelledRideDialog(BuildContext context) {
  showDialog(
    context: context,
    barrierDismissible: false,  
    builder: (context) => AlertDialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      backgroundColor: Colors.white,
      title: Column(
        children: [
          const Icon(
            Icons.car_crash,
            color: Colors.redAccent,
            size: 50,
          ),
          const SizedBox(height: 10),
          Text(
            "Driver Cancelled Ride".translate(context),
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
        ],
      ),
      content: Text(
        "The driver has unexpectedly cancelled the ride.\n\nWe're sorry for the inconvenience.\nYou can go back to the home screen and request another ride."
            .translate(context),
        textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 14, color: Colors.black54),
      ),
      actionsAlignment: MainAxisAlignment.center,
      actions: [
        InkWell(
          onTap: () {
            goBack();
            context.read<RideRequestCubit>().resetState();
            context.read<GetRideRequestStatusCubit>().resetState();
            box.delete("ride_data");
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(
                builder: (context) => const ItemHomeScreen(),
              ),
              (Route<dynamic> route) => false, // Remove all previous routes
            );
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.redAccent,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.home, color: Colors.white),
                const SizedBox(width: 8),
                Text(
                  "Go Home".translate(context),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    ),
  );
}

 
void showCancelRideBottomSheet(
  BuildContext context, {
  required VoidCallback onConfirmCancel,
}) {
  showModalBottomSheet(
    context: context,
    backgroundColor: notifires.getbgcolor,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
    ),
    builder: (BuildContext context) {
      final double bottomPadding = MediaQuery.of(context).padding.bottom;

      return Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, 20 + bottomPadding),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Icon(Icons.warning_amber, color: themeColor, size: 35),
            const SizedBox(height: 10),
            Text(
              "Are you sure you want to cancel your ride?".translate(context),
              style: heading2Grey1(context),
              textAlign: TextAlign.center,
            ),
            Text(
              "If you cancel now, your current ride request will be aborted."
                  .translate(context),
              style: regular(context),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                  onTap: onConfirmCancel,
                  child: Container(
                    alignment: Alignment.center,
                    height: 50,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    decoration: BoxDecoration(
                      color: themeColor,
                      borderRadius: BorderRadius.circular(40),
                    ),
                    child: Text(
                      "Cancel Ride".translate(context),
                      style: regular2(context).copyWith(
                          color: blackColor, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(width: 25),
                InkWell(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    alignment: Alignment.center,
                    height: 50,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    decoration: BoxDecoration(
                      color: notifires.getBoxColor,
                      borderRadius: BorderRadius.circular(40),
                    ),
                    child: Text(
                      "Keep Ride".translate(context),
                      style: regular2(context)
                          .copyWith(color: grey1, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
          ],
        ),
      );
    },
  );
}
