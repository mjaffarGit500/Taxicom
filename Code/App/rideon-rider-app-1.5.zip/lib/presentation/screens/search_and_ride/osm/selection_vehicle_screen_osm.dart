import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:ride_on/app/route_settings.dart';
import 'package:ride_on/presentation/screens/search_and_ride/osm/send_ride_request/send_ride_request_screen_osm.dart';
import '../../../../core/extensions/workspace.dart';
import '../../../../core/services/data_store.dart';
import '../../../../core/utils/translate.dart';
import '../../../../core/utils/common_widget.dart';
import '../../../../core/utils/theme/project_color.dart';
import '../../../cubits/book_ride_cubit.dart';
import '../../../cubits/location/get_item_price_cubit.dart';
import '../../../cubits/location/get_nearby_drivers_cubit.dart';
import '../../../cubits/realtime/ride_request_cubit.dart';
import '../../../cubits/vehicle_data/get_vehicle_cetgegory_cubit.dart';
import '../ride_custom_widget.dart' as shared;

class SelectionVehicleScreenOSM extends StatefulWidget {
  final Set<Polyline> polylines;
  final List<Map<String, dynamic>> fareList;

  const SelectionVehicleScreenOSM({
    super.key,
    required this.polylines,
    required this.fareList,
  });

  @override
  State<SelectionVehicleScreenOSM> createState() =>
      _SelectionVehicleScreenOSMState();
}

class _SelectionVehicleScreenOSMState extends State<SelectionVehicleScreenOSM> {
  late MapController mapController;
  double currentZoom = 12;
  bool isLoadingOnMap = false;
  int selectedIdIndex = -1;
  double traveCharge = 0.0;
  int setIndex = -1;
  bool isRequestInProgress = false;
  Map<String, dynamic> selectedVehicleData = {};


  Set<Polyline> _polylines = {};
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    mapController = MapController();
    selectedIdIndex =
        context.read<VehicleDataUpdateCubit>().state.vehicleSelectedId;
    _initializeMap();
  }

  void _initializeMap() {
    _createPolylines();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _moveMapToFitRoute();
    });
  }

  void _createPolylines() {
    if (widget.polylines.isNotEmpty) {
      _polylines = widget.polylines;
    }
  }

  void _moveMapToFitRoute() {
    if (_polylines.isNotEmpty) {
      // Extract all points from all polylines
      final allPoints = <LatLng>[];
      for (final polyline in _polylines) {
        allPoints.addAll(polyline.points);
      }

      // Add pickup and dropoff points
      final bookRideState = context.read<BookRideRealTimeDataBaseCubit>().state;
      allPoints.add(LatLng(
        double.parse(bookRideState.pickupAddressLatitude),
        double.parse(bookRideState.pickupAddressLongitude),
      ));
      allPoints.add(LatLng(
        double.parse(bookRideState.dropoffAddressLatitude),
        double.parse(bookRideState.dropoffAddressLongitude),
      ));

      final bounds = _calculateBounds(allPoints);
      mapController.fitBounds(
        bounds,
        options: const FitBoundsOptions(
          padding: EdgeInsets.all(130),
        ),
      );
    }
  }

  LatLngBounds _calculateBounds(List<LatLng> points) {
    if (points.isEmpty) {
      final bookRideState = context.read<BookRideRealTimeDataBaseCubit>().state;
      // Return default bounds if no points
      return LatLngBounds(
        LatLng(
          double.parse(bookRideState.pickupAddressLatitude),
          double.parse(bookRideState.pickupAddressLongitude),
        ),
        LatLng(
          double.parse(bookRideState.pickupAddressLatitude),
          double.parse(bookRideState.pickupAddressLongitude),
        ),
      );
    }

    double minLat = points.first.latitude;
    double maxLat = points.first.latitude;
    double minLng = points.first.longitude;
    double maxLng = points.first.longitude;

    for (final point in points) {
      if (point.latitude < minLat) minLat = point.latitude;
      if (point.latitude > maxLat) maxLat = point.latitude;
      if (point.longitude < minLng) minLng = point.longitude;
      if (point.longitude > maxLng) maxLng = point.longitude;
    }

    return LatLngBounds(
      LatLng(minLat, minLng),
      LatLng(maxLat, maxLng),
    );
  }

  void _zoomIn() {
    setState(() {
      currentZoom = (currentZoom + 1).clamp(1.0, 18.0);
      final center = mapController.camera.center;
      mapController.move(center, currentZoom);
    });
  }

  void _zoomOut() {
    setState(() {
      currentZoom = (currentZoom - 1).clamp(1.0, 18.0);
      final center = mapController.camera.center;
      mapController.move(center, currentZoom);
    });
  }

  Widget _buildMapControls() {
    return Positioned(
      top: 100,
      right: 16,
      child: Column(
        children: [
          _buildControlButton(
            icon: Icons.add,
            onPressed: _zoomIn,
          ),
          const SizedBox(height: 12),
          _buildControlButton(
            icon: Icons.remove,
            onPressed: _zoomOut,
          ),
        ],
      ),
    );
  }

  Widget _buildControlButton(
      {required IconData icon, required VoidCallback onPressed}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: IconButton(
        icon: Icon(icon, color: themeColor, size: 20),
        onPressed: onPressed,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bookRideState = context.read<BookRideRealTimeDataBaseCubit>().state;
    final double bottomPadding = MediaQuery.of(context).padding.bottom;

    return PopScope(
      canPop: true,
      child: Scaffold(
        key: _scaffoldKey,
        backgroundColor: Colors.white,
        body: Stack(
          children: [
            // Map Section
            SizedBox(
              height: MediaQuery.of(context).size.height / 1.6,
              child: Stack(
                children: [
                  FlutterMap(
                    mapController: mapController,
                    options: MapOptions(
                      initialCenter: LatLng(
                        double.parse(bookRideState.pickupAddressLatitude),
                        double.parse(bookRideState.pickupAddressLongitude),
                      ),
                      initialZoom: currentZoom,
                    ),
                    children: [
                      TileLayer(
                        urlTemplate:
                            "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
                        userAgentPackageName: 'com.sizh.rideon.rider.taxiapp',
                      ),
                      PolylineLayer(
                        polylines: _polylines.toList(),
                      ),
                      MarkerLayer(
                        markers: [
                          // Pickup Marker
                          Marker(
                            width: 30,
                            height: 30,
                            point: LatLng(
                              double.parse(bookRideState.pickupAddressLatitude),
                              double.parse(
                                  bookRideState.pickupAddressLongitude),
                            ),
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.green,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.green.withOpacity(0.5),
                                    blurRadius: 8,
                                    spreadRadius: 2,
                                  ),
                                ],
                              ),
                              child: const Icon(
                                Icons.circle,
                                color: Colors.white,
                                size: 20,
                              ),
                            ),
                          ),
                          // Dropoff Marker
                          Marker(
                            width: 30,
                            height: 30,
                            point: LatLng(
                              double.parse(
                                  bookRideState.dropoffAddressLatitude),
                              double.parse(
                                  bookRideState.dropoffAddressLongitude),
                            ),
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.red,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.red.withOpacity(0.5),
                                    blurRadius: 8,
                                    spreadRadius: 2,
                                  ),
                                ],
                              ),
                              child: const Icon(
                                Icons.location_on,
                                color: Colors.white,
                                size: 20,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),

                  // Back Button
                  Positioned(
                    top: 60,
                    left: 20,
                    child: InkWell(
                      onTap: () {
                        goBack();
                      },
                      child: Container(
                        height: 40,
                        width: 40,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          color: notifires.getbgcolor,
                          border:
                              Border.all(color: notifires.getGrey3whiteColor),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.1),
                              blurRadius: 4,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Icon(
                          Icons.arrow_back,
                          size: 18,
                          color: notifires.getwhiteblackColor,
                        ),
                      ),
                    ),
                  ),

                  // Map Controls
                  _buildMapControls(),
                ],
              ),
            ),

            // Draggable Bottom Sheet
            DraggableScrollableSheet(
              initialChildSize: 0.52,
              minChildSize: 0.42,
              maxChildSize: 0.88,
              builder: (context, scrollController) {
                return Container(
                  decoration: BoxDecoration(
                    color: notifires.getbgcolor,
                    borderRadius:
                        const BorderRadius.vertical(top: Radius.circular(28)),
                  ),
                  child: ListView(
                    controller: scrollController,
                    padding: EdgeInsets.zero,
                    children: [
                      shared.buildDragHandle(),
                      _buildSheetHeader(context),
                      const SizedBox(height: 10),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: shared.bookingDetailsCard(context),
                      ),
                      const SizedBox(height: 16),
                      // Section label
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 18),
                        child: Row(
                          children: [
                            Container(
                              width: 4,
                              height: 16,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [themeColor, themeColor],
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                ),
                                borderRadius: BorderRadius.circular(4),
                              ),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              "Available Rides".translate(context),
                              style:   TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: darkBrown,
                                letterSpacing: 0.2,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),
                      ListView.builder(
                        padding: EdgeInsets.zero,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: widget.fareList.length,
                        itemBuilder: (context, index) =>
                            _buildVehicleCard(context, index),
                      ),
                      // Extra space so last vehicle card is not hidden behind Book Now bar + system nav
                      SizedBox(height: 100 + bottomPadding),
                    ],
                  ),
                );
              },
            )
          ],
        ),

        // Book Now Button
        bottomNavigationBar:
            selectedIdIndex != -1 ? _buildBookNowBar(context) : null,
      ),
    );
  }

  // ── Drag handle ───────────────────────────────────────────────────────────
  // ── Sheet header ─────────────────────────────────────────────────────────
  Widget _buildSheetHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 0),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [themeColor, themeColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: themeColor.withOpacity(0.26),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child:   Icon(Icons.local_taxi_rounded,
                size: 15, color: darkBrown),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Choose Your Ride".translate(context),
                style:   TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: darkBrown,
                  letterSpacing: 0.1,
                ),
              ),
              Text(
                "Select a vehicle for your trip".translate(context),
                style:   TextStyle(
                  fontSize: 10,
                  color: accentBrown,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── Location card ─────────────────────────────────────────────────────────
  Widget _buildVehicleCard(BuildContext context, int index) {
    final data = widget.fareList[index];
    final isSelected = selectedIdIndex == data["id"];

    final fares = context.watch<GetDistanceRouteCubit>().state.vehicleFares;
    final hasFares = fares.length > index && fares[index].isNotEmpty;

    final fare = hasFares ? fares[index]["fare"] ?? "NA" : "NA";
    final duration = hasFares ? fares[index]["duration"] ?? "NA" : "NA";
    final distance = hasFares ? fares[index]["distance"] ?? "0" : "0";

    if (isSelected) {
      setIndex = index;
      traveCharge = double.tryParse(fare.toString()) ?? 0.0;
    }

    return GestureDetector(
      onTap: () {
        if (!isSelected) {
          setState(() {
            setIndex = index;
            selectedIdIndex = data["id"]!;
            context
                .read<VehicleDataUpdateCubit>()
                .updateVehicleTypeSelectedId(data["id"]);
          });
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        margin: EdgeInsets.fromLTRB(16, index == 0 ? 2 : 6, 16, 0),
        decoration: BoxDecoration(
          gradient: isSelected
              ?   LinearGradient(
                  colors: [darkBrown, medBrown, accentBrown],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : const LinearGradient(
                  colors: [Colors.white, Color(0xFFFFFBF1)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? themeColor : themeColor.withValues(alpha: .24),
            width: isSelected ? 1.3 : 1.0,
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
        child: Row(
          children: [
            // Vehicle image box
            Container(
              width: 58,
              height: 40,
              decoration: BoxDecoration(
                color: isSelected
                    ? Colors.white.withOpacity(0.12)
                    : const Color(0xFFFFF7DC),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isSelected
                      ? Colors.white.withOpacity(0.18)
                      : themeColor.withOpacity(0.22),
                ),
              ),
              padding: const EdgeInsets.all(6),
              child: Builder(builder: (ctx) {
                final imageUrl = (data["image"] ?? "").toString().trim();
                final fallback = SvgPicture.asset(
                  "assets/images/car.svg",
                  colorFilter: ColorFilter.mode(
                    isSelected ? themeColor : accentBrown,
                    BlendMode.srcIn,
                  ),
                );
                if (imageUrl.isEmpty) return fallback;
                return Image.network(
                  imageUrl,
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => fallback,
                );
              }),
            ),
            const SizedBox(width: 8),
            // Name + meta
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    data["vehicleName"] ?? "Unknown".translate(context),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      color: isSelected ? Colors.white : darkBrown,
                    ),
                  ),
                  const SizedBox(height: 3),
                  if (hasFares)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 3),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? Colors.white.withValues(alpha: .10)
                            : themeColor.withValues(alpha: .12),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.schedule_rounded,
                              size: 10,
                              color: isSelected ? softYellow : accentBrown),
                          const SizedBox(width: 3),
                          Flexible(
                            child: Text(
                              "$duration · $distance ${"Km".translate(context)}",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 9,
                                color: isSelected ? softYellow : accentBrown,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(width: 6),
            // Fare + selected badge
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                if (hasFares)
                  Text(
                    "$currency $fare",
                    style: TextStyle(
                      fontSize: 13,
                      color: isSelected ? themeColor : darkBrown,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                if (isSelected) ...[
                  const SizedBox(height: 3),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: themeColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child:   Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.check_circle_rounded,
                            size: 9, color: darkBrown),
                        const SizedBox(width: 2),
                        Text(
                          "Selected",
                          style: TextStyle(
                            fontSize: 9,
                            color: darkBrown,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ── Book Now bottom bar ───────────────────────────────────────────────────
  Widget _buildBookNowBar(BuildContext context) {
    final double bottomPadding = MediaQuery.of(context).padding.bottom;

    return Container(
      // Fixed height hata diya, ab content + system nav bar ke hisab se height set hogi
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [cream, Colors.white.withOpacity(0.95)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        boxShadow: [
          BoxShadow(
            color: themeColor.withOpacity(0.18),
            blurRadius: 16,
            offset: const Offset(0, -3),
          ),
        ],
      ),
      // ✅ Main fix: system navigation bar / gesture area ke liye extra bottom padding
      padding: EdgeInsets.fromLTRB(16, 8, 16, 16 + bottomPadding),
      child: GestureDetector(
        onTap: isRequestInProgress
            ? null
            : () {
                if (selectedIdIndex == -1) {
                  showErrorToastMessage(
                      "Please select a vehicle type.".translate(context));
                  return;
                }
                context.read<BookRideUserCubit>().removeBookRideState();
                context.read<DriverNearByCubit>().resetNearByDriverState();
                context.read<RideRequestCubit>().resetState();
                box.delete("rideId");
                goTo(SendRideRequestScreenOSM(
                  selectedVehicleData: widget.fareList[setIndex],
                  statusOfRide: "",
                ));
              },
        child: Container(
          height: 54, // button ki fixed height
          decoration: BoxDecoration(
            gradient: isRequestInProgress
                ? const LinearGradient(
                    colors: [Color(0xFFB0A09A), Color(0xFF9E8880)])
                : LinearGradient(
                    colors: [themeColor, themeColor],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isRequestInProgress ? Colors.transparent : themeColor,
            ),
          ),
          alignment: Alignment.center,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                isRequestInProgress
                    ? Icons.hourglass_top_rounded
                    : Icons.emoji_transportation_rounded,
                color: isRequestInProgress ? Colors.white : darkBrown,
                size: 16,
              ),
              const SizedBox(width: 6),
              Text(
                isRequestInProgress
                    ? "Requesting...".translate(context)
                    : "Book Now".translate(context),
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: isRequestInProgress ? Colors.white : darkBrown,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    mapController.dispose();
    super.dispose();
  }
}
