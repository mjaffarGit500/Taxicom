import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:http/http.dart' as http;
import 'package:ride_on/core/extensions/workspace.dart';
import '../../../../core/utils/translate.dart';
import '../../../../core/utils/common_widget.dart';
import '../../../../core/utils/theme/project_color.dart';
import '../../../../core/utils/theme/theme_style.dart';
import '../../../cubits/book_ride_cubit.dart';
import '../../../cubits/location/user_current_location_cubit.dart';

class SearchMapScreenOSM extends StatefulWidget {
  final String? selectedAddressTitle;
  final bool? checkStatus;
  const SearchMapScreenOSM({super.key, this.selectedAddressTitle, this.checkStatus});
  @override
  State<SearchMapScreenOSM> createState() => _SearchMapScreenOSMState();
}

class _SearchMapScreenOSMState extends State<SearchMapScreenOSM> {
  late MapController mapController;
  double selectedMapLat = defaultLat;
  double selectedMapLng = defaultLng;
  double currentZoom = 14;
  Timer? _debounce;
  TextEditingController textEditingAddressSearchController = TextEditingController();
  bool _isLoading = false;
  bool _isMapMoving = false;

  @override
  void initState() {
    super.initState();
    mapController = MapController();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initializeMapPosition();
    });
  }

  void _initializeMapPosition() {
    try {
      final bookRideState = context.read<BookRideRealTimeDataBaseCubit>().state;
      if (bookRideState.pickupAddressLatitude.isNotEmpty &&
          bookRideState.pickupAddressLongitude.isNotEmpty) {
        selectedMapLat = double.parse(bookRideState.pickupAddressLatitude);
        selectedMapLng = double.parse(bookRideState.pickupAddressLongitude);
        mapController.move(LatLng(selectedMapLat, selectedMapLng), currentZoom);
      }
    } catch (e) {
      // Use default coordinates if parsing fails
    }
    textEditingAddressSearchController.clear();
    setState(() {});
  }

  @override
  void dispose() {
    _debounce?.cancel();
     super.dispose();
  }

  void _zoomIn() {
    setState(() {
      currentZoom = (currentZoom + 1).clamp(1.0, 18.0);
      mapController.move(LatLng(selectedMapLat, selectedMapLng), currentZoom);
    });
  }

  void _zoomOut() {
    setState(() {
      currentZoom = (currentZoom - 1).clamp(1.0, 18.0);
      mapController.move(LatLng(selectedMapLat, selectedMapLng), currentZoom);
    });
  }

  void _moveToLocation(LatLng location) {
    setState(() {
      selectedMapLat = location.latitude;
      selectedMapLng = location.longitude;
    });
    mapController.move(location, currentZoom);
  }

  Future<List<String>> getSuggestions(String query) async {
    if (query.isEmpty) return [];

    final url = Uri.parse(
      "https://nominatim.openstreetmap.org/search?q=${Uri.encodeComponent(query)}&format=json&addressdetails=1&limit=5",
    );

    try {
      final response = await http.get(url, headers: {
        "User-Agent": "RideOn/1.0 (com.sizh.rideon.rider.taxiapp)"
      });

      if (response.statusCode == 200) {
        final List data = json.decode(response.body);
        return data
            .map<String>((item) => item['display_name'].toString())
            .toList();
      } else {
        return [];
      }
    } catch (e) {
      return [];
    }
  }

  Future<void> getAddressFromLatLng(double latitude, double longitude) async {
    if (_debounce?.isActive ?? false) _debounce!.cancel();

    _debounce = Timer(const Duration(milliseconds: 700), () async {
      try {
        setState(() {
          _isLoading = true;
        });

        final url = Uri.parse(
          "https://nominatim.openstreetmap.org/reverse?lat=$latitude&lon=$longitude&format=json",
        );
        final response = await http.get(url, headers: {
          "User-Agent": "RideOn/1.0 (com.sizh.rideon.rider.taxiapp)"
        });

        if (response.statusCode == 200) {
          final data = json.decode(response.body);
          if (data.containsKey("display_name")) {
            String address = data["display_name"];
            if (mounted) {
              setState(() {
                textEditingAddressSearchController.text = address;
              });
            }
          }
        }
      } catch (e) {
        // Silent error
      } finally {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    });
  }

  Future<void> _moveToSelectedAddress(String address) async {
    setState(() {
      _isLoading = true;
    });

    try {
      final url = Uri.parse(
        "https://nominatim.openstreetmap.org/search"
        "?q=${Uri.encodeComponent(address)}"
        "&format=json"
        "&limit=1",
      );

      final response = await http.get(
        url,
        headers: {
          "User-Agent": "RideOn/1.0 (com.sizh.rideon.rider.taxiapp)",
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data.isNotEmpty) {
          final double lat = double.parse(data[0]['lat']);
          final double lon = double.parse(data[0]['lon']);

          final LatLng selectedLocation = LatLng(
            lat,
            lon,
          );

          _moveToLocation(selectedLocation);

          if (data[0].containsKey('display_name')) {
            if (mounted) {
              setState(() {
                textEditingAddressSearchController.text =
                    data[0]['display_name'];
              });
            }
          }
        }
      }
    } catch (e) {
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Widget _buildZoomButton(
      {required IconData icon, required VoidCallback onPressed}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: themeColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: themeColor.withValues(alpha: .1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: IconButton(
        icon: Icon(icon, color: blackColor, size: 24),
        onPressed: onPressed,
      ),
    );
  }

  Widget _buildSelectedLocationMarker() {
    return Stack(
      children: [
        Image.asset(
          "assets/images/dropmarker.png",
          height: 34,
          width: 34,
          alignment: Alignment.bottomCenter,
        )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    // Bottom system navigation bar / gesture area height
    final double bottomPadding = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        toolbarHeight: 70,
        elevation: 0,
        surfaceTintColor: Colors.white,
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Text(
          widget.checkStatus == true
              ? "Pickup Location".translate(context)
              : "Drop-off Location".translate(context),
          style: headingBlack(context).copyWith(
            fontSize: 18,
            color: blackColor,
            fontWeight: FontWeight.w600,
          ),
        ),
        leadingWidth: 80,
        leading: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          child: InkWell(
            onTap: () {
              Navigator.of(context).pop();
            },
            child: Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: notifires.getbgcolor,
                    border: Border.all(color: notifires.getGrey3whiteColor)),
                child: Icon(Icons.arrow_back,
                    size: 20, color: notifires.getwhiteblackColor)),
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size(double.infinity, 80),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              children: [
                const SizedBox(height: 12),
                Padding(
                  padding:
                      const EdgeInsets.only(bottom: 16, left: 20, right: 20),
                  child: Container(
                    height: 56,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Stack(
                      children: [
                        Autocomplete<String>(
                          optionsBuilder:
                              (TextEditingValue textEditingValue) async {
                            if (textEditingValue.text.isEmpty) {
                              return const Iterable<String>.empty();
                            }
                            return await getSuggestions(textEditingValue.text);
                          },
                          fieldViewBuilder: (context, controller, focusNode,
                              onFieldSubmitted) {
                            textEditingAddressSearchController = controller;
                            return TextField(
                              controller: controller,
                              focusNode: focusNode,
                              style: regularBlack(context).copyWith(
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                              decoration: InputDecoration(
                                prefixIcon: Icon(Icons.search,
                                    color: themeColor, size: 24),
                                hintText: "Search Address".translate(context),
                                hintStyle: regular3(context).copyWith(
                                  color: Colors.grey.shade600,
                                  fontSize: 14,
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  borderSide: BorderSide.none,
                                ),
                                filled: true,
                                fillColor: Colors.white,
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 20,
                                  vertical: 16,
                                ),
                              ),
                              onSubmitted: (value) {
                                if (value.isNotEmpty) {
                                  _moveToSelectedAddress(value);
                                }
                              },
                            );
                          },
                          onSelected: (String selection) {
                            _moveToSelectedAddress(selection);
                          },
                        ),
                        if (_isLoading)
                          Positioned(
                            right: 12,
                            top: 0,
                            bottom: 0,
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: themeColor,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      body: Stack(
        children: [
          FlutterMap(
            mapController: mapController,
            options: MapOptions(
              initialCenter: LatLng(selectedMapLat, selectedMapLng),
              initialZoom: currentZoom,
              onPositionChanged: (MapPosition position, bool hasGesture) {
                if (position.center == null) return;

                final newLocation = position.center!;

                setState(() {
                  selectedMapLat = newLocation.latitude;
                  selectedMapLng = newLocation.longitude;
                  currentZoom = position.zoom!;
                  _isMapMoving = hasGesture;
                });

                if (!hasGesture) return;

                _debounce?.cancel();

                _debounce = Timer(
                  const Duration(milliseconds: 0),
                  () {
                    getAddressFromLatLng(
                      selectedMapLat,
                      selectedMapLng,
                    );
                  },
                );
              },
            ),
            children: [
              TileLayer(
                urlTemplate: "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
                userAgentPackageName: 'com.sizh.rideon.rider.taxiapp',
              ),
              MarkerLayer(
                markers: [
                  Marker(
                    width: 40,
                    height: 40,
                    alignment: Alignment.bottomCenter,
                    point: LatLng(selectedMapLat, selectedMapLng),
                    child: _buildSelectedLocationMarker(),
                  ),
                ],
              ),
            ],
          ),

          // Map Controls
          Positioned(
            top: 50,
            right: 16,
            child: Column(
              children: [
                _buildZoomButton(icon: Icons.add, onPressed: _zoomIn),
                _buildZoomButton(icon: Icons.remove, onPressed: _zoomOut),
              ],
            ),
          ),

          // Loading overlay
          if (_isLoading)
            Positioned.fill(
              child: Container(
                color: Colors.black.withOpacity(0.3),
                child: Center(
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.2),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CircularProgressIndicator(color: themeColor),
                        const SizedBox(height: 12),
                        Text(
                          "Getting address...".translate(context),
                          style: regularBlack(context).copyWith(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
      // ✅ FIXED: Bottom bar ab system navigation bar / gesture area ke upar rahega
      bottomNavigationBar: Container(
        // Extra padding for phones that have bottom system buttons / gesture bar
        padding: EdgeInsets.only(
          left: 20,
          right: 20,
          top: 24,
          bottom: 24 + bottomPadding, // ← yahi main fix hai
        ),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 16,
              offset: const Offset(0, -4),
            ),
          ],
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Selected address preview
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: themeColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: themeColor.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  Icon(
                    widget.checkStatus == true ? Icons.location_on : Icons.flag,
                    color: themeColor,
                    size: 20,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      textEditingAddressSearchController.text.isNotEmpty
                          ? textEditingAddressSearchController.text
                          : "Move map to select location".translate(context),
                      style: regularBlack(context).copyWith(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            CustomsButtons(
              text:
                  "Set ${widget.checkStatus == true ? "Pickup" : "Drop-off"} Location",
              backgroundColor: themeColor,
              onPressed: _isLoading
                  ? () {}
                  : () {
                      if (textEditingAddressSearchController.text.isNotEmpty) {
                        if (widget.checkStatus == true) {
                          context
                              .read<SelectedAddressCubit>()
                              .updateIsSelectePickupdAddress(
                                  isCheckedSelectedPickup: true);
                          context
                              .read<SelectedAddressCubit>()
                              .updateIsSelectedDropOffAddress(
                                  isCheckedSelectedDropOff: false);
                          context
                              .read<SelectedAddressCubit>()
                              .updateIsCrossIconSelectePickup(
                                  icheckedCrossIconPickup: true);
                          context
                                  .read<SelectedAddressCubit>()
                                  .pickupAddressController
                                  .text =
                              textEditingAddressSearchController.text
                                  .toString();
                          context
                              .read<GetCordinatesCubit>()
                              .getCoordinatesUsingOSM(
                                  address: textEditingAddressSearchController
                                      .text
                                      .toString());

                          Navigator.of(context).pop();
                        } else {
                          context
                              .read<SelectedAddressCubit>()
                              .updateIsSelectePickupdAddress(
                                  isCheckedSelectedPickup: false);
                          context
                              .read<SelectedAddressCubit>()
                              .updateIsSelectedDropOffAddress(
                                  isCheckedSelectedDropOff: true);
                          context
                              .read<SelectedAddressCubit>()
                              .updateIsCrossIconSelectedDropOff(
                                  ischeckedCrossIconDropOff: true);

                          context
                                  .read<SelectedAddressCubit>()
                                  .dropOffAddressController
                                  .text =
                              textEditingAddressSearchController.text
                                  .toString();
                          context
                              .read<GetCordinatesCubit>()
                              .getCoordinatesUsingOSM(
                                  address: textEditingAddressSearchController
                                      .text
                                      .toString());

                          if (context
                                  .read<SelectedAddressCubit>()
                                  .dropOffAddressController
                                  .text ==
                              context
                                  .read<SelectedAddressCubit>()
                                  .pickupAddressController
                                  .text) {
                            showErrorToastMessage(
                                "Please select different address");
                            return;
                          }
                          Navigator.of(context).pop();
                        }
                      } else {
                        showErrorToastMessage(
                            "please selected the address".translate(context));
                      }
                    },
              textColor: Colors.black,
            ),
          ],
        ),
      ),
    );
  }
}