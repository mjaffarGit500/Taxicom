import 'package:flutter/material.dart';

const Color kOsmRideDarkText = Color(0xFF2A1E1A);
const Color kOsmRideAccentBrown = Color(0xFF8A5A10);
