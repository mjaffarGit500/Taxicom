import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:ride_on/presentation/cubits/location/osm_map/get_poliline_using_osm.dart';
import 'package:ride_on/presentation/cubits/location/osm_map/set_marker_osm_cubit.dart';

class PersistentOSMMap extends StatefulWidget {
  final MapController mapController;
  final LatLng initialPosition;
  final double initialZoom;
  final bool Function()? shouldFitCamera;

  const PersistentOSMMap({
    super.key,
    required this.mapController,
    required this.initialPosition,
    required this.initialZoom,
    this.shouldFitCamera,
  });

  @override
  State<PersistentOSMMap> createState() => _PersistentOSMMapState();
}

class _PersistentOSMMapState extends State<PersistentOSMMap> {
  @override
  Widget build(BuildContext context) {
    return MultiBlocListener(
      listeners: [
        BlocListener<OSMGetPolylineCubit, OSMGetPolylineState>(
          listener: (context, polylineState) {
            if (polylineState is OSMGetPolylineUpdated && mounted) {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (polylineState.polylines.isNotEmpty &&
                    (widget.shouldFitCamera?.call() ?? true)) {
                  _moveCameraToFitPolylineAndMarkers(polylineState.polylines);
                }
              });
            }
          },
        ),
      ],
      child: BlocBuilder<UserMarkerCubitOSM, UserMarkerStateOSM>(
        builder: (context, markerState) {
          return BlocBuilder<OSMGetPolylineCubit, OSMGetPolylineState>(
            builder: (context, polylineState) {
              final List<Marker> markers = markerState is UserMarkerUpdatedOSM
                  ? markerState.markers.toList()
                  : [];
              final List<Polyline> polylines =
                  polylineState is OSMGetPolylineUpdated
                      ? polylineState.polylines.toList()
                      : [];

              return FlutterMap(
                mapController: widget.mapController,
                options: MapOptions(
                  initialCenter: widget.initialPosition,
                  initialZoom: widget.initialZoom,
                  interactionOptions: const InteractionOptions(
                    flags: InteractiveFlag.all & ~InteractiveFlag.rotate,
                  ),
                ),
                children: [
                  TileLayer(
                    urlTemplate:
                        "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
                    userAgentPackageName: 'com.sizh.rideon.rider.taxiapp',
                  ),
                  PolylineLayer(polylines: polylines),
                  MarkerLayer(markers: markers),
                ],
              );
            },
          );
        },
      ),
    );
  }

  void _moveCameraToFitPolylineAndMarkers(Set<Polyline> polylines) {
    if (polylines.isEmpty) return;

    final allPoints = <LatLng>[];
    for (final polyline in polylines) {
      allPoints.addAll(polyline.points);
    }

    if (allPoints.isEmpty) return;

    final bounds = _calculateBounds(allPoints);
    widget.mapController.fitBounds(
      bounds,
      options: const FitBoundsOptions(padding: EdgeInsets.all(100)),
    );
  }

  LatLngBounds _calculateBounds(List<LatLng> points) {
    double minLat = points.first.latitude;
    double maxLat = points.first.latitude;
    double minLng = points.first.longitude;
    double maxLng = points.first.longitude;

    for (final point in points) {
      if (point.latitude < minLat) minLat = point.latitude;
      if (point.latitude > maxLat) maxLat = point.latitude;
      if (point.longitude < minLng) minLng = point.longitude;
      if (point.longitude > maxLng) maxLng = point.longitude;
    }

    return LatLngBounds(
      LatLng(minLat, minLng),
      LatLng(maxLat, maxLng),
    );
  }
}
