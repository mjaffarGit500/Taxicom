import 'dart:async';
import 'dart:convert';
import 'package:ride_on/app/route_settings.dart';
import 'package:ride_on/core/extensions/helper/push_notifications.dart';
import 'package:ride_on/core/services/data_store.dart';
import 'package:ride_on/core/extensions/workspace.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import 'package:ride_on/presentation/cubits/location/osm_map/get_poliline_using_osm.dart';
import 'package:ride_on/presentation/cubits/location/osm_map/set_marker_osm_cubit.dart';
import 'package:ride_on/presentation/cubits/vehicle_data/get_vehicle_cetgegory_cubit.dart';
import 'package:ride_on/presentation/screens/search_and_ride/chat_screen.dart';
import 'package:ride_on/presentation/widgets/sos_widget.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../../../core/utils/common_widget.dart';
import '../../../../../core/utils/smooth_driver_tracking_controller.dart';
import '../../../../../core/utils/theme/project_color.dart';
import '../../../../cubits/book_ride_cubit.dart';
import '../../../../cubits/general_cubit.dart';
import '../../../../cubits/location/get_nearby_drivers_cubit.dart';
import '../../../../cubits/realtime/get_ride_request_status_cubit.dart';
import '../../../../cubits/realtime/ride_request_cubit.dart';
import '../../../home/item_home_screen.dart';
import '../../../payment/rider_payment_screen.dart';
import '../../shared/widgets/screen_tracker.dart';
import '../../ride_custom_widget.dart' as shared;
import 'widgets/booking_details_section.dart';
import 'widgets/driver_info_section.dart';
import 'widgets/finding_driver_section.dart';
import 'widgets/persistent_osm_map.dart';
import 'widgets/ride_details_section.dart';

class SendRideRequestScreenOSM extends StatefulWidget {
  final Map<String, dynamic> selectedVehicleData;

  final String statusOfRide;
  final String? pickUpOtp, dropotp, rideId, bookingId, paymentUrl;

  const SendRideRequestScreenOSM(
      {super.key,
      required this.selectedVehicleData,
      required this.statusOfRide,
      this.rideId,
      this.pickUpOtp,
      this.dropotp,
      this.bookingId,
      this.paymentUrl});

  @override
  State<SendRideRequestScreenOSM> createState() =>
      _SendRideRequestScreenOSMState();
}

class _SendRideRequestScreenOSMState extends State<SendRideRequestScreenOSM> {


  double dropLat = 0.0;
  double dropLng = 0.0;
  double pickLat = 0.0;
  double pickLng = 0.0;
  double driverLat = 0.0;
  double driverLng = 0.0;
  String fetchDistance = "";
  String fetchDuration = "";
  String otp = "";
  String dropotp = "";
  String rideId = "";
  String bookingId = "";
  String rideStatus = "";
  String paymentUrl = '';

  Set<Polyline> polylines = {};
  Set<Marker> markers = {};
  bool isSuccessFirst = false;
  bool isCurrentScreenActive = true;
  List<LatLng> polylineCoordinates = [];
  int currentPolylineIndex = 0;
  Timer? locationUpdateTimer;
  Timer? fetchTimer;

  late MapController mapController;
  double currentZoom = 15.0;

  LatLng _currentDriverPosition = const LatLng(0, 0);
  Timer? _distanceTimer;
  double updatedDriverLat = 0.0;
  double updatedDriverLng = 0.0;

  bool _fitOnAccepted = true;
  bool _fitOnOngoing = true;
  final SmoothDriverTrackingController _trackingController =
      SmoothDriverTrackingController();
  bool _isFollowingDriver = true;
  bool _isProgrammaticCameraMove = false;
  StreamSubscription<MapEvent>? _mapEventSubscription;

  @override
  void initState() {
    super.initState();
    mapController = MapController();

    ScreenTracker.setCurrentScreen("RideTrackingScreen");
    isManuallyCancelled = false;
    isCurrentScreenActive = true;

    context.read<UserMarkerCubitOSM>().clear();
    context.read<OSMGetPolylineCubit>().resetPolylines();

    _trackingController.onFrame = (frame) {
      _currentDriverPosition = LatLng(frame.lat, frame.lng);
      driverLat = frame.lat;
      driverLng = frame.lng;
      _updateDriverMarkerPosition(LatLng(frame.lat, frame.lng),
          bearingDegrees: normalizeCarMarkerRotation(frame.bearingDegrees));
    };

    _mapEventSubscription = mapController.mapEventStream.listen((event) {
      if (event is MapEventMove &&
          event.source != MapEventSource.mapController) {
        if (_isFollowingDriver) {
          setState(() => _isFollowingDriver = false);
        }
      }
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _handleRideByStatus();
    });
  }

  void _handleRideByStatus() {
    final status = widget.statusOfRide;

    if (status.isEmpty) {
      _handleFreshRide();
    } else if (status == "pending") {
      _resumePendingRide();
    } else if (status == "accepted" || status == "pick_up") {
      _handleAcceptedRide();
    } else if (status == "ongoing") {
      _handleOngoingRide();
    }
  }

  void _handleFreshRide() {
    getNearByDrivers();
    box.put('selected_vehicle', jsonEncode(widget.selectedVehicleData));
  }

  void _resumePendingRide() {
    final rawRideRequestData = box.get("activeRide");
    final rawRideData = box.get("ride_data");
    final rawDriverIds = box.get("driverIds");
    final rawNearbyDrivers = box.get("nearbyDrivers");
    context
        .read<VehicleDataUpdateCubit>()
        .updateVehicleTypeSelectedId(widget.selectedVehicleData["id"]);

    final Map<String, dynamic>? rideRequestData = rawRideRequestData is Map
        ? Map<String, dynamic>.from(rawRideRequestData)
        : null;

    final Map<String, dynamic>? rideData =
        rawRideData is Map ? Map<String, dynamic>.from(rawRideData) : null;

    final List<String> driverIds =
        rawDriverIds is List ? rawDriverIds.whereType<String>().toList() : [];

    final List<Map<String, dynamic>> nearbyDrivers = rawNearbyDrivers is List
        ? rawNearbyDrivers
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList()
        : [];

    if (rideRequestData == null || rideData == null || driverIds.isEmpty) {
      return;
    }
    context.read<RideRequestCubit>().listenForDriverResponses(
          currentRequestId: widget.rideId ?? "",
          pickupAddress: rideData["pickAddress"] ?? "",
          dropoffAddress: rideData["dropAddress"] ?? "",
          pickupLat: (rideData["pickLat"] ?? 0).toDouble(),
          dropoffLat: (rideData["dropLat"] ?? 0).toDouble(),
          pickupLng: (rideData["pickLng"] ?? 0).toDouble(),
          dropoffLng: (rideData["dropLng"] ?? 0).toDouble(),
          durationForSearch: int.tryParse(
                context.read<DriverSearchIntervalCubit>().state.value ?? "60",
              ) ??
              60,
          driverIds: driverIds,
          rideId: widget.rideId ?? "",
          context: context,
          rideRequestData: rideRequestData,
          nearbyDrivers: nearbyDrivers,
        );
  }

  void _handleAcceptedRide() {
    setAllLatLang();
    _handleBookRideSuccess(
      context,
      widget.pickUpOtp.toString(),
      widget.dropotp.toString(),
      widget.rideId.toString(),
      widget.bookingId.toString(),
    );
    paymentUrl = widget.paymentUrl ?? "";
    rideStatus = widget.statusOfRide;
  }

  void _handleOngoingRide() {
    setAllLatLang();
    otp = widget.pickUpOtp.toString();
    dropotp = widget.dropotp.toString();
    rideId = widget.rideId.toString();
    bookingId = widget.bookingId.toString();
    rideStatus = widget.statusOfRide;
    paymentUrl = widget.paymentUrl ?? "";
    context
        .read<GetRideRequestStatusCubit>()
        .listenToRouteStatus(rideId: rideId);
    _handleLiveRideSuccess(context);
  }

  Future<void> getNearByDrivers() async {
    final stateData = context.read<BookRideRealTimeDataBaseCubit>().state;
    await context.read<DriverNearByCubit>().getNearbyDrivers(
        checkRestart: false,
        pickupLat: double.parse(stateData.pickupAddressLatitude),
        pickupLng: double.parse(stateData.pickupAddressLongitude),
        vehicleTypeId: widget.selectedVehicleData["id"].toString(),
        distance: double.parse(
            context.read<LocationAccuracyThresholdCubit>().state.value ?? "3"));
  }

  void setAllLatLang() {
    final stateData = context.read<BookRideRealTimeDataBaseCubit>().state;
    setState(() {
      pickLat = double.parse(stateData.pickupAddressLatitude);
      pickLng = double.parse(stateData.pickupAddressLongitude);
      dropLat = double.parse(stateData.dropoffAddressLatitude);
      dropLng = double.parse(stateData.dropoffAddressLongitude);
      driverLat = context.read<RideRequestCubit>().state.acceptedDriverLat;
      driverLng = context.read<RideRequestCubit>().state.acceptedDriverLng;
    });
  }

  // Fix marker size issues
  void _addUserMarker() {
    if (pickLat != 0.0 && pickLng != 0.0) {
      context.read<UserMarkerCubitOSM>().addOrUpdateMarker(
            LatLng(pickLat, pickLng),
            'User Location',
            'User_marker',
            'assets/images/pickupmarker.png',
            40, // Reduced size
          );
    }
  }

  void _addDropMarker() {
    if (dropLat != 0.0 && dropLng != 0.0) {
      context.read<UserMarkerCubitOSM>().addOrUpdateMarker(
            LatLng(dropLat, dropLng),
            'Drop Location',
            'drop_marker',
            "assets/images/dropmarker.png",
            40, // Reduced size
          );
    }
  }

  void _addDriverMarker() {
    final rideRequestState = context.read<RideRequestCubit>().state;
    final lat = rideRequestState.acceptedDriverLat;
    final lng = rideRequestState.acceptedDriverLng;

    context.read<UserMarkerCubitOSM>().addOrUpdateMarker(
          LatLng(lat, lng),
          'Driver Location',
          'driver_marker',
          'assets/images/car_marker.png',
          60, // Reduced size for driver marker
        );
  }

  // Fix polyline management - show only one at a time
  void _fetchPickupPolylines() {
    final rideRequestState = context.read<RideRequestCubit>().state;
    final sourceLat = rideRequestState.acceptedDriverLat;
    final sourceLng = rideRequestState.acceptedDriverLng;

    if (pickLat != 0.0 && pickLng != 0.0) {
      // Clear existing polylines first
      context.read<OSMGetPolylineCubit>().resetPolylines();

      context.read<OSMGetPolylineCubit>().getPolyline(
            sourcelat: sourceLat,
            sourcelng: sourceLng,
            destinationlat: pickLat,
            destinationlng: pickLng,
            isPickupRoute: true,
          );
    }
  }

  void _fetchDropoffPolylines() {
    final rideRequestState = context.read<RideRequestCubit>().state;
    final sourceLat = rideRequestState.acceptedDriverLat;
    final sourceLng = rideRequestState.acceptedDriverLng;

    if (dropLat != 0.0 && dropLng != 0.0) {
      // Clear existing polylines first
      context.read<OSMGetPolylineCubit>().resetPolylines();

      context.read<OSMGetPolylineCubit>().getPolyline(
            sourcelat: sourceLat,
            sourcelng: sourceLng,
            destinationlat: dropLat,
            destinationlng: dropLng,
            isPickupRoute: false,
          );
    }
  }

  void _updateDriverMarkerPosition(LatLng position, {double? bearingDegrees}) {
    context.read<UserMarkerCubitOSM>().addOrUpdateMarker(
          position,
          'Driver Location',
          'driver_marker',
          'assets/images/car_marker.png',
          60,
          rotationDegrees: bearingDegrees,
        );
  }

  void _fetchDriverLocationFromRealtimeDB(String rideId) async {
    try {
      if (rideId.isEmpty) {
        return;
      }

      final snapshot = await FirebaseDatabase.instance
          .ref()
          .child('ride_requests')
          .child(rideId)
          .child('driverLocation')
          .once();

      final locationData = snapshot.snapshot.value as Map?;

      if (locationData == null) return;

      final newLat = locationData['lat']?.toDouble();
      final newLng = locationData['lng']?.toDouble();

      if (newLat == null || newLng == null) return;

      updatedDriverLat = newLat;
      updatedDriverLng = newLng;
      _trackingController.onNewLocation(newLat, newLng);
    } catch (e) {
    }
  }

  bool isInilize = false;
  final DraggableScrollableController _draggableController =
      DraggableScrollableController();
  void stopAutoDistanceTimer() {
    _distanceTimer?.cancel();
  }

  Future<void> _initializeRideRequest(
      {required List<Map<String, dynamic>> nearbyDrivers,
      required bool checkRestart}) async {
    final stateData = context.read<BookRideRealTimeDataBaseCubit>().state;
    final rideRequestData = context.read<RideRequestCubit>().state;
    if (checkRestart == true) {
      rideId = rideRequestData.rideId;
    } else {
      if (isInilize) return;
      isInilize = true;
      rideId = FirebaseFirestore.instance.collection('temp').doc().id;
    }
    try {
      await context.read<RideRequestCubit>().createDriverData(
          rideId: rideId,
          checkRestart: checkRestart,
          durationForSearch: int.parse(
              context.read<DriverSearchIntervalCubit>().state.value ?? "60"),
          routeDistance: widget.selectedVehicleData["distance"].toString(),
          context: context,
          nearbyDrivers: nearbyDrivers,
          userId: stateData.userId.toString(),
          userName: stateData.userName,
          pickupLat: double.parse(stateData.pickupAddressLatitude),
          pickupLng: double.parse(stateData.pickupAddressLongitude),
          pickupAddress: stateData.pickupAddress,
          dropoffLat: double.parse(stateData.dropoffAddressLatitude),
          dropoffLng: double.parse(stateData.dropoffAddressLongitude),
          userPhoneNumber: loginModel!.data!.phone!,
          dropoffAddress: stateData.dropoffAddress,
          travelCharges: widget.selectedVehicleData["fare"].toString(),
          routeStatus: "pending",
          userImageUrl: myImage,
          totalTime: widget.selectedVehicleData["duration"].toString());
      setState(() {
        pickLat = double.parse(stateData.pickupAddressLatitude);
        pickLng = double.parse(stateData.pickupAddressLongitude);
        dropLat = double.parse(stateData.dropoffAddressLatitude);
        dropLng = double.parse(stateData.dropoffAddressLongitude);
        driverLat = stateData.acceptedDriverLat;
        driverLng = stateData.acceptedDriverLng;
      });
    } catch (e) {
      showErrorToastMessage("Failed to send ride request.");
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        backgroundColor: notifires.getbgcolor,
        body: Stack(
          children: [
            _buildMapSection(),
            MultiBlocListener(
                listeners: [
                  BlocListener<GetRideRequestStatusCubit, String>(
                      listener: (context, status) {
                    if (status == "rejected") {
                      box.delete("rideId");
                      shared.showDriverCancelledRideDialog(context);
                      return;
                    }
                    setState(() => rideStatus = status);

                    if (rideStatus.toString() == "ongoing") {
                      _handleLiveRideSuccess(context);
                    } else if (status == "completed") {
                      stopAutoDistanceTimer();
                      fetchTimer?.cancel();
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => RiderPaymentScreen(
                            bookingId: bookingId,
                            rideId: rideId,
                            fare: widget.selectedVehicleData["fare"] ?? 00,
                            paymentUrl: paymentUrl,
                          ),
                        ),
                      );
                    }
                  }),
                  BlocListener<DriverNearByCubit, DriverNearByState>(
                      listener: (context, state) {
                    if (state is DriverUpdated) {
                      if (state.nearbyDrivers!.isEmpty) {
                        context
                            .read<DriverNearByCubit>()
                            .resetNearByDriverState();
                        return;
                      }

                      context.read<RideRequestCubit>().updateNearByDrivers(
                          nearbyDrivers: state.nearbyDrivers);
                      _initializeRideRequest(
                          nearbyDrivers: state.nearbyDrivers!,
                          checkRestart: state.checkRestart!);

                      context
                          .read<DriverNearByCubit>()
                          .resetNearByDriverState();
                    }

                    if (state is DriverError) {}
                  }),
                ],
                child: BlocBuilder<RideRequestCubit, RideRequestState>(
                  builder: (context, rideRequestState) {
                    if (rideRequestState.isSubmitting &&
                        // ignore: unrelated_type_equality_checks
                        rideRequestState.selectedDriverId != 0) {
                      _handleRideBooking(context, rideRequestState);
                    }
                    if (rideRequestState.rideMessage.isNotEmpty) {
                      showErrorToastMessage(rideRequestState.rideMessage);
                      context.read<RideRequestCubit>().removeRideMessage();
                    }

                    return BlocBuilder<BookRideUserCubit, BookRideUserState>(
                      builder: (context, bookRideState) {
                        if (bookRideState is BookRideUserSuccess &&
                            bookRideState.pikupOtp != null) {
                          context
                              .read<GetRideRequestStatusCubit>()
                              .listenToRouteStatus(
                                  rideId: bookRideState.rideId.toString());
                          WidgetsBinding.instance.addPostFrameCallback((_) {
                            paymentUrl = bookRideState.paymentUrl ?? "";
                            box.put("payment_url", paymentUrl);
                            _handleBookRideSuccess(
                                context,
                                bookRideState.pikupOtp.toString(),
                                bookRideState.dropOtp.toString(),
                                bookRideState.rideId.toString(),
                                bookRideState.bookingId.toString());
                          });
                          context
                              .read<BookRideUserCubit>()
                              .removeBookRideState();
                        } else if (bookRideState is BookRideUserFailure) {
                          showErrorToastMessage(
                              bookRideState.error ?? "Failed to book ride.");
                          context
                              .read<BookRideUserCubit>()
                              .removeBookRideState();
                          box.delete("ride_data");
                          cancelRideRequest(
                              rideId: context
                                  .read<RideRequestCubit>()
                                  .state
                                  .rideId);
                        }

                        return _buildDraggableSheet(context);
                      },
                    );
                  },
                )),
          ],
        ),
      ),
    );
  }

  bool isRideBooking = false;
  void _handleRideBooking(BuildContext context, RideRequestState state) {
    if (isRideBooking) return;
    isRideBooking = true;
    final stateData = context.read<BookRideRealTimeDataBaseCubit>().state;
    final selectedItemTypeId = widget.selectedVehicleData["id"];
    final formattedDate = DateFormat('yyyy-MM-dd').format(DateTime.now());
    context.read<BookRideUserCubit>().bookRide(
          context: context,
          itemId: state.itemId,
          serviceTypeId: widget.selectedVehicleData["serviceTypeId"].toString(),
          totalFare: widget.selectedVehicleData["fare"].toString(),
          rideId: state.rideId,
          date: formattedDate,
          itemTypeId: selectedItemTypeId,
          estimatedDistance: widget.selectedVehicleData["distance"].toString(),
          pickupAddress: stateData.pickupAddress,
          pickupLat: stateData.pickupAddressLatitude,
          pickupLng: stateData.pickupAddressLongitude,
          dropOffAddress: stateData.dropoffAddress,
          dropOffLat: stateData.dropoffAddressLatitude,
          dropOffLng: stateData.dropoffAddressLongitude,
          driverId: state.selectedDriverId.toString(),
          paymentMethod: "Cash",
        );
  }

  Future<void> _fetchDistanceAndTime({
    required double fromLat,
    required double fromLng,
    required double toLat,
    required double toLng,
    required bool beforePickUp,
  }) async {
    if (fromLat == 0.0 || fromLng == 0.0 || toLat == 0.0 || toLng == 0.0) {
      return;
    }

    // Important: Order must be: longitude, latitude
    final url =
        'https://router.project-osrm.org/route/v1/driving/$fromLng,$fromLat;$toLng,$toLat?overview=false';

    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['code'] == 'Ok' &&
            data['routes'] != null &&
            data['routes'].isNotEmpty) {
          final distanceMeters = data['routes'][0]['distance'];
          final durationSeconds = data['routes'][0]['duration'];

          setState(() {
            fetchDistance = "${(distanceMeters / 1000).toStringAsFixed(2)} km";
            fetchDuration = "${(durationSeconds / 60).toStringAsFixed(0)} min";
          });
        }
      }
    } catch (e) {
    }
  }

  void startAutoDistanceTimer() {
    _distanceTimer?.cancel();
    _distanceTimer = Timer.periodic(
        Duration(
            seconds: int.parse(
                context.read<MinimumHitsTimeToUpdateTime>().state.value ??
                    "60")), (timer) {
      if (rideStatus == "ongoing") {
        stopAutoDistanceTimer();
        return;
      }
      _fetchDistanceAndTime(
          fromLat: double.parse(context
              .read<BookRideRealTimeDataBaseCubit>()
              .state
              .pickupAddressLatitude),
          fromLng: double.parse(context
              .read<BookRideRealTimeDataBaseCubit>()
              .state
              .pickupAddressLongitude),
          toLat: updatedDriverLat,
          toLng: updatedDriverLng,
          beforePickUp: true);

      setState(() {});
    });
  }

  void startAutoDistanceTimerForDropOff() {
    _distanceTimer?.cancel();
    _distanceTimer = Timer.periodic(
        Duration(
            seconds: int.parse(
                context.read<MinimumHitsTimeToUpdateTime>().state.value ??
                    "60")), (timer) {
      if (rideStatus == "complete") {
        stopAutoDistanceTimer();
        return;
      }
      _fetchDistanceAndTime(
          fromLat: updatedDriverLat,
          fromLng: updatedDriverLng,
          toLat: double.parse(context
              .read<BookRideRealTimeDataBaseCubit>()
              .state
              .dropoffAddressLatitude),
          toLng: double.parse(context
              .read<BookRideRealTimeDataBaseCubit>()
              .state
              .dropoffAddressLongitude),
          beforePickUp: false);

      setState(() {});
    });
  }

  Future<void> cancelRideRequest({
    required String rideId,
  }) async {
    try {
      if (rideId.isEmpty) {
        throw Exception('Ride ID cannot be empty');
      }

      final DatabaseReference rideRequestsRef =
          FirebaseDatabase.instance.ref().child('ride_requests');

      final rideRef = rideRequestsRef.child(rideId);

      final snapshot = await rideRef.get();

      if (snapshot.exists) {
        final data = snapshot.value as Map;

        String playerId = '';

        if (data["driverPlayerId"] != null &&
            data["driverPlayerId"].toString().trim().isNotEmpty &&
            data["driverPlayerId"].toString() != "null") {
          playerId = data["driverPlayerId"].toString();
        } else if (navigatorKey.currentContext!
            .read<RideRequestCubit>()
            .state
            .accepteDriverPlayerId
            .toString()
            .trim()
            .isNotEmpty) {
          playerId = navigatorKey.currentContext!
              .read<RideRequestCubit>()
              .state
              .accepteDriverPlayerId
              .toString();
        } else {
          playerId = navigatorKey.currentContext!
              .read<BookRideRealTimeDataBaseCubit>()
              .state
              .driverPlayerId
              .toString();
        }

        if (playerId.isNotEmpty && playerId != "null") {
          sendNotificationDirect(
            playerId: playerId,
            title: "❌ Ride Cancelled",
            message: "Rider has cancelled the ride.",
          );
        }
      }

      await rideRef.update({
        'status': 'cancelled',
      });
      final driversRef = FirebaseFirestore.instance.collection('drivers');
      final driverQuery =
          driversRef.where('ride_request.rideId', isEqualTo: rideId);
      final driverSnapshots = await driverQuery.get();

      final matchingDriverCount = driverSnapshots.docs.length;
      for (var doc in driverSnapshots.docs) {
        final driverId = doc.id;
        try {
          await driversRef.doc(driverId).update({
            'ride_request': {}, // Clear ride_request
            'rideStatus': 'available',
          });

          // ignore: empty_catches
        } catch (e) {}
      }

      await rideRef.remove();

      if (matchingDriverCount == 0) {}
    } catch (e) {
      // throw Exception('Failed to cancel ride request: $e');
    }
  }

  Widget _buildMapSection() {
    return Positioned(
      bottom: 300,
      left: 0,
      right: 0,
      top: 0,
      child: Stack(
        alignment: Alignment.center,
        children: [
          PersistentOSMMap(
            mapController: mapController,
            initialPosition: LatLng(
              double.parse(context
                  .read<BookRideRealTimeDataBaseCubit>()
                  .state
                  .pickupAddressLatitude),
              double.parse(context
                  .read<BookRideRealTimeDataBaseCubit>()
                  .state
                  .pickupAddressLongitude),
            ),
            initialZoom: currentZoom,
            shouldFitCamera: () {
              if (rideStatus != "ongoing" && _fitOnAccepted) {
                _fitOnAccepted = false;
                return true;
              } else if (rideStatus == "ongoing" && _fitOnOngoing) {
                _fitOnOngoing = false;
                return true;
              }
              return false;
            },
          ),
          if (otp.isEmpty) const shared.PulsingCircle(),
          // Map Controls
          Positioned(
            top: 60,
            right: 16,
            child: Column(
              children: [
                _buildMapControlButton(
                  icon: Icons.add,
                  onPressed: _zoomIn,
                ),
                const SizedBox(height: 12),
                _buildMapControlButton(
                  icon: Icons.remove,
                  onPressed: _zoomOut,
                ),
              ],
            ),
          ),
          if (!_isFollowingDriver && _trackingController.hasPosition)
            Positioned(
              bottom: 16,
              right: 16,
              child: _buildMapControlButton(
                icon: Icons.my_location_rounded,
                onPressed: _recenterOnDriver,
              ),
            ),
          // Back Button
        ],
      ),
    );
  }

  void _recenterOnDriver() {
    if (!_trackingController.hasPosition) return;
    final pos = _trackingController.actualPosition!;
    _isProgrammaticCameraMove = true;
    mapController.move(LatLng(pos.lat, pos.lng), currentZoom);
    _isProgrammaticCameraMove = false;
    setState(() {
      _isFollowingDriver = true;
    });
  }

  Widget _buildMapControlButton(
      {required IconData icon, required VoidCallback onPressed}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.2),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: IconButton(
        icon: Icon(icon, color: themeColor, size: 20),
        onPressed: onPressed,
      ),
    );
  }

  void _zoomIn() {
    setState(() {
      currentZoom = (currentZoom + 1).clamp(1.0, 18.0);
      mapController.move(mapController.camera.center, currentZoom);
    });
  }

  void _zoomOut() {
    setState(() {
      currentZoom = (currentZoom - 1).clamp(1.0, 18.0);
      mapController.move(mapController.camera.center, currentZoom);
    });
  }

  Future<void> _updateRide(
      {required String updatedRideId, required String upDatedBookingId}) async {
    if (updatedRideId.isEmpty || upDatedBookingId.isEmpty) {
      return;
    }

    final rideRequestRef =
        FirebaseDatabase.instance.ref().child("ride_requests");
    try {
      await rideRequestRef.child(updatedRideId).update({
        'bookingId': upDatedBookingId,
        'status': 'accepted',
      });
    } catch (error) {
      // showErrorToastMessage("Failed to update ride.");
    }
  }

  void _handleBookRideSuccess(BuildContext context, String pikupOtp,
      String dropOtp, String rideID, String bookingID) {
    context
        .read<GetRideRequestStatusCubit>()
        .listenToRouteStatus(rideId: rideID.toString());
    _fetchDriverLocationFromRealtimeDB(rideID);

    if (isSuccessFirst) return;

    isSuccessFirst = true;
    fetchTimer?.cancel();
    fetchTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      _fetchDriverLocationFromRealtimeDB(rideID);
    });
    _updateRide(updatedRideId: rideID, upDatedBookingId: bookingID.toString());

    box.put("PickOtp", pikupOtp);
    box.put("DropOtp", dropOtp);
    box.put("bookingId", bookingID);

    if (widget.statusOfRide == "accepted" || widget.statusOfRide == "pick_up") {
      paymentUrl = box.get("payment_url") ?? "";
    }

    otp = pikupOtp;
    dropotp = dropOtp;
    bookingId = bookingID.toString();
    rideId = rideID.toString();
    _addUserMarker();
    _addDriverMarker();
    _fetchDistanceAndTime(
        fromLat: double.parse(context
            .read<BookRideRealTimeDataBaseCubit>()
            .state
            .pickupAddressLatitude),
        fromLng: double.parse(context
            .read<BookRideRealTimeDataBaseCubit>()
            .state
            .pickupAddressLongitude),
        toLat: context.read<RideRequestCubit>().state.acceptedDriverLat,
        toLng: context.read<RideRequestCubit>().state.acceptedDriverLng,
        beforePickUp: true);
    startAutoDistanceTimer();
    _fetchPickupPolylines();
    getUnreadCount(rideId, loginModel?.data?.id.toString() ?? "");
    setState(() {});
    context.read<BookRideUserCubit>().removeBookRideState();
  }

  Stream<int> getUnreadCount(String rideId, String myId) {
    return FirebaseDatabase.instance
        .ref("ride_requests/$rideId/chat/messages")
        .onValue
        .map((event) {
      if (event.snapshot.value == null) return 0;

      Map data = event.snapshot.value as Map;
      int count = 0;

      data.forEach((key, value) {
        if (value["senderId"] != myId && value["seen"] != true) {
          count++;
        }
      });

      return count;
    });
  }

  bool isLiveRide = false;
  void _handleLiveRideSuccess(BuildContext context) {
    _fetchDriverLocationFromRealtimeDB(rideId);
    if (isLiveRide) return;
    fetchTimer?.cancel();
    fetchTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      _fetchDriverLocationFromRealtimeDB(rideId);
    });
    isLiveRide = true;
    context.read<UserMarkerCubitOSM>().removeMarker("User_marker");
    _addDropMarker();
    _addDriverMarker();
    _fetchDistanceAndTime(
        fromLat: context.read<RideRequestCubit>().state.acceptedDriverLat,
        fromLng: context.read<RideRequestCubit>().state.acceptedDriverLng,
        toLat: double.parse(context
            .read<BookRideRealTimeDataBaseCubit>()
            .state
            .dropoffAddressLatitude),
        toLng: double.parse(context
            .read<BookRideRealTimeDataBaseCubit>()
            .state
            .dropoffAddressLongitude),
        beforePickUp: false);
    context.read<OSMGetPolylineCubit>().resetPolylines();
    _fetchDropoffPolylines(); // Use dropoff polylines only
    startAutoDistanceTimerForDropOff();
  }

  Widget _buildDraggableSheet(BuildContext context) {
    return DraggableScrollableSheet(
      controller: _draggableController,
      initialChildSize: 0.48,
      minChildSize: 0.48,
      maxChildSize: 0.80,
      builder: (context, scrollController) {
        return SafeArea(
          bottom: false,
          child: Stack(
            children: [
              rideStatus == "ongoing"
                  ? const SosButtonWidget()
                  : const SizedBox(),
              Positioned.fill(
                top: 44,
                child: Container(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 40),
                  decoration: BoxDecoration(
                    color: notifires.getbgcolor,
                    borderRadius:
                        const BorderRadius.vertical(top: Radius.circular(32)),
                    boxShadow: [
                      BoxShadow(
                        color: themeColor.withValues(alpha: 0.14),
                        blurRadius: 24,
                        spreadRadius: 2,
                        offset: const Offset(0, -6),
                      ),
                    ],
                  ),
                  child: ListView(
                    controller: scrollController,
                    padding: const EdgeInsets.only(bottom: 26),
                    children: [
                      shared.buildDragHandleCompact(),
                      const SizedBox(height: 10),
                      if (rideStatus == "accepted")
                        _buildDriverInfoSection(context)
                      else if (otp.isEmpty)
                        _buildFindingDriverSection(context)
                      else
                        _buildDriverInfoSection(context),
                      const SizedBox(height: 14),
                      _buildBookingDetails(context),
                      _buildRideDetails(context),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildFindingDriverSection(BuildContext context) {
    return FindingDriverSection(statusOfRide: widget.statusOfRide);
  }

  Widget _buildDriverInfoSection(BuildContext context) {
    return DriverInfoSection(
      rideStatus: rideStatus,
      fetchDistance: fetchDistance,
      fetchDuration: fetchDuration,
      otp: otp,
      dropotp: dropotp,
      unreadCountStream: () =>
          getUnreadCount(rideId, loginModel?.data?.id.toString() ?? ""),
      onChatTap: (state) {
        goTo(
          RideChatScreen(
            myId: loginModel?.data?.id.toString() ?? "",
            myType: "user",
            rideId: rideId,
            driverImage: state.acceptedDriverImageUrl,
            driverName: state.acceptedDriverName,
            driverPlayerId: state.accepteDriverPlayerId.isEmpty
                ? context
                    .read<BookRideRealTimeDataBaseCubit>()
                    .state
                    .driverPlayerId
                : state.accepteDriverPlayerId,
          ),
        );
      },
      onCallTap: (phone) async {
        final Uri launchUri = Uri(scheme: 'tel', path: phone);

        if (await canLaunchUrl(launchUri)) {
          await launchUrl(launchUri);
        }
      },
    );
  }

  Widget _buildBookingDetails(BuildContext context) {
    return const BookingDetailsSection();
  }

  Widget _buildRideDetails(BuildContext context) {
    return RideDetailsSection(
      rideStatus: rideStatus,
      selectedVehicleData: widget.selectedVehicleData,
      onConfirmCancel: () async {
        isManuallyCancelled = true;
        box.delete("ride_data");
        if (bookingId.isNotEmpty) {
          context.read<UpdateRideStatusInDatabaseCubit>().updateRideStatus(
                context: context,
                bookingId: bookingId,
                rideStatus: "Cancelled",
              );
        }
        cancelRideRequest(
            rideId: context.read<RideRequestCubit>().state.rideId);
        if (widget.statusOfRide.isEmpty) {
          Navigator.pop(context);
          Navigator.pop(context);
        } else {
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (context) => const ItemHomeScreen()),
            (Route<dynamic> route) => false,
          );
          stopAutoDistanceTimer();
        }
      },
    );
  }

  @override
  void dispose() {
    fetchTimer?.cancel();
    locationUpdateTimer?.cancel();
    _distanceTimer?.cancel();
    _trackingController.dispose();
    _mapEventSubscription?.cancel();
    locationUpdateTimer = null;
    fetchTimer = null;
    isCurrentScreenActive = true;
    mapController.dispose();
    super.dispose();
  }
}
