import 'package:flutter/material.dart';
import 'package:ride_on/core/extensions/workspace.dart';
import 'package:ride_on/core/utils/translate.dart';

import '../../../../../../core/utils/theme/project_color.dart';
import '../../../../../../core/utils/theme/theme_style.dart';
import '../../../ride_custom_widget.dart' as shared;
import '../ride_request_palette.dart';
import 'cancel_ride_button.dart';
import 'vehicle_details_section.dart';

/// "Ride Details" / "Total Fare" block. Shows the fare card once the ride is
/// ongoing, otherwise the vehicle summary plus the cancel button.
///
/// Extracted verbatim from `_buildRideDetails` in
/// `google_map/send_ride_request_screen.dart`.
class RideDetailsSection extends StatelessWidget {
  final String rideStatus;
  final Map<String, dynamic> selectedVehicleData;
  final VoidCallback onConfirmCancel;

  const RideDetailsSection({
    super.key,
    required this.rideStatus,
    required this.selectedVehicleData,
    required this.onConfirmCancel,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 14),
        shared.buildSectionLabel(
          context,
          title: rideStatus == "ongoing"
              ? "Total Fare".translate(context)
              : "Ride Details".translate(context),
          icon: rideStatus == "ongoing"
              ? Icons.payments_rounded
              : Icons.local_taxi_rounded,
        ),
        const SizedBox(height: 8),
        if (rideStatus == "ongoing")
          Container(
            padding: const EdgeInsets.all(11),
            decoration: BoxDecoration(
              color: notifires.getbgcolor,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: themeColor.withValues(alpha: 0.35)),
            ),
            child: Row(
              children: [
                Container(
                  height: 38,
                  width: 38,
                  decoration: BoxDecoration(
                    color: whiteColor,
                    borderRadius: BorderRadius.circular(13),
                    border:
                        Border.all(color: themeColor.withValues(alpha: 0.45)),
                  ),
                  alignment: Alignment.center,
                  child: Image.asset("assets/images/cashIcon.png", height: 22),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Total Fare".translate(context),
                        style: regularBlack(context).copyWith(
                          fontSize: 9,
                          color: kRideRequestAccentBrown,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        "$currency ${selectedVehicleData["fare"]}",
                        style: heading2(context).copyWith(
                          color: kRideRequestDarkText,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          )
        else
          VehicleDetailsSection(selectedVehicleData: selectedVehicleData),
        const SizedBox(height: 14),
        if (rideStatus != "ongoing")
          CancelRideButton(onConfirmCancel: onConfirmCancel),
      ],
    );
  }
}
