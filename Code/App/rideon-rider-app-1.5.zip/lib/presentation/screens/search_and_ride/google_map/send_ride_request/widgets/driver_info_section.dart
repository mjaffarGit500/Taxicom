import 'package:flutter/material.dart';
import 'package:ride_on/core/services/data_store.dart';
import 'package:ride_on/core/utils/translate.dart';

import '../../../../../../core/utils/theme/project_color.dart';
import '../../../../../../core/utils/theme/theme_style.dart';
import '../../../../../cubits/realtime/ride_request_cubit.dart';
import '../../../ride_custom_widget.dart' as shared;
import '../ride_request_palette.dart';
import 'driver_card.dart';

/// Card shown once a driver is assigned: ETA/distance header, status pills, the
/// pickup and (for parcels) drop OTP cards, and the driver card.
///
/// Extracted verbatim from `_buildDriverInfoSection` in
/// `google_map/send_ride_request_screen.dart`.
class DriverInfoSection extends StatelessWidget {
  final String rideStatus;
  final String fetchDistance;
  final String fetchDuration;
  final String otp;
  final String dropotp;
  final Stream<int> Function() unreadCountStream;
  final void Function(RideRequestState state) onChatTap;
  final Future<void> Function(String phone) onCallTap;

  const DriverInfoSection({
    super.key,
    required this.rideStatus,
    required this.fetchDistance,
    required this.fetchDuration,
    required this.otp,
    required this.dropotp,
    required this.unreadCountStream,
    required this.onChatTap,
    required this.onCallTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: themeColor.withValues(alpha: 0.30)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      rideStatus == ""
                          ? "Driver on the way".translate(context)
                          : rideStatus == "pick_up"
                              ? "Driver has arrived at your pickup point"
                                  .translate(context)
                              : rideStatus == "accepted"
                                  ? "Driver on the way"
                                  : "Reaching".translate(context),
                      style: heading2Grey1(context).copyWith(fontSize: 10),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      fetchDistance.isEmpty
                          ? "Calculating...".translate(context)
                          : "$fetchDistance ${"away".translate(context)}",
                      style: regular(context).copyWith(
                        color: grey2,
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [kRideRequestDarkText, kRideRequestAccentBrown],
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.schedule_rounded,
                      color: Colors.white,
                      size: 12,
                    ),
                    const SizedBox(width: 5),
                    Text(
                      fetchDuration.isEmpty ? "..." : fetchDuration,
                      style: heading2(context)
                          .copyWith(color: Colors.white, fontSize: 10),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 9),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              shared.buildInfoPill(
                  icon: Icons.local_taxi_rounded,
                  label: rideStatus == "ongoing"
                      ? "Trip live".translate(context)
                      : "Driver assigned".translate(context),
                  colors: [themeColor, themeColor],
                  foreground: kRideRequestDarkText),
              shared.buildInfoPill(
                icon: Icons.route_rounded,
                label: fetchDistance.isEmpty
                    ? "Live ETA".translate(context)
                    : fetchDistance,
                colors: [
                  themeColor.withValues(alpha: 0.18),
                  themeColor.withValues(alpha: 0.30)
                ],
                foreground: kRideRequestAccentBrown,
              ),
            ],
          ),
          if (rideStatus != "ongoing") ...[
            const SizedBox(height: 10),
            shared.buildOtpCard(
              context,
              title: "Start your ride with PIN".translate(context),
              value: otp,
              icon: Icons.lock_clock_rounded,
              gradient: [themeColor, themeColor],
            ),
          ],
          if (rideStatus == "ongoing" &&
              box.get("current_parcel_data") != null) ...[
            const SizedBox(height: 10),
            shared.buildOtpCard(
              context,
              title:
                  "Share this drop OTP with the driver to complete the delivery"
                      .translate(context),
              value: dropotp,
              icon: Icons.inventory_2_rounded,
              gradient: [themeColor, themeColor],
            ),
          ],
          DriverCard(
            unreadCountStream: unreadCountStream,
            onChatTap: onChatTap,
            onCallTap: onCallTap,
          ),
        ],
      ),
    );
  }
}
