import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:ride_on/presentation/cubits/location/google_map/get_poliline_using_google.dart';
import 'package:ride_on/presentation/cubits/location/google_map/set_marker_cubit.dart';

class PersistentGoogleMap extends StatefulWidget {
  final LatLng initialPosition;
  final Set<Marker> markers;
  final Set<Polyline> polylines;
  final bool myLocationEnabled;
  final Function(GoogleMapController) onMapCreated;

  const PersistentGoogleMap({
    super.key,
    required this.initialPosition,
    required this.markers,
    required this.polylines,
    required this.myLocationEnabled,
    required this.onMapCreated,
  });

  @override
  PersistentGoogleMapState createState() => PersistentGoogleMapState();
}

class PersistentGoogleMapState extends State<PersistentGoogleMap> {
  GoogleMapController? _mapController;
  Set<Marker> markers = {};
  Set<Polyline> polyline = {};

  @override
  void initState() {
    super.initState();
    markers = widget.markers;
    polyline = widget.polylines;
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<GetPolylineCubit, GetPolylineState>(
      builder: (context, polylineState) {
        if (polylineState is GetPolylineUpdated) {
          polyline = polylineState.polylines ?? {};
          if (polyline.isNotEmpty) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              _moveCameraToFitPolylineAndMarkers();
            });
          }
          context.read<GetPolylineCubit>().resetPolylines();
        }

        return BlocBuilder<UserMarkerCubit, UserMarkerState>(
            builder: (context, markerState) {
          if (markerState is UserMarkerUpdated) {
            markers = markerState.markers;
          }
          return GoogleMap(
            initialCameraPosition: CameraPosition(
              target: widget.initialPosition,
              zoom: 15,
            ),
            myLocationEnabled: widget.myLocationEnabled,
            markers: markers,
            polylines: polyline,
            onMapCreated: (controller) {
              if (_mapController == null) {
                _mapController = controller;
                widget.onMapCreated(controller);
              }
            },
          );
        });
      },
    );
  }

  void _moveCameraToFitPolylineAndMarkers() {
    if (_mapController == null || polyline.isEmpty) return;

    LatLngBounds bounds;
    final points = polyline.expand((p) => p.points).toList();

    if (points.isEmpty) return;

    final southwestLat =
        points.map((p) => p.latitude).reduce((a, b) => a < b ? a : b);
    final southwestLng =
        points.map((p) => p.longitude).reduce((a, b) => a < b ? a : b);
    final northeastLat =
        points.map((p) => p.latitude).reduce((a, b) => a > b ? a : b);
    final northeastLng =
        points.map((p) => p.longitude).reduce((a, b) => a > b ? a : b);

    bounds = LatLngBounds(
      southwest: LatLng(southwestLat, southwestLng),
      northeast: LatLng(northeastLat, northeastLng),
    );

    _mapController!.animateCamera(
      CameraUpdate.newLatLngBounds(bounds, 150), // 150 = padding
    );
  }

  @override
  void dispose() {
    _mapController?.dispose();
    super.dispose();
  }
}
