import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_places_flutter/google_places_flutter.dart';
import 'package:google_places_flutter/model/prediction.dart';
import 'package:ride_on/core/extensions/workspace.dart';
import 'package:ride_on/core/utils/translate.dart';
import '../../../../core/services/config.dart';
import '../../../../core/utils/common_widget.dart';
import '../../../../core/utils/theme/project_color.dart';
import '../../../../core/utils/theme/theme_style.dart';
import '../../../cubits/book_ride_cubit.dart';
import '../../../cubits/location/user_current_location_cubit.dart';

class SearchMapScreen extends StatefulWidget {
  final String? selectedAddressTitle;
  final bool? checkStatus;
  const SearchMapScreen(
      {super.key, this.selectedAddressTitle, this.checkStatus});
  @override
  State<SearchMapScreen> createState() => _SearchMapScreenState();
}

class _SearchMapScreenState extends State<SearchMapScreen> {
  double selectedMapLat = defaultLat;
  double selectedMapLng = defaultLng;
  GoogleMapController? mapController;
  TextEditingController textEditingAddressSearchController =
      TextEditingController();
  FocusNode focusNode1 = FocusNode();

  bool _isMapMoving = false;
  bool _isResolvingAddress = false;
  bool _searchFocused = false;

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      selectedMapLat = double.parse(context
          .read<BookRideRealTimeDataBaseCubit>()
          .state
          .pickupAddressLatitude);
      selectedMapLng = double.parse(context
          .read<BookRideRealTimeDataBaseCubit>()
          .state
          .pickupAddressLongitude);

      textEditingAddressSearchController.clear();
    });
    focusNode1.addListener(() {
      if (!mounted) return;
      setState(() {
        _searchFocused = focusNode1.hasFocus;
      });
    });
    super.initState();
  }

  void _onMapCreated(GoogleMapController controller) {
    if (mapController != null) {
      mapController!.dispose();
    }
    mapController = controller;
    if (selectedMapLat != 0 && selectedMapLng != 0) {
      mapController?.animateCamera(
          CameraUpdate.newLatLng(LatLng(selectedMapLat, selectedMapLng)));
    }
  }

  void _zoomIn() {
    mapController?.animateCamera(CameraUpdate.zoomIn());
  }

  void _zoomOut() {
    mapController?.animateCamera(CameraUpdate.zoomOut());
  }

  void _moveToCurrentLocation({LatLng? currentLocation}) {
    selectedMapLat = currentLocation!.latitude;
    selectedMapLng = currentLocation.longitude;
    mapController?.animateCamera(CameraUpdate.newLatLng(currentLocation));
  }

  @override
  void dispose() {
    _debounce?.cancel();
    mapController?.dispose();
    focusNode1.dispose();
    textEditingAddressSearchController.dispose();
    super.dispose();
  }

  Timer? _debounce;

  void _handleSetAddress(BuildContext context) {
    if (textEditingAddressSearchController.text.isNotEmpty) {
      if (widget.checkStatus == true) {
        context
            .read<SelectedAddressCubit>()
            .updateIsSelectePickupdAddress(isCheckedSelectedPickup: true);
        context
            .read<SelectedAddressCubit>()
            .updateIsSelectedDropOffAddress(isCheckedSelectedDropOff: false);
        context
            .read<SelectedAddressCubit>()
            .updateIsCrossIconSelectePickup(icheckedCrossIconPickup: true);
        context.read<SelectedAddressCubit>().pickupAddressController.text =
            textEditingAddressSearchController.text.toString();
        context.read<GetCordinatesCubit>().getCoordinates(
            address: textEditingAddressSearchController.text.toString());

        Navigator.of(context).pop();
      } else {
        context
            .read<SelectedAddressCubit>()
            .updateIsSelectePickupdAddress(isCheckedSelectedPickup: false);
        context
            .read<SelectedAddressCubit>()
            .updateIsSelectedDropOffAddress(isCheckedSelectedDropOff: true);
        context
            .read<SelectedAddressCubit>()
            .updateIsCrossIconSelectedDropOff(
                ischeckedCrossIconDropOff: true);

        context.read<SelectedAddressCubit>().dropOffAddressController.text =
            textEditingAddressSearchController.text.toString();
        context.read<GetCordinatesCubit>().getCoordinates(
            address: textEditingAddressSearchController.text.toString());

        if (context.read<SelectedAddressCubit>().dropOffAddressController.text ==
            context.read<SelectedAddressCubit>().pickupAddressController.text) {
          showErrorToastMessage(
              "Please select different address".translate(context));
          return;
        }
        Navigator.of(context).pop();
      }
    } else {
      showErrorToastMessage("please selected the address".translate(context));
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool isPickup = widget.checkStatus == true;
    final bottomSafe = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: notifires.getbgcolor,
      body: Stack(
        children: [
          // ---- Map ----
          BlocBuilder<UpdateSearchMapAddressCubit, UpdateSearchMapAddressState>(
              builder: (context, state) {
            if (state is UpdateSearchMapAddresSuccess) {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                textEditingAddressSearchController.text =
                    state.currentAddress.toString();
                context.read<UpdateSearchMapAddressCubit>().removeAddress();
                if (_isResolvingAddress && mounted) {
                  setState(() => _isResolvingAddress = false);
                }
              });
            }
            return GoogleMap(
              onMapCreated: _onMapCreated,
              scrollGesturesEnabled: true,
              rotateGesturesEnabled: true,
              zoomGesturesEnabled: true,
              compassEnabled: true,
              myLocationEnabled: false,
              myLocationButtonEnabled: false,
              zoomControlsEnabled: false,
              onCameraMoveStarted: () {
                if (!_isMapMoving) {
                  setState(() => _isMapMoving = true);
                }
              },
              onCameraMove: (CameraPosition position) {
                selectedMapLat = position.target.latitude;
                selectedMapLng = position.target.longitude;
              },
              onCameraIdle: () {
                if (_isMapMoving) {
                  setState(() => _isMapMoving = false);
                }

                if (_debounce?.isActive ?? false) {
                  _debounce!.cancel();
                }

                setState(() => _isResolvingAddress = true);

                _debounce = Timer(const Duration(milliseconds: 700), () {
                  context.read<UpdateSearchMapAddressCubit>().removeAddress();

                  context
                      .read<UpdateSearchMapAddressCubit>()
                      .getAddressFromLatLng(
                        latitude: selectedMapLat,
                        longitude: selectedMapLng,
                      );
                });
              },
              initialCameraPosition: CameraPosition(
                target: LatLng(selectedMapLat, selectedMapLng),
                zoom: 14,
              ),
            );
          }),

          // ---- Center pin ----
          Positioned.fill(
            child: IgnorePointer(
              child: Align(
                alignment: Alignment.center,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 40),
                  child: AnimatedSlide(
                    duration: const Duration(milliseconds: 180),
                    curve: Curves.easeOut,
                    offset: _isMapMoving ? const Offset(0, -0.08) : Offset.zero,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      margin: EdgeInsets.only(bottom: _isMapMoving ? 6 : 0),
                      child: Image.asset(
                        "assets/images/dropmarker.png",
                        height: 34,
                        width: 34,
                        alignment: Alignment.bottomCenter,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),

          // ---- Floating search header ----
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 16, 0),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    InkWell(
                      onTap: () => Navigator.of(context).pop(),
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        height: 46,
                        width: 46,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: whiteColor,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.08),
                              blurRadius: 12,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Icon(Icons.arrow_back,
                            size: 20, color: blackColor),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        curve: Curves.easeOut,
                        decoration: BoxDecoration(
                          color: whiteColor,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: _searchFocused
                                ? themeColor
                                : Colors.transparent,
                            width: 1.3,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black
                                  .withOpacity(_searchFocused ? 0.12 : 0.08),
                              blurRadius: _searchFocused ? 18 : 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: GooglePlaceAutoCompleteTextField(
                          containerVerticalPadding: 6,
                          focusNode: focusNode1,
                          containerHorizontalPadding: 0,
                          textStyle:
                              regularBlack(context).copyWith(fontSize: 14.5),
                          textEditingController:
                              textEditingAddressSearchController,
                          boxDecoration: BoxDecoration(
                            color: Colors.transparent,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          isLatLngRequired: true,
                          googleAPIKey: Config.googleKey,
                          countries: null,
                          inputDecoration: InputDecoration(
                              isDense: true,
                              contentPadding: const EdgeInsets.symmetric(
                                  vertical: 16),
                              prefixIcon: Icon(
                                Icons.search_rounded,
                                color: notifires.getGrey3whiteColor,
                                size: 21,
                              ),
                              hintStyle: regular3(context).copyWith(
                                  color: notifires.getGrey3whiteColor,
                                  fontSize: 14.5),
                              hintText: (isPickup
                                      ? "Search pickup location"
                                      : "Search drop-off location")
                                  .translate(context),
                              border: InputBorder.none),
                          getPlaceDetailWithLatLng: (Prediction prediction) {
                            if (prediction.lat != null &&
                                prediction.lng != null) {
                              _moveToCurrentLocation(
                                  currentLocation: LatLng(
                                      double.parse(prediction.lat!),
                                      double.parse(prediction.lng!)));
                            }
                          },
                          itemClick: (Prediction prediction) {},
                          itemBuilder: (context, index, Prediction prediction) {
                            return AnimatedOpacity(
                              duration: const Duration(milliseconds: 180),
                              opacity: 1,
                              child: Container(
                                color: whiteColor,
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 14, vertical: 10),
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Icon(
                                          Icons.location_on_outlined,
                                          color: themeColor,
                                          size: 20,
                                        ),
                                        const SizedBox(width: 10),
                                        Expanded(
                                          child: Text(
                                            prediction.description ?? "",
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            style: regular2(context).copyWith(
                                              color:
                                                  notifires.getwhiteblackColor,
                                              fontSize: 14,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 8),
                                    Container(
                                      height: 1,
                                      color: notifires.getGrey4whiteColor
                                          .withOpacity(0.35),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // ---- Zoom control ----
          Positioned(
            right: 16,
            bottom: 240 + bottomSafe,
            child: Container(
              decoration: BoxDecoration(
                color: whiteColor,
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.10),
                    blurRadius: 14,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _MapControlButton(
                    icon: Icons.add,
                    onTap: _zoomIn,
                  ),
                  Container(
                    height: 1,
                    width: 28,
                    color: notifires.getGrey4whiteColor.withOpacity(0.4),
                  ),
                  _MapControlButton(
                    icon: Icons.remove,
                    onTap: _zoomOut,
                  ),
                ],
              ),
            ),
          ),

          // ---- Bottom confirmation panel ----
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              padding: EdgeInsets.fromLTRB(20, 10, 20, 20 + bottomSafe),
              decoration: BoxDecoration(
                color: whiteColor,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(26),
                  topRight: Radius.circular(26),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.10),
                    blurRadius: 24,
                    offset: const Offset(0, -6),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      height: 4,
                      width: 40,
                      margin: const EdgeInsets.only(bottom: 16),
                      decoration: BoxDecoration(
                        color: notifires.getGrey4whiteColor.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  Text(
                    (isPickup ? "Pickup Location" : "Drop-off Location")
                        .translate(context),
                    style: headingBlack(context)
                        .copyWith(fontSize: 15, color: blackColor),
                  ),
                  const SizedBox(height: 10),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 200),
                    child: _isResolvingAddress
                        ? Row(
                            key: const ValueKey("resolving"),
                            children: [
                              SizedBox(
                                height: 15,
                                width: 15,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: themeColor,
                                ),
                              ),
                              const SizedBox(width: 10),
                              Text(
                                "Finding address...".translate(context),
                                style: heading3Grey1(context)
                                    .copyWith(fontSize: 13.5),
                              ),
                            ],
                          )
                        : textEditingAddressSearchController.text.isEmpty
                            ? Column(
                                key: const ValueKey("empty"),
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Choose your location".translate(context),
                                    style: regular2(context).copyWith(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14.5,
                                      color: notifires.getwhiteblackColor,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    "Move the map or search for an address"
                                        .translate(context),
                                    style: heading3Grey1(context)
                                        .copyWith(fontSize: 13),
                                  ),
                                ],
                              )
                            : Row(
                                key: const ValueKey("address"),
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Icon(Icons.location_on,
                                      color: themeColor, size: 20),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      textEditingAddressSearchController.text,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: regular2(context).copyWith(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14.5,
                                        color: notifires.getwhiteblackColor,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                  ),
                  const SizedBox(height: 18),
                  CustomsButtons(
                    text: "Set Address",
                    backgroundColor: themeColor,
                    onPressed: () => _isResolvingAddress
                        ? () {}
                        : _handleSetAddress(context),
                    textColor: blackColor,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MapControlButton extends StatefulWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _MapControlButton({required this.icon, required this.onTap});

  @override
  State<_MapControlButton> createState() => _MapControlButtonState();
}

class _MapControlButtonState extends State<_MapControlButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapCancel: () => setState(() => _pressed = false),
      onTapUp: (_) => setState(() => _pressed = false),
      child: InkWell(
        onTap: widget.onTap,
        child: AnimatedScale(
          duration: const Duration(milliseconds: 120),
          scale: _pressed ? 0.9 : 1,
          child: SizedBox(
            height: 44,
            width: 44,
            child: Icon(widget.icon, size: 20, color: blackColor),
          ),
        ),
      ),
    );
  }
}