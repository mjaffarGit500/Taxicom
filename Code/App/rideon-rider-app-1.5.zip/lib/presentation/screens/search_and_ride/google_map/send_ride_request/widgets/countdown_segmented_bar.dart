import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on/core/extensions/workspace.dart';
import 'package:ride_on/core/services/data_store.dart';
import 'package:ride_on/core/utils/translate.dart';

import '../../../../../../core/utils/common_widget.dart';
import '../../../../../../core/utils/theme/project_color.dart';
import '../../../../../../core/utils/theme/theme_style.dart';
import '../../../../../cubits/book_ride_cubit.dart';
import '../../../../../cubits/general_cubit.dart';
import '../../../../../cubits/location/get_nearby_drivers_cubit.dart';
import '../../../../../cubits/vehicle_data/get_vehicle_cetgegory_cubit.dart';
import '../../../../home/item_home_screen.dart';

class CountdownSegmentedBar extends StatefulWidget {
  final String statusOfRide;

  const CountdownSegmentedBar({super.key, required this.statusOfRide});

  @override
  State<CountdownSegmentedBar> createState() => _CountdownSegmentedBarState();
}

class _CountdownSegmentedBarState extends State<CountdownSegmentedBar>
    with WidgetsBindingObserver {
  int totalSeconds = 60;
  int segmentCount = 5;
  late double segmentSeconds; //
  late Timer _timer;
  DateTime? _startTime;

  int get _elapsedSeconds {
    if (_startTime == null) return 0;
    return DateTime.now()
        .difference(_startTime!)
        .inSeconds
        .clamp(0, totalSeconds);
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    final durationFromCubit =
        context.read<DriverSearchIntervalCubit>().state.value;
    totalSeconds = int.tryParse(durationFromCubit ?? "60") ?? 60;
    // Fixed segment count
    segmentCount = 5;
    // Dynamic segment duration
    segmentSeconds = totalSeconds / segmentCount;
    _startCountdown();
  }

  void _startCountdown() {
    _startTime = DateTime.now();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      final elapsed = _elapsedSeconds;

      if (elapsed > totalSeconds) {
        _timer.cancel();
      } else if (elapsed == totalSeconds) {
        setState(() {});
        Future.delayed(const Duration(milliseconds: 500), () {
          if (mounted) showBottomSheetMessage();
        });
        _timer.cancel();
      } else {
        setState(() {});
      }
    });
  }

  void _resetCountdown() {
    _timer.cancel();
    setState(() {
      _startTime = DateTime.now();
    });
    _startCountdown();
  }

  void _stopCountdown() {
    if (_timer.isActive) {
      _timer.cancel();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _stopCountdown();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      setState(() {});
    }
  }

  int get remainingSeconds =>
      (totalSeconds - _elapsedSeconds).clamp(0, totalSeconds);

  int get filledSegments => (_elapsedSeconds / segmentSeconds).floor();

  double get currentSegmentProgress =>
      (_elapsedSeconds % segmentSeconds) / segmentSeconds;

  void showBottomSheetMessage() {
    showModalBottomSheet(
      context: context,
      backgroundColor: notifires.getbgcolor,
      isDismissible: false,
      useSafeArea: true,
      builder: (context) {
        return PopScope(
          canPop: false,
          child: Container(
            width: double.maxFinite,
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.error_outline,
                  size: 50,
                  color: Colors.red,
                ),
                const SizedBox(height: 16),
                Text(
                  "Driver has not accepted your ride.".translate(context),
                  textAlign: TextAlign.center,
                  style: heading2Grey1(context)
                      .copyWith(fontSize: 16, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 8),
                Text(
                  "Try again or choose a different ride. Don't worry, we're here to help!"
                      .translate(context),
                  textAlign: TextAlign.center,
                  style: heading3Grey1(context).copyWith(fontSize: 14),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {
                        box.delete("ride_data");
                        isManuallyCancelled = true;

                        if (widget.statusOfRide.isEmpty) {
                          Navigator.pop(context);
                          Navigator.pop(context);
                        } else {
                          Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const ItemHomeScreen(),
                            ),
                            (Route<dynamic> route) => false,
                          );
                        }
                      },
                      child: Container(
                        height: 40,
                        width: 160,
                        alignment: Alignment.center,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: redColor,
                          borderRadius: BorderRadius.circular(40),
                        ),
                        child: Text(
                          "Cancel Ride".translate(context),
                          style: TextStyle(
                            color: whiteColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 20),
                    InkWell(
                      onTap: () {
                        box.delete("ride_data");
                        Navigator.pop(context);
                        _resetCountdown();

                        final state =
                            context.read<BookRideRealTimeDataBaseCubit>().state;

                        context.read<DriverNearByCubit>().getNearbyDrivers(
                              checkRestart: true,
                              distance: 15,
                              pickupLat:
                                  double.parse(state.pickupAddressLatitude),
                              pickupLng:
                                  double.parse(state.pickupAddressLongitude),
                              vehicleTypeId: context
                                  .read<VehicleDataUpdateCubit>()
                                  .state
                                  .vehicleSelectedId
                                  .toString(),
                            );

                        isManuallyCancelled = false;
                      },
                      child: Container(
                        height: 40,
                        width: 120,
                        alignment: Alignment.center,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: notifires.getBoxColor,
                          borderRadius: BorderRadius.circular(40),
                        ),
                        child: Text(
                          "Retry".translate(context),
                          style: TextStyle(
                            color: grey1,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 40),
              ],
            ),
          ),
        );
      },
    );
  }

  void showNoDriverFoundBottomSheet() {
    showModalBottomSheet(
      context: context,
      isDismissible: false,
      enableDrag: false,
      backgroundColor: Colors.white,
      builder: (context) {
        final double bottomPadding = MediaQuery.of(context).padding.bottom;

        return PopScope(
          canPop: false,
          child: Container(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + bottomPadding),
            child: Container(
              width: double.maxFinite,
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: themeColor.withValues(alpha: 0.18),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.location_off_rounded,
                      size: 55,
                      color: Color(0xFF8A5A10),
                    ),
                  ),
                  const SizedBox(height: 18),
                  Text(
                    "No nearby drivers found".translate(context),
                    textAlign: TextAlign.center,
                    style: heading2Grey1(context).copyWith(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF2A1E1A),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    "We couldn’t find any drivers around your pickup location. Please try again after a moment."
                        .translate(context),
                    textAlign: TextAlign.center,
                    style: heading3Grey1(context).copyWith(
                      fontSize: 12,
                      color: const Color(0xFF8A5A10),
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 26),
                  CustomsButtons(
                      text: "Try again",
                      backgroundColor: themeColor,
                      onPressed: () {
                        Navigator.pop(context);
                        _resetCountdown();

                        final state =
                            context.read<BookRideRealTimeDataBaseCubit>().state;

                        context.read<DriverNearByCubit>().getNearbyDrivers(
                              checkRestart: false,
                              distance: 15,
                              pickupLat:
                                  double.parse(state.pickupAddressLatitude),
                              pickupLng:
                                  double.parse(state.pickupAddressLongitude),
                              vehicleTypeId: context
                                  .read<VehicleDataUpdateCubit>()
                                  .state
                                  .vehicleSelectedId
                                  .toString(),
                            );
                        setState(() {});
                      }),
                  const SizedBox(height: 14),
                  CustomsButtons(
                      text: "Cancel Ride",
                      backgroundColor: redColor2,
                      textColor: whiteColor,
                      onPressed: () {
                        isManuallyCancelled = true;
                        if (widget.statusOfRide.isEmpty) {
                          Navigator.pop(context);
                          Navigator.pop(context);
                        } else {
                          Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const ItemHomeScreen()),
                            (Route<dynamic> route) => false,
                          );
                        }
                      }),
                  const SizedBox(height: 8),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<DriverNearByCubit, DriverNearByState>(
      listener: (context, state) {
        if (state is DriverUpdated) {
          if (state.nearbyDrivers!.isEmpty) {
            _stopCountdown();
            showNoDriverFoundBottomSheet();
            context.read<DriverNearByCubit>().resetNearByDriverState();
            return;
          }
        }
      },
      child: Column(
        children: [
          Row(
            children: List.generate(segmentCount, (index) {
              final int reversedIndex = segmentCount - 1 - index;
              double progress;

              if (reversedIndex < filledSegments) {
                progress = 0.0;
              } else if (reversedIndex == filledSegments) {
                progress = 1.0 - currentSegmentProgress;
              } else {
                progress = 1.0;
              }

              return Expanded(
                child: Padding(
                  padding: EdgeInsets.only(
                      right: index != segmentCount - 1 ? 4.0 : 0.0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(3),
                    child: LinearProgressIndicator(
                      value: progress,
                      minHeight: 8,
                      backgroundColor: grey5,
                      valueColor: AlwaysStoppedAnimation<Color>(appgreen),
                    ),
                  ),
                ),
              );
            }),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Text(
                "${(remainingSeconds ~/ 60).toString().padLeft(2, '0')}:${(remainingSeconds % 60).toString().padLeft(2, '0')} ${"min".translate(context)}",
                style: const TextStyle(color: Color(0xFF8A5A10), fontSize: 12),
              ),
              const Spacer(),
              Text(
                "Waiting...".translate(context),
                style: regular(context).copyWith(
                  fontSize: 12,
                  color: const Color(0xFF8A5A10),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
