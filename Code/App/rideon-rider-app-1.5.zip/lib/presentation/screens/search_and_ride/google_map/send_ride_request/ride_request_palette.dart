import 'package:flutter/material.dart';


const Color kRideRequestDarkText = Color(0xFF2A1E1A);
const Color kRideRequestAccentBrown = Color(0xFF8A5A10);
