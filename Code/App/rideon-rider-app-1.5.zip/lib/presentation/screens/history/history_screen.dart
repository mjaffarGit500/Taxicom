import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/domain/entities/history_data.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:shimmer/shimmer.dart';
import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../cubits/history/history_cubit.dart';
import 'history_detail_screen.dart';

class HistoryScreen extends StatefulWidget {
  final bool? isBackButton;
  const HistoryScreen({super.key, this.isBackButton});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {


  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<HistoryCubit>().getHistoryData(
          context: context,
          bookingKeyMap: {"typeId": "completed", "offset": "$offset"});
    });
  }

  int offset = 0;
  List<Bookings> bookings = [];

  BookingRideData? bookingRideData;

  String formatDate(String dateStr) {
    try {
      if (dateStr.isEmpty) return "";

      final inputDate = DateTime.tryParse(dateStr);
      if (inputDate == null) return dateStr;

      final formattedDate = DateFormat("dd MMM yyyy").format(inputDate);
      return formattedDate;
    } catch (e) {
      return dateStr;
    }
  }

  bool isShimmer = true;

  RefreshController refreshController = RefreshController();

  void onLoading() {
    isShimmer = false;
    context.read<HistoryCubit>().getHistoryData(
        context: context,
        bookingKeyMap: {"typeId": "completed", "offset": "$offset"});
    refreshController.loadComplete();
  }

  void onRefresh() {
    bookings.clear();
    offset = 0;
    isShimmer = true;
    context.read<HistoryCubit>().getHistoryData(
        context: context,
        bookingKeyMap: {"typeId": "completed", "offset": "$offset"});
    refreshController.loadComplete();
  }

  Widget _statusBadge(BuildContext context, String status) {
    final bg = getStatusBackground(status);
    final fg = getStatusColor(status);
    IconData icon;
    switch (status.toLowerCase()) {
      case 'completed':
        icon = Icons.check_circle_rounded;
        break;
      case 'cancelled':
        icon = Icons.cancel_rounded;
        break;
      default:
        icon = Icons.access_time_rounded;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: fg.withValues(alpha: 0.30)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: fg),
          const SizedBox(width: 5),
          Text(
            status.translate(context),
            style: headingBlack(context).copyWith(
              color: fg,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRideCard(BuildContext context, Bookings ride) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => HistoryDetailScreen(rideData: ride),
            ),
          );
        },
        borderRadius: BorderRadius.circular(20),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: themeColor.withValues(alpha: 0.22)),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Gold-to-orange gradient accent strip
                Container(
                  height: 4,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [themeColor, themeColor],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Date + Fare
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(7),
                                decoration: BoxDecoration(
                                  color: themeColor.withValues(alpha: 0.14),
                                  borderRadius: BorderRadius.circular(9),
                                ),
                                child:   Icon(
                                  Icons.calendar_today_rounded,
                                  size: 13,
                                  color: brown,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                formatDate(ride.rideDate ?? ""),
                                style: headingBlackBold(context).copyWith(
                                  fontSize: 13,
                                  color: dark,
                                ),
                              ),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 11, vertical: 6),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [themeColor, themeColor],
                              ),
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: themeColor.withValues(alpha: 0.35),
                                  blurRadius: 8,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.payments_rounded,
                                    size: 13, color: blackColor),
                                const SizedBox(width: 5),
                                Text(
                                  "${ride.currencyCode} ${ride.amountToPay}",
                                  style: TextStyle(
                                    color: blackColor,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Divider(
                          color: themeColor.withValues(alpha: 0.18), height: 1),
                      const SizedBox(height: 12),
                      // Route visualization
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: 18,
                            child: Column(
                              children: [
                                const SizedBox(height: 8),
                                Container(
                                  width: 11,
                                  height: 11,
                                  decoration: BoxDecoration(
                                    color: greenback,
                                    shape: BoxShape.circle,
                                    boxShadow: [
                                      BoxShadow(
                                        color:
                                            greenback.withValues(alpha: 0.50),
                                        blurRadius: 6,
                                        spreadRadius: 1,
                                      ),
                                    ],
                                  ),
                                ),
                                ...List.generate(
                                    6,
                                    (_) => Padding(
                                          padding:
                                              const EdgeInsets.only(top: 3),
                                          child: Container(
                                            width: 1.5,
                                            height: 5,
                                            color:
                                                brown.withValues(alpha: 0.30),
                                          ),
                                        )),
                                const SizedBox(height: 3),
                                Container(
                                  width: 11,
                                  height: 11,
                                  decoration: BoxDecoration(
                                    color: brown,
                                    shape: BoxShape.circle,
                                    boxShadow: [
                                      BoxShadow(
                                        color: brown.withValues(alpha: 0.45),
                                        blurRadius: 6,
                                        spreadRadius: 1,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 7),
                                  decoration: BoxDecoration(
                                    color: greenback.withValues(alpha: 0.07),
                                    borderRadius: BorderRadius.circular(9),
                                    border: Border.all(
                                        color:
                                            greenback.withValues(alpha: 0.22)),
                                  ),
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Icon(Icons.trip_origin_rounded,
                                          size: 12, color: greenback),
                                      const SizedBox(width: 6),
                                      Expanded(
                                        child: Text(
                                          ride.pickupLocation?.address ?? "",
                                          style: headingBlack(context).copyWith(
                                              fontSize: 12, color: dark),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 7),
                                  decoration: BoxDecoration(
                                    color: brown.withValues(alpha: 0.06),
                                    borderRadius: BorderRadius.circular(9),
                                    border: Border.all(
                                        color: brown.withValues(alpha: 0.22)),
                                  ),
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                        Icon(Icons.location_on_rounded,
                                          size: 12, color: brown),
                                      const SizedBox(width: 6),
                                      Expanded(
                                        child: Text(
                                          ride.dropoffLocation?.address ?? "",
                                          style: headingBlack(context).copyWith(
                                              fontSize: 12, color: dark),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      // Status + vehicle type
                      if (ride.status != null && ride.status!.isNotEmpty)
                        Row(
                          children: [
                            _statusBadge(context, ride.status!),
                            const Spacer(),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 6),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    themeColor.withValues(alpha: 0.16),
                                    const Color(0xFFFF8C00)
                                        .withValues(alpha: 0.10),
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                    color: themeColor.withValues(alpha: 0.28)),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    (ride.deliveryPhotos ?? []).isEmpty
                                        ? Icons.local_taxi_rounded
                                        : Icons.shopping_bag_rounded,
                                    size: 15,
                                    color: brown,
                                  ),
                                  const SizedBox(width: 5),
                                  Text(
                                    (ride.deliveryPhotos ?? []).isEmpty
                                        ? "Ride".translate(context)
                                        : "Delivery".translate(context),
                                    style:   TextStyle(
                                      fontSize: 11,
                                      color: brown,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildShimmerCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      child: Shimmer.fromColors(
        baseColor: grey5,
        highlightColor: grey4,
        child: Container(
          height: 218,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // ignore: deprecated_member_use
    return WillPopScope(
      onWillPop: () async {
        if (widget.isBackButton == true) return true;
        return false;
      },
      child: Scaffold(
        backgroundColor: bg,
        appBar: AppBar(
          elevation: 0,
          leadingWidth: 80,
          backgroundColor: notifires.getbgcolor,
          surfaceTintColor: notifires.getbgcolor,
          leading: Padding(
            padding:
                const EdgeInsets.only(left: 16, top: 8, bottom: 8, right: 17),
            child: InkWell(
              onTap: () => Navigator.of(context).pop(),
              borderRadius: BorderRadius.circular(14),
              child: Container(
                decoration: BoxDecoration(
                  color: themeColor,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: themeColor.withValues(alpha: 0.28)),
                  boxShadow: [
                    BoxShadow(
                      color: themeColor.withValues(alpha: 0.15),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child:   Icon(
                  Icons.arrow_back_ios_new_rounded,
                  size: 16,
                  color: dark,
                ),
              ),
            ),
          ),
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Rich Header ──────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: themeColor,
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: Icon(
                          Icons.history_rounded,
                          size: 24,
                          color: blackColor,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "History".translate(context),
                            style: regularBlack(context).copyWith(
                              fontSize: 22,
                              fontWeight: FontWeight.w800,
                              color: dark,
                            ),
                          ),
                          Text(
                            "Your past rides".translate(context),
                            style: regularBlack(context).copyWith(
                              fontSize: 12,
                              color: brown,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Divider(color: themeColor.withValues(alpha: 0.22), height: 1),
            // ── List ────────────────────────────────────────
            Expanded(
              child: BlocBuilder<HistoryCubit, HistoryState>(
                  builder: (context, state) {
                if (state is HistoryLoading && isShimmer) {
                  return ListView.builder(
                    itemCount: 5,
                    padding: const EdgeInsets.only(top: 10),
                    itemBuilder: (context, index) => _buildShimmerCard(),
                  );
                }
                if (state is HistorySuccess) {
                  isShimmer = true;
                  bookings.addAll(state.bookings ?? []);
                  offset = state.historyModel?.data?.offset ?? 0;
                }
                return SmartRefresher(
                  controller: refreshController,
                  onLoading: onLoading,
                  onRefresh: onRefresh,
                  enablePullUp: offset == -1 ? false : true,
                  child: bookings.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                padding: const EdgeInsets.all(24),
                                child: Icon(Icons.history_rounded,
                                    size: 35, color: themeColor),
                              ),
                              const SizedBox(height: 16),
                              Text(
                                "Order history not found".translate(context),
                                style: headingBlack(context).copyWith(
                                    color: dark.withValues(alpha: 0.60)),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.only(top: 10, bottom: 50),
                          itemCount: bookings.length,
                          itemBuilder: (context, index) =>
                              _buildRideCard(context, bookings[index]),
                        ),
                );
              }),
            ),
          ],
        ),
      ),
    );
  }
}

class RideHistory {
  final String dateTime;
  final String location;
  final double price;
  final String status;

  RideHistory({
    required this.dateTime,
    required this.location,
    required this.price,
    required this.status,
  });
}
