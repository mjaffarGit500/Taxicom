import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';
import 'package:ride_on/app/route_settings.dart';
import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/presentation/cubits/localizations_cubit.dart';
import 'package:ride_on/presentation/screens/onboarding/language_select_screen.dart';
import 'package:ride_on/presentation/widgets/auth_widgets.dart';
import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../cubits/auth/apple_login_cubit.dart';
import '../../cubits/auth/google_login_cubit.dart';
import '../auth/google_update_screen.dart';
import '../auth/signup_screen.dart';
import '../home/item_home_screen.dart';

class Onboardingscreen extends StatefulWidget {
  const Onboardingscreen({super.key});

  @override
  State<Onboardingscreen> createState() => _OnboardingscreenState();
}

class _OnboardingscreenState extends State<Onboardingscreen> {
  List content = [
    {
      "image": "assets/images/cuate.svg",
      "title": "More than just a ride, it's a vibe!",
      "description":
          "Book rides in seconds, track your arrival in real-time, and enjoy stress-free journeys. Choose from different ride options, all driven by professional and friendly drivers."
    },
  ];

  late PageController pageController;
  int currentIndex = 0;
  @override
  void initState() {
    super.initState();
    pageController = PageController(initialPage: 0);
  }

  @override
  void dispose() {
    pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    notifires = Provider.of<ColorNotifires>(context, listen: true);
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8EE),
      body: MultiBlocListener(
          listeners: [
            BlocListener<GoogleLoginCubit, GoogleLoginState>(
              listener: (context, state) {
                if (state is GoogleLoginSucess) {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const ItemHomeScreen()));
                } else if (state is AddPhoneNumberState) {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => GoogleUpdate(
                                email: state.loginModel.data?.email ?? "",
                              )));
                } else if (state is GoogleLoginFailure) {
                  showErrorToastMessage(state.error);
                }
              },
            ),
            BlocListener<AppleLoginCubit, AppleLoginState>(
              listener: (context, state) {
                if (state is AppleLoginSuccess) {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const ItemHomeScreen()));
                } else if (state is AddPhoneNumberAppleState) {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const GoogleUpdate()));
                } else if (state is AppleLoginFailure) {
                  closeLoading();
                  showErrorToastMessage(state.error);
                }
              },
            )
          ],
          child: SafeArea(
            child: LayoutBuilder(
              builder: (context, constraints) {
                final availableHeight = constraints.maxHeight;
                final isCompact = availableHeight < 700;
                return Stack(
                  children: [
                    SizedBox(
                      height: availableHeight,
                      child: Column(
                        children: [
                          SizedBox(height: isCompact ? 20 : 50),
                          // Editorial dark hero panel with the car spotlit inside.
                          Expanded(
                            flex: 8,
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 20),
                              child: Container(
                                width: double.infinity,
                                clipBehavior: Clip.antiAlias,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(36),
                                  boxShadow: [
                                    BoxShadow(
                                      color: blackColor.withOpacity(0.30),
                                      blurRadius: 44,
                                      offset: const Offset(0, 22),
                                    ),
                                  ],
                                ),
                                child: SizedBox(
                                  height: double.infinity,
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      // Deep gradient base.
                                      const Positioned.fill(
                                        child: DecoratedBox(
                                          decoration: BoxDecoration(
                                            gradient: LinearGradient(
                                              begin: Alignment.topCenter,
                                              end: Alignment.bottomCenter,
                                              colors: [
                                                Color(0xFF14161A),
                                                Color(0xFF1E2228),
                                                Color(0xFF0E1013),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      // Warm spotlight from above the car.
                                      Positioned.fill(
                                        child: DecoratedBox(
                                          decoration: BoxDecoration(
                                            gradient: RadialGradient(
                                              center:
                                                  const Alignment(0.05, -0.55),
                                              radius: 0.85,
                                              colors: [
                                                themeColor.withOpacity(0.30),
                                                Colors.transparent,
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      // Oversized watermark ring for depth.
                                      Positioned(
                                        right: -60,
                                        top: -40,
                                        child: Container(
                                          height: 220,
                                          width: 220,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            border: Border.all(
                                              color:
                                                  themeColor.withOpacity(0.16),
                                              width: 1.5,
                                            ),
                                          ),
                                        ),
                                      ),
                                      // Speed-line accents trailing behind the car.
                                      Positioned(
                                        bottom: 104,
                                        left: 0,
                                        right: 0,
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                          children: List.generate(3, (i) {
                                            final widths = [0.34, 0.23, 0.13];
                                            return Padding(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      vertical: 4.5),
                                              child: Container(
                                                margin: EdgeInsets.only(
                                                    right: 30.0 + (i * 16)),
                                                height: 3,
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    widths[i],
                                                decoration: BoxDecoration(
                                                  gradient: LinearGradient(
                                                    colors: [
                                                      themeColor
                                                          .withOpacity(0.0),
                                                      themeColor.withOpacity(
                                                          0.85 - i * 0.2),
                                                    ],
                                                  ),
                                                  borderRadius:
                                                      BorderRadius.circular(4),
                                                ),
                                              ),
                                            );
                                          }),
                                        ),
                                      ),
                                      // Ground reflection beneath the car.
                                      Positioned(
                                        bottom: 34,
                                        child: Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.58,
                                          height: 22,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(40),
                                            gradient: RadialGradient(
                                              colors: [
                                                themeColor.withOpacity(0.30),
                                                Colors.transparent,
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        bottom: 30,
                                        child: Image.asset(
                                          "assets/images/carImage.png",
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.78,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            flex: isCompact ? 5 : 6,
                            child: Padding(
                              padding: EdgeInsets.fromLTRB(
                                  36, 0, 36, isCompact ? 12 : 30),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  // Gold accent rule above the headline.
                                  Container(
                                    height: 4,
                                    width: 46,
                                    decoration: BoxDecoration(
                                      color: themeColor,
                                      borderRadius: BorderRadius.circular(4),
                                    ),
                                  ),
                                  const SizedBox(height: 15),
                                  Text(
                                    "Reliable Rides. Seamless Journeys."
                                        .translate(context),
                                    textAlign: TextAlign.center,
                                    style: largeHeadingMedium.copyWith(
                                      fontSize: 22,
                                      height: 1.18,
                                      letterSpacing: -0.6,
                                    ),
                                  ),
                                  SizedBox(height: isCompact ? 8 : 14),
                                  Flexible(
                                    child: Text(
                                      "Book instantly, track live, and relax with verified drivers. Multiple ride types, one stress-free experience."
                                          .translate(context),
                                      textAlign: TextAlign.center,
                                      style: smallHeadingMedium.copyWith(
                                        color: notifires.getGrey2whiteColor,
                                        fontSize: 14,
                                        height: 1.5,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 32),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Material(
                                  color: Colors.transparent,
                                  child: InkWell(
                                    borderRadius: BorderRadius.circular(30),
                                    onTap: () {
                                      Navigator.pushReplacement(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                const SignUp()),
                                      );
                                    },
                                    child: Ink(
                                      height: 58,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(30),
                                        gradient: LinearGradient(
                                          colors: [
                                            themeColor,
                                            Color.lerp(
                                                themeColor, orangeColor, 0.35)!,
                                          ],
                                        ),
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Text(
                                            "Proceed to Sign-Up"
                                                .translate(context),
                                            style: largeHeadingMedium.copyWith(
                                              color: blackColor,
                                              fontSize: 15.5,
                                              letterSpacing: 0.2,
                                            ),
                                          ),
                                          const SizedBox(width: 12),
                                          Container(
                                            height: 30,
                                            width: 30,
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              color:
                                                  blackColor.withOpacity(0.12),
                                            ),
                                            child: Icon(
                                              Icons.arrow_forward_rounded,
                                              size: 17,
                                              color: blackColor,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(height: isCompact ? 16 : 30),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Expanded(
                                      child: Divider(
                                          color: lightgrey, thickness: 1),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 14),
                                      child: Text(
                                        "Or continue using".translate(context),
                                        style: regular(context).copyWith(
                                          color: notifires.getGrey2whiteColor,
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: Divider(
                                          color: lightgrey, thickness: 1),
                                    ),
                                  ],
                                ),
                                SizedBox(height: isCompact ? 14 : 22),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    socialButton(
                                        "assets/images/google_icon.svg", () {
                                      context
                                          .read<GoogleLoginCubit>()
                                          .googleLogin(context);
                                    }),
                                    const SizedBox(width: 18),
                                    if (Platform.isIOS)
                                      socialButton(
                                          "assets/images/apple_icon.svg", () {
                                        context
                                            .read<AppleLoginCubit>()
                                            .appleLogin(context);
                                      }),
                                  ],
                                ),
                                SizedBox(height: isCompact ? 20 : 40),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    SafeArea(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: AuthSpacing.small),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            AuthLanguagePill(
                              onTap: () {
                                goTo(const SelectLanguageScreen(
                                  isBack: true,
                                ));
                              },
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.language_rounded,
                                      color: themeColor, size: 16),
                                  const SizedBox(width: 5),
                                  BlocBuilder<LCodeCubit, String>(
                                      builder: (context, state) {
                                    return Text(
                                      state.toUpperCase(),
                                      style: regular(context).copyWith(
                                        color: notifires.getwhiteblackColor,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 12.5,
                                      ),
                                    );
                                  }),
                                  Icon(Icons.keyboard_arrow_down_rounded,
                                      color: notifires.getGrey3whiteColor,
                                      size: 16),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          )),
    );
  }
}

Widget customOnboardingWidget(String image, String title, String description) {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20),
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 20, right: 20),
          child: SvgPicture.asset(image),
        ),
        const SizedBox(
          height: 20,
        ),
        Flexible(
          child: Text(
            title,
            textAlign: TextAlign.start,
            style: largeHeadingMedium.copyWith(fontSize: 20),
            softWrap: true,
          ),
        ),
        const SizedBox(
          height: 15,
        ),
        Text(
          description,
          style: smallHeadingMedium.copyWith(
              color: notifires.getGrey2whiteColor, fontSize: 12),
          textAlign: TextAlign.start,
        )
      ],
    ),
  );
}

/// ehkaarr
