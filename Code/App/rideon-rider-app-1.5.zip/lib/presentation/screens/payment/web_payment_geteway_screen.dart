import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:ride_on/presentation/screens/payment/payment_success_page.dart';

import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../../core/utils/translate.dart';

class PaymentsScreen extends StatefulWidget {
  final String? url;
  final String? rideId;

  const PaymentsScreen({super.key, this.url, this.rideId});

  @override
  State<PaymentsScreen> createState() => _PaymentsScreenState();
}

class _PaymentsScreenState extends State<PaymentsScreen> {
  InAppWebViewController? webViewController;
  bool isLoading = true;
  Timer? timer;
  int secondsRemaining = 600; // 10 minutes
  bool isDisposed = false;
  bool hasEndedSession = false;

  @override
  void initState() {
    super.initState();
    if (Platform.isAndroid) {
      InAppWebViewController.setWebContentsDebuggingEnabled(true);
    }
    startTimer();
  }

  void safeSetState(VoidCallback fn) {
    if (mounted && !isDisposed) {
      setState(fn);
    }
  }

  void startTimer() {
    timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!isDisposed) {
        if (secondsRemaining <= 0) {
          timer.cancel();
          _showTimeoutBottomSheet();
        } else {
          safeSetState(() => secondsRemaining--);
        }
      }
    });
  }

  void handleNavigation(String url) {
    if (hasEndedSession) return;

    if (url.contains("payment_success")) {
      endSession(success: true);
    } else if (url.contains("payment_fail")) {
      endSession(message: "Your payment failed");
    } else if (url.contains("/invalid-order") || url.contains("invalid")) {
      endSession(message: "Invalid Order");
    }
  }

  void endSession({bool success = false, String? message}) {
    if (hasEndedSession) return;
    hasEndedSession = true;
    timer?.cancel();

    if (!isDisposed) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (message != null) showErrorToastMessage(message);

        if (success) {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(
              builder: (context) => BookingSuccessScreen(
                rideId: widget.rideId ?? "",
              ),
            ),
          );
        } else {
          Navigator.of(context).pop(); // Go back on failure
        }
      });
    }
  }

  void _showTimeoutBottomSheet() {
    if (isDisposed) return;

    showModalBottomSheet(
      context: context,
      isDismissible: false,
      backgroundColor: notifires.getbgcolor,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) {
        Future.delayed(const Duration(seconds: 3), () {
          if (mounted) {
            Navigator.of(context).pop(); // close bottom sheet
            Navigator.of(context).pop(); // go back
          }
        });
        return PopScope(
          canPop: false,
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.timer_off, size: 48, color: Colors.redAccent),
                const SizedBox(height: 16),
                Text("Payment Time Expired".translate(context),
                    style: heading3(context)),
                const SizedBox(height: 12),
                Text(
                  "Your payment session has timed out. Redirecting...",
                  textAlign: TextAlign.center,
                  style: regular(context).copyWith(color: Colors.grey),
                ),
                const SizedBox(height: 20),
                LinearProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(themeColor),
                  backgroundColor: Colors.grey[300],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  String _formatTime(int seconds) {
    final m = (seconds ~/ 60).toString().padLeft(2, '0');
    final s = (seconds % 60).toString().padLeft(2, '0');
    return "$m:$s";
  }

  Future<void> _showBackDialog() async {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: notifires.getbgcolor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              height: 80,
              width: 80,
              decoration: BoxDecoration(
                color: themeColor.withValues(alpha: 0.15),
                shape: BoxShape.circle,
              ),
              child: Padding(
                padding: const EdgeInsets.all(0),
                child: commonlyUserLogo(),
              ),
            ),
            const SizedBox(height: 16),
            Text("Go Back?".translate(context),
                style: heading2Grey1(context).copyWith(
                    fontWeight: FontWeight.w700,
                    color: notifires.getwhiteblackColor)),
            const SizedBox(height: 10),
            Text("Are you sure you want to go back?".translate(context),
                textAlign: TextAlign.center,
                style: regular(context).copyWith(color: Colors.grey)),
            const SizedBox(height: 24),
            Row(children: [
              Expanded(
                child: _buildDialogButton("Cancel", onTap: () {
                  Navigator.pop(context);
                }),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildDialogButton("Yes", filled: true, onTap: () {
                  Navigator.pop(context);
                  Navigator.of(context).pop();
                }),
              ),
            ])
          ]),
        ),
      ),
    );
  }

  Widget _buildDialogButton(String text,
      {bool filled = false, VoidCallback? onTap}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: filled ? themeColor : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: notifires.getwhiteblackColor),
        ),
        child: Center(
          child: Text(
            text.translate(context),
            style: regular(context).copyWith(
              color: notifires.getwhiteblackColor,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    isDisposed = true;
    timer?.cancel();
    webViewController = null;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: notifires.getbgcolor,
        resizeToAvoidBottomInset: false, // Important for keyboard stability
        appBar: CustomAppBarNew(
          backgroundColor: notifires.getbgcolor,
          title: "Payment".translate(context),
          onBackTap: _showBackDialog,
          actions: [
            Row(
              children: [
                const Icon(Icons.timer, size: 20),
                const SizedBox(width: 4),
                Text(
                  _formatTime(secondsRemaining),
                  style: TextStyle(
                    color: notifires.getwhiteblackColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(width: 10),
          ],
        ),
        body: Stack(
          children: [
            InAppWebView(
              initialSettings: InAppWebViewSettings(
                transparentBackground: true,
                javaScriptEnabled: true,
                useShouldOverrideUrlLoading: true,
                allowsInlineMediaPlayback: true,
                mediaPlaybackRequiresUserGesture: false,
                useHybridComposition: false,
                scrollsToTop: false,
                suppressesIncrementalRendering: true,
                allowsBackForwardNavigationGestures: false,
              ),
              initialUrlRequest: widget.url != null
                  ? URLRequest(url: WebUri(widget.url!))
                  : null,
              onWebViewCreated: (controller) {
                webViewController = controller;
              },
              onScrollChanged: Platform.isIOS
                  ? (controller, x, y) {
                      // Let iOS WKWebView handle keyboard naturally
                    }
                  : null,
              onLoadStart: (_, __) => safeSetState(() => isLoading = true),
              onLoadStop: (controller, url) {
                safeSetState(() => isLoading = false);
                if (url != null) {
                  handleNavigation(url.toString());
                }
              },
              shouldOverrideUrlLoading: (_, action) async {
                final url = action.request.url?.toString() ?? "";
                handleNavigation(url);
                return NavigationActionPolicy.ALLOW;
              },
            ),
            if (isLoading) const Center(child: CircularProgressIndicator()),
          ],
        ),
      ),
    );
  }
}
