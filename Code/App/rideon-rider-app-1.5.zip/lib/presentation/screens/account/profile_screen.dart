import 'dart:convert';
import 'dart:io';
import 'package:ride_on/app/route_settings.dart';
import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/domain/entities/login_data.dart' as logmod;

import 'package:ride_on/core/services/data_store.dart';

import 'package:ride_on/core/extensions/workspace.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ride_on/presentation/cubits/auth/user_authenticate_cubit.dart';

import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../cubits/auth/email_otp_cubit.dart';
import '../../cubits/book_ride_cubit.dart';
import '../../cubits/profile/edit_profile_cubit.dart';
import '../../cubits/realtime/update_ride_request_parameter.dart';
import '../../widgets/custom_text_form_field.dart';
import '../auth/email_update_screen.dart';
import '../auth/phone_update_screen.dart';

class EditProfile extends StatefulWidget {
  const EditProfile({super.key});

  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  File? image;
  final picker = ImagePicker();
  GlobalKey buttonKey = GlobalKey();

  TextEditingController textEditingEditProfileNameController =
      TextEditingController();
  TextEditingController textEditingEditProfileEmailController =
      TextEditingController();
  TextEditingController textEditingEditProfileNumberController =
      TextEditingController();

  @override
  void initState() {
    super.initState();

    textEditingEditProfileNameController.text =
        loginModel?.data?.firstName ?? "";

    textEditingEditProfileNumberController.text = loginModel?.data?.phone ?? "";
    textEditingEditProfileEmailController.text = loginModel?.data?.email ?? "";
    context.read<SetCountryCubit>().setCountry(
        dialCode: loginModel?.data?.phoneCountry ?? "+91",
        countryCode: loginModel?.data?.defaultCountry ?? "IN");
  }

  Future<void> pickImage(ImageSource source) async {
    final pickedFile = await picker.pickImage(source: source);
    if (pickedFile != null) {
      final base64Img = await compressAndUploadImage(pickedFile.path);
      setState(() {
        image = File(pickedFile.path);
      });
      // ignore_for_file: use_build_context_synchronously
      context.read<UpdateProfileCubit>().uploadProfileImage(postData: {
        "profile_image": base64Img,
      });
    }
  }

  List<String> optionsList = ["male", "female", "others"];

  static const double _sectionSpacing = 28;
  static const double _fieldSpacing = 14;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAF8),
      appBar: CustomAppBarNew(
        title: "Edit Profile",
        backgroundColor: const Color(0xFFFAFAF8),
        onBackTap: () {
          goBack();
        },
      ),
      body: BlocBuilder<UpdateProfileCubit, UpdateProfileState>(
          builder: (context, state) {
        if (state is UpdateProfileLoading) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            Widgets.showLoader(context);
          });
        } else if (state is UpdateProfileSuccess) {
          Widgets.hideLoder(context);
          String storedData = box.get("UserData");
          loginModel = logmod.LoginModel.fromJson(jsonDecode(storedData));
          loginModel!.data?.firstNameSetter =
              state.loginModel.data?.firstName ?? "";
          loginModel!.data?.lastNameSetter =
              state.loginModel.data?.lastName ?? "";
          loginModel!.data?.gender = state.loginModel.data?.gender ?? "";
          UserData userObj = UserData();
          userObj.saveLoginData("UserData", jsonEncode(loginModel!.toJson()));
          context.read<UpdateProfileCubit>().clear();
          context
              .read<NameCubit>()
              .updateName("${state.loginModel.data!.firstName}");

          showToastMessage(state.loginModel.message ?? "");
        } else if (state is UpdateProfileImageSuccess) {
          Widgets.hideLoder(context);

          String storedImageData = box.get("UserData");
          loginModel = logmod.LoginModel.fromJson(jsonDecode(storedImageData));
          loginModel!.data?.profileImageSetter = state.imageUrl;
          myImage = state.imageUrl;

          UserData userObj = UserData();
          userObj.saveLoginData("UserData", jsonEncode(loginModel!.toJson()));
          context
              .read<BookRideRealTimeDataBaseCubit>()
              .updateUserImageUrl(userImageUrl: state.imageUrl);

          context
              .read<UpdateRideRequestParameterCubit>()
              .updateFirebaseUserParameter(
                  rideId: context
                      .read<BookRideRealTimeDataBaseCubit>()
                      .state
                      .rideId,
                  userParameter: {"userImageUrl": state.imageUrl});

          context.read<MyImageCubit>().updateMyImage(myImage);
        } else if (state is UpdateProfileFailed) {
          Widgets.hideLoder(context);

          showErrorToastMessage(state.error);
          context.read<UpdateProfileCubit>().clear();
        }
        return SafeArea(
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Column(
                          children: [
                            Stack(
                              alignment: Alignment.bottomRight,
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(4),
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: whiteColor,
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.06),
                                        blurRadius: 16,
                                        offset: const Offset(0, 6),
                                      ),
                                    ],
                                  ),
                                  child: myImage.isNotEmpty
                                      ? ClipOval(
                                          child: SizedBox(
                                            width: 112,
                                            height: 112,
                                            child: myNetworkImage(myImage),
                                          ),
                                        )
                                      : Container(
                                          width: 112,
                                          height: 112,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: grey6,
                                          ),
                                          child: Icon(
                                            CupertinoIcons.profile_circled,
                                            size: 104,
                                            color: themeColor,
                                          ),
                                        ),
                                ),
                                GestureDetector(
                                  key: buttonKey,
                                  onTap: () {
                                    getButtonPosition(buttonKey);
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.all(9),
                                    decoration: BoxDecoration(
                                      color: themeColor,
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                          color: whiteColor, width: 2.5),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.black.withOpacity(0.12),
                                          blurRadius: 6,
                                          offset: const Offset(0, 2),
                                        ),
                                      ],
                                    ),
                                    child: Icon(
                                      Icons.edit,
                                      color: blackColor,
                                      size: 16,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            InkWell(
                              onTap: () => getButtonPosition(buttonKey),
                              child: Text(
                                "Change Photo".translate(context),
                                style: regular2(context).copyWith(
                                  color: themeColor,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 13,
                                ),
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              "Keep your information updated"
                                  .translate(context),
                              style: regular(context).copyWith(
                                color: notifires.getGrey3whiteColor,
                                fontSize: 12.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: _sectionSpacing),
                      ProfileSectionHeader(
                          title: "Personal Information".translate(context)),
                      const SizedBox(height: _fieldSpacing),
                      ProfileFieldLabel(text: "Name".translate(context)),
                      const SizedBox(height: 6),
                      TextFieldAdvance(
                          icons: Icon(Icons.person_2_outlined,
                              color: notifires.getGrey2whiteColor),
                          txt: "Enter Your Name".translate(context),
                          textEditingControllerCommon:
                              textEditingEditProfileNameController,
                          inputType: TextInputType.name,
                          inputAlignment: TextAlign.start),
                      const SizedBox(height: _sectionSpacing),
                      ProfileSectionHeader(
                          title: "Contact Information".translate(context)),
                      const SizedBox(height: _fieldSpacing),
                      ProfileFieldLabel(text: "Email".translate(context)),
                      const SizedBox(height: 6),
                      BlocBuilder<EmailOtpCubit, EmailOtpState>(
                          builder: (context, state) {
                        if (state is OtpSuccessForChangeEmailSate) {
                          textEditingEditProfileEmailController.text =
                              state.loginModel.data?.email ?? "";
                          context
                              .read<EmailCubit>()
                              .updateEmail(state.loginModel.data?.email ?? "");
                        }
                        return ProfileReadOnlyField(
                          icon: Icons.email_outlined,
                          hintText: "Enter Your Email".translate(context),
                          controller: textEditingEditProfileEmailController,
                          onEditTap: () {
                            goTo(const EmailUpdateScreen());
                          },
                        );
                      }),
                      const SizedBox(height: _fieldSpacing),
                      ProfileFieldLabel(text: "Phone no".translate(context)),
                      const SizedBox(height: 6),
                      ProfileReadOnlyField(
                        icon: Icons.call_outlined,
                        hintText: "Enter Your Mobile".translate(context),
                        controller: textEditingEditProfileNumberController,
                        onEditTap: () {
                          context.read<SetCountryCubit>().setCountry(
                              dialCode: loginModel?.data?.phoneCountry ?? "+91",
                              countryCode:
                                  loginModel?.data?.defaultCountry ?? "IN");

                          goTo(PhoneUpdateScreen(
                              phone:
                                  textEditingEditProfileNumberController.text));
                        },
                      ),
                      const SizedBox(height: 12),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
                child: CustomsButtons(
                    textColor: blackColor,
                    text: "Update Profile".translate(context),
                    backgroundColor: themeColor,
                    onPressed: () {
                      context
                          .read<UpdateProfileCubit>()
                          .updateProfileMethod(postData: {
                        "first_name": textEditingEditProfileNameController.text,
                      });
                    }),
              ),
            ],
          ),
        );
      }),
    );
  }

  void showImagePickerPopup(BuildContext context, Offset offset) {
    showMenu(
      context: context,
      position: RelativeRect.fromLTRB(
          offset.dx, offset.dy, offset.dx + 10, offset.dy + 10),
      items: [
        PopupMenuItem(
          child: Row(
            children: [
              Icon(Icons.camera_alt, color: themeColor),
              const SizedBox(width: 10),
              Text("Camera".translate(context)),
            ],
          ),
          onTap: () {
            pickImage(ImageSource.camera);
          },
        ),
        PopupMenuItem(
          child: Row(
            children: [
              Icon(Icons.photo, color: themeColor),
              const SizedBox(width: 10),
              Text("Gallery".translate(context)),
            ],
          ),
          onTap: () {
            pickImage(ImageSource.gallery);
          },
        ),
      ],
      elevation: 10,
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
    );
  }

  void getButtonPosition(GlobalKey key) {
    final RenderBox renderBox =
        key.currentContext!.findRenderObject() as RenderBox;
    final Offset offset = renderBox.localToGlobal(Offset.zero);
    showImagePickerPopup(context, offset);
  }
}

/// Small uppercase-ish section label ("Personal Information",
/// "Contact Information") used to visually group the Edit Profile fields.
class ProfileSectionHeader extends StatelessWidget {
  final String title;

  const ProfileSectionHeader({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: regular2(context).copyWith(
        color: notifires.getwhiteblackColor,
        fontSize: 16,
        fontWeight: FontWeight.w600,
      ),
    );
  }
}

/// Compact field label ("Name", "Email", "Phone") shown above each input.
class ProfileFieldLabel extends StatelessWidget {
  final String text;

  const ProfileFieldLabel({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: regular(context).copyWith(
        color: notifires.getGrey3whiteColor,
        fontSize: 12.5,
        fontWeight: FontWeight.w500,
      ),
    );
  }
}

/// Read-only profile field (Email / Phone) with a compact circular edit
/// action. Purely presentational -- the controller and [onEditTap] callback
/// are supplied by the caller so existing navigation/Cubit wiring is
/// untouched.
class ProfileReadOnlyField extends StatelessWidget {
  final IconData icon;
  final String hintText;
  final TextEditingController controller;
  final VoidCallback onEditTap;

  const ProfileReadOnlyField({
    super.key,
    required this.icon,
    required this.hintText,
    required this.controller,
    required this.onEditTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: notifires.getIsDark
            ? Colors.white.withOpacity(0.04)
            : const Color(0xFFF8F8F8),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: notifires.getGrey4whiteColor.withOpacity(0.4),
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      child: Row(
        children: [
          Icon(icon, size: 19, color: notifires.getGrey2whiteColor),
          const SizedBox(width: 10),
          Expanded(
            child: AnimatedBuilder(
              animation: controller,
              builder: (context, _) {
                final value = controller.text;
                return Text(
                  value.isNotEmpty ? value : hintText,
                  overflow: TextOverflow.ellipsis,
                  style: regular2(context).copyWith(
                    color: value.isNotEmpty
                        ? notifires.getGrey2whiteColor
                        : notifires.getGrey3whiteColor,
                    fontSize: 14.5,
                  ),
                );
              },
            ),
          ),
          InkWell(
            onTap: onEditTap,
            borderRadius: BorderRadius.circular(18),
            child: Container(
              height: 34,
              width: 34,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: themeColor.withOpacity(0.16),
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.mode, color: blackColor, size: 15),
            ),
          ),
        ],
      ),
    );
  }
}
