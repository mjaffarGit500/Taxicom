import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on/app/route_settings.dart';
import 'package:ride_on/core/utils/translate.dart';

import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../../domain/entities/general_data.dart';
import '../../cubits/general_cubit.dart';
import 'static_screen.dart';

class MyAccountScreen extends StatelessWidget {
  const MyAccountScreen({super.key});

  IconData _getIconForPage(String? name) {
    final pageName = (name ?? "").toLowerCase();

    if (pageName.contains("about")) {
      return Icons.info_outline;
    } else if (pageName.contains("help") || pageName.contains("support")) {
      return Icons.help_outline;
    } else if (pageName.contains("term") || pageName.contains("condition")) {
      return Icons.description_outlined;
    } else if (pageName.contains("privacy") || pageName.contains("policy")) {
      return Icons.privacy_tip_outlined;
    } else if (pageName.contains("cancel")) {
      return Icons.cancel_outlined;
    } else {
      return Icons.article_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: notifires.getbgcolor,
      appBar: CustomAppBars(
        title: "My Account".translate(context),
        backgroundColor: notifires.getbgcolor,
        iconColor: notifires.getwhiteblackColor,
        titleColor: notifires.getwhiteblackColor,
      ),
      body: BlocBuilder<StaticPagesCubit, SimpleState<List<StaticPage>>>(
        builder: (context, state) {
          final pages = state.value;

          if (pages.isEmpty) {
            return Center(
              child: Text(
                "No Services".translate(context),
                style: regular2(context).copyWith(
                  color: notifires.getGrey3whiteColor,
                ),
              ),
            );
          }

          return ListView.separated(
            padding: const EdgeInsets.symmetric(vertical: 12),
            itemCount: pages.length,
            separatorBuilder: (_, __) =>
                const Divider(height: 1, indent: 20, endIndent: 20),
            itemBuilder: (context, index) {
              final page = pages[index];
              return ListTile(
                leading: Icon(_getIconForPage(page.name), color: blackColor),
                title: Text(
                  page.name ?? "",
                  style: heading3Grey1(context).copyWith(fontSize: 16),
                ),
                trailing: Icon(Icons.arrow_forward_ios_rounded,
                    size: 16, color: notifires.getGrey3whiteColor),
                onTap: () {
                  goTo(StaticScreen(
                    name: page.name ?? "",
                    id: page.id.toString(),
                    isBack: true,
                  ));
                },
              );
            },
          );
        },
      ),
    );
  }
}
