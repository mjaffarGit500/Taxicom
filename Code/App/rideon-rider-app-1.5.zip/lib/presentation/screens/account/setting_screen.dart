import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ride_on/core/utils/translate.dart';

import '../../../core/extensions/change_language.dart';
import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';

class SettingScreen extends StatefulWidget {
  const SettingScreen({super.key});

  @override
  State<SettingScreen> createState() => _SettingScreenState();
}

class _SettingScreenState extends State<SettingScreen> {
  @override
  Widget build(BuildContext context) {
    notifires = Provider.of<ColorNotifires>(context, listen: true);

    return Scaffold(
      backgroundColor: notifires.getbgcolor,
      appBar: CustomAppBars(
        onBackButtonPressed: () => Navigator.pop(context),
        title: "Settings".translate(context),
        backgroundColor: notifires.getbgcolor,
        iconColor: notifires.getwhiteblackColor,
        titleColor: notifires.getwhiteblackColor,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Change Language
              _buildSettingTile(
                icon: Icons.language_rounded,
                title: "Change Language",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const ChangeLanguage()),
                  );
                },
              ),

              const SizedBox(height: 12),

              // Delete Account
              _buildSettingTile(
                icon: Icons.delete_forever_rounded,
                title: "Delete Account",
                isDestructive: true,
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (_) => const DeleteConfirmationDialogs(),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSettingTile({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    bool isDestructive = false,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: whiteColor,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            // Icon Container
            Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                color: isDestructive
                    ? Colors.red.withOpacity(0.08)
                    : themeColor.withOpacity(0.09),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                icon,
                color: isDestructive ? Colors.red : themeColor,
                size: 22,
              ),
            ),

            const SizedBox(width: 16),

            // Title
            Expanded(
              child: Text(
                title.translate(context),
                style: regular2(context).copyWith(
                  fontSize: 15.2, // Smaller & cleaner text
                  color:
                      isDestructive ? Colors.red : notifires.getGrey2whiteColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),

            // Arrow
            Icon(
              Icons.arrow_forward_ios_rounded,
              size: 16,
              color: isDestructive
                  ? Colors.red.withOpacity(0.7)
                  : notifires.getGrey3whiteColor,
            ),
          ],
        ),
      ),
    );
  }
}
