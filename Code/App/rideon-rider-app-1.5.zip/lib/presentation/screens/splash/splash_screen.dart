import 'package:ride_on/core/extensions/workspace.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';
import 'package:ride_on/core/utils/theme/project_color.dart';
import 'package:ride_on/core/utils/theme/theme_style.dart';
import 'package:ride_on/core/utils/translate.dart';
import '../../../core/utils/common_widget.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  AnimationController? controller;

  late final Animation<double> _logoScale;
  late final Animation<double> _logoOpacity;
  late final Animation<double> _glowPulse;
  late final Animation<double> _ringScale;
  late final Animation<double> _ringOpacity;
  late final Animation<double> _titleOpacity;
  late final Animation<Offset> _titleOffset;
  late final Animation<double> _taglineOpacity;
  late final Animation<Offset> _taglineOffset;

  @override
  void initState() {
    super.initState();
    getUserDataLocallyToHandleTheState(context);
    controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3000),
    );

    // Logo: settles in with a bounce while fading in.
    _logoScale = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(
        parent: controller!,
        curve: const Interval(0.0, 0.5, curve: Curves.easeOutBack),
      ),
    );
    _logoOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: controller!,
        curve: const Interval(0.0, 0.35, curve: Curves.easeIn),
      ),
    );

    // Glow behind the logo keeps breathing for the whole timeline.
    _glowPulse = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween(begin: 0.0, end: 1.0)
            .chain(CurveTween(curve: Curves.easeOut)),
        weight: 30,
      ),
      TweenSequenceItem(
        tween: Tween(begin: 1.0, end: 0.6)
            .chain(CurveTween(curve: Curves.easeInOut)),
        weight: 35,
      ),
      TweenSequenceItem(
        tween: Tween(begin: 0.6, end: 1.0)
            .chain(CurveTween(curve: Curves.easeInOut)),
        weight: 35,
      ),
    ]).animate(controller!);

    // Thin ring expands outward from the logo and fades as it grows.
    _ringScale = Tween<double>(begin: 0.7, end: 1.6).animate(
      CurvedAnimation(
        parent: controller!,
        curve: const Interval(0.05, 0.65, curve: Curves.easeOut),
      ),
    );
    _ringOpacity = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween(begin: 0.0, end: 0.6),
        weight: 20,
      ),
      TweenSequenceItem(
        tween: Tween(begin: 0.6, end: 0.0),
        weight: 80,
      ),
    ]).animate(
      CurvedAnimation(
        parent: controller!,
        curve: const Interval(0.05, 0.65, curve: Curves.easeOut),
      ),
    );

    // App name fades + rises shortly after the logo settles.
    _titleOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: controller!,
        curve: const Interval(0.42, 0.7, curve: Curves.easeOut),
      ),
    );
    _titleOffset = Tween<Offset>(
      begin: const Offset(0, 0.25),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: controller!,
        curve: const Interval(0.42, 0.7, curve: Curves.easeOutCubic),
      ),
    );

    // Tagline slides up and fades in last.
    _taglineOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: controller!,
        curve: const Interval(0.65, 1.0, curve: Curves.easeOut),
      ),
    );
    _taglineOffset = Tween<Offset>(
      begin: const Offset(0, 0.4),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: controller!,
        curve: const Interval(0.65, 1.0, curve: Curves.easeOutCubic),
      ),
    );

    controller?.forward();
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final notifires = Provider.of<ColorNotifires>(context);
    final Color accent = notifires.getthemeColor;

    return Stack(
      children: [
        // Deep, premium dark gradient backdrop.
        Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  darkmode,
                  Color.lerp(darkmode, boxcolor, 0.6)!,
                  Color.lerp(darkmode, accent, 0.12)!,
                ],
              ),
            ),
          ),
        ),
        Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(0, -0.35),
                radius: 1.1,
                colors: [
                  accent.withOpacity(0.22),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
        Positioned(
          bottom: 0,
          left: 0,
          child: Opacity(
            opacity: 0.35,
            child: SvgPicture.asset(
              "assets/images/vector_bottom.svg",
              colorFilter: ColorFilter.mode(
                accent,
                BlendMode.srcIn,
              ),
            ),
          ),
        ),
        Positioned(
          top: 0,
          right: 0,
          child: Opacity(
            opacity: 0.35,
            child: SvgPicture.asset(
              "assets/images/vector_top.svg",
              colorFilter: ColorFilter.mode(
                accent,
                BlendMode.srcIn,
              ),
            ),
          ),
        ),
        Center(
          child: AnimatedBuilder(
            animation: controller!,
            builder: (context, child) {
              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(
                    height: 200,
                    width: 200,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        // Breathing glow.
                        Opacity(
                          opacity: (0.25 + (_glowPulse.value * 0.35))
                              .clamp(0.0, 1.0),
                          child: Container(
                            height: 190,
                            width: 190,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: RadialGradient(
                                colors: [
                                  accent.withOpacity(0.55),
                                  accent.withOpacity(0.0),
                                ],
                              ),
                            ),
                          ),
                        ),
                        // Expanding ring pulse.
                        Opacity(
                          opacity: _ringOpacity.value,
                          child: Transform.scale(
                            scale: _ringScale.value,
                            child: Container(
                              height: 130,
                              width: 130,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: accent.withOpacity(0.8),
                                  width: 1.4,
                                ),
                              ),
                            ),
                          ),
                        ),
                        // Logo card with soft elevated glass look.
                        FadeTransition(
                          opacity: _logoOpacity,
                          child: ScaleTransition(
                            scale: _logoScale,
                            child: Container(
                              padding: const EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: whiteColor.withOpacity(0.06),
                                border: Border.all(
                                  color: whiteColor.withOpacity(0.12),
                                  width: 1,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: accent.withOpacity(0.35),
                                    blurRadius: 30,
                                    spreadRadius: 2,
                                  ),
                                ],
                              ),
                              child: commonlyUserLogo(),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  SlideTransition(
                    position: _titleOffset,
                    child: FadeTransition(
                      opacity: _titleOpacity,
                      child: ShaderMask(
                        shaderCallback: (bounds) => LinearGradient(
                          colors: [whiteColor, accent],
                        ).createShader(bounds),
                        child: Text(
                          "Ride On".translate(context),
                          style: heading1(context).copyWith(
                            color: whiteColor,
                            fontSize: 30,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SlideTransition(
                    position: _taglineOffset,
                    child: FadeTransition(
                      opacity: _taglineOpacity,
                      child: Text(
                        "Your ride, your way".translate(context),
                        textAlign: TextAlign.center,
                        style: captionText(context).copyWith(
                          color: whiteColor.withOpacity(0.65),
                          letterSpacing: 2.2,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
        
      ],
    );
  }
}
