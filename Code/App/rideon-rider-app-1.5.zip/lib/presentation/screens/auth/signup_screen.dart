import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import 'package:ride_on/app/route_settings.dart';
import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/domain/entities/general_data.dart' show StaticPage;
import 'package:ride_on/presentation/cubits/general_cubit.dart';
import 'package:ride_on/presentation/cubits/localizations_cubit.dart';
import 'package:ride_on/presentation/screens/onboarding/language_select_screen.dart';
import '../../../core/extensions/workspace.dart';
import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../cubits/auth/apple_login_cubit.dart';
import '../../cubits/auth/google_login_cubit.dart';
import '../../cubits/auth/signup_cubit.dart';
import '../../cubits/auth/user_authenticate_cubit.dart';
import '../../widgets/auth_widgets.dart';
import '../../widgets/custom_text_form_field.dart';
import '../../widgets/form_validations.dart';
import '../Account/static_screen.dart';
import '../home/item_home_screen.dart';
import 'google_update_screen.dart';
import 'login_screen.dart';
import 'otp_screen.dart';

const int termsAndConditionsPageId = 11;

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  TextEditingController textEditingSignUpControllerFirstName =
      TextEditingController();
  TextEditingController textEditingSignUpControllerEmail =
      TextEditingController();
  TextEditingController textEditingSingUpControllerlastName =
      TextEditingController();
  TextEditingController textEditingSingUpControllerPhoneNumber =
      TextEditingController();
  TextEditingController textEditingSignUpControllerPassword =
      TextEditingController();

  bool isChecked = false;
  String selectedCountryCode = "+91";
  String defaultCountry = "IN";

  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    context.read<SetCountryCubit>().reset();
    super.initState();
    isNumeric = false;
  }

  @override
  Widget build(BuildContext context) {
    notifires = Provider.of<ColorNotifires>(context, listen: true);

    return PopScope(
      canPop: false,
      child: Scaffold(
        // ========== MAIN FIX ==========
        resizeToAvoidBottomInset: true, // Important: allow screen to resize
        bottomSheet: isNumeric == true && Platform.isIOS
            ? KeyboardDoneButton(
                onTap: () {
                  setState(() {
                    isNumeric = false;
                  });
                  FocusScope.of(context).unfocus(); // close keyboard
                },
              )
            : null,
        backgroundColor: notifires.getbgcolor,
        body: MultiBlocListener(
          listeners: [
            BlocListener<AuthSignUpCubit, AuthSignUpState>(
                listener: (context, state) {
              if (state is SignUpLoading) {
                Widgets.showLoader(context);
              } else if (state is SignUpSuccess) {
                Widgets.hideLoder(context);
                context.read<AuthSignUpCubit>().resetState();

                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => OtpScreen(
                              number: state.loginModel.data!.phone,
                              countryCode: state.loginModel.data!.phoneCountry,
                              otpValue: state.loginModel.data!.otpValue,
                              email: "",
                              defaultCountry:
                                  state.loginModel.data!.defaultCountry,
                              changeMobile: false,
                              loginWithSocialMedia: false,
                              routeString: "SignUp",
                            )));
              } else if (state is SignUpFailure) {
                Widgets.hideLoder(context);
                showErrorToastMessage(state.error);
              }
            }),
            BlocListener<GoogleLoginCubit, GoogleLoginState>(
              listener: (context, state) {
                if (state is GoogleLoginSucess) {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const ItemHomeScreen()));
                } else if (state is AddPhoneNumberState) {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => GoogleUpdate(
                                email: state.loginModel.data?.email ?? "",
                              )));
                } else if (state is GoogleLoginFailure) {
                  showErrorToastMessage(state.error);
                }
              },
            ),
            BlocListener<AppleLoginCubit, AppleLoginState>(
              listener: (context, state) {
                if (state is AppleLoginSuccess) {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const ItemHomeScreen()));
                } else if (state is AddPhoneNumberAppleState) {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const GoogleUpdate()));
                } else if (state is AppleLoginFailure) {
                  closeLoading();
                  showErrorToastMessage(state.error);
                }
              },
            )
          ],
          child: Stack(
            children: [
              const AuthBackgroundDecoration(
                assetPath: "assets/images/EllipseTop.svg",
                alignment: Alignment.topLeft,
              ),
              SafeArea(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  keyboardDismissBehavior:
                      ScrollViewKeyboardDismissBehavior.onDrag,
                  child: Align(
                    alignment: Alignment.center,
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(
                          maxWidth: AuthMetrics.maxContentWidth),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: Dimensions.paddingSizeLarge,
                        ),
                        child: Form(
                          key: _formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              AuthHeader(
                                title: "Create your account",
                                subtitle: "Get started with Ride",
                                logo: commonlyUserLogo(),
                                logoHeight: 56,
                                topSpacerFraction: 0.05,
                              ),
                              const SizedBox(height: AuthSpacing.xxl),
                              TextFieldAdvance(
                                onTap: () {
                                  isNumeric = false;
                                  setState(() {});
                                },
                                inputAlignment: TextAlign.start,
                                txt: "Name".translate(context),
                                icons: Icon(
                                  Icons.person_2_outlined,
                                  color: blackColor,
                                ),
                                textEditingControllerCommon:
                                    textEditingSignUpControllerFirstName,
                                inputType: TextInputType.name,
                                validator: (value) {
                                  if (isValidName(value!)) {
                                    return null;
                                  } else {
                                    return "Please enter the name"
                                        .translate(context);
                                  }
                                },
                              ),
                              const SizedBox(height: AuthSpacing.medium),
                              BlocBuilder<SetCountryCubit, SetCountryState>(
                                  builder: (context, state) {
                                return IntelPhoneFieldRefs(
                                  onTap: () {
                                    isNumeric = true;
                                    setState(() {});
                                  },
                                  hintText: "Phone no".translate(context),
                                  key: ValueKey(state.countryCode),
                                  defultcountry: state.countryCode,
                                  textEditingControllerCommons:
                                      textEditingSingUpControllerPhoneNumber,
                                  oncountryChanged: (number) {
                                    context.read<SetCountryCubit>().reset();
                                    textEditingSingUpControllerPhoneNumber
                                        .clear();
                                    context.read<SetCountryCubit>().setCountry(
                                        dialCode: number.dialCode,
                                        countryCode: number.code);
                                  },
                                  validator: (phoneNumber) {
                                    if (phoneNumber == null ||
                                        phoneNumber.number.isEmpty) {
                                      return "Please enter your phone number"
                                          .translate(context);
                                    }
                                    int expectedLength = phoneLengths[
                                            phoneNumber.countryISOCode] ??
                                        10;
                                    if (phoneNumber.number.length !=
                                        expectedLength) {
                                      return "${"Phone number must be".translate(context)} $expectedLength ${"digits".translate(context)}";
                                    }
                                    return null;
                                  },
                                );
                              }),
                              const SizedBox(height: AuthSpacing.medium),
                              TextFieldAdvance(
                                onTap: () {
                                  isNumeric = false;
                                  setState(() {});
                                },
                                inputAlignment: TextAlign.start,
                                txt: "Email".translate(context),
                                icons: Icon(
                                  Icons.mail_outline_outlined,
                                  color: blackColor,
                                ),
                                textEditingControllerCommon:
                                    textEditingSignUpControllerEmail,
                                inputType: TextInputType.emailAddress,
                                validator: (value) {
                                  return validateEmail(value!, context);
                                },
                              ),
                              const SizedBox(height: AuthSpacing.large),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SizedBox(
                                    width: 22,
                                    height: 22,
                                    child: Transform.scale(
                                      scale: 0.9,
                                      child: Checkbox(
                                        activeColor: themeColor,
                                        focusColor: whiteColor,
                                        value: isChecked,
                                        materialTapTargetSize:
                                            MaterialTapTargetSize.shrinkWrap,
                                        onChanged: (bool? newValue) {
                                          setState(() {
                                            isChecked = newValue!;
                                          });
                                        },
                                        checkColor: whiteColor,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                              Dimensions.radiusSmall),
                                        ),
                                        side: BorderSide(
                                            color: notifires.getGrey3whiteColor,
                                            width: 1.4),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: AuthSpacing.small),
                                  Expanded(
                                    child: BlocBuilder<StaticPagesCubit,
                                        SimpleState<List<StaticPage>>>(
                                      builder: (context, state) {
                                        final List<StaticPage> pages =
                                            state.value;

                                        // Terms and Conditions page dhoondo
                                        StaticPage? termsPage;
                                        for (final page in pages) {
                                          if (page.id ==
                                              termsAndConditionsPageId) {
                                            termsPage = page;
                                            break;
                                          }
                                        }

                                        // Agar Terms and Conditions nahi mila to simple text dikhao
                                        if (termsPage == null ||
                                            termsPage.name == null ||
                                            termsPage.name!.isEmpty) {
                                          return Text(
                                            "By creating an account, you agree to our terms."
                                                .translate(context),
                                            style: regular(context).copyWith(
                                              color:
                                                  notifires.getGrey2whiteColor,
                                              fontSize: 12.5,
                                              height: 1.35,
                                            ),
                                          );
                                        }

                                        // Agar mila to clickable dikhao
                                        return GestureDetector(
                                          onTap: () {
                                            showModalBottomSheet(
                                              useRootNavigator: true,
                                              backgroundColor:
                                                  notifires.getbgcolor,
                                              isScrollControlled: true,
                                              useSafeArea: true,
                                              context: context,
                                              builder: (BuildContext context) {
                                                return StaticScreen(
                                                  name: termsPage!.name ??
                                                      "Terms and Conditions",
                                                  id: termsPage.id.toString(),
                                                  isBack: true,
                                                );
                                              },
                                            );
                                          },
                                          child: Text.rich(
                                            TextSpan(
                                              text:
                                                  "By creating an account, you agree to our "
                                                      .translate(context),
                                              style: regular(context).copyWith(
                                                color: notifires
                                                    .getGrey2whiteColor,
                                                fontSize: 12.5,
                                                height: 1.35,
                                              ),
                                              children: [
                                                TextSpan(
                                                  text: (termsPage.name ??
                                                          "Terms and Conditions")
                                                      .translate(context),
                                                  style:
                                                      regular(context).copyWith(
                                                    fontWeight: FontWeight.w600,
                                                    color: themeColor,
                                                    fontSize: 12.5,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        );
                                      },
                                    ),
                                  )
                                ],
                              ),
                              const SizedBox(height: AuthSpacing.xxl),
                              AuthPrimaryButton(
                                text: "Sign up",
                                onPressed: () {
                                  setState(() {
                                    isNumeric = false;
                                  });

                                  if (_formKey.currentState!.validate()) {
                                    if (isChecked == false) {
                                      showErrorToastMessage(
                                          "Please select the terms and condition."
                                              .translate(context));
                                      return;
                                    }
                                    if (textEditingSingUpControllerPhoneNumber
                                        .text.isEmpty) {
                                      showErrorToastMessage(
                                          "Fill valid mobile number"
                                              .translate(context));
                                      return;
                                    }
                                    context.read<AuthSignUpCubit>().signUp(
                                          context: context,
                                          name:
                                              textEditingSignUpControllerFirstName
                                                  .text,
                                          phoneCountry: context
                                                  .read<SetCountryCubit>()
                                                  .state
                                                  .dialCode
                                                  .startsWith("+")
                                              ? context
                                                  .read<SetCountryCubit>()
                                                  .state
                                                  .dialCode
                                              : "+${context.read<SetCountryCubit>().state.dialCode}",
                                          defaultCountry: context
                                              .read<SetCountryCubit>()
                                              .state
                                              .countryCode,
                                          phoneNumber:
                                              textEditingSingUpControllerPhoneNumber
                                                  .text,
                                          email:
                                              textEditingSignUpControllerEmail
                                                  .text,
                                        );
                                  }
                                },
                              ),
                              const SizedBox(height: AuthSpacing.xxl),
                              const AuthDivider(),
                              const SizedBox(height: AuthSpacing.xl),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  socialButton("assets/images/google_icon.svg",
                                      () {
                                    context
                                        .read<GoogleLoginCubit>()
                                        .googleLogin(context);
                                  }),
                                  const SizedBox(width: 18),
                                  if (Platform.isIOS)
                                    socialButton("assets/images/apple_icon.svg",
                                        () {
                                      context
                                          .read<AppleLoginCubit>()
                                          .appleLogin(context);
                                    }),
                                ],
                              ),
                              const SizedBox(height: AuthSpacing.xxl),
                              AuthBottomLink(
                                question: "Already have an account?",
                                actionText: "Sign in",
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              const LoginScreen()));
                                },
                              ),
                              // Extra space so content can scroll above keyboard
                              SizedBox(
                                  height:
                                      MediaQuery.of(context).viewInsets.bottom >
                                              0
                                          ? 30
                                          : MediaQuery.of(context).size.height *
                                              0.05),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              // Language Button
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: AuthSpacing.large,
                      vertical: AuthSpacing.small),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      AuthLanguagePill(
                        onTap: () {
                          goTo(const SelectLanguageScreen(
                            isBack: true,
                          ));
                        },
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.language_rounded,
                                color: themeColor, size: 16),
                            const SizedBox(width: 5),
                            BlocBuilder<LCodeCubit, String>(
                                builder: (context, state) {
                              return Text(
                                state.toUpperCase(),
                                style: regular(context).copyWith(
                                  color: notifires.getwhiteblackColor,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 12.5,
                                ),
                              );
                            }),
                            Icon(Icons.keyboard_arrow_down_rounded,
                                color: notifires.getGrey3whiteColor, size: 16),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
