import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import 'package:ride_on/app/route_settings.dart';
import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/presentation/cubits/general_cubit.dart';
import 'package:ride_on/presentation/cubits/localizations_cubit.dart';
import 'package:ride_on/presentation/screens/auth/signup_screen.dart';
import 'package:ride_on/presentation/screens/onboarding/language_select_screen.dart';
import '../../../core/extensions/workspace.dart';
import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../cubits/auth/apple_login_cubit.dart';
import '../../cubits/auth/google_login_cubit.dart';
import '../../cubits/auth/login_cubit.dart';
import '../../cubits/auth/user_authenticate_cubit.dart';
import '../../widgets/auth_widgets.dart';
import '../../widgets/custom_text_form_field.dart';
import '../home/item_home_screen.dart';
import 'google_update_screen.dart';
import 'otp_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController textEditingLoginControllerPhoneNumber =
      TextEditingController();
  TextEditingController textEditingLoginControllerPassword =
      TextEditingController();

  bool isChecked = false;

  final _formKey = GlobalKey<FormState>();
  String selectedCountryCode = "+91";
  String defaultCountry = "IN";

  @override
  void initState() {
    context.read<SetCountryCubit>().reset();
    context.read<GeneralCubit>().fetchGeneralSetting(context);

    super.initState();
    isNumeric = false;
  }

  @override
  Widget build(BuildContext context) {
    notifires = Provider.of<ColorNotifires>(context, listen: true);
    return PopScope(
      canPop: false,
      child: Scaffold(
        // ========== MAIN FIX ==========
        resizeToAvoidBottomInset: true,
        bottomSheet: isNumeric == true && Platform.isIOS
            ? KeyboardDoneButton(
                onTap: () {
                  setState(() {
                    isNumeric = false;
                  });
                  FocusScope.of(context).unfocus(); // close keyboard
                },
              )
            : null,
        backgroundColor: notifires.getbgcolor,
        body: MultiBlocListener(
          listeners: [
            BlocListener<AuthLoginCubit, AuthLoginState>(
                listener: (context, state) {
              if (state is LoginLoading) {
                Widgets.showLoader(context);
              } else if (state is LoginSuccess) {
                Widgets.hideLoder(context);
                context.read<AuthLoginCubit>().resetState();

                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => OtpScreen(
                              number:
                                  textEditingLoginControllerPhoneNumber.text,
                              countryCode:
                                  state.loginModel.data?.phoneCountry ?? "+91",
                              defaultCountry: defaultCountry,
                              routeString: "Login",
                              otpValue: state.loginModel.data?.resetToken ?? "",
                            )));
              } else if (state is LoginFailure) {
                Widgets.hideLoder(context);
                showErrorToastMessage(state.error);
              }
            }),
            BlocListener<GoogleLoginCubit, GoogleLoginState>(
              listener: (context, state) {
                if (state is GoogleLoginSucess) {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const ItemHomeScreen()));
                } else if (state is AddPhoneNumberState) {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => GoogleUpdate(
                                email: state.loginModel.data?.email ?? "",
                              )));
                } else if (state is GoogleLoginFailure) {
                  showErrorToastMessage(state.error);
                }
              },
            ),
            BlocListener<AppleLoginCubit, AppleLoginState>(
              listener: (context, state) {
                if (state is AppleLoginSuccess) {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const ItemHomeScreen()));
                } else if (state is AddPhoneNumberAppleState) {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const GoogleUpdate()));
                } else if (state is AppleLoginFailure) {
                  closeLoading();
                  showErrorToastMessage(state.error);
                }
              },
            )
          ],
          child: Stack(
            children: [
              const AuthBackgroundDecoration(
                assetPath: "assets/images/EllipseTop.svg",
                alignment: Alignment.topLeft,
              ),
              SafeArea(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  keyboardDismissBehavior:
                      ScrollViewKeyboardDismissBehavior.onDrag,
                  child: Align(
                    alignment: Alignment.center,
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(
                          maxWidth: AuthMetrics.maxContentWidth),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: Dimensions.paddingSizeLarge,
                        ),
                        child: Form(
                          key: _formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              AuthHeader(
                                title: "Welcome Back",
                                subtitle: "Sign in to continue your ride",
                                logo: commonlyUserLogo(),
                              ),
                              const SizedBox(height: AuthSpacing.xxl),
                              BlocBuilder<SetCountryCubit, SetCountryState>(
                                  builder: (context, state) {
                                return IntelPhoneFieldRefs(
                                  onTap: () {
                                    isNumeric = true;
                                    setState(() {});
                                  },
                                  onChanged: (value) {
                                    final countryCode =
                                        value?.countryISOCode ?? '';
                                    String number = value?.number ?? '';

                                    if (countryCode == 'MY' &&
                                        number.startsWith('0')) {
                                      number = number.substring(1);
                                      textEditingLoginControllerPhoneNumber
                                          .text = number;
                                      textEditingLoginControllerPhoneNumber
                                              .selection =
                                          TextSelection.fromPosition(
                                        TextPosition(offset: number.length),
                                      );
                                    }
                                    return null;
                                  },
                                  key: ValueKey(state.countryCode),
                                  defultcountry: state.countryCode,
                                  textEditingControllerCommons:
                                      textEditingLoginControllerPhoneNumber,
                                  oncountryChanged: (number) {
                                    context.read<SetCountryCubit>().reset();
                                    textEditingLoginControllerPhoneNumber
                                        .clear();

                                    context.read<SetCountryCubit>().setCountry(
                                        dialCode: number.dialCode,
                                        countryCode: number.code);
                                  },
                                  hintText: "Phone no".translate(context),
                                  validator: (phoneNumber) {
                                    if (phoneNumber == null ||
                                        phoneNumber.number.isEmpty) {
                                      return "Please enter your phone number"
                                          .translate(context);
                                    }

                                    final countryCode =
                                        phoneNumber.countryISOCode;
                                    final expectedLength =
                                        phoneLengths[countryCode] ?? 10;

                                    String cleanedNumber = phoneNumber.number
                                        .replaceAll(RegExp(r'\D'), '');
                                    if (cleanedNumber.startsWith('0')) {
                                      cleanedNumber =
                                          cleanedNumber.substring(1);
                                    }

                                    if (cleanedNumber.length !=
                                        expectedLength) {
                                      return "${"Phone number must be".translate(context)} $expectedLength ${"digits".translate(context)}";
                                    }

                                    return null;
                                  },
                                );
                              }),
                              const SizedBox(height: AuthSpacing.xxl),
                              AuthPrimaryButton(
                                text: "Sign in",
                                onPressed: () {
                                  setState(() {
                                    isNumeric = false;
                                  });
                                  if (_formKey.currentState!.validate()) {
                                    if (textEditingLoginControllerPhoneNumber
                                        .text.isEmpty) {
                                      showErrorToastMessage(
                                          "Please enter the phone number"
                                              .translate(context));
                                      return;
                                    }
                                    context.read<AuthLoginCubit>().login(
                                        context: context,
                                        phoneCountry: context
                                                .read<SetCountryCubit>()
                                                .state
                                                .dialCode
                                                .startsWith("+")
                                            ? context
                                                .read<SetCountryCubit>()
                                                .state
                                                .dialCode
                                            : "+${context.read<SetCountryCubit>().state.dialCode}",
                                        phoneNumber:
                                            textEditingLoginControllerPhoneNumber
                                                .text);
                                  }
                                },
                              ),
                              const SizedBox(height: AuthSpacing.xxl),
                              const AuthDivider(),
                              const SizedBox(height: AuthSpacing.xl),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  socialButton("assets/images/google_icon.svg",
                                      () {
                                    context
                                        .read<GoogleLoginCubit>()
                                        .googleLogin(context);
                                  }),
                                  const SizedBox(width: 18),
                                  if (Platform.isIOS)
                                    socialButton("assets/images/apple_icon.svg",
                                        () {
                                      context
                                          .read<AppleLoginCubit>()
                                          .appleLogin(context);
                                    }),
                                ],
                              ),
                              const SizedBox(height: AuthSpacing.xxl),
                              AuthBottomLink(
                                question: "Don't have an account?",
                                actionText: "Sign Up",
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              const SignUp()));
                                },
                              ),
                              // Extra space when keyboard is open
                              SizedBox(
                                  height:
                                      MediaQuery.of(context).viewInsets.bottom >
                                              0
                                          ? 30
                                          : MediaQuery.of(context).size.height *
                                              0.05),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: AuthSpacing.large,
                      vertical: AuthSpacing.small),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      AuthLanguagePill(
                        onTap: () {
                          goTo(const SelectLanguageScreen(
                            isBack: true,
                          ));
                        },
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.language_rounded,
                                color: themeColor, size: 16),
                            const SizedBox(width: 5),
                            BlocBuilder<LCodeCubit, String>(
                                builder: (context, state) {
                              return Text(
                                state.toUpperCase(),
                                style: regular(context).copyWith(
                                  color: notifires.getwhiteblackColor,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 12.5,
                                ),
                              );
                            }),
                            Icon(Icons.keyboard_arrow_down_rounded,
                                color: notifires.getGrey3whiteColor, size: 16),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
