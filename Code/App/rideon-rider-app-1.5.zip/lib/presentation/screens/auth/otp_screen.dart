import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on/app/route_settings.dart';
import 'package:ride_on/core/services/data_store.dart';
import 'package:ride_on/core/utils/translate.dart';
import '../../../core/extensions/workspace.dart';
import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../cubits/auth/otp_verify_cubit.dart';
import '../../cubits/auth/resend_otp_cubit.dart';
import '../../cubits/auth/user_authenticate_cubit.dart';
import '../../widgets/auth_widgets.dart';
import '../../widgets/custom_text_form_field.dart';
import '../home/item_home_screen.dart';

class OtpScreen extends StatefulWidget {
  final String? number;
  final String? countryCode;
  final String? otpValue;
  final String? email;
  final bool? changeMobile;
  final bool? changeEmail;
  final String? defaultCountry;
  final String? routeString;
  final bool? loginWithSocialMedia;

  const OtpScreen({
    super.key,
    this.number,
    this.routeString,
    this.countryCode,
    this.otpValue,
    this.email,
    this.changeMobile,
    this.changeEmail,
    this.defaultCountry,
    this.loginWithSocialMedia,
  });

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController textEditingOtpController =
      TextEditingController();

  int _remainingTime = 15;
  bool _isResendEnabled = true;
  late Timer _timer;

  @override
  void initState() {
    super.initState();
    isNumeric = false;

    Future.delayed(const Duration(seconds: 1), () {
      if (widget.otpValue != null && widget.otpValue!.isNotEmpty) {
        textEditingOtpController.text = widget.otpValue!;
      }
    });

    startResendTimer();
  }

  void startResendTimer() {
    setState(() {
      _isResendEnabled = false;
    });

    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      setState(() {
        if (_remainingTime > 0) {
          _remainingTime--;
        } else {
          _timer.cancel();
          _isResendEnabled = true;
          _remainingTime = 0;
        }
      });
    });
  }

  String formatTimer(int totalSeconds) {
    final minutes = totalSeconds ~/ 60;
    final seconds = totalSeconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  @override
  void dispose() {
    _timer.cancel();
    textEditingOtpController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        bottomSheet: isNumeric == true && Platform.isIOS
            ? KeyboardDoneButton(
                onTap: () {
                  setState(() {
                    isNumeric = false;
                  });
                },
              )
            : null,
        resizeToAvoidBottomInset: isNumeric,
        backgroundColor: notifires.getbgcolor,
        body: MultiBlocListener(
          listeners: [
            BlocListener<AuthUserAuthenticateCubit, AuthUserAuthenticateState>(
              listener: (context, state) {
                if (state is UserLoading) {
                  Widgets.showLoader(context);
                } else if (state is UserSucesss) {
                  box.put('Remember', true);
                  box.put('Firstuser', true);
                  Widgets.hideLoder(context);
                  goToWithClear(const ItemHomeScreen());
                } else if (state is UserFailure) {
                  Widgets.hideLoder(context);
                  if (state.error.isNotEmpty) {
                    showErrorToastMessage(state.error);
                  }
                }
              },
            ),
            BlocListener<AuthOtpVerifyCubit, OtpVerifyState>(
              listener: (context, state) {
                if (state is OtpLoading) {
                  Widgets.showLoader(context);
                } else if (state is OtpSuccess) {
                  Widgets.hideLoder(context);
                  goToWithClear(const ItemHomeScreen());
                } else if (state is OtpFailure) {
                  Widgets.hideLoder(context);
                  if (state.error.isNotEmpty) {
                    showErrorToastMessage(state.error);
                  }
                }
              },
            ),
            BlocListener<AuthResendOtpCubit, ResendOtpState>(
              listener: (context, state) {
                if (state is ResendOtpLoading) {
                  Widgets.showLoader(context);
                } else if (state is ResendOtpSuccess) {
                  Widgets.hideLoder(context);
                  if (state.otpValue != null && state.otpValue!.isNotEmpty) {
                    textEditingOtpController.text = state.otpValue!;
                  }
                } else if (state is ResendOtpFailure) {
                  Widgets.hideLoder(context);
                  showErrorToastMessage(state.error);
                }
              },
            ),
          ],
          child: SafeArea(
            child: LayoutBuilder(
              builder: (context, constraints) {
                final isSmallPhone =
                    constraints.maxHeight < 700 || constraints.maxWidth < 360;
                final horizontalPadding = isSmallPhone ? 16.0 : 24.0;

                return SingleChildScrollView(
                  keyboardDismissBehavior:
                      ScrollViewKeyboardDismissBehavior.onDrag,
                  child: Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: horizontalPadding,
                      vertical: isSmallPhone
                          ? Dimensions.space16
                          : Dimensions.space24,
                    ),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Back Button
                          InkWell(
                            borderRadius: BorderRadius.circular(20),
                            onTap: () => goBack(),
                            child: Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: notifires.getBoxColor,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Icon(
                                Icons.arrow_back,
                                color: notifires.getwhiteblackColor,
                                size: 20,
                              ),
                            ),
                          ),

                          SizedBox(height: isSmallPhone ? 20 : 32),

                          // Icon
                          Container(
                            width: isSmallPhone ? 64 : 76,
                            height: isSmallPhone ? 64 : 76,
                            decoration: BoxDecoration(
                              color: themeColor.withValues(alpha: 0.14),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Icon(
                              Icons.sms_outlined,
                              color: themeColor,
                              size: isSmallPhone ? 30 : 36,
                            ),
                          ),

                          SizedBox(height: isSmallPhone ? 16 : 24),

                          // Title
                          Text(
                            "Verify your phone".translate(context),
                            style: screenTitle(context),
                          ),

                          const SizedBox(height: Dimensions.space8),

                          // Subtitle
                          Text(
                            "We've sent a verification code to"
                                .translate(context),
                            style: screenSubtitle(context),
                          ),

                          const SizedBox(height: Dimensions.space4),

                          // Phone Number
                          Text(
                            "${widget.countryCode} ${widget.number}",
                            style: sectionTitleStyle(context),
                          ),

                          SizedBox(height: isSmallPhone ? 24 : 32),

                          // OTP Field
                          Directionality(
                            textDirection: TextDirection
                                .ltr, // Arabic mein bhi left-to-right rahega
                            child: AuthOtpBoxInput(
                              controller: textEditingOtpController,
                              onTapAny: (_) {
                                isNumeric = true;
                                setState(() {});
                              },
                            ),
                          ),

                          SizedBox(height: isSmallPhone ? 20 : 28),

                          // Resend Section
                          Align(
                            alignment: Alignment.center,
                            child: _isResendEnabled
                                ? Wrap(
                                    alignment: WrapAlignment.center,
                                    crossAxisAlignment:
                                        WrapCrossAlignment.center,
                                    spacing: 6,
                                    runSpacing: 4,
                                    children: [
                                      Text(
                                        "Didn't receive code?"
                                            .translate(context),
                                        style: captionText(context),
                                      ),
                                      InkWell(
                                        onTap: () async {
                                          startResendTimer();
                                          setState(() {
                                            _remainingTime = 15;
                                            _isResendEnabled = false;
                                          });
                                          context
                                              .read<AuthResendOtpCubit>()
                                              .resendOtp(
                                                phone: widget.number,
                                                phoneCountry: widget
                                                        .countryCode!
                                                        .startsWith("+")
                                                    ? widget.countryCode!
                                                    : "+${widget.countryCode!}",
                                              );
                                        },
                                        child: Text(
                                          "Resend".translate(context),
                                          style: linkTextStyle(context),
                                        ),
                                      ),
                                    ],
                                  )
                                : Wrap(
                                    alignment: WrapAlignment.center,
                                    crossAxisAlignment:
                                        WrapCrossAlignment.center,
                                    spacing: 6,
                                    runSpacing: 4,
                                    children: [
                                      Text(
                                        "Resend code in".translate(context),
                                        style: captionText(context),
                                      ),
                                      Text(
                                        formatTimer(_remainingTime),
                                        style: captionText(context).copyWith(
                                          fontFamily: "Poppins SemiBold",
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ],
                                  ),
                          ),

                          SizedBox(height: isSmallPhone ? 24 : 32),

                          // Continue Button
                          AuthPrimaryButton(
                            text: "Continue".translate(context),
                            onPressed: () {
                              if (_formKey.currentState!.validate()) {
                                if (textEditingOtpController.text.isEmpty) {
                                  showErrorToastMessage("Please Enter the Otp"
                                      .translate(context));
                                  return;
                                }

                                if (widget.routeString == "Login") {
                                  context
                                      .read<AuthUserAuthenticateCubit>()
                                      .userAuthenticate(
                                        context: context,
                                        phoneNumber: widget.number!,
                                        phoneCountry:
                                            widget.countryCode!.startsWith("+")
                                                ? widget.countryCode!
                                                : "+${widget.countryCode!}",
                                        otpValue: textEditingOtpController.text,
                                      );
                                } else {
                                  context
                                      .read<AuthOtpVerifyCubit>()
                                      .otpVerification(
                                        context: context,
                                        phone: widget.number,
                                        otpValue: textEditingOtpController.text,
                                        countryCode:
                                            widget.countryCode!.startsWith("+")
                                                ? widget.countryCode!
                                                : "+${widget.countryCode!}",
                                        email: widget.email,
                                        changeEmail: widget.changeEmail,
                                        changeMobile: widget.changeMobile,
                                        defaultCountry: widget.defaultCountry,
                                        loginWithGoogle:
                                            widget.loginWithSocialMedia,
                                      );
                                }
                              }
                            },
                          ),

                          SizedBox(height: isSmallPhone ? 20 : 28),

                          // Go Back
                          Align(
                            alignment: Alignment.center,
                            child: Wrap(
                              alignment: WrapAlignment.center,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              spacing: 6,
                              runSpacing: 4,
                              children: [
                                Text(
                                  "Wrong number?".translate(context),
                                  style: bodyText(context),
                                ),
                                InkWell(
                                  onTap: () => goBack(),
                                  child: Text(
                                    "Go Back".translate(context),
                                    style: linkTextStyle(context),
                                  ),
                                ),
                              ],
                            ),
                          ),

                          SizedBox(height: isSmallPhone ? 16 : 24),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
