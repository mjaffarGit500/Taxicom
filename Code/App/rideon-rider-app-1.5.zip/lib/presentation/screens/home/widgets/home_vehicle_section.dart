import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on/core/utils/theme/project_color.dart';
import 'package:ride_on/core/utils/theme/theme_style.dart';
import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/domain/entities/catrgory.dart';
import 'package:ride_on/domain/entities/service_type.dart';
import 'package:ride_on/presentation/cubits/vehicle_data/get_service_type_cubit.dart'
    hide GetVehcileFailure;
import 'package:ride_on/presentation/cubits/vehicle_data/get_service_type_cubit.dart'
    as service_type_cubit show GetVehcileFailure;
import '../../../cubits/location/user_current_location_cubit.dart';
import '../../../cubits/vehicle_data/get_vehicle_cetgegory_cubit.dart';

class HomeVehicleSection extends StatelessWidget {
  final List<ServiceType> serviceTypes;
  final bool isServiceTypeLoading;
  final VoidCallback onRetryServiceType;
  final void Function(ItemTypes item) onVehicleSelected;

  const HomeVehicleSection({
    super.key,
    required this.serviceTypes,
    required this.isServiceTypeLoading,
    required this.onRetryServiceType,
    required this.onVehicleSelected,
  });

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<GetServiceTypeDataCubit, GetServiceTypeDataState>(
      builder: (context, serviceTypeState) {
        final bool isLoading = serviceTypeState is GetServiceTypeLoading ||
            serviceTypeState is GetServiceTypeInitial;

        if (serviceTypeState is service_type_cubit.GetVehcileFailure) {
          return HomeVehicleSectionError(
            message: serviceTypeState.error,
            onRetry: onRetryServiceType,
          );
        }

        return BlocBuilder<GetVehicleDataCubit, GetVehicleDataState>(
          builder: (context, vehicleState) {
            List<ItemTypes> itemList = [];
            if (vehicleState is GetItemTypeSuccess &&
                vehicleState.itemTypes.isNotEmpty) {
              itemList = vehicleState.itemTypes;
              context
                  .read<SetVehicleCategoryCubit>()
                  .updateSetVehicleCategoryList(itemList);
            }

            if (vehicleState is GetVehcileFailure) {
              return HomeVehicleSectionError(
                message: vehicleState.error,
                onRetry: onRetryServiceType,
              );
            }

            final bool isVehicleLoading = vehicleState is GetVehicleLoading ||
                vehicleState is GetVehicleInitial;
            final bool showShimmer =
                isLoading || isVehicleLoading || serviceTypes.isEmpty;

            return HomeVehicleGrid(
              items: itemList,
              isLoading: showShimmer,
              onRetry: onRetryServiceType,
              onVehicleSelected: onVehicleSelected,
            );
          },
        );
      },
    );
  }
}

class HomeVehicleSectionError extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;

  const HomeVehicleSectionError({
    super.key,
    required this.message,
    required this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 50),
      child: Center(
        child: Column(
          children: [
            Icon(Icons.error_outline, color: Colors.grey[300], size: 60),
            const SizedBox(height: 12),
            Text(
              message.isEmpty
                  ? "Unable to load options".translate(context)
                  : message,
              textAlign: TextAlign.center,
              style: regular2(context).copyWith(color: Colors.grey[400]),
            ),
            const SizedBox(height: 10),
            InkWell(
              onTap: onRetry,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                decoration: BoxDecoration(
                  color: themeColor,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  "Retry".translate(context),
                  style: regular2(context).copyWith(color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class HomeVehicleGrid extends StatelessWidget {
  final List<ItemTypes> items;
  final bool isLoading;
  final VoidCallback onRetry;
  final void Function(ItemTypes item) onVehicleSelected;

  const HomeVehicleGrid({
    super.key,
    required this.items,
    required this.isLoading,
    required this.onRetry,
    required this.onVehicleSelected,
  });

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty && !isLoading) {
      return Padding(
        padding: const EdgeInsets.only(top: 50),
        child: Center(
          child: Column(
            children: [
              Icon(Icons.car_repair, color: Colors.grey[300], size: 60),
              const SizedBox(height: 12),
              Text(
                "No vehicles available".translate(context),
                style: regular2(context).copyWith(color: Colors.grey[400]),
              ),
              const SizedBox(height: 10),
              InkWell(
                onTap: onRetry,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 20, vertical: 10),
                  decoration: BoxDecoration(
                    color: themeColor,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    "Retry".translate(context),
                    style: regular2(context).copyWith(color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return GridView.builder(
      padding: const EdgeInsets.only(bottom: 20),
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: isLoading ? 4 : items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.85,
      ),
      itemBuilder: (_, index) {
        if (isLoading) {
          return Container(
            decoration: BoxDecoration(
              color: Colors.grey[200],
              borderRadius: BorderRadius.circular(12),
            ),
          );
        }

        final item = items[index];
        return HomeVehicleCard(
          item: item,
          onTap: () => onVehicleSelected(item),
        );
      },
    );
  }
}

class HomeVehicleCard extends StatelessWidget {
  final ItemTypes item;
  final VoidCallback? onTap;

  const HomeVehicleCard({super.key, required this.item, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: themeColor.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(
                  child: Builder(
                    builder: (context) {
                      final imageUrl = (item.image ?? "").trim();

                      if (imageUrl.isEmpty) {
                        return Icon(
                          Icons.directions_car,
                          color: themeColor,
                          size: 30,
                        );
                      }

                      return Image.network(
                        imageUrl,
                        width: 40,
                        height: 40,
                        errorBuilder: (_, __, ___) => Icon(
                          Icons.directions_car,
                          color: themeColor,
                          size: 30,
                        ),
                      );
                    },
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                item.name ?? "",
                style: heading3(context).copyWith(
                  color: blackColor,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
                maxLines: 2,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
