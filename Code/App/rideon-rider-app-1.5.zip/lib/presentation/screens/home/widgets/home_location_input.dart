import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on/core/utils/theme/project_color.dart';
import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/domain/entities/service_type.dart';
import 'package:ride_on/presentation/screens/search_and_ride/route_location/route_location_screen.dart';
import '../../../cubits/book_ride_cubit.dart';
import '../../../cubits/location/user_current_location_cubit.dart';
import '../../../cubits/vehicle_data/get_vehicle_cetgegory_cubit.dart';

class HomeLocationInput extends StatelessWidget {
  final VoidCallback onOpenDrawer;
  final bool isLoadingLocation;
  final bool locationError;
  final String currentAddress;
  final ServiceType? activeServiceType;
  final ValueChanged<String> onAddressResolved;
  final Future<void> Function() onRetryLocation;
  final VoidCallback onAfterSearchNavigate;

  const HomeLocationInput({
    super.key,
    required this.onOpenDrawer,
    required this.isLoadingLocation,
    required this.locationError,
    required this.currentAddress,
    required this.activeServiceType,
    required this.onAddressResolved,
    required this.onRetryLocation,
    required this.onAfterSearchNavigate,
  });

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<UpdateCurrentAddressCubit, UpdateCurrentAddressState>(
      listener: (context, state) {
        if (state is UpdateCurrentAddresSuccess) {
          final address = state.currentAddress ?? '';
          context
              .read<BookRideRealTimeDataBaseCubit>()
              .updatePickupAddress(pickupAddress: address);
          context.read<BookRideRealTimeDataBaseCubit>().updatePickupLatAndLng(
                pickupAddressLatitude: state.lat.toString(),
                pickupAddressLongitude: state.lng.toString(),
              );
          context.read<UpdateCurrentAddressCubit>().removeAddress();
          onAddressResolved(address);
        }
      },
      builder: (context, state) {
        String address = currentAddress;
        bool error = locationError;

        if (state is UpdateCurrentAddresSuccess) {
          address = state.currentAddress ?? '';
          error = false;
        } else if (state is UpdateCurrentAddressFailed) {
          error = true;
        }

        final bool showError = error && address.isEmpty;
        final bool showLoading =
            !showError && (isLoadingLocation || address.isEmpty);

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              InkWell(
                onTap: onOpenDrawer,
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.1),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Icon(Icons.menu_outlined, color: themeColor, size: 22),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 200),
                  switchInCurve: Curves.easeOut,
                  switchOutCurve: Curves.easeIn,
                  child: showError
                      ? _buildLocationErrorRow(context)
                      : _buildLocationNormalRow(context, address, showLoading),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildLocationNormalRow(
      BuildContext context, String address, bool showLoading) {
    return InkWell(
      key: const ValueKey('location_normal_row'),
      onTap: () async {
        if (showLoading) {
          return await onRetryLocation();
        }

        context.read<VehicleDataUpdateCubit>().updateVehicleTypeSelectedId(1);
        context.read<SelectedAddressCubit>().pickupAddressController.text =
            address;
        context.read<GetSuggestionAddressCubit>().getSuggestions("");

        if (address.isEmpty || activeServiceType?.id.toString() == "2") {
          return;
        }

        await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => UserSearchLocation(
              currentAddress: address,
            ),
          ),
        );
        onAfterSearchNavigate();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.08),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: themeColor.withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.location_on, color: themeColor, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    address.isEmpty
                        ? "Fetching location...".translate(context)
                        : address.length > 40
                            ? "${address.substring(0, 40)}..."
                            : address,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          color: Colors.grey[800],
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            if (showLoading)
              SizedBox(
                width: 15,
                height: 15,
                child: CircularProgressIndicator(
                  strokeWidth: 1.8,
                  valueColor: AlwaysStoppedAnimation<Color>(themeColor),
                ),
              )
            else
              Icon(Icons.arrow_forward_ios, color: Colors.grey[400], size: 16),
          ],
        ),
      ),
    );
  }

  Widget _buildLocationErrorRow(BuildContext context) {
    return InkWell(
      key: const ValueKey('location_error_row'),
      onTap: onRetryLocation,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF1EC),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFFFFD8C7), width: 1),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: Colors.deepOrange.withValues(alpha: 0.12),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.location_off_rounded,
                  color: Colors.deepOrange, size: 18),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                "Unable to fetch location".translate(context),
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: Color(0xFF6F4A3D),
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(width: 8),
            InkWell(
              onTap: onRetryLocation,
              borderRadius: BorderRadius.circular(10),
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: themeColor,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      "Retry".translate(context),
                      style: const TextStyle(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(width: 3),
                    const Icon(Icons.refresh_rounded,
                        size: 14, color: Colors.black87),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
