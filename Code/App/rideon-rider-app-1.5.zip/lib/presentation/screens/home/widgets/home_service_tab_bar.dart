import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on/core/utils/theme/project_color.dart';
import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/domain/entities/service_type.dart';
import 'package:ride_on/presentation/cubits/vehicle_data/get_service_type_cubit.dart';
import '../../../../core/utils/common_widget.dart';
import '../../../cubits/general_cubit.dart';
import '../../../cubits/vehicle_data/get_vehicle_cetgegory_cubit.dart';

class HomeServiceTabBar extends StatelessWidget {
  static const int parcelServiceTypeId = 2;

  final int selectedTab;
  final String? selectedServiceTypeId;
  final ValueChanged<List<ServiceType>> onServiceTypesLoaded;
  final void Function(int index, ServiceType item) onTabSelected;

  const HomeServiceTabBar({
    super.key,
    required this.selectedTab,
    required this.selectedServiceTypeId,
    required this.onServiceTypesLoaded,
    required this.onTabSelected,
  });

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<GetServiceTypeDataCubit, GetServiceTypeDataState>(
      listener: (context, state) {
        if (state is GetServiceTypeSuccess) {
          onServiceTypesLoaded(state.itemTypes);

          if (state.itemTypes.isEmpty) {
            return;
          }

          int safeIndex =
              selectedTab >= state.itemTypes.length ? 0 : selectedTab;

          if (selectedServiceTypeId == null) {
            final firstRideIndex = state.itemTypes.indexWhere(
                (serviceType) => serviceType.id != parcelServiceTypeId);
            if (firstRideIndex != -1) {
              safeIndex = firstRideIndex;
            }
          }

          onTabSelected(safeIndex, state.itemTypes[safeIndex]);

          final selectedService = state.itemTypes[safeIndex];
          final selectedServiceId = selectedService.id?.toString() ?? "";

          if (selectedServiceId.isNotEmpty &&
              selectedServiceTypeId != selectedServiceId) {
            context
                .read<GetVehicleDataCubit>()
                .getItemTypesByService(selectedServiceId);
            context.read<ServiceTypeId>().update(selectedServiceId);
          }
        }
      },
      builder: (context, state) {
        bool isLoading = state is GetServiceTypeLoading;

        List<ServiceType> serviceTypes = [];
        if (state is GetServiceTypeSuccess) {
          serviceTypes = state.itemTypes;
        }

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Container(
            height: 43,
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(30),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: .08),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: isLoading
                ? Row(
                    children: [
                      Expanded(child: ShimmerLoader()),
                      const SizedBox(width: 10),
                      Expanded(child: ShimmerLoader()),
                    ],
                  )
                : serviceTypes.isEmpty
                    ? Center(child: Text("No Services".translate(context)))
                    : Row(
                        children: List.generate(serviceTypes.length, (index) {
                          final item = serviceTypes[index];
                          final isSelected = selectedTab == index;

                          return Expanded(
                            child: InkWell(
                              borderRadius: BorderRadius.circular(26),
                              onTap: () {
                                if (selectedTab == index) return;

                                final serviceTypeId =
                                    item.id?.toString() ?? "";

                                onTabSelected(index, item);

                                if (serviceTypeId.isNotEmpty) {
                                  context
                                      .read<GetVehicleDataCubit>()
                                      .getItemTypesByService(serviceTypeId);
                                  context
                                      .read<ServiceTypeId>()
                                      .update(serviceTypeId);
                                }
                              },
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 250),
                                curve: Curves.easeInOut,
                                decoration: BoxDecoration(
                                  color: isSelected
                                      ? themeColor
                                      : Colors.transparent,
                                  borderRadius: BorderRadius.circular(26),
                                ),
                                alignment: Alignment.center,
                                child: Text(
                                  item.name ?? "",
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: isSelected ? grey1 : grey2,
                                  ),
                                ),
                              ),
                            ),
                          );
                        }),
                      ),
          ),
        );
      },
    );
  }
}
