import 'package:flutter/material.dart';
import 'package:ride_on/core/utils/theme/project_color.dart';
import 'package:ride_on/core/utils/theme/theme_style.dart';
import 'package:ride_on/core/utils/translate.dart';

class HomeRecentSearches extends StatelessWidget {
  final List<Map<String, String>> recentDropLocations;
  final VoidCallback onClear;
  final ValueChanged<Map<String, String>> onTapItem;

  const HomeRecentSearches({
    super.key,
    required this.recentDropLocations,
    required this.onClear,
    required this.onTapItem,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: .06),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: themeColor.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(Icons.history, color: themeColor, size: 16),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    "Recent".translate(context),
                    style: heading3Grey1(context).copyWith(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              if (recentDropLocations.isNotEmpty)
                GestureDetector(
                  onTap: onClear,
                  child: Text(
                    "Clear".translate(context),
                    style: regular2(context).copyWith(
                      color: Colors.redAccent,
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 10),
          if (recentDropLocations.isEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Text(
                  "No recent searches".translate(context),
                  style: regular2(context).copyWith(
                    color: Colors.grey[400],
                    fontSize: 12,
                  ),
                ),
              ),
            )
          else
            Column(
              children: recentDropLocations.take(2).map((item) {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: () => onTapItem(item),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 8),
                      decoration: BoxDecoration(
                        color: themeColor.withValues(alpha: 0.05),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 4,
                            height: 32,
                            decoration: BoxDecoration(
                              color: themeColor,
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Icon(Icons.location_on, size: 16, color: themeColor),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              item['address'] ?? "",
                              style: regular(context).copyWith(
                                fontSize: 12.5,
                                color: notifires.getGrey1whiteColor,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Icon(Icons.arrow_forward_ios,
                              size: 12, color: Colors.grey[400]),
                        ],
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
        ],
      ),
    );
  }
}
