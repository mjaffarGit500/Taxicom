import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:ride_on/core/utils/theme/project_color.dart';
import 'package:ride_on/core/utils/theme/theme_style.dart';
import 'package:ride_on/core/utils/translate.dart';

void showLocationPermissionDeniedDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (context) => AlertDialog(
      backgroundColor: notifires.getbgcolor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.location_on, color: Colors.redAccent, size: 24),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              "Location Access Needed".translate(context),
              style: heading2Grey1(context),
            ),
          ),
        ],
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "To keep your rides accurate and smooth, please allow location access. You can enable it easily by following these steps:"
                .translate(context),
            style: regular2(context),
          ),
          const SizedBox(height: 12),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("👉 "),
              Expanded(
                child: Text("Open your phone's Settings".translate(context),
                    style: regular2(context)),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("👉 "),
              Expanded(
                child: Text("Go to App Permissions".translate(context),
                    style: regular2(context)),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("👉 "),
              Expanded(
                child: Text(
                    "Allow Location Access for this app".translate(context),
                    style: regular2(context)),
              ),
            ],
          ),
        ],
      ),
      actionsPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(
            "Not Now".translate(context),
            style: const TextStyle(color: Colors.grey),
          ),
        ),
        ElevatedButton.icon(
          onPressed: () {
            Geolocator.openAppSettings();
            Navigator.pop(context);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blueAccent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          icon: const Icon(Icons.settings, size: 18, color: Colors.white),
          label: Text(
            "Open Settings".translate(context),
            style: const TextStyle(color: Colors.white),
          ),
        ),
      ],
    ),
  );
}
