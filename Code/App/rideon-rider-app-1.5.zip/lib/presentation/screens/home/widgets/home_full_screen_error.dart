import 'package:flutter/material.dart';
import 'package:ride_on/core/utils/theme/project_color.dart';
import 'package:ride_on/core/utils/theme/theme_style.dart';
import 'package:ride_on/core/utils/translate.dart';

class HomeFullScreenError extends StatelessWidget {
  final String? message;
  final VoidCallback onRetry;

  const HomeFullScreenError({
    super.key,
    this.message,
    required this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.wifi_off_rounded, color: Colors.grey[400], size: 70),
            const SizedBox(height: 16),
            Text(
              "Something went wrong".translate(context),
              textAlign: TextAlign.center,
              style: heading2Grey1(context).copyWith(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.grey[700],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              (message == null || message!.isEmpty)
                  ? "We couldn't load your home data. Please try again."
                      .translate(context)
                  : message!,
              textAlign: TextAlign.center,
              style: regular2(context).copyWith(color: Colors.grey[500]),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: onRetry,
              style: ElevatedButton.styleFrom(
                backgroundColor: themeColor,
                padding: const EdgeInsets.symmetric(
                    horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              icon: const Icon(Icons.refresh_rounded, color: Colors.black87),
              label: Text(
                "Retry".translate(context),
                style: const TextStyle(
                  color: Colors.black87,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
