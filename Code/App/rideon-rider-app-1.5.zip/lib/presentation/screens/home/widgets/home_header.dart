import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on/core/utils/common_widget.dart';
import 'package:ride_on/core/utils/theme/project_color.dart';
import 'package:ride_on/core/utils/theme/theme_style.dart';
import 'package:ride_on/core/utils/translate.dart';
import '../../../cubits/profile/edit_profile_cubit.dart';

class HomeHeader extends StatelessWidget {
  final VoidCallback onOpenDrawer;

  const HomeHeader({super.key, required this.onOpenDrawer});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Row(
        children: [
          BlocBuilder<MyImageCubit, dynamic>(builder: (context, state) {
            return InkWell(
              onTap: onOpenDrawer,
              child: state.isEmpty
                  ? Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        color: themeColor.withValues(alpha: 0.1),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        CupertinoIcons.profile_circled,
                        size: 40,
                        color: themeColor,
                      ),
                    )
                  : Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: themeColor, width: 2),
                      ),
                      child: ClipOval(
                        child:
                            myNetworkImage(context.watch<MyImageCubit>().state),
                      ),
                    ),
            );
          }),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: "${"Hi".translate(context)}, ",
                        style: heading2Grey1(context).copyWith(
                          fontSize: 18,
                          color: Colors.grey[700],
                        ),
                      ),
                      TextSpan(
                        text: " ${context.watch<NameCubit>().state}",
                        style: heading2Grey1(context).copyWith(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: blackColor,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "Where do you want to go today?".translate(context),
                  style: heading3Grey1(context).copyWith(
                    color: grey2,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
