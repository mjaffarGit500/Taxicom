import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:ride_on/app/route_settings.dart';
import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/core/extensions/helper/push_notifications.dart';
import 'package:ride_on/core/utils/common_widget.dart';
import 'package:ride_on/core/utils/theme/theme_style.dart';
import 'package:ride_on/core/extensions/workspace.dart';
import 'package:ride_on/domain/entities/catrgory.dart';
import 'package:ride_on/domain/entities/service_type.dart';
import 'package:ride_on/presentation/cubits/slider_cubit.dart';
import 'package:ride_on/presentation/cubits/vehicle_data/get_service_type_cubit.dart';
import 'package:ride_on/presentation/screens/home/parcel_details_screen.dart'
    show ParcelDetailsScreen;
import 'package:ride_on/presentation/screens/search_and_ride/loading_nearby_search_screen.dart';
import 'package:ride_on/presentation/screens/search_and_ride/route_location/route_location_screen.dart';
import 'package:ride_on/presentation/widgets/drawer_custom.dart';
import '../../../core/services/data_store.dart';
import '../../cubits/book_ride_cubit.dart';
import '../../cubits/general_cubit.dart';
import '../../cubits/location/user_current_location_cubit.dart';
import '../../cubits/profile/edit_profile_cubit.dart';
import '../../cubits/realtime/update_ride_request_parameter.dart';
import '../../cubits/vehicle_data/get_vehicle_cetgegory_cubit.dart'
    hide GetVehcileFailure;
import 'widgets/auto_image_slider.dart';
import 'widgets/home_delivery_notes.dart';
import 'widgets/home_full_screen_error.dart';
import 'widgets/home_header.dart';
import 'widgets/home_location_input.dart';
import 'widgets/home_recent_searches.dart';
import 'widgets/home_service_tab_bar.dart';
import 'widgets/home_vehicle_section.dart';
import 'widgets/location_permission_dialog.dart';

class ItemHomeScreen extends StatefulWidget {
  const ItemHomeScreen({super.key});

  @override
  State<ItemHomeScreen> createState() => _ItemHomeScreenState();
}

class _ItemHomeScreenState extends State<ItemHomeScreen>
    with SingleTickerProviderStateMixin {
  final ValueNotifier<LatLng> _selectedLocation =
      ValueNotifier(const LatLng(0, 0));
  static LatLng defaultLocation = LatLng(defaultLat, defaultLng);
  Timer? _debounceTimer;
  bool showAlert = false;
  late TabController _tabController;
  int _selectedTab = 0;
  String? _selectedServiceTypeId;
  String? pickupLocation;
  String? dropLocation;
  DateTime? selectedDate;
  TimeOfDay? selectedTime;
  double? pickupLat;
  double? pickupLng;
  double? dropLat;
  double? dropLng;
  List<Map<String, dynamic>> scheduledRides = [];

  @override
  void initState() {
    super.initState();
    getFCMToken();

    box.delete('current_parcel_data');
    _tabController = TabController(length: 3, vsync: this, initialIndex: 0);
    _tabController.addListener(_handleTabSelection);
    _loadRecentDropLocations();
    context.read<MyImageCubit>().updateMyImage(myImage);
    context
        .read<BookRideRealTimeDataBaseCubit>()
        .updateUserImageUrl(userImageUrl: myImage);
    context.read<UpdateRideRequestParameterCubit>().updateFirebaseUserParameter(
        rideId: context.read<BookRideRealTimeDataBaseCubit>().state.rideId,
        userParameter: {"userImageUrl": myImage});
    context.read<NameCubit>().updateName(loginModel?.data?.firstName ?? "");
    context.read<EmailCubit>().updateEmail(loginModel?.data?.email ?? "");
    isNumeric = false;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initializeApp();
      showNotification(context);
    });
  }

  void _handleTabSelection() {
    if (_tabController.indexIsChanging) {
      setState(() {
        _selectedTab = _tabController.index;
      });
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  List<Map<String, String>> recentDropLocations = [];
  void _loadRecentDropLocations() {
    final storedList = box.get('recent_drop_locations', defaultValue: []);
    if (storedList is List) {
      recentDropLocations =
          storedList.map((e) => Map<String, String>.from(e)).toList();
    }
    setState(() {});
  }

  String _currentAddress = "";
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  bool _isInitialLocationLoaded = false;
  bool _isLoadingLocation = false;
  bool _locationError = false;

  Future<void> _initializeApp() async {
    context.read<GetServiceTypeDataCubit>().getServiceType();
    context.read<SlidersCubit>().getSlidersList(context);
    getCurrency(context);
    getUserDataLocallyToHandleTheState(context);
    await _loadInitialLocation();
  }

  Future<void> _refreshHomeScreenData() async {
    context.read<GetServiceTypeDataCubit>().getServiceType();
    context.read<SlidersCubit>().getSlidersList(context);
    getCurrency(context);
    await _loadInitialLocation();
    final serviceTypeId = _selectedServiceTypeId;
    if (serviceTypeId != null && serviceTypeId.isNotEmpty) {
      context.read<GetVehicleDataCubit>().getItemTypesByService(serviceTypeId);
    }
  }

  Future<void> _loadInitialLocation() async {
    if (_isInitialLocationLoaded || _isLoadingLocation) return;
    setState(() => _isLoadingLocation = true);
    final cachedLocation = await _loadCachedLocation();
    if (cachedLocation != null) {
      _selectedLocation.value = cachedLocation;
      setState(() => _isInitialLocationLoaded = true);
    }
    try {
      await startLiveLocationTracking(isInitialLoad: true).timeout(
        const Duration(seconds: 5),
        onTimeout: () {
          _selectedLocation.value = defaultLocation;
          setState(() => _isInitialLocationLoaded = true);
        },
      );
    } catch (e) {
      _selectedLocation.value = defaultLocation;
      setState(() => _isInitialLocationLoaded = true);
    } finally {
      setState(() => _isLoadingLocation = false);
    }
  }

  Future<LatLng?> _loadCachedLocation() async {
    final lat = box.get('last_latitude');
    final lng = box.get('last_longitude');
    if (lat != null && lng != null) {
      return LatLng(lat, lng);
    }
    return null;
  }

  Future<void> startLiveLocationTracking({bool isInitialLoad = false}) async {
    if (_isLoadingLocation && !isInitialLoad) return;

    if (mounted) {
      setState(() {
        _isLoadingLocation = true;
        _locationError = false;
      });
    } else {
      _isLoadingLocation = true;
    }

    try {
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        permission = await Geolocator.requestPermission();

        if ((permission != LocationPermission.always &&
                permission != LocationPermission.whileInUse) &&
            Platform.isIOS) {
          if (showAlert == true) return;
          showAlert = true;
          if (mounted) showLocationPermissionDeniedDialog(context);
          return;
        }
        if (permission != LocationPermission.always &&
            permission != LocationPermission.whileInUse) {
          await Geolocator.openAppSettings();
        }
      }

      final position = await Geolocator.getCurrentPosition(
          // ignore: deprecated_member_use
          desiredAccuracy: LocationAccuracy.high);

      updateUserLocation(position, debounce: !isInitialLoad);
    } catch (e) {
      showErrorToastMessage('Error getting location: $e');
      if (mounted) {
        setState(() => _locationError = true);
      } else {
        _locationError = true;
      }
    } finally {
      _isLoadingLocation = false;
    }
  }

  Future<LocationPermission> checkPermissions() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      showErrorToastMessage(
          // ignore: use_build_context_synchronously
          "Please enable location services".translate(context));
      return LocationPermission.denied;
    }
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    return permission;
  }

  void updateUserLocation(Position position, {bool debounce = true}) {
    _debounceTimer?.cancel();
    if (!debounce) {
      context.read<UpdateCurrentAddressCubit>().getAddressFromLatLng(
            latitude: position.latitude,
            longitude: position.longitude,
          );
      return;
    }
    _debounceTimer = Timer(const Duration(seconds: 1), () {
      context.read<UpdateCurrentAddressCubit>().getAddressFromLatLng(
            latitude: position.latitude,
            longitude: position.longitude,
          );
    });
  }

  void _showParcelDetailsDialog(String maxWeight) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
      ),
      builder: (context) => Padding(
        padding: const EdgeInsets.only(top: 60),
        child: ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(25)),
            child: ParcelDetailsScreen(maxWeight: maxWeight)),
      ),
    );
  }

  Future<void> _refreshVehicleCategories() async {
    if (!mounted) return;
    final serviceTypeId = _selectedServiceTypeId;
    if (serviceTypeId == null || serviceTypeId.isEmpty) {
      return;
    }
    context.read<GetVehicleDataCubit>().getItemTypesByService(serviceTypeId);
  }

  Future<void> _retryLocationFetch() async {
    if (_isLoadingLocation) return;
    await startLiveLocationTracking();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      onPopInvokedWithResult: (v, e) async => dialogExit(context),
      canPop: false,
      child: Scaffold(
        extendBodyBehindAppBar: true,
        drawer: const MyDrawer(),
        key: _scaffoldKey,
        onDrawerChanged: (isOpened) {
          if (!isOpened) {
            _refreshVehicleCategories();
          }
        },
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(170),
          child: Container(
            color: Colors.transparent,
            child: SafeArea(
              child: Column(
                children: [
                  HomeHeader(
                    onOpenDrawer: () => _scaffoldKey.currentState?.openDrawer(),
                  ),
                  const SizedBox(height: 5),
                  HomeLocationInput(
                    onOpenDrawer: () => _scaffoldKey.currentState?.openDrawer(),
                    isLoadingLocation: _isLoadingLocation,
                    locationError: _locationError,
                    currentAddress: _currentAddress,
                    activeServiceType: _activeServiceType,
                    onAddressResolved: (address) {
                      if (_currentAddress == address) return;
                      setState(() {
                        pickupLocation = address;
                        _currentAddress = address;
                      });
                    },
                    onRetryLocation: _retryLocationFetch,
                    onAfterSearchNavigate: _loadRecentDropLocations,
                  ),
                ],
              ),
            ),
          ),
        ),
        body: Container(
          height: double.maxFinite,
          width: double.maxFinite,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color.fromARGB(255, 245, 237, 213),
                Color.fromARGB(255, 255, 247, 223),
                Color.fromARGB(255, 248, 242, 226),
                Color.fromARGB(255, 254, 238, 196),
              ],
            ),
          ),
          child: Stack(
            children: [
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: SvgPicture.asset("assets/images/home_group.svg"),
              ),
              SafeArea(
                child: _buildBody(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBody() {
    return BlocBuilder<GetServiceTypeDataCubit, GetServiceTypeDataState>(
      builder: (context, state) {
        if (state is GetVehcileFailure) {
          return HomeFullScreenError(
            message: state.error,
            onRetry: _refreshHomeScreenData,
          );
        }

        if (state is GetServiceTypeSuccess && state.itemTypes.isEmpty) {
          return HomeFullScreenError(
            onRetry: _refreshHomeScreenData,
          );
        }

        return Column(
          children: [
            const AutoImageSlider(),
            const SizedBox(height: 15),
            _buildTabBar(),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(
                  children: [
                    _buildTabContent(),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  List<ServiceType> serviceTypes = [];

  Widget _buildTabBar() {
    return HomeServiceTabBar(
      selectedTab: _selectedTab,
      selectedServiceTypeId: _selectedServiceTypeId,
      onServiceTypesLoaded: (types) {
        serviceTypes = types;
      },
      onTabSelected: (index, item) {
        final serviceTypeId = item.id?.toString() ?? "";
        setState(() {
          _selectedTab = index;
          _selectedServiceTypeId = serviceTypeId.isEmpty ? null : serviceTypeId;
        });
      },
    );
  }

  Widget _buildTabContent() {
    final activeServiceType = _activeServiceType;

    if (_isParcelService(activeServiceType)) {
      return _buildParcelContent();
    }

    return _buildRideContent();
  }

  static const int _parcelServiceTypeId = HomeServiceTabBar.parcelServiceTypeId;

  ServiceType? get _activeServiceType {
    if (serviceTypes.isEmpty) return null;

    final selectedId = _selectedServiceTypeId;
    if (selectedId != null && selectedId.isNotEmpty) {
      for (final serviceType in serviceTypes) {
        if (serviceType.id?.toString() == selectedId) {
          return serviceType;
        }
      }
    }

    return serviceTypes.first;
  }

  bool _isParcelService(ServiceType? serviceType) {
    return serviceType?.id == _parcelServiceTypeId;
  }

  Widget _buildRideContent() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0),
          child: Column(
            children: [
              const SizedBox(height: 20),
              if (recentDropLocations.isNotEmpty)
                HomeRecentSearches(
                  recentDropLocations: recentDropLocations,
                  onClear: () {
                    box.delete('recent_drop_locations');
                    _loadRecentDropLocations();
                  },
                  onTapItem: _handleRecentSearchTap,
                ),
              if (recentDropLocations.isNotEmpty) const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "🚗 ${"Choose Your Ride".translate(context)}"
                        .translate(context),
                    style: heading2Grey1(context).copyWith(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 15),
              _buildDependentVehicleSection(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildParcelContent() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20),
            _buildVehicleSelectionSection(),
            const SizedBox(height: 30),
            const HomeDeliveryNotes(),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildVehicleSelectionSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "🚚 ${"Select Delivery Vehicle".translate(context)}"
                  .translate(context),
              style: heading2Grey1(context).copyWith(
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Text(
          "Choose the right vehicle for your parcel size".translate(context),
          style: regular2(context).copyWith(
            color: Colors.grey[600],
            fontSize: 11,
          ),
        ),
        const SizedBox(height: 12),
        _buildDependentVehicleSection(),
      ],
    );
  }

  void _handleRecentSearchTap(Map<String, String> item) {
    if (_currentAddress.isEmpty) {
      showAlert = false;
      startLiveLocationTracking();
      setState(() {});
      return;
    }

    context.read<SelectedAddressCubit>().dropOffAddressController.text =
        item['address'] ?? "";
    context.read<BookRideRealTimeDataBaseCubit>().updateDropOffLatAndLng(
          dropoffAddressLatitude: item['lat'] ?? "",
          dropoffAddressLongitude: item['lng'] ?? "",
        );

    final bookRide = context.read<BookRideRealTimeDataBaseCubit>();
    bookRide.updatePickupAddress(pickupAddress: _currentAddress);
    bookRide.updateDropOffAddress(dropoffAddress: item['address'] ?? "");
    box.delete("current_parcel_data");

    if (bookRide.state.pickupAddress.isNotEmpty &&
        bookRide.state.dropoffAddress.isNotEmpty &&
        bookRide.state.pickupAddressLatitude.isNotEmpty &&
        bookRide.state.pickupAddressLongitude.isNotEmpty &&
        bookRide.state.dropoffAddressLatitude.isNotEmpty &&
        bookRide.state.dropoffAddressLongitude.isNotEmpty) {
      goTo(const LoadingNearbySearchScreen());
    }
  }

  Widget _buildDependentVehicleSection() {
    return HomeVehicleSection(
      serviceTypes: serviceTypes,
      isServiceTypeLoading: false,
      onRetryServiceType: () {
        context.read<GetServiceTypeDataCubit>().getServiceType();
        setState(() {
          _selectedTab = 0;
          _selectedServiceTypeId = null;
        });
      },
      onVehicleSelected: _onVehicleSelected,
    );
  }

  Future<void> _onVehicleSelected(ItemTypes item) async {
    if (!_isParcelService(_activeServiceType)) {
      context.read<VehicleDataUpdateCubit>().updateVehicleTypeSelectedId(item.id);
      context.read<SelectedAddressCubit>().pickupAddressController.text =
          _currentAddress;
      context.read<GetSuggestionAddressCubit>().getSuggestions("");
      box.delete('current_parcel_data');

      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => UserSearchLocation(
            currentAddress: _currentAddress,
          ),
        ),
      );
      _loadRecentDropLocations();
    } else {
      context.read<SelectedAddressCubit>().pickupAddressController.text =
          _currentAddress;
      context.read<GetSuggestionAddressCubit>().getSuggestions("");
      context.read<VehicleDataUpdateCubit>().updateVehicleTypeSelectedId(item.id);
      _showParcelDetailsDialog(item.maxWeight ?? "");
    }
  }
}

void getCurrency(BuildContext context) {
  context.read<GeneralCubit>().fetchGeneralSetting(context);
}
