// ignore_for_file: void_checks

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on/core/extensions/workspace.dart';
import 'package:ride_on/core/utils/theme/project_color.dart';
import 'package:ride_on/core/utils/translate.dart';
import 'package:ride_on/core/utils/common_widget.dart';
import 'package:ride_on/presentation/cubits/auth/user_authenticate_cubit.dart';
import 'package:ride_on/presentation/cubits/location/user_current_location_cubit.dart';
import 'package:ride_on/presentation/screens/search_and_ride/route_location/route_location_screen.dart';
import 'package:ride_on/presentation/widgets/custom_text_form_field.dart';
import 'package:ride_on/presentation/widgets/form_validations.dart';
import '../../../core/services/data_store.dart';

class ParcelDetailsScreen extends StatefulWidget {
  final String maxWeight;
  const ParcelDetailsScreen({
    super.key,
    required this.maxWeight,
  });

  @override
  State<ParcelDetailsScreen> createState() => _ParcelDetailsScreenState();
}

class _ParcelDetailsScreenState extends State<ParcelDetailsScreen> {
  final TextEditingController _parcelNameController = TextEditingController();
  final TextEditingController _parcelWeightController = TextEditingController();
  final TextEditingController _parcelValueController = TextEditingController();
  final TextEditingController _receiverNameController = TextEditingController();
  final TextEditingController _receiverPhoneController =
      TextEditingController();
  final TextEditingController _pickupInstructionsController =
      TextEditingController();
  final TextEditingController _specialInstructionsController =
      TextEditingController();

  File? parcelImage;

  

  final FocusNode _nameFocus = FocusNode();
  final FocusNode _weightFocus = FocusNode();
  final FocusNode _pickupFocus = FocusNode();

  @override
  void initState() {
    super.initState();
    _nameFocus.addListener(() => setState(() {}));
    _weightFocus.addListener(() => setState(() {}));
    _pickupFocus.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _parcelNameController.dispose();
    _parcelWeightController.dispose();
    _parcelValueController.dispose();
    _receiverNameController.dispose();
    _receiverPhoneController.dispose();
    _pickupInstructionsController.dispose();
    _specialInstructionsController.dispose();
    _nameFocus.dispose();
    _weightFocus.dispose();
    _pickupFocus.dispose();
    super.dispose();
  }

  bool isWeightValid() {
    final enteredWeight = double.tryParse(_parcelWeightController.text);
    final maxAllowedWeight = double.tryParse(widget.maxWeight);

    if (enteredWeight == null) return false;
    if (maxAllowedWeight == null) return true;

    return enteredWeight <= maxAllowedWeight;
  }

  void _validateAndProceed() {
    if (_parcelNameController.text.isEmpty) {
      return showErrorToastMessage(
          "Please enter parcel name".translate(context));
    }
    if (_parcelWeightController.text.isEmpty) {
      return showErrorToastMessage("Please enter weight".translate(context));
    }

    if (!isWeightValid()) {
      return showErrorToastMessage(
        "${"Max allowed weight is".translate(context)} ${widget.maxWeight} ${"kg".translate(context)}"
            .translate(context),
      );
    }
    if (_receiverNameController.text.isEmpty) {
      return showErrorToastMessage(
          "Please enter receiver name".translate(context));
    }
    if (_receiverPhoneController.text.isEmpty) {
      return showErrorToastMessage(
          "Please enter receiver phone".translate(context));
    }

    final parcelData = {
      'name': _parcelNameController.text,
      'weight': _parcelWeightController.text,
      'receiverName': _receiverNameController.text,
      'receiverPhone': _receiverPhoneController.text,
      'pickupInstructions': _pickupInstructionsController.text,
    };

    box.put('current_parcel_data', parcelData);

    final currentAddress =
        context.read<SelectedAddressCubit>().pickupAddressController.text;

    context.read<GetSuggestionAddressCubit>().getSuggestions("");

    Navigator.pop(context);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => UserSearchLocation(currentAddress: currentAddress),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomSheet: isNumeric == true && Platform.isIOS
          ? KeyboardDoneButton(
              onTap: () {
                setState(() {
                  isNumeric = false;
                });
              },
            )
          : null,
      backgroundColor: bgColor,
      appBar: _buildAppBar(context),
      body: SafeArea(
        top: false,
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildHeader(context),
                    const SizedBox(height: 20),
                    _buildProgressIndicator(context),
                    const SizedBox(height: 24),
                    _buildParcelInformation(context),
                    const SizedBox(height: 20),
                    _buildReceiverDetails(context),
                    const SizedBox(height: 20),
                    _buildPickupInstructions(context),
                  ],
                ),
              ),
            ),
            _buildBottomAction(context),
          ],
        ),
      ),
    );
  }

  // ==================== AppBar ====================
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      backgroundColor: bgColor,
      scrolledUnderElevation: 0,
      elevation: 0,
      titleSpacing: 4,
      leadingWidth: 60,
      leading: Padding(
        padding: const EdgeInsetsDirectional.only(
          start: 16,
          top: 16,
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () => Navigator.pop(context),
          child: Container(
            height: 40,
            width: 40,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: borderNeutral),
            ),
            child: _DirectionalIcon(
              icon: Icons.arrow_back_ios_new_rounded,
              size: 16,
              color: themeColor,
            ),
          ),
        ),
      ),
      title: Text(
        "Parcel Details".translate(context),
        style:  TextStyle(
          fontSize: 17,
          fontWeight: FontWeight.w700,
          color: darkText,
        ),
      ),
    );
  }

  // ==================== Header ====================
  Widget _buildHeader(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Parcel Delivery".translate(context),
          style:  TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: darkText,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          "Add a few details to get your delivery started".translate(context),
          style: TextStyle(
            fontSize: 12,
            color: mutedText,
            height: 1.35,
          ),
        ),
      ],
    );
  }

  // ==================== Progress indicator (visual only) ====================
  Widget _buildProgressIndicator(BuildContext context) {
    return Row(
      children: [
        _buildProgressStep(
          number: "01",
          label: "Details".translate(context),
          isActive: true,
        ),
        Expanded(
          child: Container(
            height: 2,
            margin: const EdgeInsets.symmetric(horizontal: 8),
            color: themeColor.withOpacity(0.35),
          ),
        ),
        _buildProgressStep(
          number: "02",
          label: "Route".translate(context),
          isActive: false,
        ),
      ],
    );
  }

  Widget _buildProgressStep({
    required String number,
    required String label,
    required bool isActive,
  }) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          height: 22,
          width: 22,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: isActive ? themeColor : fieldFill,
            shape: BoxShape.circle,
            border: Border.all(
              color: isActive ? themeColor : borderNeutral,
            ),
          ),
          child: Text(
            number,
            style: TextStyle(
              fontSize: 9.5,
              fontWeight: FontWeight.w700,
              color: isActive ? Colors.black87 : mutedText,
            ),
          ),
        ),
        const SizedBox(width: 6),
        Text(
          label,
          style: TextStyle(
            fontSize: 11.5,
            fontWeight: FontWeight.w600,
            color: isActive ? darkText : mutedText,
          ),
        ),
      ],
    );
  }

  // ==================== Section header ====================
  Widget _buildSectionHeader({required IconData icon, required String title}) {
    return Row(
      children: [
        Icon(icon, size: 17, color: themeColor),
        const SizedBox(width: 8),
        Text(
          title,
          style:  TextStyle(
            fontSize: 13.5,
            fontWeight: FontWeight.w700,
            color: darkText,
          ),
        ),
      ],
    );
  }

  // ==================== Parcel information ====================
  Widget _buildParcelInformation(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader(
          icon: Icons.inventory_2_outlined,
          title: "Parcel Information".translate(context),
        ),
        const SizedBox(height: 12),
        _buildModernInput(
          controller: _parcelNameController,
          focusNode: _nameFocus,
          hint: "e.g., Laptop, Documents, Electronics".translate(context),
          prefixIcon: Icons.edit_outlined,
        ),
        const SizedBox(height: 12),
        _buildModernInput(
          controller: _parcelWeightController,
          focusNode: _weightFocus,
          hint: "e.g., 2.5".translate(context),
          prefixIcon: Icons.scale_outlined,
          keyboardType: TextInputType.number,
          suffix: "kg".translate(context),
        ),
        const SizedBox(height: 6),
        Padding(
          padding: const EdgeInsetsDirectional.only(start: 2),
          child: Text(
            "${"Maximum allowed".translate(context)}: ${widget.maxWeight} ${"kg".translate(context)}",
            style: TextStyle(
              fontSize: 10.5,
              fontWeight: FontWeight.w500,
              color: themeColor.computeLuminance() > 0.6
                  ? const Color(0xFF8A6D00)
                  : themeColor,
            ),
          ),
        ),
      ],
    );
  }

  // ==================== Receiver details ====================
  Widget _buildReceiverDetails(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader(
          icon: Icons.person_outline_rounded,
          title: "Receiver Details".translate(context),
        ),
        const SizedBox(height: 12),
        TextFieldAdvance(
          onTap: () {
            isNumeric = false;
            setState(() {});
          },
          inputAlignment: TextAlign.start,
          txt: "Receiver Name".translate(context),
          icons: Icon(
            Icons.person_2_outlined,
            color: themeColor,
            size: 18,
          ),
          textEditingControllerCommon: _receiverNameController,
          inputType: TextInputType.name,
          validator: (value) {
            if (isValidName(value!)) {
              return null;
            } else {
              return "Enter receiver full name".translate(context);
            }
          },
        ),
        const SizedBox(height: 12),
        BlocBuilder<SetCountryCubit, SetCountryState>(
          builder: (context, state) {
            return IntelPhoneFieldRefs(
              onTap: () {
                isNumeric = true;
                setState(() {});
              },
              onChanged: (value) {
                int expectedLength = phoneLengths[state.countryCode] ?? 10;

                if (value!.number.length > expectedLength) {
                  _receiverPhoneController.text =
                      value.number.substring(0, expectedLength);

                  _receiverPhoneController.selection =
                      TextSelection.fromPosition(
                    TextPosition(
                      offset: _receiverPhoneController.text.length,
                    ),
                  );
                }
                setState(() {});
                return null;
              },
              key: ValueKey(state.countryCode),
              defultcountry: state.countryCode,
              textEditingControllerCommons: _receiverPhoneController,
              oncountryChanged: (number) {
                context.read<SetCountryCubit>().reset();
                _receiverPhoneController.clear();

                context.read<SetCountryCubit>().setCountry(
                      dialCode: number.dialCode,
                      countryCode: number.code,
                    );
              },
              hintText: "Phone no".translate(context),
              validator: (phoneNumber) {
                if (phoneNumber == null || phoneNumber.number.isEmpty) {
                  return "Please enter receiver phone number"
                      .translate(context);
                }
                int expectedLength =
                    phoneLengths[phoneNumber.countryISOCode] ?? 10;
                if (phoneNumber.number.length != expectedLength) {
                  return "${"Phone number must be".translate(context)} $expectedLength ${"digits".translate(context)}";
                }
                return null;
              },
            );
          },
        ),
      ],
    );
  }

  // ==================== Pickup instructions ====================
  Widget _buildPickupInstructions(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader(
          icon: Icons.notes_outlined,
          title: "Pickup Notes".translate(context),
        ),
        const SizedBox(height: 12),
        _buildModernInput(
          controller: _pickupInstructionsController,
          focusNode: _pickupFocus,
          hint: "e.g., Call before arriving, Leave at door".translate(context),
          prefixIcon: Icons.note_alt_outlined,
          maxLines: 2,
          minHeight: 76,
        ),
        const SizedBox(height: 6),
        Padding(
          padding: const EdgeInsetsDirectional.only(start: 2),
          child: Text(
            "${"Optional".translate(context)} • ${"Help the driver with pickup".translate(context)}",
            style:  TextStyle(
              fontSize: 10.5,
              color: mutedText,
            ),
          ),
        ),
      ],
    );
  }

  // ==================== Reusable modern input shell ====================
  Widget _buildModernInput({
    required TextEditingController controller,
    required FocusNode focusNode,
    String? hint,
    IconData? prefixIcon,
    TextInputType? keyboardType,
    String? suffix,
    int maxLines = 1,
    double? minHeight,
  }) {
    final bool isFocused = focusNode.hasFocus;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      curve: Curves.easeOut,
      constraints: minHeight != null
          ? BoxConstraints(minHeight: minHeight)
          : const BoxConstraints(minHeight: 52),
      decoration: BoxDecoration(
        color: isFocused ? themeColor.withOpacity(0.06) : fieldFill,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isFocused ? themeColor : borderNeutral,
          width: isFocused ? 1.4 : 1,
        ),
      ),
      child: TextField(
        controller: controller,
        focusNode: focusNode,
        keyboardType: keyboardType,
        textInputAction: TextInputAction.done,
        maxLines: maxLines,
        style:  TextStyle(
          fontSize: 13.5,
          color: darkText,
          fontWeight: FontWeight.w500,
        ),
        decoration: InputDecoration(
          border: InputBorder.none,
          isDense: true,
          contentPadding: EdgeInsets.symmetric(
            horizontal: 14,
            vertical: maxLines > 1 ? 14 : 15,
          ),
          hintText: hint,
          hintStyle: const TextStyle(
            color: Color(0xFFA7AEC1),
            fontSize: 12.5,
          ),
          suffixText: suffix,
          suffixStyle: TextStyle(
            color: themeColor.computeLuminance() > 0.6
                ? const Color(0xFF8A6D00)
                : themeColor,
            fontSize: 12,
            fontWeight: FontWeight.w700,
          ),
          prefixIcon: prefixIcon != null
              ? Padding(
                  padding: const EdgeInsetsDirectional.only(start: 10, end: 4),
                  child: Icon(prefixIcon,
                      color: isFocused ? themeColor : mutedText, size: 18),
                )
              : null,
          prefixIconConstraints:
              const BoxConstraints(minWidth: 36, minHeight: 36),
        ),
      ),
    );
  }

  // ==================== Bottom action ====================
  Widget _buildBottomAction(BuildContext context) {
    return SafeArea(
      top: false,
      minimum: const EdgeInsets.fromLTRB(20, 8, 20, 12),
      child: Material(
        color: themeColor,
        borderRadius: BorderRadius.circular(16),
        elevation: 3,
        shadowColor: themeColor.withOpacity(0.4),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: _validateAndProceed,
          child: Container(
            height: 54,
            alignment: Alignment.center,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Proceed to Location".translate(context),
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(width: 8),
                const _DirectionalIcon(
                  icon: Icons.arrow_forward_rounded,
                  size: 18,
                  color: Colors.black87,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Mirrors fixed-direction arrow icons (back/forward) for RTL locales,
/// since Flutter does not auto-flip glyphs like [Icons.arrow_back_ios_new].
class _DirectionalIcon extends StatelessWidget {
  final IconData icon;
  final double size;
  final Color color;

  const _DirectionalIcon({
    required this.icon,
    required this.size,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final isRtl = Directionality.of(context) == TextDirection.rtl;
    final child = Icon(icon, size: size, color: color);
    if (!isRtl) return child;
    return Transform.flip(flipX: true, child: child);
  }
}
