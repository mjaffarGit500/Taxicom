class PaymentGatewaysResponse {
  int? status;
  String? message;
  List<PaymentGateway>? data;
  String? error;

  PaymentGatewaysResponse({
    this.status,
    this.message,
    this.data,
    this.error,
  });

  factory PaymentGatewaysResponse.fromJson(Map<String, dynamic> json) {
    return PaymentGatewaysResponse(
      status: json['status'] is int
          ? json['status']
          : int.tryParse(json['status']?.toString() ?? ''),
      message: json['message']?.toString(),
      data: json['data'] != null
          ? (json['data'] as List)
              .map((e) => PaymentGateway.fromJson(
                    e as Map<String, dynamic>,
                  ))
              .toList()
          : [],
      error: json['error']?.toString(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'status': status,
      'message': message,
      'data': data?.map((e) => e.toJson()).toList() ?? [],
      'error': error,
    };
  }
}

class PaymentGateway {
  String? name;
  String? method;
  String? displayName;
  String? logo;
  String? publicKey;
  String? paymentUrl;

  PaymentGateway({
    this.name,
    this.method,
    this.displayName,
    this.logo,
    this.publicKey,
    this.paymentUrl,
  });

  factory PaymentGateway.fromJson(Map<String, dynamic> json) {
    return PaymentGateway(
      name: json['name']?.toString(),
      method: json['method']?.toString(),
      displayName: json['display_name']?.toString(),
      logo: json['logo']?.toString(),
      publicKey: json['public_key']?.toString(),
      paymentUrl: json['payment_url']?.toString()
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'method': method,
      'display_name': displayName,
      'logo': logo,
      'public_key': publicKey,
      'payment_url': paymentUrl,
    };
  }
}