import 'package:flutter/material.dart';
import '../../core/extensions/workspace.dart';
import '../../core/services/config.dart';
import '../../core/services/http.dart';

class ProfileRepository {
  Future<Map<String, dynamic>> editProfile(
      {required Map<String, dynamic> postData}) async {
    try {
      var response = await httpPost(Config.editProfile, postData,
          context: navigatorKey.currentContext!);
      return response;
    } catch (e) {
      rethrow;
    }
  }

  Future<Map<String, dynamic>> deleteAccount() async {
    try {
      var response = await httpPost(Config.deleteAccount, {},
          context: navigatorKey.currentState!.context);
      return response;
    } catch (e) {
      rethrow;
    }
  }

  Future<Map<String, dynamic>> uploadProfileImage(
      {required Map<String, dynamic> postData}) async {
    try {
      var response = await httpPost(Config.uploadProfileImage, postData,
          context: navigatorKey.currentContext!);
      return response;
    } catch (e) {
      rethrow;
    }
  }

   Future<Map<String, dynamic>> getStaticPage(
      BuildContext context, String id) async {
    try {
      var response = await httpGet(Config.staticPage, {"id": id},
          context: navigatorKey.currentContext!);

      return response;
    } catch (e) {
      rethrow;
    }
  }
 Future<Map<String, dynamic>> getSosData(
      {required Map<String, dynamic> postData}) async {
    try {
      var response = await httpGet(Config.sos, postData,
          context: navigatorKey.currentContext!);
      return response;
    } catch (e) {
      rethrow;
    }
  }
  Future<Map<String, dynamic>> getGeneralData(
      {required Map<String, dynamic> postData}) async {

    try {
      var response = await httpGet(Config.getgeneralSettings, postData,
          context: navigatorKey.currentContext!);
      return response;
    } catch (e) {
      rethrow;
    }
  }
}
