import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:ride_on_driver/core/services/data_store.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import 'package:ride_on_driver/presentation/widgets/thanku_screen.dart';
import '../../core/utils/common_widget.dart';
import '../../core/utils/theme/project_color.dart';
import '../../core/utils/theme/theme_style.dart';
import '../../domain/entities/realtime_ride_request.dart';
import '../cubits/location/get_polyline_cubit.dart';
import '../cubits/location/location_cubit.dart';
import '../cubits/realtime/listen_ride_request_cubit.dart';
import '../cubits/realtime/manage_driver_cubit.dart';
import '../cubits/realtime/ride_status_cubit.dart';
import '../cubits/review/review_cubit.dart';
import '../screens/bottom_bar/home_main.dart';
import 'custom_text_form_field.dart';
import 'primary_button.dart';

class CustomReviewWidget extends StatefulWidget {
  final RealTimeRideRequest rideRequest;
  const CustomReviewWidget({super.key, required this.rideRequest});
  @override
  State<CustomReviewWidget> createState() => _CustomReviewWidgetState();
}

class _CustomReviewWidgetState extends State<CustomReviewWidget> {
  @override
  void initState() {
    super.initState();
  }

  String ratingData = "";

  TextEditingController textEditingReviewController = TextEditingController();
  static const List<String> _ratingLabels = [
    "",
    "Poor",
    "Fair",
    "Good",
    "Great",
    "Excellent",
  ];

  @override
  Widget build(BuildContext context) {
    final int currentRating = ratingData.isEmpty ? 0 : int.parse(ratingData);
    return PopScope(
      canPop: false,
      child: DraggableScrollableSheet(
        initialChildSize: 0.82,
        minChildSize: 0.82,
        maxChildSize: 0.82,
        builder: (context, scrollController) {
          return Container(
            decoration: BoxDecoration(
              color: notifires.getbgcolor,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(Dimensions.radiusSheet),
                topRight: Radius.circular(Dimensions.radiusSheet),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.12),
                  blurRadius: 20,
                  offset: const Offset(0, -4),
                ),
              ],
            ),
            padding: const EdgeInsets.fromLTRB(
              Dimensions.space20,
              Dimensions.space12,
              Dimensions.space20,
              Dimensions.space20,
            ),
            child: ListView(
              controller: scrollController,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: appBorderColor,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ),
                const SizedBox(height: Dimensions.space16),
                Align(
                  alignment: Alignment.centerRight,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(10),
                    onTap: () {
                      goToWithClear(const HomeMain(initialIndex: 0));
                      clearDriverData(context);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: Dimensions.space12, vertical: 6),
                      decoration: BoxDecoration(
                        color: notifires.getBoxColor,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        "Skip".translate(context),
                        style: captionText(context).copyWith(
                            fontFamily: "Poppins SemiBold",
                            fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: Dimensions.space16),
                Center(
                  child: Container(
                    width: 84,
                    height: 84,
                    padding: const EdgeInsets.all(3),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                          color: themeColor.withValues(alpha: 0.5), width: 2),
                    ),
                    child: ClipOval(
                      child: myNetworkImage(
                          widget.rideRequest.customer?.userPhoto ?? ""),
                    ),
                  ),
                ),
                const SizedBox(height: Dimensions.space12),
                Text(
                  widget.rideRequest.customer?.userName ?? "",
                  textAlign: TextAlign.center,
                  style: sectionTitleStyle(context),
                ),
                const SizedBox(height: Dimensions.space4),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.cable_rounded, color: greentext, size: 16),
                    const SizedBox(width: Dimensions.space4),
                    Text(widget.rideRequest.rideId ?? "",
                        style: captionText(context)),
                  ],
                ),
                const SizedBox(height: Dimensions.space24),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      vertical: Dimensions.space20,
                      horizontal: Dimensions.space16),
                  decoration: BoxDecoration(
                    color: notifires.getBoxColor,
                    borderRadius: BorderRadius.circular(Dimensions.radiusCard),
                  ),
                  child: Column(
                    children: [
                      Text("How was the rider?".translate(context),
                          style: bodyText(context).copyWith(
                              fontFamily: "Poppins SemiBold",
                              fontWeight: FontWeight.w600)),
                      const SizedBox(height: Dimensions.space16),
                      RatingBar.builder(
                        initialRating: 0,
                        minRating: 1,
                        glow: false,
                        direction: Axis.horizontal,
                        allowHalfRating: false,
                        itemCount: 5,
                        itemSize: 34,
                        itemPadding:
                            const EdgeInsets.symmetric(horizontal: 4.0),
                        itemBuilder: (context, _) =>
                            Icon(Icons.star_rounded, color: yelloColor),
                        onRatingUpdate: (rating) {
                          setState(() {
                            ratingData = rating.toInt().toString();
                          });
                        },
                      ),
                      if (currentRating > 0) ...[
                        const SizedBox(height: Dimensions.space8),
                        Text(
                          _ratingLabels[currentRating].translate(context),
                          style: linkTextStyle(context),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: Dimensions.space24),
                Text("Add a comment".translate(context),
                    style: inputLabelStyle(context)),
                const SizedBox(height: Dimensions.space8),
                TextFieldAdvance(
                    maxlines: 5,
                    backgroundColor: notifires.getBoxColor,
                    txt: "Add a comment for the rider ...".translate(context),
                    textEditingControllerCommon: textEditingReviewController,
                    inputType: TextInputType.text,
                    textInputAction: TextInputAction.done,
                    inputAlignment: TextAlign.start),
                const SizedBox(height: Dimensions.space24),
                BlocConsumer<ReviewCubit, ReviewState>(
                    builder: (context, state) {
                  return PrimaryButton(
                    text: "Submit".translate(context),
                    backgroundColor: ratingData.isEmpty ? grey4 : themeColor,
                    textColor: ratingData.isEmpty ? grey2 : blackColor,
                    onPressed: () {
                      if (ratingData.isEmpty) {
                        return;
                      }
                      context.read<ReviewCubit>().submitReview(
                          message: textEditingReviewController.text,
                          context: context,
                          bookingId: context
                                  .read<UpdateDriverParameterCubit>()
                                  .state
                                  .bookingId
                                  .isEmpty
                              ? widget.rideRequest.bookingId ?? ""
                              : context
                                  .read<UpdateDriverParameterCubit>()
                                  .state
                                  .bookingId,
                          rating: ratingData);
                    },
                  );
                }, listener: (context, state) {
                  if (state is ReviewLoading) {
                    Widgets.showLoader(context);
                  }

                  if (state is ReviewSuceess) {
                    Widgets.hideLoder(context);
                    context
                        .read<UpdateDriverParameterCubit>()
                        .removeBookingId(bookingId: "");
                    clearDriverData(context);

                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ThankuScreen(
                                  rating: int.parse(ratingData),
                                  msg: textEditingReviewController.text,
                                )));
                  }
                  if (state is ReviewFailure) {
                    Widgets.hideLoder(context);
                  }
                }),
                const SizedBox(height: Dimensions.space40),
              ],
            ),
          );
        },
      ),
    );
  }
}

void clearDriverData(BuildContext context) {
  box.delete("ride_id");
  context.read<UpdateDriverParameterCubit>().removeDriverDropOffLatAndLng();
  context.read<UpdateDriverParameterCubit>().removeDriverPickupLatAndLng();
  context.read<UpdateDriverParameterCubit>().removeRideId();
  context.read<ListenRideRequestCubit>().resetListenRideRequest();
  context.read<MarkerCubit>().removeMarker();
  context.read<RideStatusCubit>().resetAllParameters();
  context.read<UpdateRideRequestCubit>().resetRideRequestState();
  context.read<UpdateBookingIdCubit>().resetState();
  context.read<GetRideDataCubit>().clear();
  context.read<GetPolylineCubit>().resetPolylines();
}
