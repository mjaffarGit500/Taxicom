import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on_driver/core/utils/theme/project_color.dart';
import 'package:ride_on_driver/core/utils/theme/theme_style.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import 'package:ride_on_driver/domain/entities/sos_data.dart';
import 'package:ride_on_driver/presentation/cubits/sos_cubit.dart';
import 'package:url_launcher/url_launcher.dart';

class SosButtonWidget extends StatefulWidget {
  const SosButtonWidget({super.key});

  @override
  State<SosButtonWidget> createState() => _SosButtonWidgetState();
}

class _SosButtonWidgetState extends State<SosButtonWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);

    _animation = Tween<double>(begin: 1.0, end: 1.25).animate(
      CurvedAnimation(parent: _controller, curve: Curves.fastOutSlowIn),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _makePhoneCall(String number) async {
    final Uri launchUri = Uri(scheme: 'tel', path: number);
    await launchUrl(launchUri);
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Padding(
          padding: const EdgeInsets.only(right: 18, bottom: 18, left: 15),
          child: ScaleTransition(
            scale: _animation,
            child: GestureDetector(
              onTap: () {
                context.read<SosCubit>().getSosList(context);
                _showSosDialog(context);
              },
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xffFF3B30), Color(0xffFF5E57)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.redAccent.withValues(alpha: .50),
                      blurRadius: 25,
                      spreadRadius: 3,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.sos_rounded,
                  color: Colors.white,
                  size: 20,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _showSosDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) {
        final size = MediaQuery.of(context).size;
        final isSmallPhone = size.height < 700 || size.width < 360;

        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: EdgeInsets.symmetric(
            horizontal: isSmallPhone ? 14 : 20,
            vertical: isSmallPhone ? 14 : 24,
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(isSmallPhone ? 24 : 30),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
              child: ConstrainedBox(
                constraints: BoxConstraints(maxHeight: size.height * 0.86),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: .85),
                    borderRadius: BorderRadius.circular(isSmallPhone ? 24 : 30),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black.withValues(alpha: .2),
                          blurRadius: 20)
                    ],
                  ),
                  padding: EdgeInsets.symmetric(
                    horizontal: isSmallPhone ? 14 : 22,
                    vertical: isSmallPhone ? 16 : 28,
                  ),
                  child: BlocBuilder<SosCubit, SosState>(
                    builder: (context, state) {
                      if (state is SosLoading) {
                        return SizedBox(
                          height: 200,
                          child: Center(
                            child: CircularProgressIndicator(
                              color: Colors.redAccent.shade200,
                            ),
                          ),
                        );
                      }

                      if (state is SosFailed) {
                        return _errorDialog(context, state.error);
                      }

                      List<Sos> sosList = [];
                      if (state is SosSuccess) {
                        sosList = state.sosData.sos ?? [];
                      }

                      return SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              padding: EdgeInsets.all(isSmallPhone ? 10 : 12),
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: LinearGradient(
                                  colors: [
                                    Color(0xffFF3B30),
                                    Color(0xffFF6B6B)
                                  ],
                                ),
                              ),
                              child: Icon(
                                Icons.sos_rounded,
                                size: isSmallPhone ? 44 : 55,
                                color: Colors.white,
                              ),
                            ),
                            SizedBox(height: isSmallPhone ? 12 : 16),
                            Text(
                              "Emergency Support".translate(context),
                              textAlign: TextAlign.center,
                              style: heading1Grey1(context).copyWith(
                                color: redColor,
                                fontSize: isSmallPhone ? 30 : null,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              "Choose a contact to call instantly"
                                  .translate(context),
                              textAlign: TextAlign.center,
                              style: regular2(context).copyWith(
                                fontSize: isSmallPhone ? 13 : null,
                              ),
                            ),
                            SizedBox(height: isSmallPhone ? 14 : 22),
                            if (sosList.isEmpty)
                              Text(
                                "No SOS contacts available!".translate(context),
                                style: regular2(context),
                                textAlign: TextAlign.center,
                              )
                            else
                              Column(
                                children: sosList.map((e) {
                                  return _modernSosCard(
                                    name: e.name ?? "Unknown",
                                    number: e.sosNumber ?? "",
                                    compact: isSmallPhone,
                                    onCall: () {
                                      Navigator.pop(context);
                                      _makePhoneCall(e.sosNumber ?? "");
                                    },
                                  );
                                }).toList(),
                              ),
                            SizedBox(height: isSmallPhone ? 10 : 20),
                            _cancelButton(context, compact: isSmallPhone),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _errorDialog(BuildContext context, String msg) {
    return SizedBox(
      height: 200,
      child: Center(
        child: Text(
          msg,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
        ),
      ),
    );
  }

  Widget _modernSosCard({
    required String name,
    required String number,
    required bool compact,
    required VoidCallback onCall,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: compact ? 10 : 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: whiteColor,
        boxShadow: [
          BoxShadow(
            color: blackColor.withValues(alpha: .07),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onCall,
        child: Padding(
          padding: EdgeInsets.all(compact ? 12 : 16),
          child: Row(
            children: [
              Container(
                padding: EdgeInsets.all(compact ? 10 : 13),
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [Color(0xffFF5A5A), Color(0xffFF7E7E)],
                  ),
                ),
                child: Icon(Icons.call,
                    color: whiteColor, size: compact ? 20 : 24),
              ),
              SizedBox(width: compact ? 10 : 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: heading3(context).copyWith(
                        color: blackColor,
                        fontSize: compact ? 18 : null,
                      ),
                    ),
                    SizedBox(height: compact ? 2 : 4),
                    Text(
                      number,
                      style: regular(context)
                          .copyWith(fontSize: compact ? 15 : null),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.arrow_forward_ios_rounded,
                size: compact ? 14 : 16,
                color: blackColor,
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _cancelButton(BuildContext context, {required bool compact}) {
    return TextButton(
      onPressed: () => Navigator.pop(context),
      style: TextButton.styleFrom(
        backgroundColor: Colors.grey.shade300,
        padding: EdgeInsets.symmetric(
          horizontal: compact ? 26 : 40,
          vertical: compact ? 10 : 12,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
      child: Text(
        "Close".translate(context),
        style: heading3(context).copyWith(fontSize: compact ? 18 : null),
      ),
    );
  }
}
