import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/utils/theme/project_color.dart';
import '../../core/utils/theme/theme_style.dart';
import '../../core/utils/translate.dart';

/// Shared premium primary action button used across the redesigned
/// Login / Signup / OTP / Driver-Setup / Document-Upload screens.
///
/// Mirrors [CustomsButtons]' contract (text, onPressed, optional
/// backgroundColor/textColor) so existing call sites can swap in this
/// widget without touching the surrounding logic. Loading state is driven
/// externally via [isLoading] (kept separate from the app's global
/// Widgets.showLoader overlay, which screens may keep using instead).
class PrimaryButton extends StatefulWidget {
  final String text;
  final VoidCallback? onPressed;
  final Color? backgroundColor;
  final Color? textColor;
  final double? width;
  final double? height;
  final bool isLoading;
  final IconData? icon;

  const PrimaryButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.backgroundColor,
    this.textColor,
    this.width,
    this.height,
    this.isLoading = false,
    this.icon,
  });

  @override
  State<PrimaryButton> createState() => _PrimaryButtonState();
}

class _PrimaryButtonState extends State<PrimaryButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    notifires = Provider.of<ColorNotifires>(context, listen: true);
    final bool disabled = widget.onPressed == null || widget.isLoading;
    final Color baseColor = widget.backgroundColor ?? themeColor;
    final Color effectiveColor = disabled
        ? baseColor.withValues(alpha: 0.45)
        : (_pressed ? Color.lerp(baseColor, blackColor, 0.12)! : baseColor);

    return GestureDetector(
      onTapDown: disabled ? null : (_) => setState(() => _pressed = true),
      onTapCancel: disabled ? null : () => setState(() => _pressed = false),
      onTapUp: disabled ? null : (_) => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        width: widget.width ?? double.infinity,
        height: widget.height ?? Dimensions.buttonHeight,
        decoration: BoxDecoration(
          color: effectiveColor,
          borderRadius: BorderRadius.circular(Dimensions.radiusButton),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(Dimensions.radiusButton),
            onTap: disabled ? null : widget.onPressed,
            child: Center(
              child: widget.isLoading
                  ? SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.4,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          widget.textColor ?? blackColor,
                        ),
                      ),
                    )
                  : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (widget.icon != null) ...[
                          Icon(widget.icon, size: 20, color: widget.textColor ?? blackColor),
                          const SizedBox(width: 8),
                        ],
                        Text(
                          widget.text.translate(context),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 1,
                          style: buttonTextStyle.copyWith(
                            color: widget.textColor ?? blackColor,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }
}
