import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on_driver/core/extensions/workspace.dart';
import 'package:ride_on_driver/core/utils/translate.dart';

import '../../core/utils/common_widget.dart';
import '../../core/utils/theme/project_color.dart';
import '../../core/utils/theme/theme_style.dart';
import '../cubits/register_vehicle/make_model_cubit.dart';

class CustomDropdownList extends StatefulWidget {
  final List options;
  final String hintText;
  final Function(String) onSelected;
  final Function(String) onSelectedValue;
  final Function(String) onSelectedImageUrl;
  final Color checkmarkColor;
  final String? heading;
  final dynamic selectedEditInitialValue;
  final bool? removeAll;
  final bool? clearDataonVehgicletype;
  final bool? checkMake;
  final bool? checkModel;
  final bool? checkImage;
  final bool? cumpulsoryIcon;

  const CustomDropdownList({
    super.key,
    this.cumpulsoryIcon = false,
    this.heading,
    required this.options,
    required this.onSelectedImageUrl,
    this.checkModel = false,
    this.checkImage = false,
    this.checkMake = false,
    required this.onSelectedValue,
    required this.onSelected,
    required this.checkmarkColor,
    this.hintText = 'Select One',
    this.selectedEditInitialValue,
    this.removeAll,
    this.clearDataonVehgicletype,
  });

  @override
  CustomDropdownListState createState() => CustomDropdownListState();
}

class CustomDropdownListState extends State<CustomDropdownList> {
  String? selectedValue;
  int? selectedId;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (widget.checkMake == true) {

        syncInitialValueForMake();
      } else {
        syncInitialValue();
      }
    });
  }

  void syncInitialValue() {
    if (widget.clearDataonVehgicletype == true ||
        widget.selectedEditInitialValue == null ||
        widget.selectedEditInitialValue.toString().isEmpty) {
      if (selectedValue != null || selectedId != null) {
        setState(() {
          selectedValue = null;
          selectedId = null;
        });
      }
      return;
    }

    final matched = widget.options.firstWhereOrNull(
          (item) =>
      item.id.toString() == widget.selectedEditInitialValue.toString(),
    );

    if (matched != null &&
        (matched.id != selectedId || matched.name != selectedValue)) {
      setState(() {
        selectedValue = matched.name;
        selectedId = matched.id;
      });
    }
  }

  void syncInitialValueForMake() {

    if (widget.clearDataonVehgicletype == true ||
        widget.selectedEditInitialValue == null ||
        widget.selectedEditInitialValue.toString().isEmpty) {
      if (selectedValue != null || selectedId != null) {


        setState(() {
          selectedValue = null;
          selectedId = null;
        });
      }
      return;
    }

    final matched = widget.options.firstWhereOrNull(
          (item) =>
      item.id.toString() == widget.selectedEditInitialValue.toString(),
    );


    if (matched != null &&
        (matched.id != selectedId || matched.name != selectedValue)) {
      setState(() {
        selectedValue = matched.name;
        selectedId = matched.id;
      });

    }
  }

  void _openBottomSheet(BuildContext context) {
    showModalBottomSheet(
      backgroundColor: whiteColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
            top: Radius.circular(Dimensions.radiusSheet)),
      ),
      context: context,
      builder: (BuildContext context) {
        List<dynamic> filteredOptions = List.from(widget.options);

        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: Dimensions.space12),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: appBorderColor,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: Dimensions.space20, vertical: Dimensions.space16),
              child: Row(
                children: [
                  Text(
                    "${"Select".translate(context)} ${widget.hintText.translate(context)}".translate(context),
                    style: sectionTitleStyle(context),
                  ),
                  const Spacer(),
                  InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    borderRadius: BorderRadius.circular(20),
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: notifires.getBoxColor,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        Icons.close,
                        size: 18,
                        color: notifires.getwhiteblackColor,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            filteredOptions.isEmpty
                ? SizedBox(
                    height: 350,
                    child: Center(
                      child: Text(
                        "No data available".translate(context),
                        style: bodyText(context),
                      ),
                    ),
                  )
                : Flexible(
              child: ListView.separated(
                shrinkWrap: true,
                itemCount: filteredOptions.length,
                itemBuilder: (BuildContext context, int index) {
                  bool isSelected = filteredOptions[index].id == selectedId;

                  return ListTile(
                    title: Text(
                      filteredOptions[index].name ?? "select one".translate(context),
                      style: bodyText(context).copyWith(
                        fontFamily: isSelected ? "Poppins SemiBold" : null,
                        fontWeight: isSelected ? FontWeight.w600 : null,
                      ),
                    ),
                    trailing: isSelected
                        ? Icon(Icons.check_circle, color: widget.checkmarkColor)
                        : null,
                    onTap: () {
                      setState(() {
                        selectedId = filteredOptions[index].id;
                        selectedValue = filteredOptions[index].name;
                      });
                      if (widget.checkMake == true) {
                        widget.onSelected(
                            filteredOptions[index].id.toString());
                      } else {
                        widget
                            .onSelected(filteredOptions[index].id.toString());
                      }
                      widget.onSelectedValue(
                          filteredOptions[index].name.toString());
                      if (widget.checkImage == true) {
                        if (filteredOptions[index]
                            .image
                            .toString()
                            .isNotEmpty) {
                          widget.onSelectedImageUrl(
                              filteredOptions[index].image.toString());
                        }
                      }

                      if (widget.checkModel == true) {
                        context
                            .read<SelectedCubit>()
                            .updateSelectedValue(false);
                      }

                      Navigator.pop(context);
                    },
                  );
                },
                separatorBuilder: (BuildContext context, int index) =>
                    Divider(height: 1, color: appBorderColor),
              ),
            ),
            const SizedBox(height: Dimensions.space16),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MakeModelCubit, MakeModelState>(
      builder: (context,makeState) {

        if (makeState is MakeModelLoading&& widget.checkMake==true) {
          return   LoadingDropdownBox(
            loadingText: "Fetching vehicle make...".translate(context),
          );
        }
        return GestureDetector(
          onTap: () {
            if (widget.checkMake == true) {

              if(context.read<VehicleFormCubit>().state.vehicleTypeId.isEmpty){
                showErrorToastMessage("Please select first vehicle type");
                return;
              }
              context.read<SelectedCubit>().updateSelectedValue(true);
            }

            _openBottomSheet(context);
          },
          child: Container(
            height: Dimensions.compactFieldHeight,
            padding:
                const EdgeInsets.symmetric(horizontal: Dimensions.space16),
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(Dimensions.radiusField),
              border: Border.all(color: appBorderColor),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.03),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                widget.checkModel == true
                    ? Expanded(
                  child: BlocBuilder<SelectedCubit, bool>(
                    builder: (context, value) {
                      final String displayText = value
                          ? widget.hintText
                          : selectedValue ?? widget.hintText;
                      final bool isPlaceholder =
                          displayText == widget.hintText;
                      return RichText(
                          text: TextSpan(
                              text: displayText.translate(context),
                              style: inputTextStyle(context).copyWith(
                                color: isPlaceholder
                                    ? notifires.getGrey3whiteColor
                                    : null,
                              ),
                              children: [
                                widget.cumpulsoryIcon == true
                                    ? TextSpan(
                                    text: "  *",
                                    style: TextStyle(color: appErrorColor))
                                    : const TextSpan()
                              ]));
                    },
                  ),
                )
                    : Expanded(
                  child: RichText(
                      text: TextSpan(
                          text: (selectedValue ?? widget.hintText)
                              .translate(context),
                          style: inputTextStyle(context).copyWith(
                              overflow: TextOverflow.ellipsis,
                              color: selectedValue == null
                                  ? notifires.getGrey3whiteColor
                                  : null),
                          children: [
                            widget.cumpulsoryIcon == true
                                ? TextSpan(
                                text: "  *",
                                style: TextStyle(color: appErrorColor))
                                : const TextSpan()
                          ])),
                ),
                Icon(
                  Icons.keyboard_arrow_down_rounded,
                  color: notifires.getGrey3whiteColor,
                ),
              ],
            ),
          ),
        );
      }
    );
  }
}

class CustomDropdown extends StatefulWidget {
  final List options;
  final String hintText;
  final String? prefixIconImage;
  final Function(String) onSelected;
  final Color checkmarkColor;
  final String? heading;
  final String? selectedEditInitialValue;
  final bool? removeAll;
  final bool? clearDataonVehgicletype;
  final TextStyle? textStyle;
  final Color? prefixIconColor;

  const CustomDropdown({
    super.key,
    this.heading,
    this.prefixIconColor,
    this.textStyle,
    this.prefixIconImage,
    required this.options,
    required this.onSelected,
    required this.checkmarkColor,
    this.hintText = 'Select One',
    this.selectedEditInitialValue,
    this.removeAll,
    this.clearDataonVehgicletype,
  });

  @override
  CustomDropdownState createState() => CustomDropdownState();
}

class CustomDropdownState extends State<CustomDropdown> {
  String? selectedValue;
  int? selectedId;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (widget.selectedEditInitialValue != null) {
        setState(() {
          selectedValue = widget.selectedEditInitialValue;
        });
      }
    });
  }


  void _openBottomSheet(BuildContext context) {
    showModalBottomSheet(
      backgroundColor: whiteColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
            top: Radius.circular(Dimensions.radiusSheet)),
      ),
      context: context,
      builder: (BuildContext context) {
        List<dynamic> filteredOptions = List.from(widget.options);

        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: Dimensions.space12),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: appBorderColor,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: Dimensions.space20, vertical: Dimensions.space16),
              child: Row(
                children: [
                  Text(
                    "${"Select".translate(context)} ${widget.hintText.translate(context)}".translate(context),
                    style: sectionTitleStyle(context),
                  ),
                  const Spacer(),
                  InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    borderRadius: BorderRadius.circular(20),
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: notifires.getBoxColor,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        Icons.close,
                        size: 18,
                        color: notifires.getwhiteblackColor,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Flexible(
              child: ListView.separated(
                shrinkWrap: true,
                itemCount: filteredOptions.length,
                itemBuilder: (BuildContext context, int index) {
                  bool isSelected = filteredOptions[index] == selectedValue;
                  return ListTile(
                    title: Text(
                      filteredOptions[index].toString().translate(context),
                      style: bodyText(context).copyWith(
                        fontFamily: isSelected ? "Poppins SemiBold" : null,
                        fontWeight: isSelected ? FontWeight.w600 : null,
                      ),
                    ),
                    trailing: isSelected
                        ? Icon(Icons.check_circle,
                            color: widget.checkmarkColor)
                        : null,
                    onTap: () {
                      setState(() {
                        selectedValue = filteredOptions[index];
                      });
                      widget.onSelected(filteredOptions[index].toString());
                      Navigator.pop(context);
                    },
                  );
                },
                separatorBuilder: (BuildContext context, int index) =>
                    Divider(height: 1, color: appBorderColor),
              ),
            ),
            const SizedBox(height: Dimensions.space16),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        _openBottomSheet(context);
      },
      child: Container(
        height: Dimensions.compactFieldHeight,
        padding: const EdgeInsets.symmetric(horizontal: Dimensions.space16),
        decoration: BoxDecoration(
          color: whiteColor,
          borderRadius: BorderRadius.circular(Dimensions.radiusField),
          border: Border.all(color: appBorderColor),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Row(
                children: [
                  widget.prefixIconImage != null &&
                      widget.prefixIconImage!.isNotEmpty
                      ? Image.asset(
                    "${widget.prefixIconImage}",
                    height: 18,
                    color: widget.prefixIconColor ?? notifires.getGrey3whiteColor,
                  )
                      : const SizedBox(),
                  SizedBox(
                      width: widget.prefixIconImage != null &&
                              widget.prefixIconImage!.isNotEmpty
                          ? 10
                          : 0),
                  Expanded(
                    child: Text(
                      (selectedValue == null || selectedValue!.isEmpty)
                          ? widget.hintText.translate(context)
                          : selectedValue.toString().translate(context),
                      style: (widget.textStyle ?? inputTextStyle(context))
                          .copyWith(
                        color: (selectedValue == null || selectedValue!.isEmpty)
                            ? notifires.getGrey3whiteColor
                            : null,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.keyboard_arrow_down_rounded,
              color: notifires.getGrey3whiteColor,
            ),
          ],
        ),
      ),
    );
  }
}
class LoadingDropdownBox extends StatelessWidget {
  final String loadingText;

  const LoadingDropdownBox({
    super.key,
    this.loadingText = "Loading...",
  });

  @override
  Widget build(BuildContext context) {
    return IgnorePointer( // disables tap
      ignoring: true,
      child: Container(
        height: Dimensions.compactFieldHeight,
        padding: const EdgeInsets.symmetric(horizontal: Dimensions.space16),
        decoration: BoxDecoration(
          color: whiteColor,
          borderRadius: BorderRadius.circular(Dimensions.radiusField),
          border: Border.all(color: appBorderColor),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(
                loadingText,
                style: inputHintStyle(context),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Icon(
              Icons.keyboard_arrow_down_rounded,
              color: notifires.getGrey3whiteColor,
            ),
          ],
        ),
      ),
    );
  }
}
