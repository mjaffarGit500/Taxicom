import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on_driver/core/extensions/workspace.dart';
import 'package:ride_on_driver/core/services/data_store.dart';
import 'package:ride_on_driver/core/utils/common_widget.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import 'package:ride_on_driver/core/utils/theme/project_color.dart';
import 'package:ride_on_driver/presentation/cubits/general_cubit.dart';
import 'package:ride_on_driver/presentation/cubits/localizations_cubit.dart';
import 'package:ride_on_driver/presentation/screens/onboarding/on_boarding_screen.dart';

class SelectLanguageScreen extends StatefulWidget {
  final bool isBack;

  const SelectLanguageScreen({
    required this.isBack,
    super.key,
  });

  @override
  State<SelectLanguageScreen> createState() => _SelectLanguageScreenState();
}

class _SelectLanguageScreenState extends State<SelectLanguageScreen>
    with SingleTickerProviderStateMixin {
  int _selectedValue = lanBox.get("lanValue") ?? -1;

  final List<Map<String, dynamic>> localeList = [
    {"name": "English", "locale": "en", "flag": "🇬🇧"},
    {"name": "French", "locale": "fr", "flag": "🇫🇷"},
    {"name": "العربية", "locale": "ar", "flag": "🇸🇦"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              themeColor.withValues(alpha: 0.06),
              themeColor.withValues(alpha: 0.12),
              Colors.white,
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 20, 24, 28),
            child: Column(
              children: [
                // Top spacer
                const Spacer(flex: 2),

                // Header
                Text(
                  "🌐 ${"Choose Your Language".translate(context)}",
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.4,
                    color: notifires.getwhiteblackColor,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                Text(
                  "Select your preferred language to continue"
                      .translate(context),
                  style: TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w400,
                    height: 1.4,
                    color: notifires.getwhiteblackColor.withValues(alpha: 0.55),
                  ),
                  textAlign: TextAlign.center,
                ),

                const SizedBox(height: 36),

                // Language options
                BlocBuilder<LanguageCubit, LanguageState>(
                  builder: (context, state) {
                    return Column(
                      children: List.generate(localeList.length, (index) {
                        final isSelected = _selectedValue == index;

                        return GestureDetector(
                          onTap: () {
                            context
                                .read<LanguageCubit>()
                                .changeLanguage(localeList[index]["locale"]);

                            globalLocalization = localeList[index]['locale'];

                            lanBox.put('lCode', localeList[index]['locale']);
                            lanBox.put("lanValue", index);

                            setState(() {
                              _selectedValue = index;
                            });

                            context
                                .read<LCodeCubit>()
                                .changeLanguage(localeList[index]['locale']);
                          },
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 250),
                            curve: Curves.easeOutCubic,
                            margin: const EdgeInsets.only(bottom: 12),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 14,
                            ),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? themeColor.withValues(alpha: 0.09)
                                  : Colors.white,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                color: isSelected
                                    ? themeColor.withValues(alpha: 0.7)
                                    : Colors.grey.shade200,
                                width: isSelected ? 1.6 : 1.2,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: isSelected
                                      ? themeColor.withValues(alpha: 0.12)
                                      : Colors.black.withValues(alpha: 0.04),
                                  blurRadius: isSelected ? 12 : 8,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Row(
                              children: [
                                // Flag
                                Text(
                                  localeList[index]['flag'],
                                  style: const TextStyle(fontSize: 22),
                                ),
                                const SizedBox(width: 14),

                                // Language name
                                Expanded(
                                  child: Text(
                                    localeList[index]['name'],
                                    style: TextStyle(
                                      fontSize: 15.5,
                                      fontWeight: isSelected
                                          ? FontWeight.w600
                                          : FontWeight.w500,
                                      letterSpacing: -0.2,
                                      color: notifires.getwhiteblackColor,
                                    ),
                                  ),
                                ),

                                // Selection indicator
                                AnimatedContainer(
                                  duration: const Duration(milliseconds: 200),
                                  width: 22,
                                  height: 22,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: isSelected
                                        ? themeColor
                                        : Colors.transparent,
                                    border: Border.all(
                                      color: isSelected
                                          ? themeColor
                                          : Colors.grey.shade300,
                                      width: 1.6,
                                    ),
                                  ),
                                  child: isSelected
                                      ? const Icon(
                                          Icons.check_rounded,
                                          size: 14,
                                          color: Colors.white,
                                        )
                                      : null,
                                ),
                              ],
                            ),
                          ),
                        );
                      }),
                    );
                  },
                ),

                const Spacer(flex: 3),

                // Continue Button
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: CustomsButtons(
                    text: "Continue",
                    backgroundColor: themeColor,
                    onPressed: () {
                      if (_selectedValue != -1) {
                        context
                            .read<GeneralCubit>()
                            .fetchGeneralSetting(context);

                        if (widget.isBack) {
                          goBack();
                        } else {
                          goToWithClear(const Onboardingscreen());
                        }
                      }
                    },
                  ),
                ),

                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
