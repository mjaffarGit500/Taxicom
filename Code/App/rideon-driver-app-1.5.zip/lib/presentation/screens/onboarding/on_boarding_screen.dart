import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../splash/allow_location_screen.dart';


const Color _premiumDeep = Color(0xff17140F);
  Color _premiumGold =themeColor;

class _OnboardingPageData {
  final String image;
  final String badge;
  final String titleKey;
  final String descriptionKey;
  final String benefitKey;

  const _OnboardingPageData({
    required this.image,
    required this.badge,
    required this.titleKey,
    required this.descriptionKey,
    required this.benefitKey,
  });
}

class Onboardingscreen extends StatefulWidget {
  const Onboardingscreen({super.key});
  @override
  State<Onboardingscreen> createState() => _OnboardingscreenState();
}

class _OnboardingscreenState extends State<Onboardingscreen> {
  final List<_OnboardingPageData> content = const [
    _OnboardingPageData(
      image: "assets/images/onBoarding1.png",
      badge: "driver_onboarding_step_1",
      titleKey: "register_vehicle",
      descriptionKey: "register_vehicle_description",
      benefitKey: "register_vehicle_benefit",
    ),
    _OnboardingPageData(
      image: "assets/images/onBoarding2.png",
      badge: "driver_onboarding_step_2",
      titleKey: "upload_documents",
      descriptionKey: "upload_documents_description",
      benefitKey: "upload_documents_benefit",
    ),
    _OnboardingPageData(
      image: "assets/images/onBoarding3.png",
      badge: "driver_onboarding_step_3",
      titleKey: "earn_money",
      descriptionKey: "earn_money_description",
      benefitKey: "earn_money_benefit",
    ),
  ];

  late PageController pageController;
  int currentIndex = 0;

  @override
  void initState() {
    super.initState();
    pageController = PageController(initialPage: 0);
  }

  @override
  void dispose() {
    pageController.dispose();
    super.dispose();
  }

  void _goToNextPage() {
    if (currentIndex < content.length - 1) {
      pageController.nextPage(
        duration: const Duration(milliseconds: 400),
        curve: Curves.fastLinearToSlowEaseIn,
      );
      return;
    }
    _goToAllowLocation();
  }

  void _goToAllowLocation() {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) =>
            const AllowLocationScreen(),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          var begin = const Offset(1.0, 0.0);
          var end = Offset.zero;
          var curve = Curves.ease;
          var tween =
              Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
          return SlideTransition(
              position: animation.drive(tween), child: child);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      backgroundColor: notifires.getbgcolor,
      body: LayoutBuilder(
        builder: (context, constraints) {
          final size = constraints.biggest;
          final double heightScale =
              (size.height / 812).clamp(0.76, 1.0).toDouble();
          final double widthScale =
              (size.width / 375).clamp(0.88, 1.0).toDouble();
          final double screenScale =
              heightScale < widthScale ? heightScale : widthScale;
          final bool isCompactHeight = size.height < 650;
          final bool isVeryCompactHeight = size.height < 580;
          final double horizontalPadding =
              ((size.width * 0.06) * screenScale).clamp(16.0, 28.0).toDouble();
          final double topSpacing =
              ((size.height * 0.02) * screenScale).clamp(6.0, 20.0).toDouble();
          final double heroHeight = isVeryCompactHeight
              ? ((size.height * 0.34) * screenScale)
                  .clamp(190.0, 260.0)
                  .toDouble()
              : isCompactHeight
                  ? ((size.height * 0.38) * screenScale)
                      .clamp(230.0, 310.0)
                      .toDouble()
                  : ((size.height * 0.42) * screenScale)
                      .clamp(280.0, 400.0)
                      .toDouble();
          final double maxContentWidth = size.width > 520 ? 480.0 : size.width;

          return Stack(
            children: [
              const _DecorativeBackground(),
              SafeArea(
                child: Center(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(maxWidth: maxContentWidth),
                    child: Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(
                          horizontalPadding, 0, horizontalPadding, 16),
                      child: Column(
                        children: [
                          SizedBox(height: topSpacing),
                          _OnboardingHeader(
                            currentIndex: currentIndex,
                            pageCount: content.length,
                            screenScale: screenScale,
                            onSkip: currentIndex < content.length - 1
                                ? _goToAllowLocation
                                : null,
                          ),
                          SizedBox(height: topSpacing),
                          Expanded(
                            child: PageView.builder(
                              controller: pageController,
                              scrollDirection: Axis.horizontal,
                              onPageChanged: (int index) {
                                setState(() {
                                  currentIndex = index;
                                });
                              },
                              itemCount: content.length,
                              itemBuilder: (context, index) {
                                return _OnboardingPage(
                                  data: content[index],
                                  heroHeight: heroHeight,
                                  isCompactHeight: isCompactHeight,
                                  isVeryCompactHeight: isVeryCompactHeight,
                                  screenScale: screenScale,
                                );
                              },
                            ),
                          ),
                          SizedBox(
                              height: ((size.height * 0.02) * screenScale)
                                  .clamp(10.0, 20.0)
                                  .toDouble()),
                          _OnboardingProgressIndicator(
                            pageCount: content.length,
                            currentIndex: currentIndex,
                            screenScale: screenScale,
                          ),
                          SizedBox(
                              height: ((size.height * 0.022) * screenScale)
                                  .clamp(12.0, 22.0)
                                  .toDouble()),
                          _OnboardingActionButton(
                            isLastPage: currentIndex == content.length - 1,
                            height:
                                ((isVeryCompactHeight ? 52 : 56) * screenScale)
                                    .clamp(48.0, 56.0)
                                    .toDouble(),
                            fontSize:
                                (15 * screenScale).clamp(13.0, 15.0).toDouble(),
                            onPressed: _goToNextPage,
                          ),
                          SizedBox(height: bottomInset > 0 ? 0 : 8),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}


class _DecorativeBackground extends StatelessWidget {
  const _DecorativeBackground();

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Stack(
        children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    themeColor.withValues(alpha: 0.10),
                    notifires.getbgcolor,
                  ],
                  stops: const [0.0, 0.55],
                ),
              ),
            ),
          ),
          PositionedDirectional(
            start: 0,
            top: 0,
            child: SvgPicture.asset("assets/images/EllipseTop.svg"),
          ),
          PositionedDirectional(
            start: 0,
            top: 0,
            child: SvgPicture.asset("assets/images/topEllipse.svg"),
          ),
        ],
      ),
    );
  }
}

class _OnboardingHeader extends StatelessWidget {
  final int currentIndex;
  final int pageCount;
  final double screenScale;
  final VoidCallback? onSkip;

  const _OnboardingHeader({
    required this.currentIndex,
    required this.pageCount,
    required this.screenScale,
    required this.onSkip,
  });

  @override
  Widget build(BuildContext context) {
    final String counter =
        "${(currentIndex + 1).toString().padLeft(2, '0')} / ${pageCount.toString().padLeft(2, '0')}";

    return Row(
      children: [
        Container(
          width: (36 * screenScale).clamp(30.0, 36.0).toDouble(),
          height: (36 * screenScale).clamp(30.0, 36.0).toDouble(),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: whiteColor,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(Icons.local_taxi_rounded,
              color: themeColor,
              size: (18 * screenScale).clamp(15.0, 18.0).toDouble()),
        ),
        SizedBox(width: (10 * screenScale).clamp(8.0, 10.0).toDouble()),
        Expanded(
          child: Text(
            counter,
            style: captionText(context).copyWith(
              fontFamily: "Poppins SemiBold",
              fontWeight: FontWeight.w600,
              color: blackColor,
              letterSpacing: 0.5,
            ),
            semanticsLabel:
                "${"onboarding_step_of".translate(context)} ${currentIndex + 1} ${"of".translate(context)} $pageCount",
          ),
        ),
        if (onSkip != null)
          Semantics(
            button: true,
            label: "skip".translate(context),
            child: InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: onSkip,
              child: Padding(
                padding: const EdgeInsetsDirectional.symmetric(
                    horizontal: 14, vertical: 8),
                child: Text(
                  "skip".translate(context),
                  style: captionText(context).copyWith(
                    color: notifires.getGrey1whiteColor,
                    fontFamily: "Poppins Medium",
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class _OnboardingPage extends StatelessWidget {
  final _OnboardingPageData data;
  final double heroHeight;
  final bool isCompactHeight;
  final bool isVeryCompactHeight;
  final double screenScale;

  const _OnboardingPage({
    required this.data,
    required this.heroHeight,
    required this.isCompactHeight,
    required this.isVeryCompactHeight,
    required this.screenScale,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const NeverScrollableScrollPhysics(),
      child: Column(
        children: [
          _OnboardingHeroCard(
            key: ValueKey(data.image),
            image: data.image,
            height: heroHeight,
            badgeKey: data.badge,
          ),
          Transform.translate(
            offset: Offset(
                0,
                -((isVeryCompactHeight ? 18 : 26) * screenScale)
                    .clamp(14.0, 26.0)
                    .toDouble()),
            child: _OnboardingContentCard(
              key: ValueKey("${data.titleKey}_content"),
              badgeKey: data.badge,
              titleKey: data.titleKey,
              descriptionKey: data.descriptionKey,
              benefitKey: data.benefitKey,
              isCompact: isCompactHeight,
              screenScale: screenScale,
            ),
          ),
        ],
      ),
    );
  }
}

class _OnboardingHeroCard extends StatelessWidget {
  final String image;
  final double height;
  final String badgeKey;

  const _OnboardingHeroCard({
    super.key,
    required this.image,
    required this.height,
    required this.badgeKey,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: height,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(32),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            _premiumDeep,
            Color.lerp(_premiumDeep, themeColor, 0.45) ?? _premiumDeep,
          ],
        ),
        border: Border.all(color: _premiumGold.withValues(alpha: 0.28)),
        boxShadow: [
          BoxShadow(
            color: _premiumDeep.withValues(alpha: 0.28),
            blurRadius: 24,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          PositionedDirectional(
            end: -36,
            top: -36,
            child: _SoftCircle(
                size: height * 0.55, color: whiteColor.withValues(alpha: 0.06)),
          ),
          PositionedDirectional(
            start: -28,
            bottom: -28,
            child: _SoftCircle(
                size: height * 0.4,
                color: _premiumGold.withValues(alpha: 0.10)),
          ),
          PositionedDirectional(
            start: 0,
            end: 0,
            bottom: 0,
            child: Container(
              height: 2,
              margin: const EdgeInsetsDirectional.symmetric(horizontal: 28),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    _premiumGold.withValues(alpha: 0.55),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 320),
              transitionBuilder: (child, animation) => FadeTransition(
                opacity: animation,
                child: ScaleTransition(
                  scale: Tween<double>(begin: 0.94, end: 1).animate(animation),
                  child: child,
                ),
              ),
              child: Image.asset(
                image,
                key: ValueKey(image),
                fit: BoxFit.contain,
              ),
            ),
          ),
          PositionedDirectional(
            top: 16,
            end: 16,
            child: Container(
              width: 40,
              height: 40,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.12),
                shape: BoxShape.circle,
                border: Border.all(color: _premiumGold.withValues(alpha: 0.4)),
              ),
              child: Icon(_badgeIcon(badgeKey), color: _premiumGold, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  IconData _badgeIcon(String key) {
    switch (key) {
      case "driver_onboarding_step_1":
        return Icons.directions_car_filled_rounded;
      case "driver_onboarding_step_2":
        return Icons.description_outlined;
      default:
        return Icons.payments_rounded;
    }
  }
}

class _SoftCircle extends StatelessWidget {
  final double size;
  final Color color;

  const _SoftCircle({required this.size, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
    );
  }
}

class _OnboardingContentCard extends StatelessWidget {
  final String badgeKey;
  final String titleKey;
  final String descriptionKey;
  final String benefitKey;
  final bool isCompact;
  final double screenScale;

  const _OnboardingContentCard({
    super.key,
    required this.badgeKey,
    required this.titleKey,
    required this.descriptionKey,
    required this.benefitKey,
    required this.isCompact,
    required this.screenScale,
  });

  @override
  Widget build(BuildContext context) {
    final double titleFontSize =
        ((isCompact ? 19 : 22) * screenScale).clamp(17.0, 22.0).toDouble();
    final double descriptionFontSize =
        ((isCompact ? 13 : 14) * screenScale).clamp(12.0, 14.0).toDouble();

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 320),
      transitionBuilder: (child, animation) => FadeTransition(
        opacity: animation,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.06),
            end: Offset.zero,
          ).animate(animation),
          child: child,
        ),
      ),
      child: Container(
        key: ValueKey(titleKey),
        width: double.infinity,
        margin: const EdgeInsetsDirectional.symmetric(horizontal: 4),
        padding: EdgeInsetsDirectional.all((isCompact ? 18 : 22).toDouble()),
        decoration: BoxDecoration(
          color: whiteColor,
          borderRadius: BorderRadius.circular(28),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.07),
              blurRadius: 20,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsetsDirectional.symmetric(
                  horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: themeColor.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                "driver_onboarding".translate(context),
                style: captionText(context).copyWith(
                  color: themeColor,
                  fontFamily: "Poppins SemiBold",
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.6,
                  fontSize: 10.5,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              titleKey.translate(context),
              textAlign: TextAlign.start,
              style:
                  sectionTitleStyle(context).copyWith(fontSize: titleFontSize),
            ),
            const SizedBox(height: 8),
            Text(
              descriptionKey.translate(context),
              textAlign: TextAlign.start,
              style: bodyText(context).copyWith(
                color: notifires.getGrey1whiteColor,
                fontSize: descriptionFontSize,
                height: 1.4,
              ),
            ),
            SizedBox(height: (isCompact ? 12 : 16).toDouble()),
            Container(height: 1, color: themeColor.withValues(alpha: 0.12)),
            SizedBox(height: (isCompact ? 12 : 16).toDouble()),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.stars_rounded,
                    color: _premiumGold,
                    size: (isCompact ? 16 : 18).toDouble()),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    benefitKey.translate(context),
                    textAlign: TextAlign.start,
                    style: captionText(context).copyWith(
                      color: notifires.getGrey1whiteColor,
                      fontFamily: "Poppins Medium",
                      fontWeight: FontWeight.w500,
                      fontSize: (isCompact ? 11.5 : 12.5).toDouble(),
                      height: 1.35,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}


class _OnboardingProgressIndicator extends StatelessWidget {
  final int pageCount;
  final int currentIndex;
  final double screenScale;

  const _OnboardingProgressIndicator({
    required this.pageCount,
    required this.currentIndex,
    required this.screenScale,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label:
          "${"onboarding_step_of".translate(context)} ${currentIndex + 1} ${"of".translate(context)} $pageCount",
      child: Row(
        children: List.generate(pageCount, (index) {
          final bool isActive = index == currentIndex;
          final bool isDone = index < currentIndex;
          return Expanded(
            child: Padding(
              padding: EdgeInsetsDirectional.only(
                  end: index == pageCount - 1 ? 0 : 6),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 260),
                curve: Curves.easeOut,
                height: (5 * screenScale).clamp(4.0, 5.0).toDouble(),
                decoration: BoxDecoration(
                  color: (isActive || isDone)
                      ? themeColor
                      : themeColor.withValues(alpha: 0.18),
                  borderRadius: BorderRadius.circular(6),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _OnboardingActionButton extends StatelessWidget {
  final bool isLastPage;
  final double height;
  final double fontSize;
  final VoidCallback onPressed;

  const _OnboardingActionButton({
    required this.isLastPage,
    required this.height,
    required this.fontSize,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    final String labelKey = isLastPage ? "get_started" : "next";

    return SizedBox(
      width: double.infinity,
      height: height,
      child: Semantics(
        button: true,
        label: labelKey.translate(context),
        child: ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor: themeColor,
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(height / 2),
            ),
          ),
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 220),
            child: Row(
              key: ValueKey(labelKey),
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  labelKey.translate(context),
                  style: sectionTitleStyle(context).copyWith(
                    color: blackColor,
                    fontSize: fontSize,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(width: 8),
                Icon(
                  isLastPage
                      ? Icons.check_circle_outline_rounded
                      : Icons.arrow_forward_rounded,
                  color: blackColor,
                  size: 18,
                  textDirection: Directionality.of(context),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
