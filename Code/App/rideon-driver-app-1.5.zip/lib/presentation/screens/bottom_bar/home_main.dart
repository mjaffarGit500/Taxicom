import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:ride_on_driver/core/utils/common_widget.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import 'package:ride_on_driver/presentation/screens/home/item_home_screen_map_box/item_home_screen_map_box.dart';
import 'package:ride_on_driver/presentation/screens/home/item_home_screen_osm/item_home_screen_osm.dart';
import '../../../core/extensions/helper/push_notifications.dart';
import '../../../core/extensions/workspace.dart';
import '../../../core/services/data_store.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../cubits/bottom_bar_cubit.dart';
import '../../cubits/general_cubit.dart';
import '../../cubits/realtime/listen_ride_request_cubit.dart';
import '../../cubits/realtime/manage_driver_cubit.dart';
import '../../widgets/internet_checkert.dart';
import '../Account/my_account_screen.dart';
import '../home/item_home_screen/item_home_screen.dart';
import '../Payment/finance_screen.dart';
import '../history/history_screen.dart';

class HomeMain extends StatefulWidget {
  final int? initialIndex;
  final String? route;

  const HomeMain({super.key, this.initialIndex, this.route});

  @override
  State<HomeMain> createState() => _HomeMainState();
}

class _HomeMainState extends State<HomeMain>
    with SingleTickerProviderStateMixin {
  late TabController tabController;

  List<Widget> pages = [
    box.get("mapType") == "osm"
        ? const ItemHomeScreenOSM()
        : box.get("mapType") == "mapBox"
            ? const ItemHomeScreenMapBox()
            : box.get("mapType") == "ola"
                ? const ItemHomeScreen()
                : const ItemHomeScreen(),
    const HistoryScreen(),
    const FinanceMainScreen(isFormHome: true),
    const MyAccountScreen(),
  ];

  late final StreamSubscription bottomBarSubscription;

  @override
  void initState() {
    super.initState();
    getFCMToken();
    showNotification(context);

    if (widget.initialIndex == 0) {
      context.read<BottomBarCubit>().changeTabIndex(0);
    }

    tabController = TabController(
      length: 4,
      vsync: this,
      initialIndex: widget.initialIndex ?? 0,
    );

    bottomBarSubscription =
        context.read<BottomBarCubit>().stream.listen((state) {
      if (!mounted) return;
      if (tabController.index != state.index) {
        tabController.animateTo(state.index);
      }
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      // getCurrency(context);
      getUserDataLocallyToHandleTheState(context, isHomePage: true);
      final driverIdUpdated = box.get("driverId") ?? "";
      if (driverIdUpdated.isNotEmpty) {
        driverId = driverIdUpdated;
        context
            .read<UpdateDriverParameterCubit>()
            .updateDriverId(driverId: driverIdUpdated);
        context
            .read<GetDocApprovalStatusCubit>()
            .listenToDocApprovalStatus(driverId: driverIdUpdated);
        context
            .read<GetDriverStatusCubit>()
            .listenDriverStatusStatus(driverId: driverIdUpdated);
        context
            .read<ListenRideRequestCubit>()
            .listenForRideRequests(driverIdUpdated, context: context);
      }
    });
  }

  @override
  void dispose() {
    bottomBarSubscription.cancel();
    tabController.dispose();
    super.dispose();
  }

  late Future<void> _startupBarrier;

  Widget _modernTabItem({
    required BuildContext context,
    required bool isActive,
    required String asset,
    required String label,
  }) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOut,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        gradient: isActive
            ? LinearGradient(
                colors: [
                  themeColor.withValues(alpha: 0.22),
                  themeColor.withValues(alpha: 0.1),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              )
            : null,
        color: isActive ? null : Colors.transparent,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isActive
              ? themeColor.withValues(alpha: 0.18)
              : Colors.transparent,
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SvgPicture.asset(
            asset,
            height: 18,
            // ignore: deprecated_member_use
            color: isActive ? themeColor : grey3,
          ),
          const SizedBox(height: 3),
          Text(
            label.translate(context),
            style: headingBlack(context).copyWith(
              fontSize: 10,
              fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
              color: isActive ? themeColor : grey3,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: notifires.getbgcolor,
      extendBody: true,
      body: ConnectivityWrapper(
        child: TabBarView(
          physics: const NeverScrollableScrollPhysics(),
          controller: tabController,
          children: pages,
        ),
      ),
      floatingActionButtonAnimator: FloatingActionButtonAnimator.scaling,
      floatingActionButton: InkWell(
        onTap: () {
          context.read<BottomBarCubit>().changeTabIndex(0);
        },
        child: Container(
          height: 57,
          width: 57,
          padding: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(38),
            color: themeColor,
            boxShadow: [
              BoxShadow(
                color: themeColor.withValues(alpha: 0.2),
                blurRadius: 18,
                spreadRadius: 1,
                offset: const Offset(0, 8),
              )
            ],
          ),
          child: ClipOval(child: commonlyUserLogo()),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BlocBuilder<BottomBarCubit, BottomBarChangeState>(
          builder: (context, state) {
        return SafeArea(
          minimum: const EdgeInsets.fromLTRB(12, 0, 12, 0),
          child: Container(
            margin: const EdgeInsets.fromLTRB(0, 0, 0, 0),
            padding: const EdgeInsets.fromLTRB(6, 6, 6, 6),
            decoration: BoxDecoration(
              color: whiteColor.withValues(alpha: 0.98),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: themeColor.withValues(alpha: 0.14)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.08),
                  blurRadius: 24,
                  spreadRadius: 1,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: BottomAppBar(
              height: 62,
              padding: EdgeInsets.zero,
              color: Colors.transparent,
              elevation: 0,
              surfaceTintColor: Colors.transparent,
              child: TabBar(
                  onTap: (index) async {
                    context.read<BottomBarCubit>().changeTabIndex(index);
                    if (index == 0) {
                      final driverIdUpdated = box.get("driverId") ??
                          loginModel?.data?.fireStoreId ??
                          "";

                      _startupBarrier =
                          checkAndCleanRideOnStartup(driverId: driverIdUpdated);

                      await _startupBarrier;
                    }
                  },
                  labelPadding: const EdgeInsets.all(0),
                  dividerColor: Colors.transparent,
                  indicatorColor: Colors.transparent,
                  controller: tabController,
                  tabs: [
                    Tab(
                      height: 52,
                      child: _modernTabItem(
                        context: context,
                        isActive: state.index == 0,
                        asset: 'assets/images/Home_icon.svg',
                        label: "Home",
                      ),
                    ),
                    Tab(
                      height: 52,
                      child: _modernTabItem(
                        context: context,
                        isActive: state.index == 1,
                        asset: 'assets/images/doc_icon.svg',
                        label: "History",
                      ),
                    ),
                    Tab(
                      height: 52,
                      child: _modernTabItem(
                        context: context,
                        isActive: state.index == 2,
                        asset: 'assets/images/wallet_icon.svg',
                        label: "Finance",
                      ),
                    ),
                    Tab(
                      height: 52,
                      child: _modernTabItem(
                        context: context,
                        isActive: state.index == 3,
                        asset: 'assets/images/profile_icon.svg',
                        label: "Account",
                      ),
                    ),
                  ]),
            ),
          ),
        );
      }),
    );
  }
}

void getCurrency(BuildContext context) {
  context.read<GeneralCubit>().fetchGeneralSetting(context);
}
