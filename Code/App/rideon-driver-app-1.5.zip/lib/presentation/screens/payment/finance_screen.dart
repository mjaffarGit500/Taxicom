import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../cubits/bottom_bar_cubit.dart';
import 'driver_earning.dart';
import 'driver_wallet.dart';

class FinanceMainScreen extends StatefulWidget {
  final bool isFormHome;
  const FinanceMainScreen({super.key, required this.isFormHome});

  @override
  State<FinanceMainScreen> createState() => _FinanceMainScreenState();
}

class _FinanceMainScreenState extends State<FinanceMainScreen> {
  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    // ignore: deprecated_member_use
    return WillPopScope(
      onWillPop: () async {
        if (widget.isFormHome == true) {
          context.read<BottomBarCubit>().changeTabIndex(0);
        } else {
          goBack();
        }
        return false;
      },
      child: Scaffold(
        backgroundColor: notifires.getbgcolor,
        appBar: CustomAppBar(
          title: "Finance".translate(context),
          isCenterTitle: true,
          isBackButton: widget.isFormHome,
        ),
        body: Column(
          children: [
            Container(
              margin: const EdgeInsets.fromLTRB(16, 14, 16, 8),
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: themeColor.withValues(alpha: 0.14)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.05),
                    blurRadius: 12,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Row(
                children: [
                  _buildTabItem(0, "Wallet".translate(context), Icons.wallet),
                  const SizedBox(width: 8),
                  _buildTabItem(
                    1,
                    "Earning".translate(context),
                    Icons.trending_up_rounded,
                  )
                ],
              ),
            ),
            const SizedBox(height: 4),
            Expanded(
              child: selectedIndex == 0
                  ? const Center(child: DriverWalletScreen())
                  : const Center(child: DriverEarning()),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTabItem(int index, String title, IconData icon) {
    bool isSelected = selectedIndex == index;
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedIndex = index;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        decoration: BoxDecoration(
          gradient: isSelected
              ? LinearGradient(
                  colors: [
                    themeColor,
                    themeColor.withValues(alpha: 0.72),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
          color: isSelected ? null : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
              color: isSelected
                  ? themeColor.withValues(alpha: 0.3)
                  : Colors.transparent,
              width: 1.2),
          boxShadow: isSelected == false
              ? [BoxShadow(color: grey5, blurRadius: 4)]
              : [],
        ),
        child: Row(
          children: [
            Icon(
              icon,
              size: 16,
              color: isSelected ? Colors.black87 : grey2,
            ),
            const SizedBox(width: 7),
            Text(
              title,
              style: TextStyle(
                fontSize: 12,
                color: isSelected ? blackColor : grey2,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
