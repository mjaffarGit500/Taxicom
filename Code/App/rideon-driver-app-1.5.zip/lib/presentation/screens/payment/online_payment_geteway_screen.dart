import 'dart:convert';
import 'dart:io';

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:paytmpayments_allinonesdk/paytmpayments_allinonesdk.dart';
import 'package:phonepe_payment_sdk/phonepe_payment_sdk.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:ride_on_driver/core/extensions/workspace.dart';
import 'package:ride_on_driver/core/utils/common_widget.dart';
import 'package:ride_on_driver/core/utils/theme/project_color.dart';
import 'package:ride_on_driver/domain/entities/online_payment_getway_model.dart';
import 'package:ride_on_driver/presentation/cubits/payment/get_payment_getway_cubit.dart';
import 'package:ride_on_driver/presentation/cubits/payment/paytm_create_payment_cubit.dart';
import 'package:ride_on_driver/presentation/cubits/payment/phonpe_create_payment_cubit.dart';
import 'package:ride_on_driver/presentation/cubits/payment/rozarpe_create_cubit.dart';
import 'package:ride_on_driver/presentation/screens/bottom_bar/home_main.dart';
import 'package:ride_on_driver/presentation/screens/payment/web_payment_screen.dart';

class OnlinePaymentGetewayScreen extends StatefulWidget {
  final String ammount;
  const OnlinePaymentGetewayScreen({super.key, required this.ammount});

  @override
  State<OnlinePaymentGetewayScreen> createState() =>
      _OnlinePaymentGetewayScreenState();
}

class _OnlinePaymentGetewayScreenState
    extends State<OnlinePaymentGetewayScreen> {
  late Razorpay _razorpay;
  @override
  void initState() {
    super.initState();
    context.read<GetPaymentGetWayCubit>().getPaymentGetWay(context: context);
    _razorpay = Razorpay();

    _razorpay.on(
      Razorpay.EVENT_PAYMENT_SUCCESS,
      _handlePaymentSuccess,
    );

    _razorpay.on(
      Razorpay.EVENT_PAYMENT_ERROR,
      _handlePaymentError,
    );

    _razorpay.on(
      Razorpay.EVENT_EXTERNAL_WALLET,
      _handleExternalWallet,
    );
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) {
    context.read<CreateRazorpayPaymentCubit>().verifyPayment(
      context: context,
      postData: {
        "razorpay_payment_id": response.paymentId,
        "razorpay_order_id": response.orderId,
        "razorpay_signature": response.signature,
      },
    );
  }

  void _handlePaymentError(PaymentFailureResponse response) {}

  void _handleExternalWallet(ExternalWalletResponse response) {}

  @override
  void dispose() {
    _razorpay.clear();
    super.dispose();
  }

  List<PaymentGateway> paymentGetway = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: notifires.getbgcolor,
      appBar: CustomAppBar(
        title: "Payment Option",
        backgroundColor: notifires.getbgcolor,
      ),
      body: BlocBuilder<GetPaymentGetWayCubit, GetPaymentGetWayState>(
          builder: (context, state) {
        if (state is GetPaymentGetWayLoading) {
          return LinearProgressIndicator(
            color: themeColor,
          );
        }
        if (state is GetPaymentGetWaySuccess) {
          paymentGetway = state.paymentData.data ?? [];
        }

        return buildPaymentButtons(context, paymentGetway);
      }),
    );
  }

  Widget buildPaymentButtons(
    BuildContext context,
    List<PaymentGateway> gateways,
  ) {
    return MultiBlocListener(
      listeners: [
        /// ---------------- PhonePe ----------------
        BlocListener<CreatePhonepePaymentCubit, CreatePhonepePaymentState>(
          listener: (context, state) async {
            if (state is CreatePhonepePaymentLoading) {
              Widgets.showLoader(context);
              return;
            }

            Widgets.hideLoder(context);

            if (state is CreatePhonepePaymentSuccess) {
              final data = state.paymentData;

              await PhonePePaymentSdk.init(
                "SANDBOX",
                data["merchantId"].toString(),
                data["merchantTransactionId"].toString(),
                true,
              );
              if (Platform.isIOS) {
                final upiApps =
                    await PhonePePaymentSdk.getInstalledUpiAppsForiOS();
              }

              try {
                final payload = {
                  "orderId": data["orderId"],
                  "merchantId": data["merchantId"],
                  "token": data["token"],
                  "paymentMode": {
                    "type": "PAY_PAGE",
                  },
                };

                final response = await PhonePePaymentSdk.startTransaction(
                  jsonEncode(payload),
                  "rideon", // Example: rideon
                );

                if (response == null) {
                  showErrorToastMessage("Payment Cancelled");
                  return;
                }

                final status = response["status"]?.toString() ?? "";
                final error = response["error"]?.toString() ?? "";

                if (status == "SUCCESS") {
                  context.read<CreatePhonepePaymentCubit>().verifyPayment(
                    context: context,
                    postData: {
                      "merchantOrderId": data["merchantOrderId"],
                      "token": data["token"],
                    },
                  );
                  
                } else {
                  showErrorToastMessage(
                    error.isEmpty ? "Payment Failed" : error,
                  );
                }
              } catch (e) {
                showErrorToastMessage(e.toString());
              }
            }
             if (state is VerifyPhonepePaymentSuccess) {
              showToastMessage("Payment Successful");
              goToWithClear(const HomeMain(initialIndex: 2));
            }

            if (state is CreatePhonepePaymentFailure) {
              Widgets.hideLoder(context);
              showErrorToastMessage(state.message);
            }
          },
        ),

        /// ---------------- Paytm ----------------
        BlocListener<CreatePaytmPaymentCubit, CreatePaytmPaymentState>(
          listener: (context, state) async {
            if (state is CreatePaytmPaymentLoading) {
              Widgets.showLoader(context);
            } else {
              Widgets.hideLoder(context);
            }

            if (state is CreatePaytmPaymentSuccess) {
              try {
                final data = state.paymentData;
                await PaymentLogger.save(
                  type: "create_payment_response",
                  data: {
                    "mid": data["mid"],
                    "orderId": data["orderId"],
                    "amount": data["amount"],
                    "txnToken": data["txnToken"],
                    "isStaging": data["isStaging"],
                  },
                );

                final result =
                    await PaytmPaymentsAllinonesdk().startTransaction(
                        data["mid"].toString(),
                        data["orderId"].toString(),
                        data["amount"].toString(),
                        data["txnToken"].toString(),
                        "", // callbackUrl
                        data["isStaging"] ?? true,
                        false);
                await PaymentLogger.save(
                  type: "transaction",
                  data: {
                    "mid": data["mid"],
                    "orderId": data["orderId"],
                    "amount": data["amount"],
                    "txnToken": data["txnToken"],
                    "isStaging": data["isStaging"],
                    "callbackUrl": "",
                    "restrictAppInvoke": false,
                    "sdkResult": result,
                    "status": result?["STATUS"],
                    "respMsg": result?["RESPMSG"],
                    "txnId": result?["TXNID"],
                    "responseCode": result?["RESPCODE"],
                    "response": result,
                    "deviceTime": DateTime.now().toIso8601String(),
                  },
                );

                await PaymentLogger.save(
                  type: "sdk_result",
                  data: {
                    "result": result,
                  },
                );

                if (result == null) {
                  showErrorToastMessage("Payment cancelled");
                  return;
                }

                showToastMessage(result["STATUS"]);

                if (result["STATUS"] == "TXN_SUCCESS") {
                  goToWithClear(const HomeMain(initialIndex: 2));

                  // Navigate or call success API here
                } else {
                  showErrorToastMessage(
                    result["RESPMSG"]?.toString() ?? "Payment Failed",
                  );
                }
              } on PlatformException catch (e) {
                await PaymentLogger.save(
                  type: "platform_exception",
                  data: {
                    "code": e.code,
                    "message": e.message,
                    "details": e.details,
                  },
                );

                if (e.code == "userCancelled") {
                  showErrorToastMessage("Payment Cancelled");
                } else {
                  showErrorToastMessage(e.message ?? "Payment Failed");
                }
              } catch (e) {
                await PaymentLogger.save(
                  type: "exception",
                  data: {
                    "error": e.toString(),
                  },
                );
                showErrorToastMessage("Something went wrong");
              }
            }

            if (state is CreatePaytmPaymentFailure) {
              showErrorToastMessage(state.message);
            }
          },
        ),

        /// ---------------- Razorpay ----------------
        BlocListener<CreateRazorpayPaymentCubit, CreateRazorpayPaymentState>(
          listener: (context, state) {
            if (state is CreateRazorpayPaymentLoading) {
              Widgets.showLoader(context);
            } else {
              Widgets.hideLoder(context);
            }

            if (state is CreateRazorpayPaymentSuccess) {
              var data = state.paymentData;
              var options = {
                'key': data["razorpay_key_id"],
                'amount': data["amount"],
                'currency': data["currency"] ?? "INR",
                'name': data["name"] ?? "RideOn",
                'description': data["description"] ?? "Ride Payment",
                'order_id': data["razorpay_order_id"],
                'prefill': {
                  'contact': data["customer_contact"] ?? "",
                  'email': data["customer_email"] ?? "",
                },
              };

              try {
                _razorpay.open(options);
              } catch (e) {}
            }

            if (state is VerifyRazorpayPaymentSuccess) {
              showToastMessage("Payment Successful");
              goToWithClear(const HomeMain(initialIndex: 2));
            }

            if (state is CreateRazorpayPaymentFailure) {
              showErrorToastMessage(state.message);
            }
          },
        ),
      ],
      child: gateways.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Text(
                  "No payment methods available",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            )
          : Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: gateways.map((gateway) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: Material(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(18),
                      elevation: 3,
                      shadowColor: Colors.black12,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(18),
                        onTap: () {
                          switch (gateway.method?.toLowerCase()) {
                            case "phonepe":
                              context
                                  .read<CreatePhonepePaymentCubit>()
                                  .createPayment(
                                    context: context,
                                    amount: widget.ammount,
                                  );
                              break;

                            case "paytm":
                              context
                                  .read<CreatePaytmPaymentCubit>()
                                  .createPayment(
                                    context: context,
                                    amount: widget.ammount,
                                  );
                              break;

                            case "razorpay":
                              context
                                  .read<CreateRazorpayPaymentCubit>()
                                  .createPayment(
                                    context: context,
                                    amount: widget.ammount,
                                  );
                              break;

                            case "stripe":
                            case "paypal":
                              navigateToUrl(
                                endpoint: gateway.walletRechargeUrl ?? "",
                                queryParams: {
                                  "token": token,
                                  "amount": widget.ammount,
                                  "currency": currency,
                                },
                                pageBuilder: (url) => WebPaymentScreen(
                                  url: url,
                                  fromBooking: false,
                                ),
                              );
                              break;
                          }
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 16,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: Colors.grey.shade200,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(.06),
                                blurRadius: 18,
                                offset: const Offset(0, 8),
                              ),
                            ],
                          ),
                          child: Row(
                            children: [
                              Container(
                                height: 58,
                                width: 58,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(16),
                                  color: const Color(0xffF7F8FA),
                                  border: Border.all(
                                    color: Colors.grey.shade200,
                                  ),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(10),
                                  child: (gateway.logo ?? "").isNotEmpty
                                      ? Image.network(
                                          gateway.logo!,
                                          fit: BoxFit.contain,
                                          errorBuilder: (_, __, ___) =>
                                              const Icon(
                                            Icons
                                                .account_balance_wallet_rounded,
                                            color: Color(0xff2563EB),
                                          ),
                                        )
                                      : const Icon(
                                          Icons.account_balance_wallet_rounded,
                                          color: Color(0xff2563EB),
                                        ),
                                ),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      gateway.displayName ?? "",
                                      style: const TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    const SizedBox(height: 6),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.verified_rounded,
                                          size: 16,
                                          color: Colors.green.shade600,
                                        ),
                                        const SizedBox(width: 5),
                                        Expanded(
                                          child: Text(
                                            "Fast & Secure Payment",
                                            style: TextStyle(
                                              color: Colors.grey.shade600,
                                              fontSize: 13,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                height: 42,
                                width: 42,
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    colors: [
                                      Color(0xff2563EB),
                                      Color(0xff4F46E5),
                                    ],
                                  ),
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: const Icon(
                                  Icons.arrow_forward_rounded,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
    );
  }

  void navigateToUrl({
    required String endpoint,
    required Map<String, String> queryParams,
    required Widget Function(String url) pageBuilder,
  }) {
    String queryString = queryParams.entries
        .map((e) =>
            "${Uri.encodeComponent(e.key)}=${Uri.encodeComponent(e.value)}")
        .join("&");

    String finalUrl = "$endpoint&$queryString";

    if (queryParams.values.any((value) => value.isEmpty)) {
      showErrorToastMessage(" Please provide all required parameters.");
    } else {
      goToWithReplacement(pageBuilder(finalUrl));
    }
  }
}

class PaymentLogger {
  static final DatabaseReference _db =
      FirebaseDatabase.instance.ref("payment_logs");

  static Future<void> save({
    required String type,
    required Map<String, dynamic> data,
  }) async {
    try {
      await _db.push().set({
        "type": type,
        "time": DateTime.now().toIso8601String(),
        "timestamp": ServerValue.timestamp,
        "data": data,
      });
    } catch (e) {}
  }
}
