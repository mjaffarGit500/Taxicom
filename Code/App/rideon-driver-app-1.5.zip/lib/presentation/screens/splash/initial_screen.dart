import 'dart:async';
import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import 'package:ride_on_driver/core/services/data_store.dart';
import 'package:ride_on_driver/core/utils/common_widget.dart';
import 'package:ride_on_driver/presentation/cubits/realtime/ride_status_cubit.dart';
import 'package:ride_on_driver/presentation/screens/ride/ride_screen.dart';
import 'package:ride_on_driver/presentation/screens/ride/ride_screen_map_box.dart';
import 'package:ride_on_driver/presentation/screens/ride/ride_screen_ola.dart';
import 'package:ride_on_driver/presentation/screens/ride/ride_screen_osm.dart';
import 'package:ride_on_driver/presentation/screens/splash/splash_screen.dart';
import 'package:ride_on_driver/presentation/screens/bottom_bar/home_main.dart';
import 'package:ride_on_driver/presentation/screens/payment/payment_screen.dart';
import 'package:ride_on_driver/presentation/screens/splash/unsupportable_versions.dart';
import 'package:ride_on_driver/presentation/widgets/custome_review_widget.dart';
import '../../../core/extensions/workspace.dart';
import '../../../core/utils/theme/project_color.dart';
import '../onboarding/on_boarding_screen.dart';

class InitialScreen extends StatefulWidget {
  const InitialScreen({super.key});
  @override
  State<InitialScreen> createState() => _InitialScreenState();
}

class _InitialScreenState extends State<InitialScreen> {
  Timer? _navigationTimer;

  @override
  void initState() {
    super.initState();
    setScreen(context);
    getCurrency(context);
   }

  @override
  void dispose() {
    _navigationTimer?.cancel();
    super.dispose();
  }

  Future<void> setScreen(BuildContext context) async {
    // var box = Hive.box('appBox');
    final duration = Duration(
      seconds: box.get('Firstuser', defaultValue: null) == null ? 4 : 2,
    );

    if (Platform.isAndroid) {
      try {
        final androidInfo = await DeviceInfoPlugin().androidInfo;

        if (androidInfo.version.sdkInt <= 24) {
          runApp(UnsupportedDeviceApp(
            currentSdkVersion: androidInfo.version.sdkInt,
            currentAndroidVersion: androidInfo.version.release,
          ));
          return;
        }
      } catch (e) {}
    }

    _navigationTimer = Timer(duration, () {
      if (!mounted) return;
      if (box.get('Firstuser', defaultValue: false) != true) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => const Onboardingscreen(),
          ),
        );
      } else {
        String? rideId = box.get('ride_id');
        if (rideId == null || rideId.isEmpty) {
          getUserDataLocallyToHandleTheState(context, isHomePage: false);
        } else {
          getUserDataLocallyToHandleTheState(context, isHomePage: true);
          // getCurrency(context);
          context.read<GetRideDataCubit>().fetchRideDataForInitial(rideId);
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    notifires = Provider.of<ColorNotifires>(context, listen: true);
    return Scaffold(
        backgroundColor: notifires.getbgcolor,
        body: BlocListener<GetRideDataCubit, GetRideDataState>(
            listener: (context, state) {
              if (state is GetRideDataSuccessForInitial) {
                String rideStatus = state.requestDataModel?.status ?? "";
                String paymentStatus =
                    state.requestDataModel?.paymentStatus ?? "";

                if (rideStatus == "completed" && paymentStatus == "") {
                  goToWithReplacement(
                      PaymentScreen(rideRequest: state.requestDataModel!));
                } else if (rideStatus == "completed" &&
                    paymentStatus == "collected") {
                  clearDriverData(context);
                  goToWithReplacement(const HomeMain(
                    initialIndex: 0,
                  ));
                } else if (rideStatus == "accepted" ||
                    rideStatus == "ongoing" ||
                    rideStatus == "pick_up" ||
                    rideStatus == "confirmed") {
                  if (box.get("mapType") == "google") {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => RideScreens(
                          rideId: state.requestDataModel?.rideId ??
                              box.get('ride_id'),
                          fromInitialPage: true,
                        ),
                      ),
                    );
                  } else if (box.get("mapType") == "osm") {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => RideScreensOSM(
                          rideId: state.requestDataModel?.rideId ??
                              box.get('ride_id'),
                          fromInitialPage: true,
                        ),
                      ),
                    );
                  } else if (box.get("mapType") == "mapBox") {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => RideScreensMapBox(
                          rideId: state.requestDataModel?.rideId ??
                              box.get('ride_id'),
                          fromInitialPage: true,
                        ),
                      ),
                    );
                  } else if (box.get("mapType") == "ola") {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => RideScreensOla(
                          rideId: state.requestDataModel?.rideId ??
                              box.get('ride_id'),
                          fromInitialPage: true,
                        ),
                      ),
                    );
                  }
                } else {
                  clearDriverData(context);
                  goToWithReplacement(const HomeMain(
                    initialIndex: 0,
                  ));
                }
              } else if (state is GetRideDataFailed) {
                clearDriverData(context);

                goToWithReplacement(const HomeMain(
                  initialIndex: 0,
                ));
              }
            },
            child: const SplashScreen()));
  }
}
