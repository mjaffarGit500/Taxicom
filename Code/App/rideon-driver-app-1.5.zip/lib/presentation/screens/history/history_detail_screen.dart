import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../../domain/entities/history.dart';
import '../../../domain/entities/realtime_ride_request.dart';

class HistoryDetailScreen extends StatefulWidget {
  final Bookings? rideData;
  const HistoryDetailScreen({super.key, this.rideData});

  @override
  State<HistoryDetailScreen> createState() => _HistoryDetailScreenState();
}

class _HistoryDetailScreenState extends State<HistoryDetailScreen> {
  static const double _mapHeight = 230;


  RealTimeRideRequest? bookingRideData;

  @override
  void initState() {
    super.initState();
    getData();
  }

  void getData() {
    try {
      final Map<String, dynamic> json =
          jsonDecode(widget.rideData?.rideData.toString() ?? '{}');
      bookingRideData = RealTimeRideRequest.fromMap(json);
    } catch (_) {
      bookingRideData = null;
    }
  }

  String formatDate(String dateStr) {
    try {
      if (dateStr.isEmpty) return '';
      final inputDate = DateTime.tryParse(dateStr);
      if (inputDate == null) return dateStr;
      return DateFormat('dd MMM yyyy').format(inputDate);
    } catch (_) {
      return dateStr;
    }
  }

  String formatTimestamp(String isoDate) {
    try {
      if (isoDate.isEmpty) return '';
      final dateTime = DateTime.parse(isoDate);
      return DateFormat('MMM dd, yyyy - h:mm a').format(dateTime);
    } catch (_) {
      return isoDate;
    }
  }

  Color getStatusBackground(String status) {
    switch (status.toLowerCase()) {
      case 'completed':
        return greentext;
      case 'cancelled':
        return redColor;
      case 'pending':
        return Colors.yellow.shade700;
      default:
        return grey4;
    }
  }

  Color getStatusColor(String status) {
    return status.toLowerCase() == 'completed' ? whiteColor : Colors.black87;
  }

  void copyTokenToClipboard(String? token) {
    if (token != null && token.isNotEmpty) {
      Clipboard.setData(ClipboardData(text: token));
    }
  }

  bool isNonZero(dynamic value) {
    if (value == null) return false;
    try {
      return double.tryParse(value.toString()) != 0.0;
    } catch (_) {
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.rideData == null) {
      return Scaffold(
        backgroundColor: bg,
        body: Center(
          child: Text(
            'No ride data available'.translate(context),
            style: headingBlack(context),
          ),
        ),
      );
    }

    final rideData = widget.rideData!;

    return Scaffold(
      backgroundColor: bg,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            buildMapSection(context, rideData),
            const SizedBox(height: 16),
            buildLocationSection(context, rideData),
            const SizedBox(height: 18),
            if (bookingRideData != null) buildRideInfo(context),
            if (bookingRideData != null) ...[
              const SizedBox(height: 14),
              Divider(color: themeColor.withValues(alpha: 0.30)),
              const SizedBox(height: 10),
              buildRiderInfo(context),
              Divider(color: themeColor.withValues(alpha: 0.30)),
            ],
            const SizedBox(height: 10),
            buildBillDetailsSection(context, rideData),
          ],
        ),
      ),
    );
  }

  Widget buildRideInfo(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [themeColor, themeColor],
                  ),
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: themeColor.withValues(alpha: 0.35),
                      blurRadius: 8,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Icon(Icons.info_rounded, size: 15, color: blackColor),
              ),
              const SizedBox(width: 10),
              Text(
                'Ride Information'.translate(context),
                style: heading3Grey1(context).copyWith(
                  fontSize: 17,
                  color: dark,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          rideInfoItem(
            icon: Icons.access_time_rounded,
            title: 'Date & Time',
            value: formatTimestamp(bookingRideData?.timestamp ?? ''),
          ),
          Row(
            children: [
              Expanded(
                child: rideInfoItem(
                  icon: Icons.straighten_rounded,
                  title: 'Distance',
                  value:
                      '${bookingRideData?.totalDistance ?? ''} ${'Km'.translate(context)}',
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: rideInfoItem(
                  icon: Icons.timer_rounded,
                  title: 'Duration',
                  value: bookingRideData?.totalTime ?? '',
                ),
              ),
            ],
          ),
          ParcelInfoWidget(
            name: bookingRideData?.parcalData?.name ?? '',
            weight: bookingRideData?.parcalData?.weight ?? '',
            receiverName: bookingRideData?.parcalData?.reciverName ?? '',
            receiverPhone: bookingRideData?.parcalData?.reciverNumber ?? '',
            pickupInstructions: bookingRideData?.parcalData?.instruction ?? '',
          ),
          if ((widget.rideData?.deliveryPhotos ?? []).isNotEmpty) ...[
            const SizedBox(height: 16),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: brown.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(7),
                  ),
                  child:   Icon(Icons.photo_library_rounded,
                      size: 13, color: brown),
                ),
                const SizedBox(width: 8),
                Text(
                  'Parcel Images'.translate(context),
                  style: heading3Grey1(context).copyWith(
                    fontSize: 14,
                    color: brown,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 100,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: widget.rideData?.deliveryPhotos?.length ?? 0,
                itemBuilder: (context, index) {
                  final imageUrl =
                      widget.rideData?.deliveryPhotos?[index] ?? '';
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ParcelImagePreviewScreen(
                              images: widget.rideData?.deliveryPhotos ?? [],
                              initialIndex: index,
                            ),
                          ),
                        );
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                              color: themeColor.withValues(alpha: 0.30)),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.08),
                              blurRadius: 6,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: myNetworkImage(
                            imageUrl,
                            width: 100,
                            height: 100,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget buildRiderInfo(BuildContext context) {
    final rating =
        double.tryParse(widget.rideData?.reviewRating?.toString() ?? '0') ?? 0;
    final riderRating =
        double.tryParse(bookingRideData?.customer?.userRating ?? '0') ?? 0;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
           
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: themeColor.withValues(alpha: 0.28)),
          
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [themeColor, themeColor],
                ),
                shape: BoxShape.circle,
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(38),
                child: Container(
                  width: 60,
                  height: 60,
                  color: Colors.grey[200],
                  child: myNetworkImage(
                      bookingRideData?.customer?.userPhoto ?? ''),
                ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                        Icon(Icons.person_rounded, size: 14, color: brown),
                      const SizedBox(width: 5),
                      Expanded(
                        child: Text(
                          bookingRideData?.customer?.userName ?? '',
                          style: heading3Grey1(context).copyWith(
                              fontWeight: FontWeight.w700, fontSize: 15),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Row(
                        children: List.generate(5, (i) {
                          final filled = i < riderRating;
                          return Icon(
                            filled
                                ? Icons.star_rounded
                                : Icons.star_outline_rounded,
                            size: 15,
                            color: filled ? themeColor : grey3,
                          );
                        }),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        bookingRideData?.customer?.userRating ?? '0.0',
                        style:   TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 12,
                          color: dark,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 7),
                  if ((bookingRideData?.vehicleDetails?.vehicleNumber ?? '')
                      .isNotEmpty)
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [themeColor, themeColor],
                            ),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.directions_car_rounded,
                                  size: 11, color: blackColor),
                              const SizedBox(width: 4),
                              Text(
                                bookingRideData
                                        ?.vehicleDetails?.vehicleNumber ??
                                    '',
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 11,
                                  color: blackColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            '${bookingRideData?.vehicleDetails?.vehicleMake ?? ''} ${bookingRideData?.vehicleDetails?.vehicleModel ?? ''}',
                            style: TextStyle(
                              color: Colors.grey[600],
                              fontSize: 11,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                        Icon(Icons.grade_rounded, size: 13, color: brown),
                      const SizedBox(width: 5),
                      Text(
                        '${'You Rated'.translate(context)}:',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey[600],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Row(
                        children: List.generate(5, (index) {
                          return Icon(
                            index < rating
                                ? Icons.star_rounded
                                : Icons.star_outline_rounded,
                            size: 16,
                            color: index < rating
                                ? Colors.orange
                                : grey3,
                          );
                        }),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildMapSection(BuildContext context, Bookings rideData) {
    return Stack(
      children: [
        SizedBox(
          height: _mapHeight,
          width: double.infinity,
          child: Stack(
            children: [
              Image.asset(
                'assets/images/basemap_image.png',
                height: _mapHeight,
                width: double.infinity,
                fit: BoxFit.cover,
                semanticLabel: 'Map preview'.translate(context),
              ),
              Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.black.withValues(alpha: 0.0),
                        Colors.black.withValues(alpha: 0.62),
                      ],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        Positioned(
          top: 70,
          left: 20,
          child: InkWell(
            onTap: () => Navigator.of(context).pop(),
            borderRadius: BorderRadius.circular(14),
            child: Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [themeColor, themeColor],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: themeColor.withValues(alpha: 0.35)),
              ),
              child:   Icon(
                Icons.arrow_back_ios_new_rounded,
                size: 16,
                color: dark,
              ),
            ),
          ),
        ),
        Positioned(
          bottom: 16,
          left: 20,
          right: 20,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.22),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Icon(Icons.calendar_today_rounded,
                        size: 12, color: Colors.white),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    formatDate(rideData.rideDate ?? ''),
                    style: headingBlackBold(context).copyWith(
                      fontSize: 18,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  GestureDetector(
                    onTap: () => copyTokenToClipboard(rideData.token),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.18),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                            color: Colors.white.withValues(alpha: 0.30)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.confirmation_number_rounded,
                              size: 12, color: Colors.white),
                          const SizedBox(width: 5),
                          Text(
                            rideData.token ?? 'N/A',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(width: 6),
                          const Icon(Icons.copy_rounded,
                              size: 11, color: Colors.white),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  rideData.status != null && rideData.status!.isNotEmpty
                      ? Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(
                            color: getStatusBackground(rideData.status!),
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.20),
                                blurRadius: 8,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                rideData.status!.toLowerCase() == 'completed'
                                    ? Icons.check_circle_rounded
                                    : rideData.status!.toLowerCase() ==
                                            'cancelled'
                                        ? Icons.cancel_rounded
                                        : Icons.access_time_rounded,
                                size: 13,
                                color: getStatusColor(rideData.status!),
                              ),
                              const SizedBox(width: 5),
                              Text(
                                rideData.status!.translate(context),
                                style: headingBlack(context).copyWith(
                                  color: getStatusColor(rideData.status!),
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        )
                      : const SizedBox()
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget buildLocationSection(BuildContext context, Bookings rideData) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: themeColor.withValues(alpha: 0.28)),
          boxShadow: [
            BoxShadow(
              color: themeColor.withValues(alpha: 0.12),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Column(
              children: [
                const SizedBox(height: 3),
                Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    color: greentext,
                    shape: BoxShape.circle,
                  ),
                ),
                ...List.generate(
                    6,
                    (_) => Padding(
                          padding: const EdgeInsets.only(top: 3),
                          child: Container(
                            width: 1.5,
                            height: 5,
                            color: greentext.withValues(alpha: 0.30),
                          ),
                        )),
                Container(
                  width: 10,
                  height: 10,
                  decoration: const BoxDecoration(
                    color: Color(0xFF8A5A10),
                    shape: BoxShape.circle,
                  ),
                ),
              ],
            ),
            const SizedBox(width: 14),
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 1),
                        child: Icon(Icons.trip_origin_rounded,
                            size: 13, color: greentext),
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          rideData.pickupLocation?.address ??
                              'N/A'.translate(context),
                          style: headingBlack(context).copyWith(
                            fontSize: 13,
                            color: dark,
                          ),
                          softWrap: true,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Padding(
                        padding: EdgeInsets.only(top: 1),
                        child: Icon(Icons.location_on_rounded,
                            size: 13, color: Color(0xFF8A5A10)),
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          rideData.dropoffLocation?.address ??
                              'N/A'.translate(context),
                          style: headingBlack(context).copyWith(
                            fontSize: 13,
                            color: dark,
                          ),
                          softWrap: true,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildBillDetailsSection(BuildContext context, Bookings rideData) {
    final hasCoupon =
        isNonZero(rideData.couponDiscount) && isNonZero(rideData.basePrice);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [themeColor, themeColor],
                  ),
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: themeColor.withValues(alpha: 0.35),
                      blurRadius: 8,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Icon(Icons.receipt_long_rounded,
                    size: 15, color: blackColor),
              ),
              const SizedBox(width: 10),
              Text(
                'Bill Details'.translate(context),
                style: headingBlackBold(context).copyWith(
                  fontSize: 17,
                  color: dark,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: themeColor.withValues(alpha: 0.25)),
              boxShadow: [
                BoxShadow(
                  color: themeColor.withValues(alpha: 0.10),
                  blurRadius: 10,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Column(
              children: [
                if (isNonZero(rideData.ivaTax)) ...[
                  buildBillRow(
                    context,
                    'Tax'.translate(context),
                    '${rideData.currencyCode ?? ''} ${rideData.ivaTax}',
                  ),
                  const SizedBox(height: 10),
                ],
                if (isNonZero(rideData.serviceCharge)) ...[
                  buildBillRow(
                    context,
                    'Service Charges'.translate(context),
                    '${rideData.currencyCode ?? ''} ${rideData.serviceCharge}',
                  ),
                  const SizedBox(height: 10),
                ],
                buildBillRow(
                  context,
                  'Total Fare'.translate(context),
                  '${rideData.currencyCode ?? ''} ${rideData.basePrice ?? rideData.total ?? ''}',
                ),
                if (hasCoupon) ...[
                  const SizedBox(height: 10),
                  buildBillRow(
                    context,
                    'Coupon discount'.translate(context),
                    '${rideData.currencyCode ?? ''} ${rideData.couponDiscount}',
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: List.generate(
                      28,
                      (_) => Expanded(
                        child: Container(
                          margin: const EdgeInsets.symmetric(horizontal: 2),
                          height: 1,
                          color: themeColor.withValues(alpha: 0.40),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          themeColor.withValues(alpha: 0.12),
                          const Color(0xFFFF8C00).withValues(alpha: 0.08),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(10),
                      border:
                          Border.all(color: themeColor.withValues(alpha: 0.30)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                              Icon(Icons.payments_rounded,
                                size: 15, color: brown),
                            const SizedBox(width: 8),
                            Text(
                              'Final Fare'.translate(context),
                              style: regularBlack(context).copyWith(
                                fontSize: 14,
                                color: dark,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                        Text(
                          '${rideData.currencyCode ?? ''} ${rideData.amountToPay ?? rideData.total ?? ''}',
                          style: regularBlack(context).copyWith(
                            fontSize: 15,
                            color: brown,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 14),
                Row(
                  children: List.generate(
                    28,
                    (_) => Expanded(
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 2),
                        height: 1,
                        color: themeColor.withValues(alpha: 0.25),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(5),
                      decoration: BoxDecoration(
                        color: brown.withValues(alpha: 0.10),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child:   Icon(Icons.credit_card_rounded,
                          size: 13, color: brown),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Payment method'.translate(context),
                      style: regularBlack(context).copyWith(
                        fontSize: 13,
                        color: Colors.grey.shade600,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      rideData.paymentMethod ?? '',
                      style: heading3Grey1(context).copyWith(
                        color: brown,
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 60),
        ],
      ),
    );
  }

  Widget buildBillRow(BuildContext context, String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label.translate(context),
          style: regularBlack(context).copyWith(
            fontSize: 13,
            color: Colors.grey.shade600,
          ),
        ),
        Text(
          value,
          style: regularBlack(context).copyWith(
            fontSize: 13,
            color: brown,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Widget rideInfoItem({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: themeColor.withValues(alpha: 0.22)),
        boxShadow: [
          BoxShadow(
            color: themeColor.withValues(alpha: 0.08),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [themeColor, themeColor],
              ),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, size: 14, color: blackColor),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title.translate(context),
                  style: TextStyle(
                    fontSize: 11,
                    color: Colors.grey[600],
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF2A1E1A),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ParcelImagePreviewScreen extends StatefulWidget {
  final List<String> images;
  final int initialIndex;

  const ParcelImagePreviewScreen({
    super.key,
    required this.images,
    required this.initialIndex,
  });

  @override
  State<ParcelImagePreviewScreen> createState() =>
      _ParcelImagePreviewScreenState();
}

class _ParcelImagePreviewScreenState extends State<ParcelImagePreviewScreen> {
  late PageController _pageController;
  int currentIndex = 0;

  @override
  void initState() {
    super.initState();
    currentIndex = widget.initialIndex;
    _pageController = PageController(initialPage: currentIndex);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Text(
          '${currentIndex + 1}/${widget.images.length}',
          style: const TextStyle(color: Colors.white),
        ),
      ),
      body: PageView.builder(
        controller: _pageController,
        itemCount: widget.images.length,
        onPageChanged: (index) {
          setState(() => currentIndex = index);
        },
        itemBuilder: (context, index) {
          final imageUrl = widget.images[index].trim();
          return Center(
            child: Hero(
              tag: 'parcel_$index',
              child: InteractiveViewer(
                child: imageUrl.isEmpty
                    ? const Icon(Icons.image, color: Colors.white, size: 48)
                    : Image.network(
                        imageUrl,
                        fit: BoxFit.contain,
                      ),
              ),
            ),
          );
        },
      ),
    );
  }
}
