import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import 'package:shimmer/shimmer.dart';

import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../../domain/entities/history.dart';
import '../../cubits/history/history_cubit.dart';
import 'history_detail_screen.dart';

class HistoryScreen extends StatefulWidget {
  final bool? isBackButton;
  const HistoryScreen({super.key, this.isBackButton});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<Bookings> bookings = [];
  int offset = 0;
  bool isPaginating = true;
  int selectedIndex = 0;

  final List<String> statuses = [
    'Completed',
    'Rejected',
    'Cancelled',
  ];

  final RefreshController refreshController = RefreshController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      fetchData(isInitial: true);
    });
  }

  Future<void> fetchData({bool isInitial = false}) async {
    if (isInitial) {
      offset = 0;
    }

    await context.read<HistoryCubit>().getHistoryData(
          context: context,
          bookingKeyMap: {
            'type': statuses[selectedIndex].toLowerCase(),
            'offset': offset.toString(),
          },
          type: statuses[selectedIndex].toLowerCase(),
        );
  }

  void onRefresh() async {
    bookings.clear();
    offset = 0;
    isPaginating = true;
    await fetchData(isInitial: true);
    refreshController.refreshCompleted();
  }

  void onLoading() async {
    if (offset == -1) {
      refreshController.loadComplete();
      refreshController.loadNoData();
      return;
    }

    isPaginating = false;
    await fetchData();
    refreshController.loadComplete();
  }

  String formatDate(String dateStr) {
    try {
      if (dateStr.isEmpty) return '';
      final inputDate = DateTime.tryParse(dateStr);
      if (inputDate == null) return dateStr;
      return DateFormat('dd MMM yyyy').format(inputDate);
    } catch (_) {
      return dateStr;
    }
  }

  Widget _statusBadge(BuildContext context, String status) {
    final bg = getStatusBackground(status);
    final fg = getStatusColor(status);
    IconData icon;

    switch (status.toLowerCase()) {
      case 'completed':
        icon = Icons.check_circle_rounded;
        break;
      case 'cancelled':
        icon = Icons.cancel_rounded;
        break;
      case 'rejected':
        icon = Icons.block_rounded;
        break;
      default:
        icon = Icons.access_time_rounded;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: fg.withValues(alpha: 0.30)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: fg),
          const SizedBox(width: 5),
          Text(
            status.translate(context),
            style: headingBlack(context).copyWith(
              color: fg,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildShimmerCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      child: Shimmer.fromColors(
        baseColor: grey5,
        highlightColor: grey4,
        child: Container(
          height: 218,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
          ),
        ),
      ),
    );
  }

  Widget _buildRideCard(BuildContext context, Bookings ride) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      child: InkWell(
        onTap: () {
          goTo(HistoryDetailScreen(rideData: ride));
        },
        borderRadius: BorderRadius.circular(20),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: themeColor.withValues(alpha: 0.20),
                blurRadius: 14,
                offset: const Offset(0, 4),
              ),
            ],
            border: Border.all(color: themeColor.withValues(alpha: 0.22)),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  height: 4,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [themeColor, themeColor],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(7),
                                decoration: BoxDecoration(
                                  color: themeColor.withValues(alpha: 0.14),
                                  borderRadius: BorderRadius.circular(9),
                                ),
                                child: Icon(
                                  Icons.calendar_today_rounded,
                                  size: 13,
                                  color: brown,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                formatDate(ride.rideDate ?? ''),
                                style: headingBlackBold(context).copyWith(
                                  fontSize: 13,
                                  color: dark,
                                ),
                              ),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 11, vertical: 6),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [themeColor, themeColor],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: themeColor.withValues(alpha: 0.35),
                                  blurRadius: 8,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.payments_rounded,
                                    size: 13, color: blackColor),
                                const SizedBox(width: 5),
                                Text(
                                  '${ride.currencyCode ?? ''} ${ride.amountToPay ?? ride.total ?? ''}',
                                  style: TextStyle(
                                    color: blackColor,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Divider(
                          color: themeColor.withValues(alpha: 0.18), height: 1),
                      const SizedBox(height: 12),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: 18,
                            child: Column(
                              children: [
                                const SizedBox(height: 8),
                                Container(
                                  width: 11,
                                  height: 11,
                                  decoration: BoxDecoration(
                                    color: greentext,
                                    shape: BoxShape.circle,
                                    boxShadow: [
                                      BoxShadow(
                                        color:
                                            greentext.withValues(alpha: 0.50),
                                        blurRadius: 6,
                                        spreadRadius: 1,
                                      ),
                                    ],
                                  ),
                                ),
                                ...List.generate(
                                    6,
                                    (_) => Padding(
                                          padding:
                                              const EdgeInsets.only(top: 3),
                                          child: Container(
                                            width: 1.5,
                                            height: 5,
                                            color:
                                                brown.withValues(alpha: 0.30),
                                          ),
                                        )),
                                const SizedBox(height: 3),
                                Container(
                                  width: 11,
                                  height: 11,
                                  decoration: BoxDecoration(
                                    color: brown,
                                    shape: BoxShape.circle,
                                    boxShadow: [
                                      BoxShadow(
                                        color: brown.withValues(alpha: 0.45),
                                        blurRadius: 6,
                                        spreadRadius: 1,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 7),
                                  decoration: BoxDecoration(
                                    color: greentext.withValues(alpha: 0.07),
                                    borderRadius: BorderRadius.circular(9),
                                    border: Border.all(
                                        color:
                                            greentext.withValues(alpha: 0.22)),
                                  ),
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Icon(Icons.trip_origin_rounded,
                                          size: 12, color: greentext),
                                      const SizedBox(width: 6),
                                      Expanded(
                                        child: Text(
                                          ride.pickupLocation?.address ?? '',
                                          style: headingBlack(context).copyWith(
                                              fontSize: 12, color: dark),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 7),
                                  decoration: BoxDecoration(
                                    color: brown.withValues(alpha: 0.06),
                                    borderRadius: BorderRadius.circular(9),
                                    border: Border.all(
                                        color: brown.withValues(alpha: 0.22)),
                                  ),
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Icon(Icons.location_on_rounded,
                                          size: 12, color: brown),
                                      const SizedBox(width: 6),
                                      Expanded(
                                        child: Text(
                                          ride.dropoffLocation?.address ?? '',
                                          style: headingBlack(context).copyWith(
                                              fontSize: 12, color: dark),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      if (ride.status != null && ride.status!.isNotEmpty)
                        Row(
                          children: [
                            _statusBadge(context, ride.status!),
                            const Spacer(),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 6),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    themeColor.withValues(alpha: 0.16),
                                    const Color(0xFFFF8C00)
                                        .withValues(alpha: 0.10),
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                    color: themeColor.withValues(alpha: 0.28)),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    (ride.deliveryPhotos ?? []).isEmpty
                                        ? Icons.local_taxi_rounded
                                        : Icons.shopping_bag_rounded,
                                    size: 15,
                                    color: brown,
                                  ),
                                  const SizedBox(width: 5),
                                  Text(
                                    (ride.deliveryPhotos ?? []).isEmpty
                                        ? "Ride".translate(context)
                                        : "Delivery".translate(context),
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: brown,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatusTabs() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 0, 18, 14),
      child: Container(
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: themeColor.withValues(alpha: 0.30)),
          boxShadow: [
            BoxShadow(
              color: themeColor.withValues(alpha: 0.10),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: List.generate(statuses.length, (index) {
            final selected = selectedIndex == index;
            return Expanded(
              child: GestureDetector(
                onTap: () {
                  if (selected) return;
                  bookings.clear();
                  setState(() {
                    selectedIndex = index;
                  });
                  fetchData(isInitial: true);
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  decoration: BoxDecoration(
                    gradient: selected
                        ? LinearGradient(
                            colors: [themeColor, themeColor],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          )
                        : null,
                    color: selected ? null : Colors.transparent,
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: Text(
                    statuses[index].translate(context),
                    textAlign: TextAlign.center,
                    style: regularBlack(context).copyWith(
                      fontSize: 11,
                      color: selected ? blackColor : brown,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: widget.isBackButton == true,
      child: Scaffold(
        backgroundColor: bg,
        appBar: AppBar(
          elevation: 0,
          leadingWidth: 75,
          backgroundColor: bg,
          surfaceTintColor: bg,
          automaticallyImplyLeading: false,
          leading: widget.isBackButton == true
              ? Padding(
                  padding: const EdgeInsets.only(
                      left: 16, top: 8, bottom: 8, right: 16),
                  child: InkWell(
                    onTap: () => Navigator.of(context).pop(),
                    borderRadius: BorderRadius.circular(14),
                    child: Container(
                      decoration: BoxDecoration(
                        color: themeColor,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                            color: themeColor.withValues(alpha: 0.28)),
                      ),
                      child: Icon(
                        Icons.arrow_back_ios_new_rounded,
                        size: 16,
                        color: dark,
                      ),
                    ),
                  ),
                )
              : null,
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [themeColor, themeColor],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(15),
                          boxShadow: [
                            BoxShadow(
                              color: themeColor.withValues(alpha: 0.40),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Icon(
                          Icons.history_rounded,
                          size: 24,
                          color: blackColor,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'History'.translate(context),
                            style: regularBlack(context).copyWith(
                              fontSize: 22,
                              fontWeight: FontWeight.w800,
                              color: dark,
                            ),
                          ),
                          Text(
                            "Your past rides".translate(context),
                            style: regularBlack(context).copyWith(
                              fontSize: 12,
                              color: brown,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                ],
              ),
            ),
            _buildStatusTabs(),
            Divider(color: themeColor.withValues(alpha: 0.22), height: 1),
            Expanded(
              child: BlocBuilder<HistoryCubit, HistoryState>(
                builder: (context, state) {
                  if (state is HistoryLoading && isPaginating) {
                    return ListView.builder(
                      itemCount: 5,
                      padding: const EdgeInsets.only(top: 10),
                      itemBuilder: (context, index) => _buildShimmerCard(),
                    );
                  }

                  if (state is HistorySuccess) {
                    if (statuses[selectedIndex].toLowerCase() == state.type) {
                      isPaginating = true;
                      if (offset == 0) {
                        bookings = (state.bookings ?? []);
                      } else {
                        bookings.addAll(state.bookings ?? []);
                      }
                      offset = state.historyModel?.data?.offset ?? 0;
                      context.read<HistoryCubit>().resetHistoryData();
                    }
                  }

                  return SmartRefresher(
                    controller: refreshController,
                    onLoading: onLoading,
                    onRefresh: onRefresh,
                    enablePullUp: offset != -1,
                    child: bookings.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(24),
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        themeColor.withValues(alpha: 0.13),
                                        themeColor.withValues(alpha: 0.08),
                                      ],
                                    ),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(Icons.history_rounded,
                                      size: 48, color: themeColor),
                                ),
                                const SizedBox(height: 16),
                                Text(
                                  "history not found".translate(context),
                                  style: headingBlack(context).copyWith(
                                      color: dark.withValues(alpha: 0.60)),
                                ),
                              ],
                            ),
                          )
                        : ListView.builder(
                            padding: const EdgeInsets.only(top: 10, bottom: 50),
                            itemCount: bookings.length,
                            itemBuilder: (context, index) =>
                                _buildRideCard(context, bookings[index]),
                          ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
