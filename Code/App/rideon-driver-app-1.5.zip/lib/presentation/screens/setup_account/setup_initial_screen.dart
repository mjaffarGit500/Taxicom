import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../core/extensions/workspace.dart';
import '../../../core/services/data_store.dart';
import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../cubits/logout_cubit.dart';
import '../../cubits/realtime/manage_driver_cubit.dart';
import '../../cubits/register_vehicle/get_vehicle_data.dart';
import '../../cubits/register_vehicle/make_model_cubit.dart';
import '../../cubits/register_vehicle/profile_cubit.dart';
import '../../cubits/register_vehicle/register_vehicle_document.dart';
import '../../cubits/register_vehicle/vehicle_register_cubit.dart';
import '../../widgets/primary_button.dart';
import '../../widgets/welcome_screen.dart';
import '../auth/login_screen.dart';
import 'driver_document_screen.dart';
import 'driver_profile_screen.dart';
import 'driver_vehicle/driver_vehicle_screen.dart';

class SetupInitialScreen extends StatefulWidget {
  final int? stepIndex;
  const SetupInitialScreen({super.key, this.stepIndex});

  @override
  State<SetupInitialScreen> createState() => _SetupInitialScreenState();
}

class _SetupInitialScreenState extends State<SetupInitialScreen> {
  int activeStep = 0;
  final RefreshController refreshController = RefreshController();
  Map<String, dynamic>? initialVehicleData;

  final List<Widget> stepWidgets = [
    const Profile(),
    const DriverVehicleScreen(isEdit: false),
    const DriverDocumentScreen(),
  ];

  final List<String> stepTitles = [
    "Profile",
    "Vehicle",
    "Documents",
  ];

  final List<String> stepScreenTitles = [
    "Tell us about yourself",
    "Your Vehicle",
    "Verify your documents",
  ];

  final List<String> stepSubtitles = [
    "Add a few details to complete your driver profile.",
    "Tell us about the vehicle you'll use for rides.",
    "Upload the documents required to activate your driver account.",
  ];

  @override
  void initState() {
    super.initState();
    activeStep = widget.stepIndex ?? 0;
    _initializeCubits();
  }

  void _initializeCubits() {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      context.read<GetVehicleDataCubit>().getAllCategories(context: context);
      context.read<MakeModelCubit>().getMakeModel(
            context: context,
            value: box.get("UpdatedItemTypeId") ??
                loginModel?.data?.itemTypeId.toString() ??
                "",
          );
      if (box.get("itemTypeId") == true) {
        context
            .read<GetItemVehicleDataCubit>()
            .getVehicleItemData(context: context);
      }
    });
  }

  void _nextStep() {
    if (activeStep <= stepWidgets.length - 1) {
      if (_validateAndProceed(activeStep, activeStep + 1)) {
        _handleStepAction(activeStep);
      }
    } else {
      _navigateToWelcomeScreen();
    }
  }

  void _previousStep() {
    if (activeStep > 0) {
      setState(() => activeStep--);
    } else {
      _showLogoutBottomSheet();
    }
  }

  void _goToStep(int index) {
    if (index >= 0 && index < stepWidgets.length) {
      if (index <= activeStep) {
        setState(() => activeStep = index);
      } else {
        for (int i = activeStep; i < index; i++) {
          if (!_validateAndProceed(i, index)) return;
        }
        _handleStepAction(activeStep);
      }
    }
  }

  bool _validateAndProceed(int currentStep, int targetStep) {
    if (targetStep <= currentStep) return true;

    switch (currentStep) {
      case 0:
        return _validateProfileStep();
      case 1:
        return _validateVehicleStep();
      case 2:
        return _validateDocumentStep();
      default:
        return true;
    }
  }

  bool _validateProfileStep() {
    if (loginModel?.data?.gender == null || loginModel!.data!.gender!.isEmpty) {
      showErrorToastMessage("Please select gender".translate(context));
      return false;
    }
    if (loginModel?.data?.firstName == null ||
        loginModel!.data!.firstName!.isEmpty) {
      showErrorToastMessage("Please select Name".translate(context));
      return false;
    }
    return true;
  }

  bool _validateVehicleStep() {
    final vehicleFormState = context.read<VehicleFormCubit>().state;
    if (vehicleFormState.vehicleTypeId.isEmpty) {
      showErrorToastMessage("Select the vehicle type".translate(context));
      return false;
    }
    if (vehicleFormState.vehicleMake.isEmpty) {
      showErrorToastMessage("Select the Brand type".translate(context));
      return false;
    }
    if (context
        .read<VehicleFormCubit>()
        .textEditingVehicleModelController
        .text
        .isEmpty) {
      showErrorToastMessage("Select the Model type".translate(context));
      return false;
    }
    if (context
        .read<VehicleFormCubit>()
        .textEditingVehicleNumberController
        .text
        .isEmpty) {
      showErrorToastMessage(
          "Enter the vehicle registration number".translate(context));
      return false;
    }
    if (context
        .read<VehicleFormCubit>()
        .textEditingVehicleColorController
        .text
        .isEmpty) {
      showErrorToastMessage("Enter the vehicle color".translate(context));
      return false;
    }
    if (vehicleFormState.vehicleYear.isEmpty) {
      showErrorToastMessage("Enter the vehicle Year".translate(context));
      return false;
    }
    final bool imagesRequired = box.get("itemTypeId") != true;
    if (imagesRequired) {
      List<String> missingImages = [];
      if (vehicleFormState.vehicleBase64Image.isEmpty) {
        missingImages.add("vehicle Image");
      }
      if (vehicleFormState.vehicleDocBase64Image.isEmpty) {
        missingImages.add("vehicle Document Image");
      }
      if (vehicleFormState.vehicleLicenceBase64Image.isEmpty) {
        missingImages.add("vehicle License Image");
      }
      if (missingImages.isNotEmpty) {
        if (missingImages.length == 1) {
          showErrorToastMessage(
              "Select the ${missingImages[0]}".translate(context));
        } else {
          showErrorToastMessage(
              "Select the following images: ${missingImages.join(", ")}"
                  .translate(context));
        }
        return false;
      }
    }
    return true;
  }

  bool _validateDocumentStep() {
    final state = context.read<GetDocVehicleFormCubit>().state;
    if (state.drivingLicenceFront.isNotEmpty &&
        state.driverIdFront.isNotEmpty) {
      return true;
    }
    showErrorToastMessage(
        "All images are required. Please upload them before proceeding.");
    return false;
  }

  void _handleStepAction(int currentStep) {
    if (currentStep == 0) {
      context.read<RegisterProfileCubits>().registerProfile(
            gender: loginModel!.data!.gender ?? "",
            name: loginModel!.data!.firstName ?? "",
            context: context,
          );
    } else if (currentStep == 1 && _hasVehicleDataChanged()) {
      _updateVehicleData();
    } else if (currentStep == 2) {
      _navigateToWelcomeScreen();
    } else {
      setState(() => activeStep++);
    }
  }

  bool _hasVehicleDataChanged() {
    if (initialVehicleData == null) return true;
    final vehicleFormState = context.read<VehicleFormCubit>().state;
    final stateDriverParameter =
        context.read<UpdateDriverParameterCubit>().state;

    return vehicleFormState.vehicleTypeId !=
            initialVehicleData!['vehicleTypeId'] ||
        stateDriverParameter.vehicleTypeId !=
            initialVehicleData!['vehicleTypeId'] ||
        vehicleFormState.vehicleMake != initialVehicleData!['vehicleMake'] ||
        vehicleFormState.vehicleModel != initialVehicleData!['vehicleModel'] ||
        vehicleFormState.vehicleNumber !=
            initialVehicleData!['vehicleNumber'] ||
        vehicleFormState.vehicleYear != initialVehicleData!['vehicleYear'] ||
        vehicleFormState.vehicleColor != initialVehicleData!['vehicleColor'] ||
        vehicleFormState.vehicleBase64Image !=
            initialVehicleData!['vehicleBase64Image'] ||
        vehicleFormState.vehicleDocBase64Image !=
            initialVehicleData!['vehicleDocBase64Image'] ||
        vehicleFormState.vehicleLicenceBase64Image !=
            initialVehicleData!['vehicleLicenceBase64Image'];
  }

  void _updateVehicleData() {
    final vehicleFormState = context.read<VehicleFormCubit>().state;
    final metaDataMap = context.read<MetaDataMap>();
    metaDataMap.insertToMap("year", vehicleFormState.vehicleYear);
    metaDataMap.insertToMap(
        "vehicle_registration_number",
        context
            .read<VehicleFormCubit>()
            .textEditingVehicleNumberController
            .text);
    metaDataMap.insertToMap("make", vehicleFormState.vehicleMake);
    metaDataMap.insertToMap(
        "model",
        context
            .read<VehicleFormCubit>()
            .textEditingVehicleModelController
            .text);
    metaDataMap.insertToMap("service_type", "booking");

    final addItemMap = context.read<AddItemMap>();
    addItemMap.insertToMap("metaData", jsonEncode(metaDataMap.state));
    addItemMap.insertToMap("make", vehicleFormState.vehicleMake);
    addItemMap.insertToMap(
        "model",
        context
            .read<VehicleFormCubit>()
            .textEditingVehicleModelController
            .text);
    addItemMap.insertToMap("year", vehicleFormState.vehicleYear);
    addItemMap.insertToMap(
        "color",
        context
            .read<VehicleFormCubit>()
            .textEditingVehicleColorController
            .text);
    addItemMap.insertToMap(
        "registration_number",
        context
            .read<VehicleFormCubit>()
            .textEditingVehicleNumberController
            .text);

    final state = context.read<GetVehicleDataCubit>().state;
    if (state is GetVehicleSuccess) {
      final vehicleId = context
          .read<UpdateAddEditVehicleIdCubit>()
          .state
          .vehicleAddEditTypeId;
      if (vehicleId != null && vehicleId != 0) {
        context.read<VehicleRegisterCubit>().resetState();
        context.read<VehicleRegisterCubit>().insertItem(
              context: context,
              itemMap: addItemMap.state,
              itemId: vehicleId.toString(),
              itemTypeId: vehicleFormState.vehicleTypeId,
            );
        box.put("UpdatedItemTypeId", vehicleFormState.vehicleTypeId);
      } else {
        showErrorToastMessage("Vehicle ID is not being received.");
        return;
      }
    }
  }

  void _navigateToWelcomeScreen() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const WelcomeScreen()),
    );
  }

  void _showLogoutBottomSheet() {
    showDynamicBottomSheets(
      context,
      title: "Logout".translate(context),
      description: "Are you sure you want to logout?".translate(context),
      firstButtontxt: "Cancel".translate(context),
      secondButtontxt: "Yes".translate(context),
      onpressed: () => Navigator.pop(context),
      onpressed1: () async {
        token = "";
        context.read<LogoutCubit>().logout(context);
        clearData(context, true);
      },
    );
  }

  void _onRefresh() {
    setState(() {});
    context.read<GetVehicleDocumentCubit>().getUploadDocument(context: context);
    refreshController.refreshCompleted();
  }

  @override
  void dispose() {
    refreshController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: appWarmBackground,
        body: SafeArea(
          child: MultiBlocListener(
            listeners: [
              BlocListener<RegisterProfileCubits, RegisterProfileState>(
                listener: (context, state) {
                  if (state is RegisterLoading) {
                    Widgets.showLoader(context);
                  } else if (state is RegisterSuccess) {
                    Widgets.hideLoder(context);
                    context.read<RegisterProfileCubits>().resetState();
                    setState(() => activeStep++);
                  } else if (state is RegisterFailure) {
                    Widgets.hideLoder(context);
                    showErrorToastMessage(state.error);
                  }
                },
              ),
              BlocListener<LogoutCubit, LogoutState>(
                listener: (context, state) {
                  if (state is LogoutFailure) {
                    showErrorToastMessage("Logout Failed: ${state.error}");
                  } else if (state is LogoutSuccess) {
                    box.put('isDocumentStatusShown', false);
                    goToWithClear(
                      const LoginScreen(),
                    );
                  }
                },
              ),
              BlocListener<VehicleRegisterCubit, VehicleRegisterState>(
                listener: (context, state) {
                  if (state is VehcileLoading) {
                    Widgets.showLoader(context);
                  } else if (state is VehicleSuccess) {
                    Widgets.hideLoder(context);
                    context.read<VehicleRegisterCubit>().resetState();
                    setState(() => activeStep++);
                  } else if (state is VehicleFailure) {
                    Widgets.hideLoder(context);
                    showErrorToastMessage(state.errorMsg);
                  }
                },
              ),
            ],
            child:
                BlocBuilder<GetItemVehicleDataCubit, GetItemVehicleDataState>(
              builder: (context, state) {
                if (state is GetItemSuccess) {
                  _setVehicleData(state.getItemVehicleModel.data?.items?.first);
                  context.read<GetItemVehicleDataCubit>().clear();
                }
                return Column(
                  children: [
                    _buildTopBar(context),
                    _buildProgressCard(context),
                    Expanded(
                      child: SmartRefresher(
                        controller: refreshController,
                        onRefresh: _onRefresh,
                        child: SingleChildScrollView(
                          padding: const EdgeInsets.fromLTRB(
                              Dimensions.space20,
                              Dimensions.space16,
                              Dimensions.space20,
                              Dimensions.space20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                stepScreenTitles[activeStep].translate(context),
                                style: sectionTitleStyle(context)
                                    .copyWith(fontSize: 22),
                              ),
                              const SizedBox(height: Dimensions.space4),
                              Text(
                                stepSubtitles[activeStep].translate(context),
                                style: captionText(context),
                              ),
                              const SizedBox(height: Dimensions.space20),
                              AnimatedSwitcher(
                                duration: const Duration(milliseconds: 200),
                                child: stepWidgets[activeStep],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    _buildBottomCta(context),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(Dimensions.space16, Dimensions.space12,
          Dimensions.space16, Dimensions.space8),
      child: SizedBox(
        height: 40,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: _previousStep,
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: whiteColor,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: appBorderColor),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.03),
                        blurRadius: 6,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Icon(Icons.arrow_back_ios_new_rounded,
                      size: 16, color: notifires.getwhiteblackColor),
                ),
              ),
            ),
            Text(
              "Driver Setup".translate(context),
              style: sectionTitleStyle(context).copyWith(fontSize: 16),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: Dimensions.space12, vertical: 6),
                decoration: BoxDecoration(
                  color: themeColor.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  "${activeStep + 1}/${stepWidgets.length}",
                  style: TextStyle(
                    fontFamily: "Poppins SemiBold",
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                    color: notifires.isDark ? themeColor : blackColor,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  static const double _badgeSlot = 40.0;

  Widget _buildProgressCard(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(Dimensions.space20, Dimensions.space4,
          Dimensions.space20, Dimensions.space20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: List.generate(stepWidgets.length * 2 - 1, (i) {
          if (i.isOdd) {
            final int leftStep = i ~/ 2;
            final bool trackDone = leftStep < activeStep;
            return Expanded(
              child: Padding(
                padding: const EdgeInsets.only(top: _badgeSlot / 2 - 1.5),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeOut,
                  height: 3,
                  decoration: BoxDecoration(
                    color: trackDone
                        ? appSuccessColor
                        : notifires.getGrey5whiteColor,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
            );
          }

          final int step = i ~/ 2;
          return _buildStepBadge(context, step);
        }),
      ),
    );
  }

  Widget _buildStepBadge(BuildContext context, int step) {
    final bool isActive = activeStep == step;
    final bool isDone = step < activeStep;

    return GestureDetector(
      onTap: () => _goToStep(step),
      behavior: HitTestBehavior.opaque,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: _badgeSlot,
            height: _badgeSlot,
            child: Center(
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                curve: Curves.easeOut,
                width: isActive ? 34 : 30,
                height: isActive ? 34 : 30,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: isActive
                      ? LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [themeColor, const Color(0xffFFA940)],
                        )
                      : null,
                  color: isActive
                      ? null
                      : isDone
                          ? appSuccessColor
                          : whiteColor,
                  border: Border.all(
                    color: isActive
                        ? Colors.transparent
                        : isDone
                            ? appSuccessColor
                            : appBorderColor,
                    width: 1.5,
                  ),
                  boxShadow: isActive
                      ? [
                          BoxShadow(
                            color: themeColor.withValues(alpha: 0.38),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ]
                      : isDone
                          ? [
                              BoxShadow(
                                color: appSuccessColor.withValues(alpha: 0.22),
                                blurRadius: 8,
                                offset: const Offset(0, 2),
                              ),
                            ]
                          : null,
                ),
                child: Center(
                  child: isDone
                      ? const Icon(Icons.check_rounded,
                          size: 16, color: Colors.white)
                      : Text(
                          "${step + 1}",
                          style: TextStyle(
                            fontFamily: "Poppins SemiBold",
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                            color: isActive
                                ? blackColor
                                : notifires.getGrey3whiteColor,
                          ),
                        ),
                ),
              ),
            ),
          ),
          const SizedBox(height: Dimensions.space4),
          SizedBox(
            width: _badgeSlot + 24,
            child: Text(
              stepTitles[step].translate(context),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: stepLabelStyle(context, active: isActive).copyWith(
                color: isDone
                    ? appSuccessColor
                    : isActive
                        ? notifires.getwhiteblackColor
                        : null,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomCta(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(
        Dimensions.space20,
        Dimensions.space12,
        Dimensions.space20,
        Dimensions.space12 + MediaQuery.of(context).padding.bottom,
      ),
      decoration: BoxDecoration(
        color: whiteColor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 12,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: PrimaryButton(
        text: activeStep == stepWidgets.length - 1
            ? "Complete Setup".translate(context)
            : "Continue".translate(context),
        onPressed: _nextStep,
      ),
    );
  }

  void _setVehicleData(myItems) {
    final state = context.read<VehicleFormCubit>();
    state.textEditingVehicleBrandController.text =
        myItems.vehicleMake?.toString() ?? "";
    state.textEditingVehicleColorController.text =
        myItems.vehicleColor ?? "Black";
    state.textEditingVehicleNumberController.text =
        myItems.vehicleNumber?.toString() ?? "";
    state.textEditingVehicleModelController.text =
        myItems.vehicleModel?.toString() ?? "";
    state.updateVehicleTypeId(myItems.itemTypeId?.toString() ?? "");
    context.read<CheckUpdatedDocumentImage>().checkUpdatedDocumentImage(true);
    context.read<CheckUpdatedLicenceImage>().checkUpdatedLicenceImage(true);
    context.read<CheckUpdatedImage>().checkUpdatedImage(true);
    context.read<SetVehicleImage>().setImage(myItems.frontImage?.url ?? "");
    context.read<SetDocImage>().setImage(myItems.frontImageDoc?.url ?? "");
    context
        .read<SetInsuranceImage>()
        .setImage(myItems.itemInsuranceDoc?.url ?? "");
    context.read<UpdateDriverParameterCubit>().updateVehicleTypeName(
          vehcileTypeName: myItems.vehicleType?.toString() ?? "",
        );
    context.read<UpdateDriverParameterCubit>().updateVehicleTypeId(
          vehicleTypeId: myItems.itemTypeId?.toString() ?? "",
        );
    state.updateVehicleColor(myItems.vehicleColor ?? "Black");
    state.updateVehicleModel(myItems.vehicleModel?.toString() ?? "");
    state.updateVehicleMake(myItems.vehicleMake?.toString() ?? "");
    state.updateVehicleYear(myItems.vehicleYear ?? "2025");
    state.updateVehicleNumber(myItems.vehicleNumber?.toString() ?? "");
    context.read<UpdateDocImage>().removeImage();
    context.read<UpdateLicenceImage>().removeImage();
    context.read<UpdateImage>().removeImage();

    initialVehicleData = {
      'vehicleTypeId': myItems.itemTypeId?.toString() ?? "",
      'vehicleMake': myItems.vehicleMake?.toString() ?? "",
      'vehicleModel': myItems.vehicleModel?.toString() ?? "",
      'vehicleNumber': myItems.vehicleNumber?.toString() ?? "",
      'vehicleYear': myItems.vehicleYear ?? "2025",
      'vehicleColor': myItems.vehicleColor ?? "Black",
      'vehicleBase64Image': myItems.frontImage?.url ?? "",
      'vehicleDocBase64Image': myItems.frontImageDoc?.url ?? "",
      'vehicleLicenceBase64Image': myItems.itemInsuranceDoc?.url ?? "",
    };
  }
}
