import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../../../core/utils/common_widget.dart';
import '../../../../../core/utils/theme/project_color.dart';
import '../../../../../core/utils/theme/theme_style.dart';

/// Paints a dashed rounded-rect border. Used by [UploadTriggerCard] for the
/// empty (nothing uploaded yet) state so it reads as a drop-zone.
class _DashedBorderPainter extends CustomPainter {
  final Color color;
  final double radius;
  final double strokeWidth;
  final double dashWidth;
  final double gapWidth;

  const _DashedBorderPainter({
    required this.color,
    this.radius = 16,
    this.strokeWidth = 1.2,
    this.dashWidth = 5,
    this.gapWidth = 4,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth;

    final RRect rrect = RRect.fromRectAndRadius(
      Rect.fromLTWH(strokeWidth / 2, strokeWidth / 2, size.width - strokeWidth,
          size.height - strokeWidth),
      Radius.circular(radius),
    );

    final Path basePath = Path()..addRRect(rrect);
    final Path dashPath = Path();
    for (final ui.PathMetric metric in basePath.computeMetrics()) {
      double distance = 0;
      while (distance < metric.length) {
        final double next = distance + dashWidth;
        dashPath.addPath(
          metric.extractPath(distance, next.clamp(0, metric.length)),
          Offset.zero,
        );
        distance = next + gapWidth;
      }
    }

    canvas.drawPath(dashPath, paint);
  }

  @override
  bool shouldRepaint(covariant _DashedBorderPainter oldDelegate) =>
      oldDelegate.color != color ||
      oldDelegate.radius != radius ||
      oldDelegate.strokeWidth != strokeWidth;
}

/// Shared look for the 3 document-upload trigger rows (Document/License/
/// Vehicle-image). Visual only — all bloc reads/callbacks stay in the
/// caller, this just renders the icon/status/filename/actions consistently.
class UploadTriggerCard extends StatelessWidget {
  final bool uploaded;
  final String label;
  final String description;
  final IconData icon;
  final String? existingImageUrl;
  final String? localFileName;
  final VoidCallback? onRemove;

  const UploadTriggerCard({
    super.key,
    required this.uploaded,
    required this.label,
    required this.description,
    required this.icon,
    this.existingImageUrl,
    this.localFileName,
    this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    final bool hasFile =
        localFileName != null || (existingImageUrl?.isNotEmpty ?? false);
    final String? fileLabel = localFileName ?? existingImageUrl;
    final bool showThumbnail =
        localFileName == null && (existingImageUrl?.isNotEmpty ?? false);

    return Stack(
      children: [
        AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOut,
          width: double.infinity,
          padding: const EdgeInsets.all(Dimensions.space12),
          decoration: BoxDecoration(
            color:
                hasFile ? appSuccessColor.withValues(alpha: 0.05) : whiteColor,
            borderRadius: BorderRadius.circular(Dimensions.radiusCard),
            border: hasFile
                ? Border.all(
                    color: appSuccessColor.withValues(alpha: 0.45),
                    width: 1.2,
                  )
                : null,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.03),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: _buildContent(context, hasFile, fileLabel, showThumbnail),
        ),
        if (!hasFile)
          Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(
                painter: _DashedBorderPainter(
                  color: appBorderColor,
                  radius: Dimensions.radiusCard,
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildContent(BuildContext context, bool hasFile, String? fileLabel,
      bool showThumbnail) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Container(
            width: 44,
            height: 44,
            alignment: Alignment.center,
            color: hasFile
                ? appSuccessColor.withValues(alpha: 0.12)
                : themeColor.withValues(alpha: 0.1),
            child: showThumbnail
                ? myNetworkImage(existingImageUrl, height: 44, width: 44)
                : Icon(
                    hasFile ? Icons.check_circle_rounded : icon,
                    color: hasFile ? appSuccessColor : themeColor,
                    size: 22,
                  ),
          ),
        ),
        const SizedBox(width: Dimensions.space12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              RichText(
                overflow: TextOverflow.ellipsis,
                text: TextSpan(
                  text: label,
                  style: bodyText(context).copyWith(
                    fontFamily: "Poppins SemiBold",
                    fontWeight: FontWeight.w600,
                  ),
                  children: !hasFile
                      ? [
                          TextSpan(
                            text: " *",
                            style: TextStyle(color: appErrorColor),
                          ),
                        ]
                      : const [],
                ),
              ),
              const SizedBox(height: 2),
              Text(
                description,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: captionText(context),
              ),
              const SizedBox(height: Dimensions.space8),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: Dimensions.space8, vertical: 3),
                    decoration: BoxDecoration(
                      color: hasFile
                          ? appSuccessColor.withValues(alpha: 0.12)
                          : notifires.getBoxColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          hasFile ? Icons.check_circle : Icons.upload_outlined,
                          size: 12,
                          color: hasFile ? appSuccessColor : appMutedTextColor,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          hasFile
                              ? "Uploaded".translate(context)
                              : "Not uploaded".translate(context),
                          style: captionText(context).copyWith(
                            color:
                                hasFile ? appSuccessColor : appMutedTextColor,
                            fontFamily: "Poppins Medium",
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (fileLabel != null && fileLabel.isNotEmpty) ...[
                    const SizedBox(width: Dimensions.space8),
                    Expanded(
                      child: Text(
                        fileLabel,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: captionText(context),
                      ),
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
        const SizedBox(width: Dimensions.space8),
        if (hasFile && onRemove != null)
          InkWell(
            onTap: onRemove,
            borderRadius: BorderRadius.circular(20),
            child: Padding(
              padding: const EdgeInsets.all(6),
              child: Icon(Icons.close_rounded, color: appErrorColor, size: 20),
            ),
          )
        else
          Padding(
            padding: const EdgeInsets.only(top: 2),
            child:
                Text("Add".translate(context), style: linkTextStyle(context)),
          ),
      ],
    );
  }
}
