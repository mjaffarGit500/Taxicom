import 'package:flutter/material.dart';
import '../../../../../core/utils/theme/project_color.dart';
import '../../../../../core/utils/theme/theme_style.dart';

/// Premium summary card shown once enough vehicle data is entered
/// (mirrors the screen's existing `hasEnoughData` gating). Presentation
/// only — receives already-resolved strings, touches no Cubit/Bloc state.
class VehiclePreviewCard extends StatelessWidget {
  final String model;
  final String make;
  final String color;
  final String year;
  final String number;

  const VehiclePreviewCard({
    super.key,
    required this.model,
    required this.make,
    required this.color,
    required this.year,
    required this.number,
  });

  @override
  Widget build(BuildContext context) {
    final List<MapEntry<IconData, String>> chips = [
      if (make.isNotEmpty) MapEntry(Icons.build_outlined, make),
      if (color.isNotEmpty) MapEntry(Icons.palette_outlined, color),
      if (year.isNotEmpty) MapEntry(Icons.event_outlined, year),
      if (number.isNotEmpty)
        MapEntry(Icons.confirmation_number_outlined, number),
    ];

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(Dimensions.space16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            themeColor.withValues(alpha: 0.14),
            themeColor.withValues(alpha: 0.04),
          ],
        ),
        borderRadius: BorderRadius.circular(Dimensions.radiusCard),
        border: Border.all(color: themeColor.withValues(alpha: 0.18)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 48,
            height: 48,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child:
                Icon(Icons.directions_car_rounded, color: themeColor, size: 24),
          ),
          const SizedBox(width: Dimensions.space12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  model.isEmpty ? "-" : model,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: bodyText(context).copyWith(
                    fontFamily: "Poppins SemiBold",
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                    color: notifires.getwhiteblackColor,
                  ),
                ),
                if (chips.isNotEmpty) ...[
                  const SizedBox(height: Dimensions.space8),
                  Wrap(
                    spacing: Dimensions.space8,
                    runSpacing: Dimensions.space8,
                    children: chips
                        .map((chip) =>
                            _PreviewChip(icon: chip.key, label: chip.value))
                        .toList(),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PreviewChip extends StatelessWidget {
  final IconData icon;
  final String label;

  const _PreviewChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
          horizontal: Dimensions.space8, vertical: 4),
      decoration: BoxDecoration(
        color: whiteColor.withValues(alpha: 0.75),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: appBorderColor),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: appMutedTextColor),
          const SizedBox(width: 4),
          Text(label, style: captionText(context)),
        ],
      ),
    );
  }
}
