import 'package:flutter/material.dart';
import '../../../../../core/utils/theme/project_color.dart';
import '../../../../../core/utils/theme/theme_style.dart';

/// Section heading used to give the form a clear visual hierarchy
/// ("Vehicle Identity", "Vehicle Details", "Verification"). Presentation
/// only — carries no state or callbacks.
class SectionHeader extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const SectionHeader({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 32,
          height: 32,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: themeColor.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, size: 16, color: themeColor),
        ),
        const SizedBox(width: Dimensions.space12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title,
                  style: sectionTitleStyle(context).copyWith(fontSize: 15)),
              const SizedBox(height: 2),
              Text(subtitle, style: captionText(context)),
            ],
          ),
        ),
      ],
    );
  }
}

/// Flat rounded card shell shared by the section groups. Presentation
/// only — gives every section the same soft background/border/radius so
/// the screen reads as one consistent, uncluttered system.
class SectionCard extends StatelessWidget {
  final Widget child;

  const SectionCard({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(Dimensions.space16),
      decoration: BoxDecoration(
        color: whiteColor,
        borderRadius: BorderRadius.circular(Dimensions.radiusCard),
        border: Border.all(color: appBorderColor),
      ),
      child: child,
    );
  }
}

/// Small caption-style label placed above a field/dropdown to make the
/// grouped card easier to scan than a bare hint text alone.
class FieldLabel extends StatelessWidget {
  final IconData icon;
  final String text;

  const FieldLabel({super.key, required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: Dimensions.space8, left: 2),
      child: Row(
        children: [
          Icon(icon, size: 14, color: appMutedTextColor),
          const SizedBox(width: Dimensions.space4),
          Text(text, style: inputLabelStyle(context)),
        ],
      ),
    );
  }
}
