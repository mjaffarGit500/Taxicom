import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:path/path.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../../core/utils/common_widget.dart';
import '../../../../core/utils/theme/project_color.dart';
import '../../../../core/utils/theme/theme_style.dart';
import '../../../../domain/entities/get_all_categories.dart';
import '../../../../domain/entities/get_makes.dart';
import '../../../cubits/realtime/manage_driver_cubit.dart';
import '../../../cubits/register_vehicle/get_vehicle_data.dart';
import '../../../cubits/register_vehicle/make_model_cubit.dart';
import '../../../cubits/register_vehicle/single_image_upload_cubit.dart';
import '../../../cubits/register_vehicle/vehicle_register_cubit.dart';
import '../../../widgets/custom_dropdown_widget.dart';
import '../../../widgets/custom_text_form_field.dart';
import 'widgets/section_widgets.dart';
import 'widgets/upload_trigger_card.dart';
import 'widgets/vehicle_preview_card.dart';

class DriverVehicleScreen extends StatefulWidget {
  final bool isEdit;
  const DriverVehicleScreen({
    super.key,
    required this.isEdit,
  });

  @override
  State<DriverVehicleScreen> createState() => _DriverVehicleScreenState();
}

class _DriverVehicleScreenState extends State<DriverVehicleScreen> {
  List<ItemTypes> itemTypes = [];
  List<MakeTypes> makesTypes = [];
  List<String> yearList = [];

  // Track the currently open bottom sheet
  String? currentOpenBottomSheet;
  Timer? autoCloseTimer;

  @override
  void initState() {
    super.initState();
    yearList = getYearList();
  }

  @override
  void dispose() {
    autoCloseTimer?.cancel();
    super.dispose();
  }

  String value1 = "";
  String value2 = "";
  String value3 = "";

  List<String> getYearList() {
    return List.generate(
      DateTime.now().year - 1999,
      (index) => (2000 + index).toString(), // Convert to String
    );
  }

  void openBottomSheet(
      VoidCallback onCloseCallback, BuildContext context, String sheetType) {
    // Only open if no sheet is currently open
    if (currentOpenBottomSheet != null) {
      return;
    }

    currentOpenBottomSheet = sheetType;

    showModalBottomSheet(
      backgroundColor: whiteColor,
      context: context,
      isScrollControlled: true,
      builder: (context) {
        return CustomBottomSheet(
          onClose: () {
            goBack();
            _resetBottomSheetState();
            onCloseCallback();
          },
        );
      },
    ).then((value) {
      _resetBottomSheetState();
    });

    // Auto close after 2 seconds
    autoCloseTimer?.cancel();
    autoCloseTimer = Timer(const Duration(seconds: 1), () {
      if (mounted && currentOpenBottomSheet == sheetType) {
        Navigator.pop(context);
        _resetBottomSheetState();
      }
    });
  }

  void _resetBottomSheetState() {
    if (mounted) {
      autoCloseTimer?.cancel();
      currentOpenBottomSheet = null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocListener(
        listeners: [
          BlocListener<SingleImageUploadCubits, SingleImageUploadState>(
            listener: (context, state) async {
              if (state is SingleImageLoading) {
                Widgets.showLoader(context);
              } else if (state is SingleImageSuccess) {
                Widgets.hideLoder(context);

                // Set image-specific flags and trigger relevant Cubit updates
                if (state.status == "front_image") {
                  context.read<CheckUpdatedImage>().checkUpdatedImage(true);

                  if (currentOpenBottomSheet == null) {
                    openBottomSheet(() {
                      // Callback after sheet closes
                    }, context, "front_image");
                  }
                } else if (state.status == "vehicle_insurance_doc") {
                  context
                      .read<CheckUpdatedLicenceImage>()
                      .checkUpdatedLicenceImage(true);

                  if (currentOpenBottomSheet == null) {
                    openBottomSheet(() {
                      // Callback after sheet closes
                    }, context, "vehicle_insurance_doc");
                  }
                } else if (state.status == 'vehicle_registration_doc') {
                  context
                      .read<CheckUpdatedDocumentImage>()
                      .checkUpdatedDocumentImage(true);

                  if (currentOpenBottomSheet == null) {
                    openBottomSheet(() {
                      // Callback after sheet closes
                    }, context, "vehicle_registration_doc");
                  }
                }

                context.read<SingleImageUploadCubits>().removeSingleImage();
              } else if (state is SingleImageFailure) {
                Widgets.hideLoder(context);
                _resetBottomSheetState();

                if (state.status == "front_image") {
                  context.read<CheckUpdatedImage>().checkUpdatedImage(false);
                } else if (state.status == "vehicle_insurance_doc") {
                  context
                      .read<CheckUpdatedLicenceImage>()
                      .checkUpdatedLicenceImage(false);
                } else if (state.status == "vehicle_registration_doc") {
                  context
                      .read<CheckUpdatedDocumentImage>()
                      .checkUpdatedDocumentImage(false);
                }
              }
            },
          )
        ],
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // ---------------------------------------------------------------
          // Section 1 — Vehicle Identity
          // ---------------------------------------------------------------
          SectionHeader(
            icon: Icons.directions_car_filled_rounded,
            title: "Vehicle Identity".translate(context),
            subtitle:
                "Choose your vehicle type and manufacturer".translate(context),
          ),
          const SizedBox(height: Dimensions.space12),
          SectionCard(
            child: LayoutBuilder(builder: (context, constraints) {
              final bool twoColumn = constraints.maxWidth > 420;

              final Widget typeField =
                  BlocBuilder<GetVehicleDataCubit, GetVehicleDataState>(
                      builder: (context, state) {
                if (state is GetVehicleSuccess) {
                  itemTypes = state.itemTypes;
                }
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    FieldLabel(
                      icon: Icons.category_outlined,
                      text: "Vehicle Type".translate(context),
                    ),
                    CustomDropdownList(
                      checkImage: true,
                      onSelectedImageUrl: (img) {
                        context
                            .read<UpdateDriverParameterCubit>()
                            .updateVehicleImageUrl(
                                vechicleImageUrl: img.toString());
                      },
                      onSelectedValue: (value) {
                        context
                            .read<UpdateDriverParameterCubit>()
                            .updateVehicleTypeName(
                                vehcileTypeName: value.toString());
                      },
                      options: itemTypes,
                      onSelected: (value) {
                        context
                            .read<VehicleFormCubit>()
                            .updateVehicleTypeId(value.toString());
                        context
                            .read<UpdateDriverParameterCubit>()
                            .updateVehicleTypeId(
                                vehicleTypeId: value.toString());
                        context
                            .read<MakeModelCubit>()
                            .getMakeModel(context: context, value: value);
                        context
                            .read<VehicleFormCubit>()
                            .textEditingVehicleModelController
                            .clear();
                      },
                      hintText: "Vehicle Type".translate(context),
                      checkmarkColor: themeColor,
                      selectedEditInitialValue:
                          context.read<VehicleFormCubit>().state.vehicleTypeId,
                    ),
                  ],
                );
              });

              final Widget makeField =
                  BlocBuilder<MakeModelCubit, MakeModelState>(
                      builder: (context, state) {
                if (state is MakeModelSuccess) {
                  makesTypes = state.makeType;
                }

                return BlocListener<VehicleFormCubit, VehicleFormState>(
                  listener: (context, vehicleState) {},
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      FieldLabel(
                        icon: Icons.build_outlined,
                        text: "Vehicle Make".translate(context),
                      ),
                      CustomDropdownList(
                        key: ValueKey(context
                            .read<VehicleFormCubit>()
                            .state
                            .vehicleTypeId),
                        checkImage: false,
                        onSelectedImageUrl: (img) {},
                        onSelectedValue: (value) {
                          context
                              .read<UpdateDriverParameterCubit>()
                              .updateVehicleMake(vechileMake: value);
                        },
                        options: makesTypes,
                        checkMake: true,
                        selectedEditInitialValue:
                            context.read<VehicleFormCubit>().state.vehicleMake,
                        onSelected: (value) {
                          context
                              .read<VehicleFormCubit>()
                              .updateVehicleMake(value.toString());
                        },
                        hintText: "Vehicle Make".translate(context),
                        checkmarkColor: themeColor,
                      ),
                    ],
                  ),
                );
              });

              if (!twoColumn) {
                return Column(
                  children: [
                    typeField,
                    const SizedBox(height: Dimensions.space16),
                    makeField,
                  ],
                );
              }

              return Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(child: typeField),
                  const SizedBox(width: Dimensions.space12),
                  Expanded(child: makeField),
                ],
              );
            }),
          ),
          const SizedBox(height: Dimensions.space20),

          // ---------------------------------------------------------------
          // Section 2 — Vehicle Details
          // ---------------------------------------------------------------
          SectionHeader(
            icon: Icons.assignment_outlined,
            title: "Vehicle Details".translate(context),
            subtitle:
                "Model, registration number, color and year".translate(context),
          ),
          const SizedBox(height: Dimensions.space12),
          BlocBuilder<VehicleFormCubit, VehicleFormState>(
            builder: (context, state) {
              final vehicleCubit = context.read<VehicleFormCubit>();

              return SectionCard(
                child: Column(
                  children: [
                    FieldLabel(
                      icon: Icons.directions_car_outlined,
                      text: "Vehicle Model".translate(context),
                    ),
                    TextFieldAdvance(
                        cumpulsoryIcon: true,
                        textStyle: inputTextStyle(context),
                        txt: "Vehicle Model".translate(context),
                        hintStyle: inputHintStyle(context),
                        inputFormatters: [
                          UpperCaseTextFormatter(), // 👈 Add this
                        ],
                        textEditingControllerCommon:
                            vehicleCubit.textEditingVehicleModelController,
                        inputType: TextInputType.text,
                        onChange: (value) {
                          vehicleCubit.updateVehicleModel(value!);
                          context
                              .read<UpdateDriverParameterCubit>()
                              .updateVehicleModel(vechileModel: value);
                          return null;
                        },
                        inputAlignment: TextAlign.start),
                    const SizedBox(height: Dimensions.space16),
                    FieldLabel(
                      icon: Icons.confirmation_number_outlined,
                      text: "Vehicle Number".translate(context),
                    ),
                    TextFieldAdvance(
                        cumpulsoryIcon: true,
                        textStyle: inputTextStyle(context),
                        txt: "Vehicle Number".translate(context),
                        hintStyle: inputHintStyle(context),
                        textEditingControllerCommon:
                            vehicleCubit.textEditingVehicleNumberController,
                        inputType: TextInputType.text,
                        inputFormatters: [
                          UpperCaseTextFormatter(), // 👈 Add this
                        ],
                        onChange: (value) {
                          vehicleCubit.updateVehicleNumber(value!);
                          context
                              .read<UpdateDriverParameterCubit>()
                              .updateVehicleNumber(vechileNumber: value);
                          return null;
                        },
                        inputAlignment: TextAlign.start),
                    const SizedBox(height: Dimensions.space16),
                    FieldLabel(
                      icon: Icons.palette_outlined,
                      text: "Vehicle Color".translate(context),
                    ),
                    TextFieldAdvance(
                        cumpulsoryIcon: true,
                        textStyle: inputTextStyle(context),
                        txt: "Vehicle Color".translate(context),
                        hintStyle: inputHintStyle(context),
                        textEditingControllerCommon:
                            vehicleCubit.textEditingVehicleColorController,
                        inputType: TextInputType.text,
                        onChange: (value) {
                          vehicleCubit.updateVehicleColor(value!);
                          context
                              .read<UpdateDriverParameterCubit>()
                              .updateVehicleColor(color: value);
                          return null;
                        },
                        inputAlignment: TextAlign.start),
                    const SizedBox(height: Dimensions.space16),
                    FieldLabel(
                      icon: Icons.event_outlined,
                      text: "Vehicle Year".translate(context),
                    ),
                    CustomDropdown(
                      options: yearList,
                      onSelected: (value) {
                        vehicleCubit.updateVehicleYear(value);
                      },
                      selectedEditInitialValue:
                          vehicleCubit.state.vehicleYear.isEmpty
                              ? null
                              : vehicleCubit.state.vehicleYear,
                      hintText: "Vehicle Year".translate(context),
                      checkmarkColor: themeColor,
                    ),
                  ],
                ),
              );
            },
          ),
          const SizedBox(height: Dimensions.space20),

          // ---------------------------------------------------------------
          // Vehicle preview card
          // ---------------------------------------------------------------
          BlocBuilder<VehicleFormCubit, VehicleFormState>(
            builder: (context, state) {
              final vehicleCubit = context.read<VehicleFormCubit>();
              final String model =
                  vehicleCubit.textEditingVehicleModelController.text;
              final String number =
                  vehicleCubit.textEditingVehicleNumberController.text;
              final bool hasEnoughData =
                  state.vehicleMake.isNotEmpty && model.isNotEmpty;

              if (!hasEnoughData) return const SizedBox();

              return Padding(
                padding: const EdgeInsets.only(bottom: Dimensions.space20),
                child: VehiclePreviewCard(
                  model: model.trim(),
                  make: state.vehicleMake,
                  color: state.vehicleColor,
                  year: state.vehicleYear,
                  number: number,
                ),
              );
            },
          ),

          // ---------------------------------------------------------------
          // Section 3 — Verification Documents
          // ---------------------------------------------------------------
          SectionHeader(
            icon: Icons.verified_user_outlined,
            title: "Verification".translate(context),
            subtitle: "Upload the documents required to verify your vehicle"
                .translate(context),
          ),
          const SizedBox(height: Dimensions.space12),
          Column(
            children: [
              InkWell(
                borderRadius: BorderRadius.circular(Dimensions.radiusCard),
                onTap: () {
                  showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    backgroundColor: Colors.transparent,
                    builder: (context) => CustomBottomSheetVechicle(
                      SourceType: "Document",
                      title: "Upload Vehicle Document".translate(context),
                      descrption:
                          "Securely Upload Your Document".translate(context),
                      imageUrl: context.read<SetDocImage>().state,
                      onTap: () {
                        final vehicleFormState =
                            context.read<VehicleFormCubit>().state;
                        goBack();
                        setState(() {});

                        if (context
                                    .read<UpdateAddEditVehicleIdCubit>()
                                    .state
                                    .vehicleAddEditTypeId !=
                                null &&
                            context
                                    .read<UpdateAddEditVehicleIdCubit>()
                                    .state
                                    .vehicleAddEditTypeId !=
                                0) {
                          context
                              .read<SingleImageUploadCubits>()
                              .uploadSingleImage(
                                  context: context,
                                  itemId: context
                                      .read<UpdateAddEditVehicleIdCubit>()
                                      .state
                                      .vehicleAddEditTypeId
                                      .toString(),
                                  status: "vehicle_registration_doc",
                                  itemImageMap: {
                                'vehicle_registration_doc':
                                    vehicleFormState.vehicleDocBase64Image,
                              });
                        } else {
                          showErrorToastMessage(
                              "Vehicle ID is not being received.");
                        }
                      },
                    ),
                  );
                },
                child: BlocBuilder<CheckUpdatedDocumentImage, bool?>(
                    builder: (context, value) {
                  return BlocBuilder<UpdateDocImage, XFile?>(
                      builder: (context, image) {
                    if (image == null) {
                      return BlocBuilder<SetDocImage, String>(
                          builder: (context, imageUrl) {
                        if (imageUrl.isNotEmpty) {
                          context
                              .read<CheckUpdatedDocumentImage>()
                              .checkUpdatedDocumentImage(true);
                        }
                        return UploadTriggerCard(
                          uploaded: imageUrl.isNotEmpty,
                          label: "Vehicle Document".translate(context),
                          description:
                              "Registration certificate of your vehicle"
                                  .translate(context),
                          icon: Icons.description_outlined,
                          existingImageUrl:
                              imageUrl.isNotEmpty ? imageUrl : null,
                        );
                      });
                    }

                    return UploadTriggerCard(
                      uploaded: true,
                      label: "Vehicle Document".translate(context),
                      description: "Registration certificate of your vehicle"
                          .translate(context),
                      icon: Icons.description_outlined,
                      localFileName: basename(image.path),
                      onRemove: () {
                        context.read<UpdateDocImage>().removeImage();
                        context
                            .read<CheckUpdatedDocumentImage>()
                            .removeImageDocumentStatus();
                      },
                    );
                  });
                }),
              ),
              const SizedBox(height: Dimensions.space12),
              InkWell(
                borderRadius: BorderRadius.circular(Dimensions.radiusCard),
                onTap: () {
                  showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    backgroundColor: Colors.transparent,
                    builder: (context) => CustomBottomSheetVechicle(
                      SourceType: "licence",
                      imageUrl: context.read<SetInsuranceImage>().state,
                      title:
                          "Upload Vehicle license details".translate(context),
                      descrption: "Securely Upload Your license details"
                          .translate(context),
                      onTap: () {
                        final vehicleFormState =
                            context.read<VehicleFormCubit>().state;
                        goBack();
                        setState(() {});

                        if (context
                                    .read<UpdateAddEditVehicleIdCubit>()
                                    .state
                                    .vehicleAddEditTypeId !=
                                null &&
                            context
                                    .read<UpdateAddEditVehicleIdCubit>()
                                    .state
                                    .vehicleAddEditTypeId !=
                                0) {
                          context
                              .read<SingleImageUploadCubits>()
                              .uploadSingleImage(
                                  context: context,
                                  itemId:
                                      context
                                          .read<UpdateAddEditVehicleIdCubit>()
                                          .state
                                          .vehicleAddEditTypeId
                                          .toString(),
                                  status: "vehicle_insurance_doc",
                                  itemImageMap: {
                                "vehicle_insurance_doc":
                                    vehicleFormState.vehicleLicenceBase64Image
                              });
                        } else {
                          showErrorToastMessage(
                              "Vehicle ID is not being received.");
                        }
                      },
                    ),
                  );
                },
                child: BlocBuilder<CheckUpdatedLicenceImage, bool?>(
                    builder: (context, value) {
                  return BlocBuilder<UpdateLicenceImage, XFile?>(
                      builder: (context, image) {
                    if (image == null) {
                      return BlocBuilder<SetInsuranceImage, String>(
                          builder: (context, imageUrl) {
                        if (imageUrl.isNotEmpty) {
                          context
                              .read<CheckUpdatedLicenceImage>()
                              .checkUpdatedLicenceImage(true);
                        }
                        return UploadTriggerCard(
                          uploaded: imageUrl.isNotEmpty,
                          label: "license, insurance, vehicle details"
                              .translate(context),
                          description:
                              "Driving license, insurance and vehicle details"
                                  .translate(context),
                          icon: Icons.shield_outlined,
                          existingImageUrl:
                              imageUrl.isNotEmpty ? imageUrl : null,
                        );
                      });
                    }

                    return UploadTriggerCard(
                      uploaded: true,
                      label: "license, insurance, vehicle details"
                          .translate(context),
                      description:
                          "Driving license, insurance and vehicle details"
                              .translate(context),
                      icon: Icons.shield_outlined,
                      localFileName: basename(image.path),
                      onRemove: () {
                        context
                            .read<CheckUpdatedLicenceImage>()
                            .removeImageLicenceStatus();
                        context.read<UpdateLicenceImage>().removeImage();
                      },
                    );
                  });
                }),
              ),
              const SizedBox(height: Dimensions.space12),
              InkWell(
                borderRadius: BorderRadius.circular(Dimensions.radiusCard),
                onTap: () {
                  showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    backgroundColor: Colors.transparent,
                    builder: (context) => CustomBottomSheetVechicle(
                      SourceType: "VehicleImg",
                      imageUrl: context.read<SetVehicleImage>().state,
                      title: "Securely upload your vehicle images"
                          .translate(context),
                      descrption: "Please add an external photo of your vehicle"
                          .translate(context),
                      onTap: () {
                        final vehicleFormState =
                            context.read<VehicleFormCubit>().state;
                        goBack();
                        setState(() {});

                        if (context
                                    .read<UpdateAddEditVehicleIdCubit>()
                                    .state
                                    .vehicleAddEditTypeId !=
                                null &&
                            context
                                    .read<UpdateAddEditVehicleIdCubit>()
                                    .state
                                    .vehicleAddEditTypeId !=
                                0) {
                          context
                              .read<SingleImageUploadCubits>()
                              .uploadSingleImage(
                                  context: context,
                                  itemId:
                                      context
                                          .read<UpdateAddEditVehicleIdCubit>()
                                          .state
                                          .vehicleAddEditTypeId
                                          .toString(),
                                  status: "front_image",
                                  itemImageMap: {
                                "front_image":
                                    vehicleFormState.vehicleBase64Image
                              });
                        } else {
                          showErrorToastMessage(
                              "Vehicle ID is not being received.");
                        }
                      },
                    ),
                  );
                },
                child: BlocBuilder<CheckUpdatedImage, bool?>(
                    builder: (context, value) {
                  return BlocBuilder<UpdateImage, XFile?>(
                      builder: (context, image) {
                    if (image == null) {
                      return BlocBuilder<SetVehicleImage, String>(
                          builder: (context, imageUrl) {
                        if (imageUrl.isNotEmpty) {
                          context
                              .read<CheckUpdatedImage>()
                              .checkUpdatedImage(true);
                        }
                        return UploadTriggerCard(
                          uploaded: imageUrl.isNotEmpty,
                          label: "Vehicle Image".translate(context),
                          description: "An external photo of your vehicle"
                              .translate(context),
                          icon: Icons.directions_car_filled_outlined,
                          existingImageUrl:
                              imageUrl.isNotEmpty ? imageUrl : null,
                        );
                      });
                    }

                    return UploadTriggerCard(
                      uploaded: true,
                      label: "Vehicle Image".translate(context),
                      description: "An external photo of your vehicle"
                          .translate(context),
                      icon: Icons.directions_car_filled_outlined,
                      localFileName: basename(image.path),
                      onRemove: () {
                        context.read<UpdateImage>().removeImage();
                        context.read<CheckUpdatedImage>().removeImageStatus();
                      },
                    );
                  });
                }),
              ),
            ],
          ),
        ]));
  }
}
