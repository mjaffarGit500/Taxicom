import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:ride_on_driver/core/utils/theme/theme_style.dart';
import 'package:shimmer/shimmer.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../core/extensions/workspace.dart';
import '../../../core/services/data_store.dart';
import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../domain/entities/get_item_vehicle.dart';
import '../../../domain/entities/get_makes.dart';
import '../../cubits/register_vehicle/get_vehicle_data.dart';
import '../../cubits/register_vehicle/make_model_cubit.dart';

class VehicleInformationScreen extends StatefulWidget {
  const VehicleInformationScreen({super.key});

  @override
  State<VehicleInformationScreen> createState() =>
      _VehicleInformationScreenState();
}

class _VehicleInformationScreenState extends State<VehicleInformationScreen> {
  Items? itemVehicleModel;
  List<MakeTypes> makeType = [];
  String selectedMake = "";

  @override
  void initState() {
    super.initState();
    context
        .read<GetItemVehicleDataCubit>()
        .getVehicleItemData(context: context);
    context.read<GetVehicleDataCubit>().getAllCategories(context: context);
    context.read<MakeModelCubit>().getMakeModel(
          context: context,
          value: box.get("UpdatedItemId") ?? (loginModel?.data?.itemTypeId ?? "").toString(),
        );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F4EC),
      appBar: CustomAppBars(
          title: "Vehicle Information",
          backgroundColor: notifires.getbgcolor,
          titleColor: notifires.getGrey1whiteColor),
      body: BlocBuilder<GetItemVehicleDataCubit, GetItemVehicleDataState>(
        builder: (context, state) {
          if (state is GetItemLoading) {
            return const VehicleInformationShimmer();
          } else if (state is GetItemSuccess) {
            itemVehicleModel = state.getItemVehicleModel.data?.items?.first;
            context.read<GetItemVehicleDataCubit>().clear();
          } else if (state is GetItemFailure) {
            showErrorToastMessage(state.error);
          }

          return BlocBuilder<MakeModelCubit, MakeModelState>(
            builder: (context, makeState) {
              if (makeState is MakeModelSuccess) {
                makeType = makeState.makeType;
                for (var e in makeType) {
                  if (e.id.toString() ==
                      itemVehicleModel?.vehicleMake.toString()) {
                    selectedMake = e.name ?? "N/A";
                  }
                }
              }

              return Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      const Color(0xFFF8F4EC),
                      themeColor.withValues(alpha: 0.10),
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
                child: SingleChildScrollView(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildVehicleImageCard(context),
                      const SizedBox(height: 18),
                      _buildVehicleInfoCard(context),
                      const SizedBox(height: 12),
                      _buildVehicleDocCard(context),
                    ],
                  ).animate().fadeIn(duration: 300.ms, curve: Curves.easeOut),
                ),
              );
            },
          );
        },
      ),
    );
  }

  /// Enhanced Vehicle Image Card with Modern Design
  Widget _buildVehicleImageCard(BuildContext context) {
    final imageUrl = itemVehicleModel?.frontImage?.url ?? "";

    return InkWell(
      onTap: () => _openImagePreview(
        imageUrl: imageUrl,
        title: "Vehicle".translate(context),
      ),
      borderRadius: BorderRadius.circular(24),
      child: Card(
        elevation: 8,
        shadowColor: Colors.black.withValues(alpha: 0.16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          children: [
            CachedNetworkImage(
              imageUrl: imageUrl,
              height: 220,
              width: double.infinity,
              fit: BoxFit.cover,
              placeholder: (context, url) => Shimmer.fromColors(
                baseColor: Colors.grey[300]!,
                highlightColor: Colors.grey[100]!,
                child: Container(
                  color: Colors.grey[200],
                  height: 220,
                ),
              ),
              errorWidget: (context, url, error) => Container(
                color: Colors.grey[200],
                alignment: Alignment.center,
                child: const Icon(Icons.directions_car,
                    color: Colors.black38, size: 44),
              ),
            ),
            Container(
              height: 220,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.black.withValues(alpha: 0.75),
                    Colors.black.withValues(alpha: 0.10),
                  ],
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                ),
              ),
            ),
            Positioned(
              top: 12,
              right: 12,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.90),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.zoom_in_rounded,
                        size: 14, color: Colors.black87),
                    const SizedBox(width: 4),
                    Text(
                      "View".translate(context),
                      style: regular(context).copyWith(
                        fontSize: 10,
                        color: Colors.black87,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              bottom: 16,
              left: 16,
              right: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    itemVehicleModel?.vehicleNumber ?? "N/A",
                    style: heading2Grey1(context).copyWith(
                      color: Colors.white,
                      fontSize: 19,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    "${itemVehicleModel?.vehicleModel ?? "Unknown"} • ${itemVehicleModel?.vehicleYear ?? ""}",
                    style: heading3Grey1(context).copyWith(
                      color: Colors.white.withValues(alpha: 0.9),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    )
        .animate()
        .slideY(begin: 0.3, end: 0, duration: 800.ms, curve: Curves.easeOut);
  }

  Widget _buildVehicleDocCard(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: _buildDocPreviewCard(
            title: "Vehicle Licence".translate(context),
            imageUrl: itemVehicleModel?.itemInsuranceDoc?.url ?? "",
            icon: Icons.verified_user_rounded,
            iconColor: const Color(0xFFB26A00),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildDocPreviewCard(
            title: "Vehicle Document".translate(context),
            imageUrl: itemVehicleModel?.frontImageDoc?.url ?? "",
            icon: Icons.description_rounded,
            iconColor: const Color(0xFF096B64),
          ),
        ),
      ],
    ).animate().fadeIn(
          duration: 1000.ms,
          delay: 300.ms,
          curve: Curves.easeOut,
        );
  }

  Widget _buildVehicleInfoCard(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 16, 14, 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: themeColor.withValues(alpha: 0.14)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.07),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: themeColor.withValues(alpha: 0.18),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(Icons.tune_rounded, color: blackColor, size: 18),
              ),
              const SizedBox(width: 8),
              Text(
                "Vehicle Details".translate(context),
                style: heading2Grey1(context).copyWith(
                  fontSize: 17,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: buildInfoTile(
                  icon: CupertinoIcons.number_circle_fill,
                  label: "Vehicle No.",
                  value: itemVehicleModel?.vehicleNumber ?? "NA",
                  iconColor: const Color(0xFF5B3FBE),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: buildInfoTile(
                  icon: Icons.branding_watermark_rounded,
                  label: "Make",
                  value: selectedMake,
                  iconColor: const Color(0xFF007D77),
                ),
              ),
            ],
          ),
          Row(
            children: [
              Expanded(
                child: buildInfoTile(
                  icon: Icons.directions_car_filled_rounded,
                  label: "Model",
                  value: itemVehicleModel?.vehicleModel ?? "NA",
                  iconColor: const Color(0xFF3F5FAD),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: buildInfoTile(
                  icon: Icons.local_shipping_rounded,
                  label: "Type",
                  value: itemVehicleModel?.vehicleType ?? "NA",
                  iconColor: const Color(0xFFC46500),
                ),
              ),
            ],
          ),
          Row(
            children: [
              Expanded(
                child: buildInfoTile(
                  icon: Icons.calendar_month_rounded,
                  label: "Year",
                  value: itemVehicleModel?.vehicleYear ?? "NA",
                  iconColor: const Color(0xFFB3477D),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: buildInfoTile(
                  icon: Icons.palette_rounded,
                  label: "Color",
                  value: itemVehicleModel?.vehicleColor ?? "NA",
                  iconColor: const Color(0xFFA03A2B),
                ),
              ),
            ],
          ),
        ],
      ),
    ).animate().fadeIn(duration: 1000.ms, delay: 300.ms, curve: Curves.easeOut);
  }

  Widget buildInfoTile({
    required IconData icon,
    required String label,
    required String value,
    required Color iconColor,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFCF6),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: iconColor.withValues(alpha: 0.16)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 17,
            backgroundColor: iconColor.withValues(alpha: .16),
            child: Icon(icon, color: iconColor, size: 16),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label.translate(context),
                    style: TextStyle(fontSize: 11, color: Colors.grey[700])),
                const SizedBox(height: 2),
                Text(value,
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87)),
              ],
            ),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 800.ms, delay: 200.ms);
  }

  Widget _buildDocPreviewCard({
    required String title,
    required String imageUrl,
    required IconData icon,
    required Color iconColor,
  }) {
    return InkWell(
      onTap: () => _openImagePreview(imageUrl: imageUrl, title: title),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: iconColor.withValues(alpha: 0.18)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.06),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(16)),
              child: CachedNetworkImage(
                imageUrl: imageUrl,
                height: 118,
                width: double.infinity,
                fit: BoxFit.cover,
                placeholder: (context, url) => Shimmer.fromColors(
                  baseColor: Colors.grey[300]!,
                  highlightColor: Colors.grey[100]!,
                  child: Container(
                    color: Colors.grey[200],
                    height: 118,
                  ),
                ),
                errorWidget: (context, url, error) => Container(
                  color: Colors.grey[200],
                  height: 118,
                  alignment: Alignment.center,
                  child: const Icon(Icons.image_not_supported_rounded,
                      color: Colors.black38, size: 26),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 8, 10),
              child: Row(
                children: [
                  Container(
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      color: iconColor.withValues(alpha: 0.16),
                      borderRadius: BorderRadius.circular(7),
                    ),
                    child: Icon(icon, color: iconColor, size: 14),
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      title,
                      style: regular(context).copyWith(
                        fontSize: 11,
                        color: Colors.black87,
                        fontWeight: FontWeight.w700,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openImagePreview({required String imageUrl, required String title}) {
    if (imageUrl.trim().isEmpty) return;
    goTo(_FullImagePreviewScreen(imageUrl: imageUrl, title: title));
  }
}

class _FullImagePreviewScreen extends StatelessWidget {
  final String imageUrl;
  final String title;

  const _FullImagePreviewScreen({required this.imageUrl, required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.close_rounded, color: Colors.white),
          onPressed: () => goBack(),
        ),
        title: Text(
          title,
          style: heading3Grey1(context).copyWith(color: Colors.white),
        ),
      ),
      body: Center(
        child: InteractiveViewer(
          minScale: 0.9,
          maxScale: 4.0,
          child: CachedNetworkImage(
            imageUrl: imageUrl,
            fit: BoxFit.contain,
            placeholder: (context, url) => const CircularProgressIndicator(
              color: Colors.white,
            ),
            errorWidget: (context, url, error) => const Icon(
              Icons.broken_image_rounded,
              size: 44,
              color: Colors.white70,
            ),
          ),
        ),
      ),
    );
  }
}
