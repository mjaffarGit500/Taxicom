import 'package:flutter/material.dart';
import 'package:ride_on_driver/core/utils/translate.dart';

import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';

class DriverFAQScreen extends StatefulWidget {
  const DriverFAQScreen({super.key});

  @override
  State<DriverFAQScreen> createState() => _DriverFAQScreenState();
}

class _DriverFAQScreenState extends State<DriverFAQScreen> {
  final List<Map<String, String>> faqList = [
    {
      "question": "How do I start receiving ride requests?",
      "answer":
          "Set your status to 'Online' to begin receiving nearby ride requests from passengers."
    },
    {
      "question": "How can I accept or reject a ride?",
      "answer":
          "Tap 'Accept' when a ride request appears. Ignore it if you don't wish to accept."
    },
    {
      "question": "What if the rider doesn’t show up?",
      "answer":
          "Wait 5-10 minutes, then cancel with the reason 'Rider No-show'."
    },
    {
      "question": "When do I get paid for completed rides?",
      "answer":
          "Payments reflect instantly in your wallet after each completed ride."
    },
    {
      "question": "How do I withdraw my wallet balance?",
      "answer":
          "Go to 'Wallet' > 'Withdraw', enter the amount, and confirm your bank account."
    },
    {
      "question": "Which documents are required to drive?",
      "answer":
          "Driving license, RC, insurance, and identity proof are mandatory."
    },
    {
      "question": "What if the app stops working?",
      "answer":
          "Restart your phone and check internet connection. Use 'Help' for support."
    },
    {
      "question": "Can I cancel a ride after accepting?",
      "answer":
          "Yes, with a valid reason. But frequent cancellations can affect your ratings."
    },
  ];

  int? _expandedIndex;

  @override
  Widget build(BuildContext context) {
    final isDark = notifires.getIsDark;

    return Scaffold(
      backgroundColor: notifires.getbgcolor,
      appBar: CustomAppBars(
        title: "FAQs",
        backgroundColor: notifires.getbgcolor,
        titleColor: notifires.getGrey1whiteColor,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
              itemCount: faqList.length,
              itemBuilder: (context, index) {
                return _buildFaqCard(index, isDark);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFaqCard(int index, bool isDark) {
    final faq = faqList[index];
    final isExpanded = _expandedIndex == index;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
        decoration: BoxDecoration(
          color: notifires.getcardcolor,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: isExpanded
                ? themeColor.withValues(alpha: .6)
                : Colors.transparent,
            width: 1.4,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? .28 : .05),
              blurRadius: isExpanded ? 16 : 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () {
              setState(() {
                _expandedIndex = isExpanded ? null : index;
              });
            },
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: themeColor.withValues(
                              alpha: isExpanded ? .22 : .12),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(
                          Icons.help_outline_rounded,
                          color: themeColor,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          faq["question"]!.translate(context),
                          style: TextStyle(
                            fontSize: 15.5,
                            fontWeight: FontWeight.w600,
                            color: notifires.getGrey1whiteColor,
                            height: 1.3,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      AnimatedRotation(
                        duration: const Duration(milliseconds: 220),
                        turns: isExpanded ? 0.5 : 0,
                        child: Icon(
                          Icons.keyboard_arrow_down_rounded,
                          color: isExpanded
                              ? themeColor
                              : notifires.getGrey3whiteColor,
                        ),
                      ),
                    ],
                  ),
                  AnimatedCrossFade(
                    duration: const Duration(milliseconds: 220),
                    crossFadeState: isExpanded
                        ? CrossFadeState.showFirst
                        : CrossFadeState.showSecond,
                    firstChild: Padding(
                      padding: const EdgeInsets.only(top: 12, left: 44),
                      child: Text(
                        faq["answer"]!.translate(context),
                        style: TextStyle(
                          fontSize: 14,
                          color: notifires.getGrey3whiteColor,
                          height: 1.5,
                        ),
                      ),
                    ),
                    secondChild: const SizedBox(width: double.infinity),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
