import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../core/extensions/workspace.dart';
import '../../../core/services/data_store.dart';
import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../../domain/entities/login.dart' as logmod;
import '../../cubits/account/update_profile_cubit.dart';
import '../../cubits/auth/email_otp_cubit.dart';
import '../../cubits/auth/otp_verify_cubit.dart';
import '../../cubits/auth/user_authenticate_cubit.dart';
import '../../cubits/realtime/manage_driver_cubit.dart';
import '../../widgets/custom_dropdown_widget.dart';
import '../../widgets/custom_text_form_field.dart';
import '../../widgets/primary_button.dart';
import '../auth/email_update_screen.dart';
import '../auth/phone_update_screen.dart';

class EditProfile extends StatefulWidget {
  const EditProfile({super.key});

  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  File? image;
  final picker = ImagePicker();

  TextEditingController textEditingEditProfileNameController =
      TextEditingController();
  TextEditingController textEditingEditProfileEmailController =
      TextEditingController();
  TextEditingController textEditingEditProfileNumberController =
      TextEditingController();

  @override
  void initState() {
    super.initState();

    if (loginModel!.data != null && loginModel!.data!.gender != null) {
      final gender = loginModel!.data!.gender;
      context.read<GenderCubit>().genderUpdate(gender: gender);
    }
    textEditingEditProfileNameController.text =
        loginModel?.data?.firstName ?? "";
    textEditingEditProfileNumberController.text = loginModel?.data?.phone ?? "";
    textEditingEditProfileEmailController.text = loginModel?.data?.email ?? "";

   }

  Future<void> pickImage(ImageSource source) async {
    final pickedFile = await picker.pickImage(source: source);
    if (pickedFile != null) {
      final base64Img = await compressAndUploadImage(pickedFile.path);
      setState(() {
        image = File(pickedFile.path);
      });
      // ignore: use_build_context_synchronously
      context.read<UpdateProfileCubit>().uploadProfileImage(postData: {
        "profile_image": base64Img,
      });
    }
  }

  List<String> optionsList = ["Male", "Female", "Others"];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: notifires.getbgcolor,
      body: SafeArea(
        child: BlocBuilder<UpdateProfileCubit, UpdateProfileState>(
            builder: (context, state) {
          if (state is UpdateProfileLoading) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              Widgets.showLoader(context);
            });
          } else if (state is UpdateProfileSuccess) {
            Widgets.hideLoder(context);
            String storedData = box.get("UserData");
            loginModel = logmod.LoginModel.fromJson(jsonDecode(storedData));
            loginModel!.data?.firstNameSetter =
                state.loginModel.data?.firstName ?? "";
            loginModel!.data?.lastNameSetter =
                state.loginModel.data?.lastName ?? "";
            loginModel!.data?.gender = state.loginModel.data?.gender ?? "";
            UserData userObj = UserData();
            userObj.saveLoginData("UserData", jsonEncode(loginModel!.toJson()));
            context.read<UpdateProfileCubit>().clear();
            context
                .read<NameCubit>()
                .updateName("${state.loginModel.data!.firstName}");

            showToastMessage(state.loginModel.message ?? "");
          } else if (state is UpdateProfileImageSuccess) {
            Widgets.hideLoder(context);

            String storedImageData = box.get("UserData");
            loginModel =
                logmod.LoginModel.fromJson(jsonDecode(storedImageData));
            loginModel!.data?.profileImageSetter = state.imageUrl;
            myImage = state.imageUrl;
            context.read<MyImageCubit>().updateMyImage(myImage);
            context.read<UpdateDriverCubit>().updateFirebaseImageUrl(
                driverImageUrl: state.imageUrl,
                driverId:
                    context.read<UpdateDriverParameterCubit>().state.driverId);

            UserData userObj = UserData();
            userObj.saveLoginData("UserData", jsonEncode(loginModel!.toJson()));
          } else if (state is UpdateProfileFailed) {
            Widgets.hideLoder(context);

            showErrorToastMessage(state.error);
            context.read<UpdateProfileCubit>().clear();
          }
          return Column(
            children: [
              _buildHeader(context),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(
                      Dimensions.space20,
                      Dimensions.space8,
                      Dimensions.space20,
                      Dimensions.space20),
                  child: Column(
                    children: [
                      _buildProfileHeader(context),
                      const SizedBox(height: Dimensions.space24),
                      _buildFormCard(context),
                    ],
                  ),
                ),
              ),
              _buildBottomButton(context),
            ],
          );
        }),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(Dimensions.space16, Dimensions.space12,
          Dimensions.space16, Dimensions.space8),
      child: SizedBox(
        height: 40,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => goBack(),
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: notifires.getboxcolor,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: appBorderColor),
                  ),
                  child: Icon(Icons.arrow_back_ios_new_rounded,
                      size: 16, color: notifires.getwhiteblackColor),
                ),
              ),
            ),
            Text(
              "Edit Profile".translate(context),
              style: sectionTitleStyle(context).copyWith(fontSize: 17),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileHeader(BuildContext context) {
    return Column(
      children: [
        Stack(
          alignment: Alignment.bottomRight,
          children: [
            Container(
              width: 116,
              height: 116,
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                    color: themeColor.withValues(alpha: 0.5), width: 2),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.06),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: image != null
                  ? ClipOval(
                      child: Image.file(image!,
                          fit: BoxFit.cover, width: 110, height: 110),
                    )
                  : myImage.isNotEmpty
                      ? ClipOval(child: myNetworkImage(myImage))
                      : Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: themeColor.withValues(alpha: 0.12),
                          ),
                          child: Icon(
                            CupertinoIcons.profile_circled,
                            size: 64,
                            color: themeColor,
                          ),
                        ),
            ),
            GestureDetector(
              onTap: () => _showProfileImagePickerSheet(context),
              child: Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  color: blackColor,
                  shape: BoxShape.circle,
                  border: Border.all(color: notifires.getbgcolor, width: 3),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.18),
                      blurRadius: 8,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.camera_alt_outlined,
                  color: Colors.white,
                  size: 16,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: Dimensions.space12),
        Text("Update your profile photo".translate(context),
            style: captionText(context)),
        const SizedBox(height: Dimensions.space16),
        _buildProfileSummary(context),
      ],
    );
  }

  Widget _buildProfileSummary(BuildContext context) {
    final String name = loginModel?.data?.firstName ?? "";
    final String email = loginModel?.data?.email ?? "";
    final String phone = loginModel?.data?.phone ?? "";
    final String subtitle = email.isNotEmpty ? email : phone;

    if (name.isEmpty && subtitle.isEmpty) return const SizedBox();

    return Column(
      children: [
        if (name.isNotEmpty)
          Text(name, style: sectionTitleStyle(context).copyWith(fontSize: 17)),
        if (subtitle.isNotEmpty) ...[
          const SizedBox(height: 2),
          Text(subtitle, style: captionText(context)),
        ],
      ],
    );
  }

  Widget _buildFormCard(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle(context, "Personal Information"),
        const SizedBox(height: Dimensions.space12),
        _buildNameField(context),
        const SizedBox(height: Dimensions.space24),
        _buildSectionTitle(context, "Contact Information"),
        const SizedBox(height: Dimensions.space12),
        _buildEmailField(context),
        const SizedBox(height: Dimensions.space12),
        _buildPhoneField(context),
        const SizedBox(height: Dimensions.space24),
        _buildSectionTitle(context, "Additional Information"),
        const SizedBox(height: Dimensions.space12),
        _buildGenderField(context),
      ],
    );
  }

  Widget _buildSectionTitle(BuildContext context, String label) {
    return Text(label.translate(context),
        style: sectionTitleStyle(context).copyWith(fontSize: 14));
  }

  Widget _buildFieldLabel(BuildContext context, String label) {
    return Text(label.translate(context), style: inputLabelStyle(context));
  }

  Widget _buildNameField(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildFieldLabel(context, "Name"),
        const SizedBox(height: Dimensions.space8),
        TextFieldAdvance(
            icons:
                Icon(Icons.person_outline, color: notifires.getGrey3whiteColor),
            txt: "Enter Your Name".translate(context),
            textEditingControllerCommon: textEditingEditProfileNameController,
            inputType: TextInputType.name,
            inputAlignment: TextAlign.start),
      ],
    );
  }

  Widget _buildEmailField(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildFieldLabel(context, "Email"),
        const SizedBox(height: Dimensions.space8),
        BlocBuilder<EmailOtpCubit, EmailOtpState>(builder: (context, state) {
          if (state is OtpSuccessForChangeEmailSate) {
            textEditingEditProfileEmailController.text =
                state.loginModel.data?.email ?? "";
            context
                .read<EmailCubit>()
                .updateEmail(state.loginModel.data?.email ?? "");
          }
          return _buildReadOnlyField(
            context,
            icon: Icons.email_outlined,
            hint: "Enter Your Email".translate(context),
            controller: textEditingEditProfileEmailController,
            onEditTap: () {
              goTo(const EmailUpdateScreen());
            },
          );
        }),
      ],
    );
  }

  Widget _buildPhoneField(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildFieldLabel(context, "Mobile Number"),
        const SizedBox(height: Dimensions.space8),
        BlocBuilder<AuthOtpVerifyCubit, OtpVerifyState>(
            builder: (context, state) {
          if (state is OtpSuccessForChangePhoneSate) {
            textEditingEditProfileNumberController.text =
               loginModel?.data?.phone ?? "";
            context
                .read<PhoneCubit>()
                .updatePhone(loginModel?.data?.phone ?? "");
            context.read<AuthOtpVerifyCubit>().resetState();
          }
          return _buildReadOnlyField(
            context,
            icon: Icons.call_outlined,
            hint: "Enter Your Mobile".translate(context),
            controller: textEditingEditProfileNumberController,
            onEditTap: () {
              context.read<SetCountryCubit>().setCountry(
                  dialCode: loginModel?.data?.phoneCountry ?? "+91",
                  countryCode: loginModel?.data?.defaultCountry ?? "IN");

              goTo(PhoneUpdateScreen(
                  phone: textEditingEditProfileNumberController.text));
            },
          );
        }),
      ],
    );
  }

  Widget _buildGenderField(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildFieldLabel(context, "Gender"),
        const SizedBox(height: Dimensions.space8),
        BlocBuilder<GenderCubit, String>(builder: (context, gender) {
          return CustomDropdown(
            selectedEditInitialValue: gender.translate(context),
            prefixIconColor: notifires.getGrey3whiteColor,
            textStyle: inputTextStyle(context),
            prefixIconImage: "assets/images/gender-icon.png",
            options: optionsList,
            onSelected: (value) {
              loginModel!.data!.gender = value;
            },
            hintText: "Gender".translate(context),
            checkmarkColor: themeColor,
          );
        }),
      ],
    );
  }

  Widget _buildReadOnlyField(
    BuildContext context, {
    required IconData icon,
    required String hint,
    required TextEditingController controller,
    required VoidCallback onEditTap,
  }) {
    return Container(
      height: Dimensions.compactFieldHeight,
      decoration: BoxDecoration(
        color: whiteColor,
        borderRadius: BorderRadius.circular(Dimensions.radiusField),
        border: Border.all(color: appBorderColor),
      ),
      padding: const EdgeInsets.symmetric(horizontal: Dimensions.space16),
      child: Row(
        children: [
          Icon(icon, size: 18, color: notifires.getGrey3whiteColor),
          const SizedBox(width: Dimensions.space12),
          Expanded(
            child: Text(
              controller.text.isEmpty ? hint : controller.text,
              overflow: TextOverflow.ellipsis,
              style: inputTextStyle(context),
            ),
          ),
          const SizedBox(width: Dimensions.space8),
          InkWell(
            borderRadius: BorderRadius.circular(10),
            onTap: onEditTap,
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: themeColor,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(Icons.edit_outlined, color: blackColor, size: 15),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomButton(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(
        Dimensions.space20,
        Dimensions.space12,
        Dimensions.space20,
        Dimensions.space12 + MediaQuery.of(context).padding.bottom,
      ),
      decoration: BoxDecoration(
        color: notifires.getbgcolor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 12,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: PrimaryButton(
        text: "Update Profile".translate(context),
        onPressed: () {
          if (loginModel!.data!.gender == null) {
            showErrorToastMessage("Please select gender");
            return;
          }
          context.read<UpdateProfileCubit>().updateProfileMethod(postData: {
            "gender": loginModel!.data!.gender!,
            "first_name": textEditingEditProfileNameController.text,
          });
        },
      ),
    );
  }

  void _showProfileImagePickerSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: notifires.getboxcolor,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius:
            BorderRadius.vertical(top: Radius.circular(Dimensions.radiusSheet)),
      ),
      builder: (sheetContext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(Dimensions.space20,
                Dimensions.space12, Dimensions.space20, Dimensions.space20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: appBorderColor,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ),
                const SizedBox(height: Dimensions.space20),
                Text("Update Profile Photo".translate(context),
                    style: sectionTitleStyle(context)),
                const SizedBox(height: Dimensions.space4),
                Text(
                  "Choose how you want to update your profile photo"
                      .translate(context),
                  textAlign: TextAlign.center,
                  style: captionText(context),
                ),
                const SizedBox(height: Dimensions.space24),
                Row(
                  children: [
                    Expanded(
                      child: _buildPickerOption(
                        context,
                        icon: Icons.camera_alt_outlined,
                        label: "Camera".translate(context),
                        onTap: () {
                          Navigator.pop(sheetContext);
                          pickImage(ImageSource.camera);
                        },
                      ),
                    ),
                    const SizedBox(width: Dimensions.space12),
                    Expanded(
                      child: _buildPickerOption(
                        context,
                        icon: Icons.photo_outlined,
                        label: "Gallery".translate(context),
                        onTap: () {
                          Navigator.pop(sheetContext);
                          pickImage(ImageSource.gallery);
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: Dimensions.space16),
                InkWell(
                  borderRadius: BorderRadius.circular(Dimensions.radiusField),
                  onTap: () => Navigator.pop(sheetContext),
                  child: Container(
                    width: double.infinity,
                    height: Dimensions.compactFieldHeight,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.circular(Dimensions.radiusField),
                      border: Border.all(color: appBorderColor),
                    ),
                    child: Text("Cancel".translate(context),
                        style: bodyText(context)),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildPickerOption(
    BuildContext context, {
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(Dimensions.radiusCard),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: Dimensions.space20),
        decoration: BoxDecoration(
          color: notifires.getBoxColor,
          borderRadius: BorderRadius.circular(Dimensions.radiusCard),
          border: Border.all(color: appBorderColor),
        ),
        child: Column(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: themeColor.withValues(alpha: 0.14),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: themeColor, size: 22),
            ),
            const SizedBox(height: Dimensions.space8),
            Text(label, style: bodyText(context)),
          ],
        ),
      ),
    );
  }
}
