import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import 'package:ride_on_driver/domain/entities/general_setting.dart';
import 'package:ride_on_driver/presentation/cubits/general_cubit.dart';
import 'package:ride_on_driver/presentation/screens/Account/profile_screen.dart';
import 'package:ride_on_driver/presentation/screens/Account/static_screen.dart';
import 'package:ride_on_driver/presentation/screens/Account/vehicle_information_screen.dart';
import 'package:ride_on_driver/presentation/screens/auth/login_screen.dart';
import 'package:ride_on_driver/presentation/screens/payment/payment_method_screen.dart';
import '../../../core/extensions/change_language.dart';
import '../../../core/extensions/workspace.dart';
import '../../../core/services/data_store.dart';
import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../cubits/account/update_profile_cubit.dart';
import '../../cubits/auth/user_authenticate_cubit.dart';
import '../../cubits/dashboard/dashboard_cubit.dart';
import '../../cubits/logout_cubit.dart';
import '../../cubits/realtime/manage_driver_cubit.dart';
import '../Payment/finance_screen.dart';
import '../history/history_screen.dart';
import '../setup_account/edit_driver_document_screen.dart';
import 'faq_screen.dart';

class MyAccountScreen extends StatefulWidget {
  const MyAccountScreen({super.key});

  @override
  State<MyAccountScreen> createState() => _MyAccountScreenState();
}

class _MyAccountScreenState extends State<MyAccountScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  String _appVersion = "";

  @override
  void initState() {
    super.initState();
    _loadAppVersion();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Initialize cubits with current user data
      context.read<NameCubit>().updateName(loginModel?.data?.firstName ?? "");
      context.read<PhoneCubit>().updatePhone(loginModel?.data?.phone ?? "");
      context.read<MyImageCubit>().updateMyImage(myImage);
      context.read<SetCountryCubit>().setCountry(
            dialCode: loginModel?.data?.phoneCountry ?? "",
            countryCode: loginModel?.data?.defaultCountry ?? "",
          );
      context.read<UpdateDriverCubit>().updateFirebaseImageUrl(
            driverImageUrl: myImage,
            driverId: context.read<UpdateDriverParameterCubit>().state.driverId,
          );
      context.read<EmailCubit>().updateEmail(loginModel?.data?.email ?? "");
      context
          .read<UpdateDriverParameterCubit>()
          .updateDriverId(driverId: driverId.toString());
    });
  }

  Future<void> _loadAppVersion() async {
    final packageInfo = await PackageInfo.fromPlatform();
    if (!mounted) return;
    setState(() {
      _appVersion = packageInfo.version;
    });
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        key: _scaffoldKey,
        backgroundColor: notifires.getbgcolor,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          surfaceTintColor: notifires.getbgcolor,
          backgroundColor: notifires.getbgcolor,
          title: Text(
            "My Accounts".translate(context),
            style: headingBlack(context).copyWith(fontSize: 20),
          ),
          centerTitle: true,
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Column(
              children: [
                _buildProfileHeader(context),
                const SizedBox(height: 24),
                _buildStatsCard(context),
                const SizedBox(height: 24),
                _buildSectionTitle("QUICK LINKS".translate(context)),
                const SizedBox(height: 12),
                _buildMenuItems(context),
                const SizedBox(height: 20),
                if (_appVersion.isNotEmpty)
                  Text(
                    "${"Version".translate(context)} $_appVersion",
                    style: regular(context).copyWith(color: grey4),
                  ),
                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Profile header with image, name, email, phone and edit button
  Widget _buildProfileHeader(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Profile image with animated update
          BlocBuilder<MyImageCubit, dynamic>(
            builder: (context, state) {
              return AnimatedSwitcher(
                duration: const Duration(milliseconds: 300),
                child: Container(
                  key: ValueKey(myImage),
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: themeColor, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: themeColor.withValues(alpha: 0.3),
                        blurRadius: 8,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: myImage.isEmpty
                        ? Icon(
                            CupertinoIcons.person_circle_fill,
                            size: 70,
                            color: grey3,
                          )
                        : myNetworkImage(myImage),
                  ),
                ),
              );
            },
          ),
          const SizedBox(width: 16),

          // User details
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                BlocBuilder<NameCubit, dynamic>(
                  builder: (context, state) {
                    return Text(
                      context.read<NameCubit>().state,
                      style: headingBlack(context).copyWith(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    );
                  },
                ),
                const SizedBox(height: 4),
                BlocBuilder<EmailCubit, dynamic>(
                  builder: (context, state) {
                    return Row(
                      children: [
                        Icon(Icons.email_outlined, size: 14, color: grey4),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            context.read<EmailCubit>().state,
                            style: regular(context).copyWith(fontSize: 13),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    );
                  },
                ),
                const SizedBox(height: 4),
                BlocBuilder<PhoneCubit, dynamic>(
                  builder: (context, state) {
                    return Row(
                      children: [
                        Icon(Icons.call_outlined, size: 14, color: grey4),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            "${context.read<SetCountryCubit>().state.dialCode} ${context.read<PhoneCubit>().state}",
                            style: regular(context).copyWith(fontSize: 13),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ],
            ),
          ),

          // Edit button
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const EditProfile()),
              );
            },
            borderRadius: BorderRadius.circular(20),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: themeColor,
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.edit,
                color: Colors.white,
                size: 18,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsCard(BuildContext context) {
    return BlocBuilder<DashboardCubit, DashboardState>(
      builder: (context, state) {
        final totalRating = (state is DashboardSuceess) ? state.totalRating : 0;
        final totalOrder = (state is DashboardSuceess) ? state.totalOrder : 0;
        final totalEarning = (state is DashboardSuceess)
            ? (double.tryParse(state.totalEarning) ?? 0.0).toStringAsFixed(2)
            : "0";

        return Container(
          decoration: BoxDecoration(
              color: themeColor.withValues(alpha: .2),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: themeColor.withValues(alpha: .7))),
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildStatItem(
                context,
                value: "$totalRating",
                label: "RATING".translate(context),
                icon: Icons.star,
                iconColor: yelloColor,
              ),
              _buildStatItem(
                context,
                value: "$totalOrder",
                label: "ORDERS".translate(context),
                icon: Icons.shopping_bag_outlined,
                iconColor: blackColor,
              ),
              _buildStatItem(
                context,
                value: "$currency $totalEarning",
                label: "Earnings".translate(context),
                icon: Icons.monetization_on_outlined,
                iconColor: blackColor,
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildStatItem(
    BuildContext context, {
    required String value,
    required String label,
    required IconData icon,
    required Color iconColor,
  }) {
    return Column(
      children: [
        Row(
          children: [
            label == "Earnings"
                ? const SizedBox()
                : Icon(icon, color: iconColor, size: 20),
            label == "Earnings" ? const SizedBox() : const SizedBox(width: 4),
            Text(
              value,
              style: headingBlackBold(context).copyWith(
                color: blackColor,
                fontSize: 16,
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: regular(context).copyWith(
            color: blackColor,
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  Widget _buildSectionTitle(String title) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Text(
        title,
        style: headingBlack(context).copyWith(
          fontSize: 16,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  Widget _buildMenuItems(BuildContext context) {
    return Column(
      children: [
        _buildMenuItem(
          icon: Icons.history,
          title: "History",
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const HistoryScreen(isBackButton: true),
            ),
          ),
        ),
        _buildMenuItem(
          icon: Icons.account_balance_wallet_outlined,
          title: "Earnings",
          onTap: () => goTo(const FinanceMainScreen(isFormHome: false)),
        ),
        _buildMenuItem(
          icon: Icons.payment_outlined,
          title: "Payout Options",
          onTap: () => goTo(const PaymentMethodsScreen()),
        ),
        _buildMenuItem(
          icon: CupertinoIcons.question_circle,
          title: "FAQ",
          onTap: () => goTo(const DriverFAQScreen()),
        ),
        _buildMenuItem(
          icon: CupertinoIcons.car,
          title: "Vehicle's Information",
          onTap: () => goTo(const VehicleInformationScreen()),
        ),
        _buildMenuItem(
          icon: Icons.description_outlined,
          title: "Edit Document",
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const EditDriverDocumentScreen(),
            ),
          ),
        ),
        // ====================== DYNAMIC STATIC PAGES ======================
        BlocBuilder<StaticPagesCubit, SimpleState<List<StaticPage>>>(
          builder: (context, state) {
            final pages = state.value;

            if (pages.isEmpty) {
              return const SizedBox.shrink();
            }

            return Column(
              children: pages.map((page) {
                return _buildMenuItem(
                  icon: _getIconForPage(page.name),
                  title: page.name ?? "",
                  translateTitle: false,
                  onTap: () {
                    goTo(StaticScreen(
                      name: page.name ?? "",
                      id: page.id.toString(),
                      isBack: true,
                    ));
                  },
                );
              }).toList(),
            );
          },
        ),
// =================================================================
        _buildMenuItem(
          icon: Icons.language_outlined,
          title: "Change Language",
          onTap: () => goTo(const ChangeLanguage()),
        ),
        _buildMenuItem(
          icon: Icons.delete_outline,
          title: "Delete Account",
          onTap: () {
            showDialog(
              context: context,
              builder: (_) => const DeleteConfirmationDialogs(),
            );
          },
        ),
        BlocConsumer<LogoutCubit, LogoutState>(
          listener: (context, state) {
            if (state is LogoutFailure) {
              showErrorToastMessage("Logout Failed: ${state.error}");
            } else if (state is LogoutSuccess) {
              box.put('isDocumentStatusShown', false);
              goToWithClear(const LoginScreen());
            }
          },
          builder: (context, state) {
            return _buildMenuItem(
              icon: Icons.logout_outlined,
              title: "Logout",
              onTap: () {
                showDynamicBottomSheets(
                  context,
                  title: "Logout".translate(context),
                  description:
                      "Are you sure You Want to Logout?".translate(context),
                  firstButtontxt: "Cancel".translate(context),
                  secondButtontxt: "Yes".translate(context),
                  onpressed: () => Navigator.pop(context),
                  onpressed1: () async {
                    context.read<LogoutCubit>().logout(context);
                  },
                );
              },
            );
          },
        ),
      ],
    );
  }

  IconData _getIconForPage(String? name) {
    final pageName = (name ?? "").toLowerCase();

    if (pageName.contains("about")) {
      return Icons.info_outline;
    } else if (pageName.contains("help") || pageName.contains("support")) {
      return Icons.help_outline;
    } else if (pageName.contains("term") || pageName.contains("condition")) {
      return Icons.description_outlined;
    } else if (pageName.contains("privacy") || pageName.contains("policy")) {
      return Icons.privacy_tip_outlined;
    } else if (pageName.contains("cancel")) {
      return Icons.cancel_outlined;
    } else {
      return Icons.article_outlined;
    }
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    bool translateTitle = true,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: themeColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: themeColor, size: 22),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Text(
                    translateTitle ? title.translate(context) : title,
                    style: heading3Grey1(context).copyWith(
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                Icon(
                  Icons.arrow_forward_ios,
                  size: 16,
                  color: grey4,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
