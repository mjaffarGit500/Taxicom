import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:latlong2/latlong.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import 'package:ride_on_driver/presentation/screens/ride/ride_screen_osm.dart';
import '../../../../../core/extensions/workspace.dart';
import '../../../../../core/services/data_store.dart';
import '../../../../../core/utils/common_widget.dart';
import '../../../../../core/utils/theme/project_color.dart';
import '../../../../../core/utils/theme/theme_style.dart';
import '../../../../../domain/entities/initial_ride_request.dart';
import '../../../../cubits/location/ringtone_cubit.dart';
import '../../../../cubits/realtime/manage_driver_cubit.dart';
import '../../../../cubits/realtime/listen_ride_request_cubit.dart';
import '../../../../cubits/realtime/ride_status_cubit.dart';

class CustomBottomSheet extends StatefulWidget {
  final InitialRideRequest? rideRequest;
  final LatLng currentLatlang;

  const CustomBottomSheet({
    super.key,
    this.rideRequest,
    required this.currentLatlang,
  });

  @override
  CustomBottomSheetState createState() => CustomBottomSheetState();
}

class CustomBottomSheetState extends State<CustomBottomSheet>
    with WidgetsBindingObserver {
  int durationShowPopUp = popupDuration();
  int _remainingTime = popupDuration();
  DateTime? _rideStartTime;
  Timer? _autoCloseTimer;
  @override
  void initState() {
    super.initState();
    context.read<RideStatusCubit>().removeRideAcceptedStatus();
    WidgetsBinding.instance.addObserver(this);

    _rideStartTime = box.get('ride_request_start_time');
    if (_rideStartTime == null) {
      _rideStartTime = DateTime.now();
      box.put('ride_request_start_time', _rideStartTime);
    }

    final elapsed = DateTime.now().difference(_rideStartTime!).inSeconds;
    _remainingTime = durationShowPopUp - elapsed;

    if (_remainingTime <= 0) {
      _closeSheetIfNotAccepted();
      return;
    }

    _autoCloseTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() => _remainingTime--);

      if (_remainingTime <= 0) {
        timer.cancel();
        _closeSheetIfNotAccepted();
      }
    });
  }

  void _closeSheetIfNotAccepted() {
    final rideAccepted =
        context.read<RideStatusCubit>().state.rideAcceptedStatus;
    if (!rideAccepted && Navigator.canPop(context)) {
      Navigator.pop(context);
      RingtoneHelper().stopRingtone();
      box.delete('ride_request_start_time');
      _rejectRide(context, false);
    }
  }

  @override
  void dispose() {
    _autoCloseTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    box.delete('ride_request_start_time'); // clear after use

    super.dispose();
  }

  @override
  Future<void> didChangeAppLifecycleState(AppLifecycleState state) async {
    if (state == AppLifecycleState.resumed) {
      final rideRequestState = context.read<ListenRideRequestCubit>().state;
      if (rideRequestState is ListenRideRequestSuccess &&
          rideRequestState.rideRequest == null) {
        if (Navigator.canPop(context)) {
          Navigator.pop(context);
        }
        _autoCloseTimer?.cancel();
        RingtoneHelper().stopRingtone();
        box.delete('ride_request_start_time');
      }
    } else if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive ||
        state == AppLifecycleState.detached) {
      final rideRequestState = context.read<ListenRideRequestCubit>().state;
      if (rideRequestState is ListenRideRequestSuccess &&
          rideRequestState.rideRequest == null) {
        if (Navigator.canPop(context)) {
          Navigator.pop(context);
        }
        _autoCloseTimer?.cancel();
        RingtoneHelper().stopRingtone();
        box.delete('ride_request_start_time');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final double panelMaxHeight = MediaQuery.sizeOf(context).height * 0.56;

    return ClipRRect(
      borderRadius: const BorderRadius.only(
        topLeft: Radius.circular(20),
        topRight: Radius.circular(20),
      ),
      child: PopScope(
        canPop: false,
        child: BlocListener<ListenRideRequestCubit, ListenRideRequestState>(
          listener: (context, state) async {
            if (state is ListenRideRequestSuccess) {
              if (state.rideRequest == null) {
                if (Navigator.canPop(context)) {
                  Navigator.pop(context);
                }
                box.delete('ride_request_start_time');
                _autoCloseTimer?.cancel();
                RingtoneHelper().stopRingtone();
              }
            }
          },
          child: Align(
            alignment: Alignment.bottomCenter,
            child: SafeArea(
              top: false,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 44,
                    height: 5,
                    margin: const EdgeInsets.only(top: 10, bottom: 8),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.9),
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    width: double.infinity,
                    height: 116,
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          alignment: Alignment.center,
                          height: 84,
                          width: 84,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                themeColor.withValues(alpha: 0.95),
                                themeColor.withValues(alpha: 0.65),
                              ],
                            ),
                            border: Border.all(
                                color: Colors.white.withValues(alpha: 0.92),
                                width: 2),
                          ),
                          child: Text(
                            "$_remainingTime",
                            style: heading1(context)
                                .copyWith(fontSize: 25, color: Colors.white),
                          ),
                        ),
                        const SizedBox(height: 8),
                      ],
                    ),
                  ),
                  ConstrainedBox(
                    constraints: BoxConstraints(maxHeight: panelMaxHeight),
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 8),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            whiteColor,
                            Colors.white.withValues(alpha: 0.94),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(
                            color: themeColor.withValues(alpha: 0.14)),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.14),
                            blurRadius: 18,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        padding: const EdgeInsets.fromLTRB(20, 20, 20, 22),
                        child: Column(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 6),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.centerLeft,
                                  end: Alignment.centerRight,
                                  colors: [
                                    themeColor.withValues(alpha: 0.22),
                                    themeColor.withValues(alpha: 0.08),
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                    color: themeColor.withValues(alpha: 0.24)),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.notifications_active_rounded,
                                      size: 13, color: themeColor),
                                  const SizedBox(width: 6),
                                  Text(
                                    "New Ride Request".translate(context),
                                    style: headingBlackBold(context)
                                        .copyWith(fontSize: 10),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    ClipOval(
                                      child: Container(
                                        height: 62,
                                        width: 62,
                                        color: notifires.getBoxColor,
                                        child: myNetworkImage(widget.rideRequest
                                                ?.customer.userPhoto ??
                                            ""),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          widget.rideRequest!.customer.userName,
                                          style: headingBlackBold(context)
                                              .copyWith(fontSize: 13),
                                        ),
                                        Row(
                                          children: [
                                            Icon(Icons.star,
                                                color: orangeColor, size: 13),
                                            const SizedBox(width: 3),
                                            Text(
                                              widget.rideRequest!.customer
                                                      .userRating
                                                      .toString()
                                                      .isEmpty
                                                  ? "0.0"
                                                  : widget.rideRequest!.customer
                                                      .userRating
                                                      .toString(),
                                              style: regular(context).copyWith(
                                                  color: notifires
                                                      .getGrey3whiteColor,
                                                  fontSize: 11),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Text(
                                      "$currency ${widget.rideRequest!.travelCharges}",
                                      style: headingBlack(context).copyWith(
                                          color: greentext, fontSize: 15),
                                    ),
                                    Row(
                                      children: [
                                        Icon(Icons.timer_sharp,
                                            color: grey3, size: 12),
                                        const SizedBox(width: 4),
                                        Text(
                                          "${widget.rideRequest!.travelTime}(${(double.parse(widget.rideRequest!.travelDistance)).toStringAsFixed(2)} ${"km".translate(context)})",
                                          style: regular(context)
                                              .copyWith(fontSize: 11),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            const Divider(),
                            const SizedBox(height: 16),
                            Column(
                              children: [
                                Row(
                                  children: [
                                    Column(
                                      children: [
                                        Container(
                                          height: 45,
                                          width: 28,
                                          decoration: BoxDecoration(
                                            color: greentext,
                                            borderRadius:
                                                BorderRadius.circular(20),
                                          ),
                                          alignment: Alignment.bottomCenter,
                                          child: Container(
                                            margin: const EdgeInsets.only(
                                                bottom: 10),
                                            height: 10,
                                            width: 10,
                                            decoration: BoxDecoration(
                                              color: whiteColor,
                                              borderRadius:
                                                  BorderRadius.circular(5),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(height: 5),
                                        Image.asset("assets/images/line2.png",
                                            scale: 0.9),
                                        const SizedBox(height: 5),
                                        Container(
                                          height: 45,
                                          width: 28,
                                          decoration: BoxDecoration(
                                            color: whiteColor,
                                            border: Border.all(
                                                width: 1, color: grey4),
                                            borderRadius:
                                                BorderRadius.circular(20),
                                          ),
                                          alignment: Alignment.topCenter,
                                          child: Container(
                                            margin:
                                                const EdgeInsets.only(top: 10),
                                            height: 10,
                                            width: 10,
                                            decoration: BoxDecoration(
                                              color: themeColor,
                                              borderRadius:
                                                  BorderRadius.circular(5),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(width: 15),
                                    Flexible(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                              "Verified Pickup".translate(
                                                  context),
                                              style: headingBlack(context)
                                                  .copyWith(
                                                      color: notifires
                                                          .getGrey3whiteColor,
                                                      fontSize: 14)),
                                          const SizedBox(height: 5),
                                          Text(
                                            widget.rideRequest!.pickupLocation,
                                            style: headingBlack(context)
                                                .copyWith(fontSize: 14),
                                            softWrap: true,
                                          ),
                                          const SizedBox(height: 20),
                                          Text(
                                              "Verified Drop At"
                                                  .translate(context),
                                              style: headingBlack(context)
                                                  .copyWith(
                                                      color: notifires
                                                          .getGrey3whiteColor,
                                                      fontSize: 14)),
                                          const SizedBox(height: 5),
                                          Text(
                                            widget.rideRequest!.dropoffLocation,
                                            style: headingBlack(context)
                                                .copyWith(fontSize: 14),
                                            softWrap: true,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            const SizedBox(height: 18),
                            Row(
                              children: [
                                Expanded(
                                  flex: 3,
                                  child: CustomSlideButton(
                                    textActiveColor: greentext,
                                    iconColor: blackColor,
                                    textInactiveColor: blackColor,
                                    inactiveColor: themeColor,
                                    isOnRide: context
                                        .read<RideStatusCubit>()
                                        .state
                                        .rideAcceptedStatus,
                                    acceptedText: "ACCEPTED",
                                    defaultText: "ACCEPT RIDE",
                                    onChanged: (value) async {
                                      if (value) {
                                        context
                                            .read<RideStatusCubit>()
                                            .updateRideAcceptedStatus(
                                                rideAcceptedStatus: true);
                                        context
                                            .read<UpdateRideRequestCubit>()
                                            .updateNewRideRequestsStatus(
                                              driverId: driverId,
                                              rideId:
                                                  widget.rideRequest?.rideId ??
                                                      "",
                                              newStatus: "accepted",
                                            );
                                        box.put("ride_id",
                                            widget.rideRequest?.rideId ?? "");
                                        box.put("start_time",
                                            getCurrentFormattedTime());
                                        goBack();
                                        box.delete('ride_request_start_time');

                                        Navigator.push(context,
                                            MaterialPageRoute(
                                                builder: (context) {
                                          return RideScreensOSM(
                                            tripTitle: "Start Pickup",
                                            fromInitialPage: false,
                                            isOnDutyArrived:
                                                box.get("driver_status"),
                                            currentLatLang:
                                                widget.currentLatlang,
                                            rideId: context
                                                .read<
                                                    UpdateDriverParameterCubit>()
                                                .state
                                                .rideId,
                                          );
                                        }));

                                        RingtoneHelper().stopRingtone();
                                        box.delete('ride_request_start_time');
                                      }
                                    },
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  flex: 1,
                                  child: InkWell(
                                    onTap: () => _rejectRide(context, true),
                                    child: Container(
                                      height: 55,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        color:
                                            Colors.red.withValues(alpha: 0.08),
                                        borderRadius: BorderRadius.circular(14),
                                        border: Border.all(
                                            color: Colors.red
                                                .withValues(alpha: 0.2)),
                                      ),
                                      child: Text(
                                        "Skip".translate(context),
                                        style: headingBlack(context).copyWith(
                                          fontSize: 12,
                                          color: Colors.red.shade700,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _rejectRide(BuildContext context, bool? skipStatus) async {
    _autoCloseTimer?.cancel();
    box.delete('ride_request_start_time');

    context.read<UpdateRideRequestCubit>().removeRideRequest(
        skipStatus: skipStatus,
        rideId: context.read<UpdateDriverParameterCubit>().state.rideId,
        driverId: context.read<UpdateDriverParameterCubit>().state.driverId);
    RingtoneHelper().stopRingtone();
  }
}
