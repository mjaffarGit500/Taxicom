import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import '../../../../../core/utils/theme/project_color.dart';
import '../../../../../domain/entities/initial_ride_request.dart';
import 'custom_bottom_sheet.dart';
import 'custom_bottom_sheet_for_parcel.dart';

void showCustomBottomSheet(BuildContext context,
    {InitialRideRequest? rideRequest, required LatLng currebtLatlng}) {
  showModalBottomSheet(
    isDismissible: false,
    enableDrag: false,
    useRootNavigator: true,
    barrierColor: blackColor.withValues(alpha: .2),
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) {
      if ((rideRequest?.parcalData.name ?? "").isEmpty ||
          (rideRequest?.parcalData.reciverName ?? "").isEmpty) {
        return CustomBottomSheet(
          rideRequest: rideRequest,
          currentLatlang: currebtLatlng,
        );
      } else {
        return CustomBottomSheetForParcel(
          rideRequest: rideRequest,
          currentLatlang: currebtLatlng,
        );
      }
    },
  );
}
