import 'package:flutter/material.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../../../core/extensions/workspace.dart';
import '../../../../../core/utils/theme/project_color.dart';
import '../../../../../core/utils/theme/theme_style.dart';

class ParcelInfoWidget extends StatelessWidget {
  final String name;
  final String weight;
  final String receiverName;
  final String receiverPhone;
  final String pickupInstructions;

  const ParcelInfoWidget({
    super.key,
    required this.name,
    required this.weight,
    required this.receiverName,
    required this.receiverPhone,
    required this.pickupInstructions,
  });

  bool get _shouldHide =>
      name.trim().isEmpty &&
      receiverName.trim().isEmpty &&
      receiverPhone.trim().isEmpty;

  @override
  Widget build(BuildContext context) {
    if (_shouldHide) return const SizedBox();

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.white, themeColor.withValues(alpha: 0.14)],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: themeColor.withValues(alpha: 0.28)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                height: 30,
                width: 30,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [themeColor, const Color(0xFFF4B400)],
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.inventory_2_outlined,
                  size: 16,
                  color: Color(0xFF2A1E1A),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                "Parcel Details".translate(context),
                style: heading2Grey1(context).copyWith(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: const Color(0xFF2A1E1A),
                ),
              ),
            ],
          ),

          const SizedBox(height: 10),

          // Grid rows
          Row(
            children: [
              Expanded(
                  child: _infoCard("Item", name, Icons.inventory_2_outlined)),
              const SizedBox(width: 8),
              Expanded(
                  child: _infoCard(
                      "Weight",
                      "$weight ${"kg".translate(context)}",
                      Icons.scale_outlined)),
            ],
          ),

          const SizedBox(height: 8),

          Row(
            children: [
              Expanded(
                  child: _infoCard(
                      "Receiver", receiverName, Icons.person_outline)),
              const SizedBox(width: 8),
              Expanded(
                  child:
                      _infoCard("Phone", receiverPhone, Icons.call_outlined)),
            ],
          ),

          if (pickupInstructions.trim().isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(
              "Instruction: $pickupInstructions",
              style: heading3Grey1(context).copyWith(
                fontSize: 11,
                color: const Color(0xFF8A5A10),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _infoCard(String title, String value, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: themeColor.withValues(alpha: 0.30)),
      ),
      child: Row(
        children: [
          Icon(icon, size: 16, color: const Color(0xFF8A5A10)),
          const SizedBox(width: 6),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title.translate(navigatorKey.currentContext!),
                  style: heading3Grey1(navigatorKey.currentContext!).copyWith(
                    fontSize: 10,
                    color: Colors.grey[600],
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: heading3Grey1(navigatorKey.currentContext!).copyWith(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
