import 'package:flutter/material.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../../../core/utils/theme/project_color.dart';
import '../../../../../core/utils/theme/theme_style.dart';

class ReloadMapButton extends StatelessWidget {
  final VoidCallback onReload;

  const ReloadMapButton({super.key, required this.onReload});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.grey[100],
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.location_disabled,
              size: 64,
              color: themeColor,
            ),
            const SizedBox(height: 16),
            Text(
              "Unable to get location".translate(context),
              style: heading2Grey1(context),
            ),
            const SizedBox(height: 8),
            Text(
              "Please check your connection and try again".translate(context),
              style: regular2(context),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: onReload,
              icon: const Icon(Icons.refresh),
              label: Text(
                "Reload Map".translate(context),
                style: heading3Grey1(context),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: themeColor,
                foregroundColor: blackColor,
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
