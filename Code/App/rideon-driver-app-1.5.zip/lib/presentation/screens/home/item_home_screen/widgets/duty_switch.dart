import 'package:flutter/material.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../../../core/utils/theme/project_color.dart';
import '../../../../../core/utils/theme/theme_style.dart';

/// Classic on/off duty toggle used in the home screen's top profile header.
/// Presentation only — the caller supplies [isOnline]/[status] and handles
/// [onToggle]; this widget carries no bloc/cubit reads of its own.
class DutySwitch extends StatelessWidget {
  final bool isOnline;
  final String status;
  final VoidCallback onToggle;

  const DutySwitch({
    super.key,
    required this.isOnline,
    required this.status,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    final bool isApproved = status == "approved";
    final Color activeColor = isApproved
        ? (isOnline ? Colors.green.shade700 : Colors.red.shade700)
        : Colors.orange.shade700;

    return Semantics(
      button: true,
      label: isOnline ? "On Duty" : "Off Duty",
      child: GestureDetector(
        onTap: onToggle,
        onHorizontalDragEnd: (_) => onToggle(),
        child: SizedBox(
          width: 150,
          child: Container(
            height: 36,
            decoration: BoxDecoration(
              color: notifires.getBoxColor,
              borderRadius: BorderRadius.circular(15),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                AnimatedAlign(
                  duration: const Duration(milliseconds: 260),
                  curve: Curves.easeOutCubic,
                  alignment:
                      isOnline ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    width: 72,
                    height: 30,
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: isApproved
                            ? (isOnline
                                ? [
                                    Colors.green.shade600,
                                    Colors.green.shade800,
                                  ]
                                : [
                                    Colors.red.shade500,
                                    Colors.red.shade700,
                                  ])
                            : [
                                Colors.orange.shade400,
                                Colors.orange.shade700,
                              ],
                      ),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    alignment: Alignment.center,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          isOnline
                              ? Icons.toggle_on_rounded
                              : Icons.toggle_off_rounded,
                          size: 16,
                          color: Colors.white,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          isOnline
                              ? "ON".translate(context)
                              : "OFF".translate(context),
                          style: headingBlackBold(context).copyWith(
                            fontSize: 10,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Row(
                  children: [
                    Expanded(
                      child: Center(
                        child: Text(
                          "OFF DUTY".translate(context),
                          style: headingBlackBold(context).copyWith(
                            fontSize: 9,
                            color: isOnline
                                ? Colors.grey.shade600
                                : Colors.transparent,
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Center(
                        child: Text(
                          "ON DUTY".translate(context),
                          style: headingBlackBold(context).copyWith(
                            fontSize: 9,
                            color: isOnline
                                ? Colors.transparent
                                : Colors.grey.shade600,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
