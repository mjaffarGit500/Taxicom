import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../../../core/extensions/helper/push_notifications.dart';
import '../../../../../core/extensions/workspace.dart';
import '../../../../../core/services/data_store.dart';
import '../../../../../core/utils/common_widget.dart' hide ParcelInfoWidget;
import '../../../../../core/utils/theme/project_color.dart';
import '../../../../../core/utils/theme/theme_style.dart';
import '../../../../../domain/entities/initial_ride_request.dart';
import '../../../../cubits/location/ringtone_cubit.dart';
import '../../../../cubits/realtime/manage_driver_cubit.dart';
import '../../../../cubits/realtime/listen_ride_request_cubit.dart';
import '../../../../cubits/realtime/ride_status_cubit.dart';
import 'navigate_to_ride_screen.dart';
import 'parcel_info_widget.dart';

class CustomBottomSheetForParcel extends StatefulWidget {
  final InitialRideRequest? rideRequest;
  final LatLng currentLatlang;

  const CustomBottomSheetForParcel({
    super.key,
    this.rideRequest,
    required this.currentLatlang,
  });

  @override
  CustomBottomSheetForParcelState createState() =>
      CustomBottomSheetForParcelState();
}

class CustomBottomSheetForParcelState extends State<CustomBottomSheetForParcel>
    with WidgetsBindingObserver {
  int durationShowPopUp = popupDuration();
  int _remainingTime = popupDuration();
  DateTime? _rideStartTime;
  Timer? _autoCloseTimer;

  bool get hasParcel {
    final p = widget.rideRequest?.parcalData;
    if (p == null) return false;
    return (p.name?.isNotEmpty ?? false) ||
        (p.weight?.isNotEmpty ?? false) ||
        (p.reciverName?.isNotEmpty ?? false) ||
        (p.reciverNumber?.isNotEmpty ?? false) ||
        (p.instruction?.isNotEmpty ?? false);
  }

  @override
  void initState() {
    super.initState();
    context.read<RideStatusCubit>().removeRideAcceptedStatus();
    WidgetsBinding.instance.addObserver(this);

    _rideStartTime = box.get('ride_request_start_time');
    if (_rideStartTime == null) {
      _rideStartTime = DateTime.now();
      box.put('ride_request_start_time', _rideStartTime);
    }

    final elapsed = DateTime.now().difference(_rideStartTime!).inSeconds;
    _remainingTime = durationShowPopUp - elapsed;

    if (_remainingTime <= 0) {
      _closeSheetIfNotAccepted();
      return;
    }

    _autoCloseTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() => _remainingTime--);
      if (_remainingTime <= 0) {
        timer.cancel();
        _closeSheetIfNotAccepted();
      }
    });
  }

  void _closeSheetIfNotAccepted() {
    final rideAccepted =
        context.read<RideStatusCubit>().state.rideAcceptedStatus;
    if (!rideAccepted && Navigator.canPop(context)) {
      Navigator.pop(context);
      RingtoneHelper().stopRingtone();
      box.delete('ride_request_start_time');
      _rejectRide(context, false);
    }
  }

  @override
  void dispose() {
    _autoCloseTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    box.delete('ride_request_start_time');
    super.dispose();
  }

  @override
  Future<void> didChangeAppLifecycleState(AppLifecycleState state) async {
    final rideRequestState = context.read<ListenRideRequestCubit>().state;
    if (rideRequestState is ListenRideRequestSuccess &&
        rideRequestState.rideRequest == null) {
      if (Navigator.canPop(context)) Navigator.pop(context);
      _autoCloseTimer?.cancel();
      RingtoneHelper().stopRingtone();
      box.delete('ride_request_start_time');
    }
  }

  @override
  Widget build(BuildContext context) {
    final ride = widget.rideRequest!;
    final double panelMaxHeight = MediaQuery.sizeOf(context).height * 0.62;

    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      child: PopScope(
        canPop: false,
        child: BlocListener<ListenRideRequestCubit, ListenRideRequestState>(
          listener: (context, state) {
            if (state is ListenRideRequestSuccess &&
                state.rideRequest == null) {
              if (Navigator.canPop(context)) Navigator.pop(context);
              _autoCloseTimer?.cancel();
              RingtoneHelper().stopRingtone();
              box.delete('ride_request_start_time');
            }
          },
          child: Align(
            alignment: Alignment.bottomCenter,
            child: SafeArea(
              top: false,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 44,
                    height: 5,
                    margin: const EdgeInsets.only(top: 10, bottom: 8),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.9),
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  _buildTimerCircle(),
                  ConstrainedBox(
                    constraints: BoxConstraints(maxHeight: panelMaxHeight),
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 8),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            whiteColor,
                            Colors.white.withValues(alpha: 0.95),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(
                            color: themeColor.withValues(alpha: 0.14)),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.14),
                            blurRadius: 18,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        padding: const EdgeInsets.fromLTRB(20, 20, 20, 22),
                        child: Column(
                          children: [
                            _buildSheetBadge(
                              icon: Icons.notifications_active_rounded,
                              label: "New Ride Request".translate(context),
                            ),
                            const SizedBox(height: 10),
                            _buildUserRow(ride),
                            const SizedBox(height: 10),
                            const Divider(),
                            const SizedBox(height: 14),
                            _buildLocations(ride),
                            if (hasParcel)
                              ParcelInfoWidget(
                                name: ride.parcalData.name ?? "",
                                weight: ride.parcalData.weight ?? "",
                                receiverName: ride.parcalData.reciverName ?? "",
                                receiverPhone:
                                    ride.parcalData.reciverNumber ?? "",
                                pickupInstructions:
                                    ride.parcalData.instruction ?? "",
                              ),
                            const SizedBox(height: 18),
                            _buildButtons(ride),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTimerCircle() {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      height: 116,
      alignment: Alignment.center,
      child: Container(
        height: 86,
        width: 86,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              themeColor.withValues(alpha: 0.95),
              themeColor.withValues(alpha: 0.65),
            ],
          ),
          border:
              Border.all(color: Colors.white.withValues(alpha: 0.92), width: 2),
          boxShadow: [
            BoxShadow(
              color: themeColor.withValues(alpha: 0.28),
              blurRadius: 14,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Text(
          "$_remainingTime",
          style: heading1(context).copyWith(
            fontSize: 26,
            color: Colors.white,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }

  Widget _buildUserRow(InitialRideRequest ride) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            ClipOval(
              child: Container(
                height: 62,
                width: 62,
                color: notifires.getBoxColor,
                child: myNetworkImage(ride.customer.userPhoto ?? ""),
              ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  ride.customer.userName,
                  style: headingBlackBold(context).copyWith(fontSize: 13),
                ),
                Row(
                  children: [
                    Icon(Icons.star, color: orangeColor, size: 13),
                    const SizedBox(width: 3),
                    Text(
                      ride.customer.userRating.isEmpty
                          ? "0.0"
                          : ride.customer.userRating,
                      style: regular(context).copyWith(
                          color: notifires.getGrey3whiteColor, fontSize: 11),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text("$currency ${ride.travelCharges}",
                style: headingBlack(context)
                    .copyWith(color: greentext, fontSize: 15)),
            Row(
              children: [
                Icon(Icons.timer_sharp, color: grey3, size: 12),
                const SizedBox(width: 4),
                Text(
                  "${ride.travelTime} (${double.parse(ride.travelDistance).toStringAsFixed(2)} km)",
                  style: regular(context).copyWith(fontSize: 11),
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildLocations(InitialRideRequest ride) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _locationRow(Icons.my_location_rounded, Colors.green,
            "Pickup".translate(context), ride.pickupLocation),
        const SizedBox(height: 6),
        _locationRow(Icons.location_on_rounded, Colors.red,
            "Drop".translate(context), ride.dropoffLocation),
        const SizedBox(height: 10),
      ],
    );
  }

  Widget _locationRow(IconData icon, Color color, String title, String value) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.24)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 22,
            height: 22,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.14),
              borderRadius: BorderRadius.circular(7),
            ),
            child: Icon(icon, size: 13, color: color),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: RichText(
              text: TextSpan(
                style: const TextStyle(color: Colors.black, fontSize: 11),
                children: [
                  TextSpan(
                      text: "$title:  ",
                      style: const TextStyle(
                          fontWeight: FontWeight.w700, fontSize: 11.5)),
                  TextSpan(text: value),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSheetBadge({required IconData icon, required String label}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: [
            themeColor.withValues(alpha: 0.22),
            themeColor.withValues(alpha: 0.08),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: themeColor.withValues(alpha: 0.24)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: themeColor),
          const SizedBox(width: 6),
          Text(
            label.translate(context),
            style: headingBlackBold(context).copyWith(fontSize: 10),
          ),
        ],
      ),
    );
  }

  Widget _buildButtons(InitialRideRequest ride) {
    return Row(
      children: [
        Expanded(
          flex: 3,
          child: CustomSlideButton(
            textActiveColor: greentext,
            iconColor: blackColor,
            textInactiveColor: blackColor,
            inactiveColor: themeColor,
            isOnRide: context.read<RideStatusCubit>().state.rideAcceptedStatus,
            acceptedText: "ACCEPTED",
            defaultText: "ACCEPT RIDE",
            onChanged: (value) async {
              if (value) {
                context
                    .read<RideStatusCubit>()
                    .updateRideAcceptedStatus(rideAcceptedStatus: true);
                context
                    .read<UpdateRideRequestCubit>()
                    .updateNewRideRequestsStatus(
                      driverId: driverId,
                      rideId: ride.rideId,
                      newStatus: "accepted",
                    );
                box.put("ride_id", ride.rideId);
                box.put("start_time", getCurrentFormattedTime());
                goBack();
                box.delete('ride_request_start_time');
                navigateToRideScreen(
                  context: context,
                  isReplacement: false,
                  rideId:
                      context.read<UpdateDriverParameterCubit>().state.rideId,
                  fromInitialPage: false,
                  tripTitle: "Start Pickup",
                  isOnDutyArrived: box.get("driver_status"),
                  currentLatLang: widget.currentLatlang,
                );
                RingtoneHelper().stopRingtone();
                sendNotificationDirect(
                    playerId: widget.rideRequest!.playerId,
                    title: "Ride Accepted 🚗",
                    message:
                        "Your captain has accepted the ride and is on the way to pick you up."
                            .translate(context));
              }
            },
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          flex: 1,
          child: InkWell(
            onTap: () => _rejectRide(context, true),
            child: Container(
              height: 55,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.red.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.red.withValues(alpha: 0.2)),
              ),
              child: Text(
                "Skip".translate(context),
                style: headingBlack(context).copyWith(
                  fontSize: 12,
                  color: Colors.red.shade700,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _rejectRide(BuildContext context, bool? skipStatus) async {
    _autoCloseTimer?.cancel();
    box.delete('ride_request_start_time');

    context.read<UpdateRideRequestCubit>().removeRideRequest(
          skipStatus: skipStatus,
          rideId: context.read<UpdateDriverParameterCubit>().state.rideId,
          driverId: context.read<UpdateDriverParameterCubit>().state.driverId,
        );
    RingtoneHelper().stopRingtone();
  }
}
