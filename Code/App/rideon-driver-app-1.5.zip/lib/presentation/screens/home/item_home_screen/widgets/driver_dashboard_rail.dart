import 'package:flutter/material.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../../../core/extensions/workspace.dart';
import '../../../../../core/utils/theme/project_color.dart';
import '../../../../../core/utils/theme/theme_style.dart';
import '../../../../cubits/dashboard/dashboard_cubit.dart';

class DriverDashboardRail extends StatelessWidget {
  final DashboardState state;

  const DriverDashboardRail({super.key, required this.state});

  @override
  Widget build(BuildContext context) {
    final String earningValue = state is DashboardSuceess
        ? "$currency ${(double.tryParse((state as DashboardSuceess).totalEarning) ?? 0.0).toStringAsFixed(2)}"
        : "$currency 0.00";
    final String ratingValue = state is DashboardSuceess
        ? (state as DashboardSuceess).totalRating.toString()
        : "0";
    final String ordersValue = state is DashboardSuceess
        ? (state as DashboardSuceess).totalOrder.toString()
        : "0";

    return Container(
      width: 146,
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
      decoration: BoxDecoration(
        color: notifires.getbgcolor,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: themeColor.withValues(alpha: 0.2)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(Icons.dashboard_customize_rounded,
                  size: 14, color: themeColor),
              const SizedBox(width: 6),
              Text(
                "Dashboard".translate(context),
                style: headingBlackBold(context).copyWith(fontSize: 10),
              ),
            ],
          ),
          const SizedBox(height: 8),
          _DashboardMetricTile(
            icon: Icons.payments_rounded,
            label: "Earnings".translate(context),
            value: earningValue,
            color: themeColor,
          ),
          const SizedBox(height: 7),
          _DashboardMetricTile(
            icon: Icons.star_rounded,
            label: "Ratings".translate(context),
            value: ratingValue,
            color: Colors.amber.shade700,
          ),
          const SizedBox(height: 7),
          _DashboardMetricTile(
            icon: Icons.receipt_long_rounded,
            label: "Total Order's".translate(context),
            value: ordersValue,
            color: Colors.blueGrey,
          ),
        ],
      ),
    );
  }
}

class _DashboardMetricTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _DashboardMetricTile({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.18)),
      ),
      child: Row(
        children: [
          Container(
            width: 26,
            height: 26,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.14),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, size: 14, color: color),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  style: headingBlackBold(context).copyWith(fontSize: 11),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 1),
                Text(
                  label,
                  style: regular(context).copyWith(
                    fontSize: 9.5,
                    color: Colors.grey.shade700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
