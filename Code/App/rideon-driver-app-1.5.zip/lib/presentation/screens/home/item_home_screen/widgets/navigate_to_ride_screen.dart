import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:ride_on_driver/presentation/screens/ride/ride_screen.dart';
import 'package:ride_on_driver/presentation/screens/ride/ride_screen_map_box.dart';
import 'package:ride_on_driver/presentation/screens/ride/ride_screen_ola.dart';
import '../../../../../core/services/data_store.dart';

void navigateToRideScreen({
  required BuildContext context,
  required bool isReplacement,
  required String rideId,
  required bool fromInitialPage,
  String? tripTitle,
  bool? isOnDutyArrived,
  LatLng? currentLatLang,
}) {
  final mapType = box.get("mapType");

  Widget screen;

  switch (mapType) {
    case "mapBox":
      screen = RideScreensMapBox(
        rideId: rideId,
        fromInitialPage: fromInitialPage,
        tripTitle: tripTitle,
        isOnDutyArrived: isOnDutyArrived,
        currentLatLang: currentLatLang,
      );
      break;

    case "ola":
      screen = RideScreensOla(
        rideId: rideId,
        fromInitialPage: fromInitialPage,
        tripTitle: tripTitle,
        isOnDutyArrived: isOnDutyArrived,
        currentLatLang: currentLatLang,
      );
      break;

    case "google":
    default:
      screen = RideScreens(
        rideId: rideId,
        fromInitialPage: fromInitialPage,
        tripTitle: tripTitle,
        isOnDutyArrived: isOnDutyArrived,
        currentLatLang: currentLatLang,
      );
  }

  if (isReplacement) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => screen),
    );
  } else {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => screen),
    );
  }
}
