import 'package:flutter/material.dart';
import '../../../../../core/utils/theme/project_color.dart';

class MapButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const MapButton({super.key, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          width: 34,
          height: 34,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: notifires.getbgcolor,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: themeColor),
          ),
          child: Icon(icon, size: 16, color: themeColor),
        ),
      ),
    );
  }
}
