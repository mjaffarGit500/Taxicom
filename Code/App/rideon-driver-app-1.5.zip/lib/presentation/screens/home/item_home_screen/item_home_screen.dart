import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import 'package:ride_on_driver/presentation/cubits/general_cubit.dart';
import '../../../../core/extensions/helper/push_notifications.dart';
import '../../../../core/extensions/workspace.dart';
import '../../../../core/services/data_store.dart';
import '../../../../core/utils/common_widget.dart';
import '../../../../core/utils/theme/project_color.dart';
import '../../../../core/utils/theme/theme_style.dart';
import '../../../../main.dart';
import '../../../cubits/account/update_profile_cubit.dart';
import '../../../cubits/bottom_bar_cubit.dart';
import '../../../cubits/dashboard/dashboard_cubit.dart';
import '../../../cubits/location/location_cubit.dart';
import '../../../cubits/location/ringtone_cubit.dart';
import '../../../cubits/payment/wallet_data_cubit.dart';
import '../../../cubits/realtime/listen_ride_request_cubit.dart';
import '../../../cubits/realtime/manage_driver_cubit.dart';
import '../../splash/allow_location_screen.dart';
import 'widgets/driver_dashboard_rail.dart';
import 'widgets/duty_switch.dart';
import 'widgets/map_button.dart';
import 'widgets/reload_map_button.dart';
import 'widgets/show_custom_bottom_sheet.dart';

export 'widgets/custom_bottom_sheet.dart';
export 'widgets/custom_bottom_sheet_for_parcel.dart';
export 'widgets/navigate_to_ride_screen.dart';
export 'widgets/parcel_info_widget.dart';
export 'widgets/show_custom_bottom_sheet.dart';

bool get appIsInBackground {
  final state = WidgetsBinding.instance.lifecycleState;
  return state == AppLifecycleState.paused ||
      state == AppLifecycleState.inactive ||
      state == AppLifecycleState.detached;
}

class ItemHomeScreen extends StatefulWidget {
  const ItemHomeScreen({super.key});

  @override
  State<ItemHomeScreen> createState() => _ItemHomeScreenState();
}

class _ItemHomeScreenState extends State<ItemHomeScreen>
    with AutomaticKeepAliveClientMixin, WidgetsBindingObserver {
  AppLifecycleState _appLifecycleState = AppLifecycleState.resumed;

  GoogleMapController? mapController;
  final Completer<GoogleMapController> _controller = Completer();
  LatLng? currentLocation;
  bool isOnDuty = false;
  String? lastHandledRideId;
  bool isBottomSheetOpen = false;
  Timer? _debounceTimer;
  @override
  bool get wantKeepAlive => true;
  late Future<void> _startupBarrier;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      context.read<LocationCubit>().startLiveLocationTracking();
      context.read<WalletDataCubit>().getWallet();
      final driverIdUpdated =
          box.get("driverId") ?? loginModel?.data?.fireStoreId ?? "";

      if (driverIdUpdated.isNotEmpty) {
        driverId = driverIdUpdated;
        context
            .read<UpdateDriverParameterCubit>()
            .updateDriverId(driverId: driverIdUpdated.toString());
        _startupBarrier = checkAndCleanRideOnStartup(driverId: driverIdUpdated);
        await _startupBarrier;
        // ignore_for_file: use_build_context_synchronously
        context.read<UpdateRideRequestCubit>().updateAddPlayerId(
              driverId: driverIdUpdated,
              oneSignalPlayerId: oneSignalPlayerId ?? "",
            );
        context
            .read<GetDocApprovalStatusCubit>()
            .listenToDocApprovalStatus(driverId: driverIdUpdated);
        context
            .read<GetDriverStatusCubit>()
            .listenDriverStatusStatus(driverId: driverIdUpdated);

        context
            .read<ListenRideRequestCubit>()
            .listenForRideRequests(driverIdUpdated, context: context);
      }
      context.read<DashboardCubit>().dashBoardDriver(context: context);
      context.read<MyImageCubit>().updateMyImage(myImage);
      context.read<NameCubit>().updateName(loginModel?.data?.firstName ?? "");
      context.read<PhoneCubit>().updatePhone(loginModel?.data?.phone ?? "");
    });
    showNotification(context);
  }

  void zoomIn() => mapController?.animateCamera(CameraUpdate.zoomIn());
  void zoomOut() => mapController?.animateCamera(CameraUpdate.zoomOut());

  void centerMap() {
    if (currentLocation != null) {
      mapController?.animateCamera(CameraUpdate.newLatLng(currentLocation!));
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _debounceTimer?.cancel();
    mapController?.dispose();

    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _appLifecycleState = state;
  }

  bool get appIsInForeground => _appLifecycleState == AppLifecycleState.resumed;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    // ignore: deprecated_member_use
    return WillPopScope(
      onWillPop: () async {
        dialogExit(context);
        return false;
      },
      child: MultiBlocListener(
        listeners: [
          BlocListener<GetDocApprovalStatusCubit, String>(
            listener: (context, state) {
              bool isApproved = box.get("isApproved") ?? false;
              if (state == "approved" && isApproved == false) {
                box.put("isApproved", true);
                showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (context) => AlertDialog(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                    backgroundColor: Colors.white,
                    title: const Column(
                      children: [
                        Icon(Icons.verified, color: Colors.green, size: 48),
                        SizedBox(height: 10),
                        Text(
                          "Documents Approved",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                      ],
                    ),
                    content: const Text(
                      "Your documents have been successfully verified! 🎉\nYou are now ready to receive ride requests.",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 16, color: Colors.black54),
                    ),
                    actionsAlignment: MainAxisAlignment.center,
                    actions: [
                      InkWell(
                        onTap: () {
                          Navigator.pop(context);
                          context
                              .read<GetDocApprovalStatusCubit>()
                              .setIsApprovedStatus(
                                  driverId: context
                                      .read<UpdateDriverParameterCubit>()
                                      .state
                                      .driverId,
                                  status: "yes"); // Close dialog
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 24, vertical: 12),
                          decoration: BoxDecoration(
                            color: Colors.green,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Text(
                            "Great!",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
                context.read<GetDocApprovalStatusCubit>().setIsApprovedStatus(
                    driverId: context
                        .read<UpdateDriverParameterCubit>()
                        .state
                        .driverId,
                    status: "yes");
                loginModel!.data!.itemDocumentStatus = "approved";
                UserData userObj = UserData();
                userObj.saveLoginData(
                    "UserData", jsonEncode(loginModel!.toJson()));
              } else if (isApproved && state == "rejected") {
                box.put("isApproved", false);
                box.put("driver_status", false);
                loginModel!.data!.itemDocumentStatus = "rejected";
                UserData userObj = UserData();
                userObj.saveLoginData(
                    "UserData", jsonEncode(loginModel!.toJson()));
                context.read<UpdateDriverParameterCubit>().updateDriverStatus(
                      driverStatus: "inactive",
                    );
                context.read<UpdateDriverCubit>().updateFirebaseDriverStatus(
                      driverId: context
                          .read<UpdateDriverParameterCubit>()
                          .state
                          .driverId,
                      driverStatus: "inactive",
                    );
                showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (context) => AlertDialog(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                    backgroundColor: Colors.white,
                    title: const Column(
                      children: [
                        Icon(Icons.cancel_rounded,
                            color: Colors.redAccent, size: 48),
                        SizedBox(height: 10),
                        Text(
                          "Documents Rejected",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                      ],
                    ),
                    content: const Text(
                      "Unfortunately, your submitted documents have been rejected.\n\nPlease review the requirements and upload valid documents again, or contact support for help.",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 16, color: Colors.black54),
                    ),
                    actionsAlignment: MainAxisAlignment.center,
                    actions: [
                      InkWell(
                        onTap: () {
                          Navigator.pop(context);
                          context
                              .read<GetDocApprovalStatusCubit>()
                              .setIsApprovedStatus(
                                  driverId: context
                                      .read<UpdateDriverParameterCubit>()
                                      .state
                                      .driverId,
                                  status: "no"); // Close dialog
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 24, vertical: 12),
                          decoration: BoxDecoration(
                            color: Colors.redAccent,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Text(
                            "Close",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
                context.read<GetDocApprovalStatusCubit>().setIsApprovedStatus(
                    driverId: context
                        .read<UpdateDriverParameterCubit>()
                        .state
                        .driverId,
                    status: "no");
              }
            },
          ),
          BlocListener<GetDriverStatusCubit, String>(
              listener: (context, state) {
            if (state == "active") {
              context.read<UpdateDriverParameterCubit>().updateDriverStatus(
                    driverStatus: "active",
                  );
              context.read<UpdateDriverCubit>().updateFirebaseDriverStatus(
                    driverId: context
                        .read<UpdateDriverParameterCubit>()
                        .state
                        .driverId,
                    driverStatus: "active",
                  );
              context.read<GetDriverDataCubit>().updatedDriverStatus(state);
            } else {
              context.read<UpdateDriverParameterCubit>().updateDriverStatus(
                    driverStatus: "inactive",
                  );
              context.read<UpdateDriverCubit>().updateFirebaseDriverStatus(
                    driverId: context
                        .read<UpdateDriverParameterCubit>()
                        .state
                        .driverId,
                    driverStatus: "inactive",
                  );

              context.read<GetDriverDataCubit>().updatedDriverStatus(state);
            }
          }),
          BlocListener<ListenRideRequestCubit, ListenRideRequestState>(
            listener: (context, state) async {
              if (state is ListenRideRequestSuccess) {
                if (state.rideRequest != null) {
                  if (state.rideId == lastHandledRideId) {
                    return;
                  }
                  if (!box.get("driver_status", defaultValue: false)) return;

                  isBottomSheetOpen = true;
                  lastHandledRideId = state.rideId;
                  context
                      .read<UpdateDriverParameterCubit>()
                      .removeDriverPickupLatAndLng();
                  context
                      .read<UpdateDriverParameterCubit>()
                      .removeDriverDropOffLatAndLng();

                  context
                      .read<UpdateDriverParameterCubit>()
                      .updateRideId(rideId: state.rideId);
                  context
                      .read<UpdateDriverParameterCubit>()
                      .updateRideRequest(rideRequest: state.rideRequest);
                  context
                      .read<UpdateDriverParameterCubit>()
                      .updateDriverPickupAndDropOffAddress(
                        pickupAddress: state.rideRequest!.pickupLocation,
                        dropOffAddress: state.rideRequest!.dropoffLocation,
                      );

                  final requestStartTime =
                      box.get("ride_request_start_time") ?? DateTime.now();
                  box.put("ride_request_start_time", requestStartTime);
                  RingtoneHelper().playRingtone();
                  if (appIsInBackground) {
                    await openAppWithRideIntent(
                      pickup: state.rideRequest!.pickupLocation,
                      drop: state.rideRequest!.dropoffLocation,
                      distance: double.parse(
                          state.rideRequest!.travelDistance.toString()),
                      fare: double.parse(
                          state.rideRequest!.travelCharges.toString()),
                    );
                  }

                  showCustomBottomSheet(context,
                      rideRequest: state.rideRequest,
                      currebtLatlng: currentLocation ?? const LatLng(0, 0));
                  context
                      .read<ListenRideRequestCubit>()
                      .resetListenRideRequest();
                } else if (state.rideRequest == null) {
                  isBottomSheetOpen = false;
                  lastHandledRideId = null;
                  RingtoneHelper().stopRingtone();
                  flutterLocalNotificationsPlugin.cancel(100);

                  box.delete("ride_request_start_time");
                }
              }
            },
          ),
          BlocListener<WalletDataCubit, WalletDataState>(
            listener: (context, state) async {
              if (state is WalletDataSuccess) {
                walletBalance = double.parse(
                    (state.vendorWallet?.data?.walletBalance ?? "0.0")
                        .replaceAll(",", ""));
                double minimumNegative = double.parse(
                    context.read<MinimumNegativeCubit>().state.value ?? "20.0");
                if (walletBalance < -minimumNegative) {
                  context.read<UpdateDriverParameterCubit>().updateDriverStatus(
                        driverStatus: "inactive",
                      );
                  context.read<UpdateDriverCubit>().updateFirebaseDriverStatus(
                        driverId: context
                            .read<UpdateDriverParameterCubit>()
                            .state
                            .driverId,
                        driverStatus: "inactive",
                      );
                }
              }
            },
          ),
        ],
        child: Scaffold(
          body: Stack(
            children: [
              BlocBuilder<LocationCubit, LocationState>(
                builder: (context, state) {
                  if (state is LocationSucess) {
                    currentLocation = state.currentLocation;
                    centerMap();
                    final driverId = context
                        .read<UpdateDriverParameterCubit>()
                        .state
                        .driverId;
                    if (driverId.isNotEmpty && currentLocation != null) {
                      context.read<UpdateDriverCubit>().updateDriverLocation(
                            driverId: driverId,
                            currentLocation: currentLocation!,
                          );
                    }

                    context.read<HomeMarkerCubit>().addOrUpdateMarker(
                          currentLocation!,
                          'Driver Location',
                          'driver_marker',
                          'assets/images/driverPin.png',
                          90,
                        );
                  }

                  return BlocBuilder<HomeMarkerCubit, HomeMarkerState>(
                    builder: (context, markerState) {
                      if (currentLocation == null) {
                        return FutureBuilder(
                          future: Future.delayed(const Duration(seconds: 15)),
                          builder: (context, snapshot) {
                            if (snapshot.connectionState ==
                                ConnectionState.done) {
                              return ReloadMapButton(
                                onReload: () {
                                  context
                                      .read<LocationCubit>()
                                      .startLiveLocationTracking();
                                  setState(() {});
                                },
                              );
                            } else {
                              return forMapLoadingShimmer();
                            }
                          },
                        );
                      } else {
                        return GoogleMap(
                          initialCameraPosition: CameraPosition(
                            target: currentLocation ?? const LatLng(0, 0),
                            zoom: 12,
                          ),
                          markers: markerState is HomeMarkerUpdated
                              ? markerState.markers
                              : {},
                          onMapCreated: (controller) {
                            mapController = controller;
                            if (!_controller.isCompleted) {
                              _controller.complete(controller);
                            }
                          },
                        );
                      }
                    },
                  );
                },
              ),
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
                    child: _buildTopProfileHeader(context),
                  ),
                ),
              ),
              Positioned(
                top: 100,
                right: 16,
                child: Row(
                  children: [
                    SafeArea(
                      child: Container(
                        padding: const EdgeInsets.all(7),
                        child: Column(
                          children: [
                            MapButton(
                                icon: Icons.my_location_rounded,
                                onTap: centerMap),
                            const SizedBox(height: 6),
                            MapButton(icon: Icons.zoom_in, onTap: zoomIn),
                            const SizedBox(height: 6),
                            MapButton(icon: Icons.zoom_out, onTap: zoomOut),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              BlocBuilder<DashboardCubit, DashboardState>(
                builder: (context, state) {
                  return Positioned(
                    top: 100,
                    left: 12,
                    child: SafeArea(
                      child: DriverDashboardRail(state: state),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTopProfileHeader(BuildContext context) {
    final Map<String, dynamic>? userJson = loginModel?.data?.toJson();
    final String driverName = (userJson?["fullName"] ??
            userJson?["name"] ??
            userJson?["userName"] ??
            "Driver")
        .toString();

    return BlocBuilder<GetDocApprovalStatusCubit, String>(
      builder: (context, status) {
        final bool isOnline = box.get("driver_status", defaultValue: false);
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
            color: whiteColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: themeColor.withValues(alpha: 0.24)),
          ),
          child: Directionality(
            textDirection: TextDirection.ltr,
            child: Row(
              children: [
                GestureDetector(
                  onTap: () => context.read<BottomBarCubit>().changeTabIndex(3),
                  child: BlocBuilder<MyImageCubit, dynamic>(
                    builder: (context, state) {
                      return Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: themeColor.withValues(alpha: 0.2),
                              blurRadius: 8,
                              offset: const Offset(0, 3),
                            ),
                          ],
                          border: Border.all(
                              color: themeColor.withValues(alpha: 0.24),
                              width: 1.4),
                        ),
                        child: ClipOval(
                          child: state.toString().isEmpty
                              ? Container(
                                  color: Colors.grey.shade100,
                                  alignment: Alignment.center,
                                  child: Icon(
                                    CupertinoIcons.person_fill,
                                    size: 20,
                                    color: Colors.grey.shade700,
                                  ),
                                )
                              : myNetworkImage(state, height: 44, width: 44),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Welcome".translate(context),
                        style: regular(context).copyWith(
                          fontSize: 9,
                          color: Colors.grey.shade700,
                        ),
                      ),
                      const SizedBox(height: 1),
                      Text(
                        context.watch<NameCubit>().state,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: headingBlackBold(context).copyWith(fontSize: 12),
                      ),
                    ],
                  ),
                ),
                DutySwitch(
                  isOnline: isOnline,
                  status: status,
                  onToggle: () => _toggleDutyFromHeader(
                    context: context,
                    isOnline: isOnline,
                    status: status,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _toggleDutyFromHeader({
    required BuildContext context,
    required bool isOnline,
    required String status,
  }) async {
    final bool value = !isOnline;

    if (status != "approved") {
      _showVerificationPendingSheet(context);
      return;
    }

    box.put("driver_status", value);
    if (value == false) {
      showDutyConfirmationDialog(
        context: context,
        goingOnline: value,
        onConfirmed: () {
          setState(() {
            isOnDuty = value;
          });
          context.read<UpdateDriverParameterCubit>().updateDriverStatus(
                driverStatus: "inactive",
              );
          context.read<UpdateDriverCubit>().updateFirebaseDriverStatus(
                driverId:
                    context.read<UpdateDriverParameterCubit>().state.driverId,
                driverStatus: "inactive",
              );
        },
      );
      return;
    }

    if (walletBalance <
        -double.parse(
            context.read<MinimumNegativeCubit>().state.value ?? "20.0")) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          backgroundColor: Colors.white,
          contentPadding: const EdgeInsets.all(24),
          title: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.account_balance_wallet_rounded,
                  color: themeColor, size: 28),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  "Low Wallet Balance".translate(context),
                  style: heading2Grey1(context),
                ),
              ),
            ],
          ),
          content: Text(
            "Low balance! Recharge or add money now to stay active on the platform."
                .translate(context),
            style: regular2(context),
            textAlign: TextAlign.center,
          ),
          actions: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.grey[800],
                    side: const BorderSide(color: Colors.grey),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text(
                    "Later".translate(context),
                    style: heading3Grey1(context)
                        .copyWith(fontWeight: FontWeight.bold, fontSize: 13),
                  ),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: themeColor,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                    context.read<BottomBarCubit>().changeTabIndex(2);
                  },
                  child: Text(
                    "Add Money".translate(context),
                    style: heading3Grey1(context)
                        .copyWith(fontWeight: FontWeight.bold, fontSize: 13),
                  ),
                ),
              ],
            ),
          ],
        ),
      );
      return;
    }

    if (Platform.isIOS) {
      bool locationOK = await checkAndRequestAlwaysLocationPermission(context);
      if (!locationOK) return;
    }

    setState(() {
      isOnDuty = value;
    });
    context.read<UpdateDriverParameterCubit>().updateDriverStatus(
          driverStatus: "active",
        );
    context.read<UpdateDriverCubit>().updateFirebaseDriverStatus(
          driverId: context.read<UpdateDriverParameterCubit>().state.driverId,
          driverStatus: "active",
        );
  }

  void _showVerificationPendingSheet(BuildContext context) {
    showModalBottomSheet(
      backgroundColor: notifires.getbgcolor,
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.info_outline,
                  color: Colors.orangeAccent, size: 50),
              const SizedBox(height: 16),
              Text(
                "Account Verification In Progress".translate(context),
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
              ),
              const SizedBox(height: 10),
              Text(
                "We are reviewing your documents. You will get full access once verification is complete."
                    .translate(context),
                style: Theme.of(context).textTheme.bodyMedium,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }
}
