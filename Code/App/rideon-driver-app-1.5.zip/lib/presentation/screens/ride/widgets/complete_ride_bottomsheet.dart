import 'dart:convert';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on_driver/core/extensions/workspace.dart';
import 'package:ride_on_driver/core/services/data_store.dart';
import 'package:ride_on_driver/core/utils/common_widget.dart';
import 'package:ride_on_driver/core/utils/theme/project_color.dart';
import 'package:ride_on_driver/core/utils/theme/theme_style.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import 'package:ride_on_driver/domain/entities/realtime_ride_request.dart';
import 'package:ride_on_driver/presentation/cubits/realtime/listen_ride_request_cubit.dart';
import 'package:ride_on_driver/presentation/cubits/realtime/manage_driver_cubit.dart';
import 'package:ride_on_driver/presentation/cubits/realtime/ride_status_cubit.dart';
import 'package:ride_on_driver/presentation/screens/payment/payment_screen.dart';
import 'package:ride_on_driver/presentation/screens/ride/drop_otp_verify_screen.dart';
import 'package:ride_on_driver/presentation/widgets/sos_widget.dart';

class CustomBottomSheetForComplete extends StatefulWidget {
  final RealTimeRideRequest rideRequest;

  const CustomBottomSheetForComplete({super.key, required this.rideRequest});

  @override
  State<CustomBottomSheetForComplete> createState() =>
      _CustomBottomSheetForCompleteState();
}

class _CustomBottomSheetForCompleteState
    extends State<CustomBottomSheetForComplete> {
  static const Color _sheetDark = Color(0xFF2A1E1A);
  static const Color _sheetBrown = Color(0xFF8A5A10);

  bool isOnDutyCompleteRide = false;
  String totalTime = "";
  ValueNotifier<bool> hasUnreadMessage = ValueNotifier(false);

  void listenForUnread(String rideId, String driverId) {
    final ref =
        FirebaseDatabase.instance.ref("ride_requests/$rideId/chat/messages");

    ref.onValue.listen((event) {
      if (!event.snapshot.exists) {
        hasUnreadMessage.value = false;
        return;
      }

      Map data = event.snapshot.value as Map;

      bool unreadExists = data.values
          .any((msg) => msg["senderId"] != driverId && msg["seen"] == false);

      hasUnreadMessage.value = unreadExists;
    });
  }

  @override
  void initState() {
    super.initState();
    listenForUnread(widget.rideRequest.rideId ?? "", driverId);
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<GetRideDataCubit, GetRideDataState>(
        builder: (context, state) {
      if (state is UpdatedGetRideDataSuccess) {
        final RealTimeRideRequest model = state.requestDataModel!;
        final bookingId =
            context.read<UpdateDriverParameterCubit>().state.bookingId.isEmpty
                ? model.bookingId ?? ""
                : context.read<UpdateDriverParameterCubit>().state.bookingId;

        context
            .read<UpdateRideStatusInDatabaseCubit>()
            .updateCompleteRideStatus(
                context: context,
                bookingId: bookingId,
                rideStatus: "Completed",
                json: jsonEncode(model.toJson()),
                dropOtp: "",
                totalTime: totalTime);
      }
      return DraggableScrollableSheet(
        snap: true,
        initialChildSize: .50,
        minChildSize: .40,
        maxChildSize: .58,
        builder: (context, scrollController) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 0, 14, 0),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: InkWell(
                          onTap: () {
                            startLiveNavigation(
                                sourceLat: context
                                    .read<UpdateDriverParameterCubit>()
                                    .state
                                    .lat,
                                sourceLng: context
                                    .read<UpdateDriverParameterCubit>()
                                    .state
                                    .lng,
                                destLat:
                                    widget.rideRequest.dropoffLocation?.lat ??
                                        0.0,
                                destLng:
                                    widget.rideRequest.dropoffLocation?.lng ??
                                        0.0);
                          },
                          borderRadius: BorderRadius.circular(18),
                          child: Container(
                            alignment: Alignment.center,
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 14),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [themeColor, themeColor],
                              ),
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.near_me_rounded,
                                    size: 18, color: blackColor),
                                const SizedBox(width: 8),
                                Text(
                                  "Go to Drop".translate(context),
                                  style: headingBlackBold(context).copyWith(
                                    fontSize: 14,
                                    color: blackColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      const SosButtonWidget(),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: Container(
                  decoration: const BoxDecoration(
                    color: Color(0xFFFFFCF5),
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(28),
                      topRight: Radius.circular(28),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 12,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: SingleChildScrollView(
                      controller: scrollController,
                      padding: const EdgeInsets.fromLTRB(0, 12, 0, 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Center(
                            child: Container(
                              width: 54,
                              height: 5,
                              decoration: BoxDecoration(
                                color: Colors.grey.shade300,
                                borderRadius: BorderRadius.circular(20),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                  color: themeColor.withValues(alpha: 0.2)),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 58,
                                  height: 58,
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        themeColor,
                                        themeColor,
                                      ],
                                    ),
                                    shape: BoxShape.circle,
                                  ),
                                  child: ClipOval(
                                    child: myNetworkImage(
                                        widget.rideRequest.customer?.userPhoto),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        widget.rideRequest.customer?.userName ??
                                            "",
                                        style:
                                            headingBlackBold(context).copyWith(
                                          fontSize: 15,
                                          color: _sheetDark,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Row(
                                        children: [
                                          const Icon(Icons.star_rounded,
                                              size: 15, color: Colors.amber),
                                          const SizedBox(width: 4),
                                          Text(
                                            widget
                                                        .rideRequest
                                                        .customer
                                                        ?.userRating
                                                        ?.isNotEmpty ==
                                                    true
                                                ? widget.rideRequest.customer!
                                                    .userRating!
                                                : "0.0",
                                            style: regular(context).copyWith(
                                              fontSize: 11,
                                              color: Colors.grey.shade700,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 8),
                                InkWell(
                                  onTap: () {
                                    launchDialPad(
                                        "${widget.rideRequest.customer?.userPhoneCountry} ${widget.rideRequest.customer?.userPhone}");
                                  },
                                  child: Container(
                                    height: 38,
                                    width: 38,
                                    decoration: BoxDecoration(
                                      color: themeColor,
                                      shape: BoxShape.circle,
                                    ),
                                    child: Icon(
                                      Icons.call,
                                      color: blackColor,
                                      size: 18,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                              ],
                            ),
                          ),
                          const SizedBox(height: 14),
                          Text("Drop Location".translate(context),
                              style: regular2(context).copyWith(
                                color: _sheetBrown,
                                fontWeight: FontWeight.w600,
                              )),
                          const SizedBox(height: 12),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                width: 34,
                                height: 34,
                                decoration: BoxDecoration(
                                  color: greentext.withValues(alpha: 0.12),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Icon(
                                  Icons.location_on_outlined,
                                  color: greentext,
                                  size: 18,
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 12),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(16),
                                    border: Border.all(
                                        color:
                                            greentext.withValues(alpha: 0.18)),
                                  ),
                                  child: Text(
                                    widget.rideRequest.dropoffLocation
                                            ?.dropoffAddress ??
                                        "",
                                    style: headingBlack(context)
                                        .copyWith(fontSize: 12),
                                    softWrap: true,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 14),
                          Row(
                            children: [
                              Expanded(
                                child: Container(
                                  height: 1,
                                  color: Colors.grey.shade300,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 18),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.fromLTRB(14, 14, 14, 16),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withValues(alpha: 0.06),
                                  blurRadius: 12,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: BlocConsumer<UpdateRideStatusInDatabaseCubit,
                                UpdateRideStatusInDatabaseState>(
                              builder: (context, state) {
                                return Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Main Action".translate(context),
                                      style: regular(context).copyWith(
                                        fontSize: 11,
                                        color: _sheetBrown,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    const SizedBox(height: 6),
                                    Text(
                                      "Complete ride after safe drop-off"
                                          .translate(context),
                                      style: headingBlackBold(context).copyWith(
                                        fontSize: 13,
                                        color: _sheetDark,
                                      ),
                                    ),
                                    const SizedBox(height: 14),
                                    CustomSlideButton(
                                      activeColor: themeColor,
                                      iconColor: blackColor,
                                      inactiveColor: themeColor,
                                      isOnRide: isOnDutyCompleteRide,
                                      textActiveColor: blackColor,
                                      textInactiveColor: blackColor,
                                      acceptedText: "Completed",
                                      defaultText: "COMPLETE RIDE",
                                      onChanged: (value) {
                                        box.put("rideEndTime", DateTime.now());
                                        setState(() {
                                          isOnDutyCompleteRide = value;
                                          if (value) {
                                            context
                                                .read<
                                                    UpdateRideStatusInDatabaseCubit>()
                                                .resetStatus();
                                            final bookingId = context
                                                    .read<
                                                        UpdateDriverParameterCubit>()
                                                    .state
                                                    .bookingId
                                                    .isEmpty
                                                ? widget.rideRequest
                                                        .bookingId ??
                                                    ""
                                                : context
                                                    .read<
                                                        UpdateDriverParameterCubit>()
                                                    .state
                                                    .bookingId;
                                            if (bookingId.isNotEmpty) {
                                              if ((widget.rideRequest.parcalData
                                                              ?.name ??
                                                          "")
                                                      .isNotEmpty &&
                                                  (widget.rideRequest.parcalData
                                                              ?.reciverNumber ??
                                                          "")
                                                      .isNotEmpty &&
                                                  (widget.rideRequest.parcalData
                                                              ?.reciverName ??
                                                          "")
                                                      .isNotEmpty) {
                                                final endTime =
                                                    getCurrentFormattedTime();
                                                box.put("end_time", endTime);
                                                final startTime =
                                                    box.get("start_time");
                                                totalTime =
                                                    calculateMinutesBetween(
                                                            startTime, endTime)
                                                        .toString();

                                                goTo(DropOtpVerifyRideScreen(
                                                  bookingId: bookingId,
                                                  realTimeRideRequest:
                                                      widget.rideRequest,
                                                  userName: widget.rideRequest
                                                          .customer?.userName ??
                                                      "",
                                                  totalTime: totalTime,
                                                ));
                                                return;
                                              } else {
                                                context
                                                    .read<
                                                        UpdateRideRequestCubit>()
                                                    .updatePendingRideRequests(
                                                      rideId: widget.rideRequest
                                                              .rideId ??
                                                          "",
                                                      newStatus: "completed",
                                                    );
                                                final endTime =
                                                    getCurrentFormattedTime();
                                                box.put("end_time", endTime);
                                                final startTime =
                                                    box.get("start_time");
                                                totalTime =
                                                    calculateMinutesBetween(
                                                            startTime, endTime)
                                                        .toString();

                                                context
                                                    .read<GetRideDataCubit>()
                                                    .fetchUpdatedRideData(widget
                                                            .rideRequest.rideId
                                                            ?.toString() ??
                                                        "");

                                                goTo(PaymentScreen(
                                                  rideRequest:
                                                      widget.rideRequest,
                                                ));
                                              }
                                            }
                                            Future.delayed(
                                                const Duration(
                                                    milliseconds: 200), () {
                                              isOnDutyCompleteRide = false;
                                            });
                                          }
                                        });
                                      },
                                    ),
                                  ],
                                );
                              },
                              listener: (context, state) {
                                if (state
                                    is CompleteRideStatusSuceessUpdated) {}
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      );
    });
  }
}
