import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:ride_on_driver/presentation/cubits/location/get_polyline_cubit.dart';
import 'package:ride_on_driver/presentation/cubits/location/location_cubit.dart';

class PersistentGoogleMap extends StatefulWidget {
  final LatLng initialPosition;

  final bool myLocationEnabled;
  final Function(GoogleMapController) onMapCreated;

  const PersistentGoogleMap({
    super.key,
    required this.initialPosition,
    required this.myLocationEnabled,
    required this.onMapCreated,
  });

  @override
  PersistentGoogleMapState createState() => PersistentGoogleMapState();
}

class PersistentGoogleMapState extends State<PersistentGoogleMap> {
  GoogleMapController? _mapController;

  Set<Marker> markers = {};
  Set<Polyline> polyline = {};

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MarkerCubit, MarkerState>(
      builder: (context, markerState) {
        if (markerState is MarkerUpdated) {
          markers = markerState.markers;
        }

        return BlocBuilder<GetPolylineCubit, GetPolylineState>(
          builder: (context, polylineState) {
            if (polylineState is GetPolylineUpdated) {
              polyline = polylineState.polylines ?? {};
              WidgetsBinding.instance.addPostFrameCallback((_) {
                _moveCameraToFitPolylineAndMarkers();
              });
            }

            return GoogleMap(
              initialCameraPosition: CameraPosition(
                target: widget.initialPosition,
                zoom: 15,
              ),
              myLocationEnabled: widget.myLocationEnabled,
              markers: markers,
              polylines: polyline,
              onMapCreated: (controller) {
                if (_mapController == null) {
                  _mapController = controller;
                  widget.onMapCreated(controller);
                }
              },
            );
          },
        );
      },
    );
  }

  void _moveCameraToFitPolylineAndMarkers() {
    if (_mapController == null || (polyline.isEmpty && markers.isEmpty)) return;

    LatLngBounds bounds;

    final points = [
      ...polyline.expand((p) => p.points),
      ...markers.map((m) => m.position),
    ];

    if (points.isEmpty) return;

    final southwestLat =
        points.map((p) => p.latitude).reduce((a, b) => a < b ? a : b);
    final southwestLng =
        points.map((p) => p.longitude).reduce((a, b) => a < b ? a : b);
    final northeastLat =
        points.map((p) => p.latitude).reduce((a, b) => a > b ? a : b);
    final northeastLng =
        points.map((p) => p.longitude).reduce((a, b) => a > b ? a : b);

    bounds = LatLngBounds(
      southwest: LatLng(southwestLat, southwestLng),
      northeast: LatLng(northeastLat, northeastLng),
    );

    _mapController!.animateCamera(
      CameraUpdate.newLatLngBounds(bounds, 130), // 50 = padding
    );
  }
}