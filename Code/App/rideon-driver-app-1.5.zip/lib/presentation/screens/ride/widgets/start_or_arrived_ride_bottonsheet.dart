import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on_driver/core/extensions/helper/push_notifications.dart';
import 'package:ride_on_driver/core/extensions/workspace.dart';
import 'package:ride_on_driver/core/services/data_store.dart';
import 'package:ride_on_driver/core/utils/common_widget.dart';
import 'package:ride_on_driver/core/utils/theme/project_color.dart';
import 'package:ride_on_driver/core/utils/theme/theme_style.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import 'package:ride_on_driver/domain/entities/realtime_ride_request.dart';
import 'package:ride_on_driver/presentation/cubits/realtime/listen_ride_request_cubit.dart';
import 'package:ride_on_driver/presentation/cubits/realtime/manage_driver_cubit.dart';
import 'package:ride_on_driver/presentation/cubits/realtime/ride_status_cubit.dart';
import 'package:ride_on_driver/presentation/screens/bottom_bar/home_main.dart';
import 'package:ride_on_driver/presentation/screens/ride/chat_screen.dart';
import 'package:ride_on_driver/presentation/widgets/sos_widget.dart';

class CustomRideBottomSheet extends StatefulWidget {
  final RealTimeRideRequest rideRequest;
  final VoidCallback onTap;
  final String titleText;
  final Color activeColor;
  final Color inactiveColor;
  final String acceptedText;
  final String defaultText;
  final String? addressText;
  final bool isOnDutyRide;
  final Color? textInactiveColor;
  final Color? textActiveColor;
  final Function(bool) onChanged;
  final String? pickupString;

  final String? userPhoneCountry;
  // ignore: non_constant_identifier_names
  final Color? IconBoxColor;

  const CustomRideBottomSheet(
      {super.key,
      required this.titleText,
      required this.onTap,
      required this.rideRequest,
      this.pickupString,
      required this.isOnDutyRide,
      required this.activeColor,
      this.textActiveColor,
      this.textInactiveColor,
      required this.onChanged,
      required this.inactiveColor,
      // ignore: non_constant_identifier_names
      this.IconBoxColor,
      this.userPhoneCountry,
      required this.acceptedText,
      required this.defaultText,
      required this.addressText});

  @override
  // ignore: library_private_types_in_public_api
  _CustomRideBottomSheetState createState() => _CustomRideBottomSheetState();
}

class _CustomRideBottomSheetState extends State<CustomRideBottomSheet> {
  static const Color _sheetDark = Color(0xFF2A1E1A);
  static const Color _sheetBrown = Color(0xFF8A5A10);

  ValueNotifier<bool> hasUnreadMessage = ValueNotifier(false);

  void listenForUnread(String rideId, String driverId) {
    final ref =
        FirebaseDatabase.instance.ref("ride_requests/$rideId/chat/messages");

    ref.onValue.listen((event) {
      if (!event.snapshot.exists) {
        hasUnreadMessage.value = false;
        return;
      }

      Map data = event.snapshot.value as Map;

      bool unreadExists = data.values
          .any((msg) => msg["senderId"] != driverId && msg["seen"] == false);

      hasUnreadMessage.value = unreadExists;
    });
  }

  @override
  initState() {
    super.initState();
    listenForUnread(widget.rideRequest.rideId ?? "", driverId);
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        DraggableScrollableSheet(
          initialChildSize: 0.52,
          minChildSize: 0.44,
          maxChildSize: 0.68,
          builder: (context, scrollController) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: widget.onTap,
                            borderRadius: BorderRadius.circular(18),
                            child: Container(
                              alignment: Alignment.center,
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 14),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [themeColor, themeColor],
                                ),
                                borderRadius: BorderRadius.circular(18),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.near_me_rounded,
                                    size: 18,
                                    color: blackColor,
                                  ),
                                  const SizedBox(width: 8),
                                  Flexible(
                                    child: Text(
                                      widget.pickupString?.translate(context) ??
                                          "Head to pickup".translate(context),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: headingBlackBold(context).copyWith(
                                        fontSize: 14,
                                        color: blackColor,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        const SosButtonWidget(),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: Container(
                    decoration: const BoxDecoration(
                      color: Color(0xFFFFFCF5),
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(28),
                        topRight: Radius.circular(28),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black26,
                          blurRadius: 12,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: SingleChildScrollView(
                      controller: scrollController,
                      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Center(
                            child: Container(
                              width: 54,
                              height: 5,
                              decoration: BoxDecoration(
                                color: Colors.grey.shade300,
                                borderRadius: BorderRadius.circular(30),
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),
                          Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(18),
                              border: Border.all(
                                  color: themeColor.withValues(alpha: 0.2)),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(2),
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [themeColor, themeColor],
                                    ),
                                    shape: BoxShape.circle,
                                  ),
                                  child: ClipOval(
                                    child: Container(
                                      height: 52,
                                      width: 52,
                                      color: notifires.getBoxColor,
                                      child: myNetworkImage(widget
                                          .rideRequest.customer?.userPhoto),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        widget.rideRequest.customer?.userName ??
                                            "",
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: headingBlackBold(context)
                                            .copyWith(
                                                fontSize: 14,
                                                color: _sheetDark),
                                      ),
                                      const SizedBox(height: 4),
                                      Row(
                                        children: [
                                          Icon(Icons.star_rounded,
                                              color: orangeColor, size: 14),
                                          const SizedBox(width: 4),
                                          Text(
                                            widget
                                                        .rideRequest
                                                        .customer
                                                        ?.userRating
                                                        ?.isNotEmpty ==
                                                    true
                                                ? widget.rideRequest.customer!
                                                    .userRating!
                                                : "0.0",
                                            style: regular2(context).copyWith(
                                              fontSize: 11,
                                              color: Colors.grey.shade700,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 8),
                                InkWell(
                                  onTap: () {
                                    launchDialPad(
                                        "${widget.rideRequest.customer?.userPhoneCountry} ${widget.rideRequest.customer?.userPhone}");
                                  },
                                  child: Container(
                                    height: 38,
                                    width: 38,
                                    decoration: BoxDecoration(
                                      color: themeColor,
                                      shape: BoxShape.circle,
                                    ),
                                    child: Icon(
                                      Icons.call,
                                      color: blackColor,
                                      size: 18,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                ValueListenableBuilder<bool>(
                                  valueListenable: hasUnreadMessage,
                                  builder: (context, unread, _) {
                                    return Stack(
                                      clipBehavior: Clip.none,
                                      children: [
                                        InkWell(
                                          onTap: () {
                                            goTo(DriverChatScreen(
                                              rideRequest: widget.rideRequest,
                                              driverId: driverId,
                                            ));
                                            hasUnreadMessage.value = false;
                                          },
                                          child: Container(
                                            height: 38,
                                            width: 38,
                                            decoration: BoxDecoration(
                                              color: greentext,
                                              shape: BoxShape.circle,
                                            ),
                                            child: Icon(Icons.chat,
                                                color: whiteColor, size: 18),
                                          ),
                                        ),
                                        if (unread)
                                          Positioned(
                                            right: -1,
                                            top: -1,
                                            child: Container(
                                              height: 12,
                                              width: 12,
                                              decoration: BoxDecoration(
                                                color: Colors.green,
                                                shape: BoxShape.circle,
                                                border: Border.all(
                                                  color: Colors.white,
                                                  width: 2,
                                                ),
                                              ),
                                            ),
                                          )
                                      ],
                                    );
                                  },
                                ),
                                const SizedBox(width: 8),
                                InkWell(
                                  onTap: () async {
                                    final bookingId = await context.read<UpdateBookingIdCubit>()
                                        .getBookingId(
                                            rideId: context
                                                .read<
                                                    UpdateDriverParameterCubit>()
                                                .state
                                                .rideId);
                                    if (!context.mounted) return;
                                    _showCancelRideBottomSheet(
                                      context,
                                      bookingId.toString(),
                                    );
                                  },
                                  child: Container(
                                    height: 38,
                                    width: 38,
                                    decoration: BoxDecoration(
                                      color: redColor,
                                      shape: BoxShape.circle,
                                    ),
                                    child: const Icon(
                                      Icons.close,
                                      color: Colors.white,
                                      size: 18,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            widget.pickupString.toString() == "Go to Drop"
                                ? "Drop Location".translate(context)
                                : "Pickup Location".translate(context),
                            style: regular2(context).copyWith(
                              color: _sheetBrown,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                  color: greentext.withValues(alpha: 0.18)),
                            ),
                            child: Column(
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      width: 32,
                                      height: 32,
                                      decoration: BoxDecoration(
                                        color:
                                            greentext.withValues(alpha: 0.12),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Icon(Icons.location_on_outlined,
                                          color: greentext, size: 18),
                                    ),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Text(
                                        widget.addressText ?? "",
                                        style: headingBlack(context)
                                            .copyWith(fontSize: 12),
                                        softWrap: true,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 12),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.fromLTRB(14, 14, 14, 16),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withValues(alpha: 0.06),
                                  blurRadius: 12,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Main Action".translate(context),
                                  style: regular(context).copyWith(
                                    fontSize: 11,
                                    color: _sheetBrown,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  "Slide only after reaching the passenger"
                                      .translate(context),
                                  style: headingBlackBold(context).copyWith(
                                    fontSize: 13,
                                    color: _sheetDark,
                                  ),
                                ),
                                const SizedBox(height: 14),
                                CustomSlideButton(
                                    textActiveColor: widget.textActiveColor,
                                    textInactiveColor: widget.textInactiveColor,
                                    activeColor: widget.activeColor,
                                    inactiveColor: widget.inactiveColor,
                                    isOnRide: widget.isOnDutyRide,
                                    acceptedText: widget.acceptedText,
                                    defaultText: widget.defaultText,
                                    onChanged: widget.onChanged),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ],
    );
  }

  Future<void> cancelRideRequest({
    required String rideId,
    required String bookingId,
  }) async {
    try {
      if (rideId.isEmpty) {
        throw Exception('Ride ID cannot be empty');
      }

      context.read<UpdateRideRequestCubit>().updatePendingRideRequests(
            rideId: context.read<UpdateDriverParameterCubit>().state.rideId,
            newStatus: "rejected",
          );
      context.read<UpdateRideStatusInDatabaseCubit>().updateRideStatus(
            context: context,
            bookingId: bookingId,
            rideStatus: "Rejected",
          );

      context.read<UpdateRideRequestCubit>().removeRideRequest(
          skipStatus: true, rideId: rideId, driverId: driverId);

      sendNotificationDirect(
          playerId: widget.rideRequest.playerId ?? '',
          title: "Ride Rejected ❌",
          message: "Your ride has been rejected by the driver.");
    } catch (e) {
      // Emit error state

      throw Exception('Failed to cancel ride request: $e');
    }
  }

  void _showCancelRideBottomSheet(BuildContext context, String bookingId) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFFFFFCF5),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
      ),
      builder: (BuildContext context) {
        return Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.red.shade400,
                      Colors.red.shade700,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Icon(Icons.warning_amber_rounded,
                    color: Colors.white, size: 28),
              ),
              const SizedBox(height: 14),
              Text(
                "Cancel Ride Confirmation".translate(context),
                style: heading2Grey1(context).copyWith(color: _sheetDark),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 10),
              Text(
                "You have already accepted this ride.\nCanceling now may impact your rating or future ride requests."
                    .translate(context),
                style: regular(context)
                    .copyWith(color: Colors.grey.shade700, fontSize: 12),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  InkWell(
                    onTap: () {
                      box.delete('ride_id');
                      cancelRideRequest(
                        rideId: context
                            .read<UpdateDriverParameterCubit>()
                            .state
                            .rideId,
                        bookingId: bookingId,
                      );
                      // Navigator.pop(context);
                      goToWithClear(const HomeMain(initialIndex: 0));
                    },
                    child: Container(
                      alignment: Alignment.center,
                      height: 50,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 5),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.red.shade400,
                            Colors.red.shade700,
                          ],
                        ),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Text(
                        "Cancel Ride".translate(context),
                        style: regular2(context).copyWith(
                            color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  InkWell(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      alignment: Alignment.center,
                      height: 50,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 5),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                            color: themeColor.withValues(alpha: 0.24)),
                      ),
                      child: Text(
                        "Continue Ride".translate(context),
                        style: regular2(context).copyWith(
                            color: _sheetDark, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}