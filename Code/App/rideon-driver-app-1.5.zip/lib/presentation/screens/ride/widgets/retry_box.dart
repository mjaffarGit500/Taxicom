import 'package:flutter/material.dart';
import 'package:ride_on_driver/core/utils/common_widget.dart';
import 'package:ride_on_driver/core/utils/theme/project_color.dart';
import 'package:ride_on_driver/core/utils/theme/theme_style.dart';
import 'package:ride_on_driver/core/utils/translate.dart';

class RetryWithGoHome extends StatelessWidget {
  final bool showNoData;
  final bool hasRetried;
  final VoidCallback onRetry;
  final VoidCallback onGoHome;

  const RetryWithGoHome({
    super.key,
    required this.showNoData,
    required this.hasRetried,
    required this.onRetry,
    required this.onGoHome,
  });

  @override
  Widget build(BuildContext context) {
    if (!showNoData) return const SizedBox();

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            myAssetImage("assets/images/something.png",
                height: 120, width: 120),
            const SizedBox(height: 12),
            Text(
              "Something went wrong".translate(context),
              style: heading3Grey1(context).copyWith(color: grey2),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 6),
            Text(
              "Please try again".translate(context),
              style: regular3(context),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            Wrap(
              runAlignment: WrapAlignment.center,
              crossAxisAlignment: WrapCrossAlignment.center,
              alignment: WrapAlignment.center,
              runSpacing: 10,
              children: [
                ElevatedButton.icon(
                  icon: const Icon(Icons.refresh, size: 18),
                  onPressed: onRetry,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueAccent,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  label: Text(
                    "Try Again".translate(context),
                    style: heading3Grey1(context)
                        .copyWith(color: Colors.white, fontSize: 15),
                  ),
                ),
                if (hasRetried) ...[
                  const SizedBox(width: 12),
                  OutlinedButton.icon(
                    icon: Icon(
                      Icons.home_outlined,
                      size: 18,
                      color: blackColor,
                    ),
                    onPressed: onGoHome,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: themeColor,
                      backgroundColor: themeColor,
                      side: BorderSide(color: themeColor, width: 1.2),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 22, vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    label: Text("Go Home".translate(context),
                        style: heading3Grey1(context)
                            .copyWith(color: blackColor, fontSize: 15)),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}
