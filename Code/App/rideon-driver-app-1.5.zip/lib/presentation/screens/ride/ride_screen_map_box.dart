import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart'
    hide ScreenCoordinate;
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart' as mapbox;
import 'package:ride_on_driver/core/extensions/helper/push_notifications.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import 'package:ride_on_driver/main.dart';
import 'package:ride_on_driver/presentation/cubits/location/get_polyline_map_box_cubit.dart';
import 'package:ride_on_driver/presentation/screens/home/item_home_screen/item_home_screen.dart';
import 'package:ride_on_driver/presentation/screens/ride/pickup_parcel_image_screen.dart';
import 'package:ride_on_driver/presentation/screens/ride/widgets/complete_ride_bottomsheet.dart';
import 'package:ride_on_driver/presentation/screens/ride/widgets/retry_box.dart';
import 'package:ride_on_driver/presentation/screens/ride/widgets/start_or_arrived_ride_bottonsheet.dart';
import '../../../core/extensions/workspace.dart';
import '../../../core/services/data_store.dart';
import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../../domain/entities/realtime_ride_request.dart';
import '../../cubits/location/location_cubit.dart';
import '../../cubits/realtime/listen_ride_request_cubit.dart';
import '../../cubits/realtime/manage_driver_cubit.dart';
import '../../cubits/realtime/ride_status_cubit.dart';
import '../bottom_bar/home_main.dart';
import 'otp_verify_ride_screen.dart';

class RideScreensMapBox extends StatefulWidget {
  final String? tripTitle;
  final String? buttonTitle;
  final String? rideId;
  final bool? isOnDutyCompleted;
  final bool? isOnDutyStart;
  final bool? isOnDutyArrived;
  final bool? fromInitialPage;
  final LatLng? currentLatLang;
  const RideScreensMapBox({
    super.key,
    this.tripTitle,
    this.buttonTitle,
    this.rideId,
    this.isOnDutyCompleted,
    this.isOnDutyArrived,
    this.fromInitialPage,
    this.isOnDutyStart,
    this.currentLatLang,
  });
  @override
  State<RideScreensMapBox> createState() => _RideScreenState();
}

class _RideScreenState extends State<RideScreensMapBox> {
  RealTimeRideRequest? rideData;
  ParcalData? parcalData;

  bool isOnDutyCompleted = false;
  bool isShowPopUp = false;
  bool _isMapInitialized = false;
  LatLng? currentLocation;
  bool showNoData = false;
  bool hasRetried = false;
  MapboxMap? mapController;
  final Completer<MapboxMap> _controller = Completer<MapboxMap>();


  @override
  void initState() {
    super.initState();

    currentLocation = widget.currentLatLang;
    context.read<UserMarkerCubitMapbox>().clear();
    context.read<GetPolylineMapBoxCubit>().resetPolylines();
    context.read<GetRideDataCubit>().clear();
    context.read<GetRideDataCubit>().fetchRideData(widget.rideId!);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<RideLocationCubit>().startLiveLocationTracking();
      context.read<LocationCubit>().startLiveLocationTracking();
      context
          .read<GetRideRequestStatusCubit>()
          .listenToRouteStatus(rideId: widget.rideId!);
    });
    isOnDutyCompleted = widget.isOnDutyCompleted ?? false;
    Future.delayed(const Duration(seconds: 15), () {
      if (mounted && currentLocation == null) {
        setState(() {
          showNoData = true;
        });
      }
    });
    Future.delayed(const Duration(seconds: 1), () {
      if (widget.fromInitialPage == false) {
        sendNotificationIfDriverSelected(
            rideId: widget.rideId ?? "",
            driverId: (loginModel?.data?.id ?? "").toString(),
            playerId: rideData?.playerId ?? "",
            title: "Ride Accepted 🚗",
            message: "Your ride has been accepted by the driver.");
      }
    });
  }

  bool _isLocationStarted = false;
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_isLocationStarted) {
      context.read<RideLocationCubit>().startLiveLocationTracking();
      context.read<LocationCubit>().startLiveLocationTracking();
      _isLocationStarted = true;
    }
  }

  void showGoHomeDialog(BuildContext context, VoidCallback onConfirm) {
    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          backgroundColor: screenCream,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          titlePadding: const EdgeInsets.fromLTRB(22, 22, 22, 12),
          contentPadding: const EdgeInsets.fromLTRB(22, 0, 22, 18),
          title: Column(
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [themeColor, themeColor],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Icon(
                  Icons.warning_amber_rounded,
                  color: Colors.white,
                  size: 30,
                ),
              ),
              const SizedBox(height: 14),
              Text(
                "Leave Ride?".translate(context),
                style: heading1Grey1(context).copyWith(color: screenDark),
                textAlign: TextAlign.center,
              ),
            ],
          ),
          content: Text(
            "If you go home now, this ride will be canceled.\nAre you sure you want to leave?"
                .translate(context),
            style: regular2(context).copyWith(color: Colors.grey.shade700),
            textAlign: TextAlign.center,
          ),
          actionsPadding: const EdgeInsets.all(12),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(
                "No, Stay".translate(context),
                style: heading3Grey1(context).copyWith(fontSize: 15),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: themeColor,
                foregroundColor: blackColor,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onPressed: () {
                Navigator.pop(ctx);
                onConfirm();
              },
              child: Text(
                "Yes, Go Home".translate(context),
                style: heading3Grey1(context)
                    .copyWith(color: blackColor, fontSize: 15),
              ),
            ),
          ],
        );
      },
    );
  }

  void _showRideCancelledDialog({required bool useClearNavigation}) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => PopScope(
        canPop: false,
        child: AlertDialog(
          backgroundColor: screenCream,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          titlePadding: const EdgeInsets.fromLTRB(22, 24, 22, 10),
          contentPadding: const EdgeInsets.fromLTRB(22, 0, 22, 18),
          title: Column(
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.red.shade400,
                      Colors.red.shade700,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Icon(Icons.cancel_rounded,
                    color: Colors.white, size: 30),
              ),
              const SizedBox(height: 14),
              Text(
                "Ride Cancelled".translate(context),
                textAlign: TextAlign.center,
                style: heading2Grey1(context).copyWith(color: screenDark),
              ),
            ],
          ),
          content: Text(
            "The rider has cancelled the ride request.\n\nYou can head back to the home screen and wait for another ride."
                .translate(context),
            textAlign: TextAlign.center,
            style: regular2(context).copyWith(color: Colors.grey.shade700),
          ),
          actionsAlignment: MainAxisAlignment.center,
          actions: [
            InkWell(
              onTap: () {
                box.delete("ride_id");
                if (useClearNavigation) {
                  goToWithClear(const HomeMain(initialIndex: 0));
                } else {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const HomeMain(initialIndex: 0)),
                    (Route<dynamic> route) => false,
                  );
                }
              },
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 26, vertical: 13),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [themeColor, themeColor],
                  ),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.home_rounded, color: blackColor),
                    const SizedBox(width: 8),
                    Text(
                      "Go Home".translate(context),
                      style: headingBlackBold(context)
                          .copyWith(color: blackColor, fontSize: 14),
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildTripOverlayCard() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
        child: Align(
          alignment: Alignment.topRight,
          child: Column(
            children: [
              _buildMapActionButton(
                icon: Icons.layers_rounded,
                onTap: () {
                  if (rideData == null) return;
                  startLiveNavigation(
                    sourceLat:
                        context.read<UpdateDriverParameterCubit>().state.lat,
                    sourceLng:
                        context.read<UpdateDriverParameterCubit>().state.lng,
                    destLat: isOnDutyCompleted
                        ? (rideData?.dropoffLocation?.lat ?? 0.0)
                        : (rideData?.pickupLocation?.lat ?? 0.0),
                    destLng: isOnDutyCompleted
                        ? (rideData?.dropoffLocation?.lng ?? 0.0)
                        : (rideData?.pickupLocation?.lng ?? 0.0),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMapActionButton({
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.white.withValues(alpha: 0.94),
              themeColor.withValues(alpha: 0.16),
            ],
          ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: themeColor.withValues(alpha: 0.24)),
        ),
        child: Icon(icon, size: 18, color: screenBrown),
      ),
    );
  }

  bool isLoad = false;
  @override
  Widget build(BuildContext context) {
    // ignore: deprecated_member_use
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        backgroundColor: notifires.getbgcolor,
        body: MultiBlocListener(
          listeners: [
            BlocListener<GetRideRequestStatusCubit, String>(
                listener: (context, status) async {
              if (status == "cancelled") {
                if (appIsInBackground) {
                  await openAppWithRideIntent(
                    pickup: rideData?.pickupLocation?.pickupAddress ?? "",
                    drop: rideData?.dropoffLocation?.dropoffAddress ?? "",
                    distance:
                        double.parse(rideData?.totalDistance.toString() ?? "0"),
                    fare:
                        double.parse(rideData?.travelCharges.toString() ?? "0"),
                  );
                }

                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (!mounted) return;
                  if (ModalRoute.of(context)?.isCurrent == true &&
                      !isShowPopUp) {
                    isShowPopUp = true;
                    box.delete("ride_id");
                    _showRideCancelledDialog(useClearNavigation: true);
                  }
                });
                return;
              }
            }),
            BlocListener<UpdateBookingIdCubit, String>(
              listener: (context, bookingId) {
                if (bookingId.isNotEmpty) {
                  context
                      .read<UpdateDriverParameterCubit>()
                      .updateBookingId(bookingId: bookingId);
                  context
                      .read<UpdateRideStatusInDatabaseCubit>()
                      .updateRideStatus(
                        context: context,
                        bookingId: bookingId,
                        rideStatus: "pick_up",
                      );
                }
              },
            ),
            BlocListener<LocationCubit, LocationState>(
                listener: (context, state) {
              if (state is LocationSucess) {
                context.read<UpdateDriverCubit>().updateDriverLocation(
                      driverId: loginModel?.data?.fireStoreId ?? "",
                      currentLocation: state.currentLocation,
                    );
              }
            }),
            BlocListener<ListenRideRequestCubit, ListenRideRequestState>(
              listener: (context, state) {
                if (state is ListenRideRequestSuccess &&
                    state.rideRequest == null) {
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    if (!mounted) return;

                    if (ModalRoute.of(context)?.isCurrent == true &&
                        !isShowPopUp) {
                      isShowPopUp = true;

                      _showRideCancelledDialog(useClearNavigation: false);
                    }
                  });
                }
              },
              // apka screen body
            )
          ],
          child: BlocBuilder<GetRideDataCubit, GetRideDataState>(
            builder: (context, state) {
              if (state is GetRideDataLoading) {
                return const MapShimmerScreen();
              }

              if (state is GetRideDataSuccess) {
                rideData = state.requestDataModel;
                parcalData = state.requestDataModel?.parcalData;

                context
                    .read<UpdateDriverParameterCubit>()
                    .updateRideId(rideId: rideData?.rideId);

                if (widget.fromInitialPage == true) {
                  _updateInitialDriverParameters();
                }

                context.read<GetRideDataCubit>().clear();
              }
              return Stack(
                children: [
                  BlocBuilder<RideLocationCubit, RideLocationState>(
                    builder: (context, locationState) {
                      if (locationState is RideLocationSucess &&
                          rideData != null) {
                        currentLocation = locationState.currentLocation;
                        context
                            .read<UpdateDriverParameterCubit>()
                            .updateLoaction(
                              lat: currentLocation?.latitude ?? 0.0,
                              lng: currentLocation?.longitude ?? 0.0,
                            );

                        if (isLoad == false) {
                          isLoad = true;
                          _updateMarkersAndPolylines(currentLocation!);
                        }
                      }

                      return BlocBuilder<MarkerCubit, MarkerState>(
                        builder: (context, markerState) {
                          if (currentLocation == null) {
                            if (showNoData) {
                              return RetryWithGoHome(
                                showNoData: showNoData,
                                hasRetried: hasRetried,
                                onRetry: () {
                                  setState(() {
                                    showNoData = false;
                                    hasRetried = true;
                                  });

                                  context.read<UserMarkerCubitMapbox>().clear();
                                  context
                                      .read<GetPolylineMapBoxCubit>()
                                      .resetPolylines();
                                  context
                                      .read<RideStatusCubit>()
                                      .resetAllParameters();
                                  context
                                      .read<GetRideDataCubit>()
                                      .fetchRideData(widget.rideId ?? "");
                                  context
                                      .read<RideLocationCubit>()
                                      .startLiveLocationTracking();

                                  Future.delayed(const Duration(seconds: 15),
                                      () {
                                    if (mounted && currentLocation == null) {
                                      setState(() {
                                        showNoData = true;
                                      });
                                    }
                                  });
                                },
                                onGoHome: () {
                                  showGoHomeDialog(context, () async {
                                    final bookingId = await context
                                        .read<UpdateBookingIdCubit>()
                                        .getBookingId(
                                            rideId: widget.rideId ?? "");
                                    box.delete('ride_id');
                                    cancelRideRequestByError(
                                        rideId: widget.rideId ?? "",
                                        bookingId: bookingId ?? "",
                                        context: context);
                                  });
                                },
                              );
                            } else if (rideData == null) {
                              return const MapShimmerScreen();
                            } else {
                              return forMapLoadingShimmer();
                            }
                          } else {
                            return _buildMap(currentLocation!);
                          }
                        },
                      );
                    },
                  ),
                  if (rideData != null) _buildTripOverlayCard(),
                  BlocConsumer<RideStatusCubit, RideStatusState>(
                    builder: (context, state) {
                      if (rideData == null) return const SizedBox();
                      if (rideData!.rideId == null &&
                          rideData!.travelCharges == null &&
                          rideData!.pickupLocation!.lat == null) {
                        return DraggableScrollableSheet(
                          initialChildSize: 0.3,
                          minChildSize: 0.3,
                          maxChildSize: 0.3,
                          builder: (context, scrollController) {
                            return Container(
                              decoration: const BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.vertical(
                                    top: Radius.circular(20)),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black26,
                                    blurRadius: 8,
                                    offset: Offset(0, -2),
                                  ),
                                ],
                              ),
                              child: SingleChildScrollView(
                                controller: scrollController,
                                padding: const EdgeInsets.all(20),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Icon(
                                      Icons.error_outline,
                                      color: Colors.redAccent,
                                      size: 60,
                                    ),
                                    const SizedBox(height: 12),
                                    Text(
                                      "Something went wrong".translate(context),
                                      style: heading2Grey1(context),
                                    ),
                                    const SizedBox(height: 6),
                                    Text(
                                      "Please retry again".translate(context),
                                      textAlign: TextAlign.center,
                                      style: regular2(context),
                                    ),
                                    const SizedBox(height: 20),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        ElevatedButton.icon(
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.redAccent,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                            ),
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 24, vertical: 12),
                                          ),
                                          onPressed: () {
                                            context
                                                .read<GetPolylineMapBoxCubit>()
                                                .resetPolylines();
                                            context
                                                .read<RideStatusCubit>()
                                                .resetAllParameters();
                                            context
                                                .read<GetRideDataCubit>()
                                                .fetchRideData(
                                                    widget.rideId ?? "");
                                            context
                                                .read<RideLocationCubit>()
                                                .startLiveLocationTracking();
                                          },
                                          icon: const Icon(Icons.refresh,
                                              color: Colors.white),
                                          label: Text(
                                              "Retry".translate(context),
                                              style: heading3Grey1(context)
                                                  .copyWith(color: whiteColor)),
                                        ),
                                        const SizedBox(
                                          width: 10,
                                        ),
                                        OutlinedButton.icon(
                                          icon: const Icon(Icons.home_outlined,
                                              size: 18),
                                          onPressed: () async {
                                            final bookingId = await context
                                                .read<UpdateBookingIdCubit>()
                                                .getBookingId(
                                                    rideId:
                                                        widget.rideId ?? "");
                                            cancelRideRequestByError(
                                                rideId: widget.rideId ?? "",
                                                bookingId: bookingId ?? "",
                                                context: context);
                                            box.delete('ride_id');
                                          },
                                          style: OutlinedButton.styleFrom(
                                            foregroundColor: blackColor,
                                            backgroundColor: themeColor,
                                            side: BorderSide(
                                                color: themeColor, width: 1.2),
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 22, vertical: 12),
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                            ),
                                          ),
                                          label: Text(
                                              "Go Home".translate(context),
                                              style: heading3Grey1(context)
                                                  .copyWith(
                                                      color: blackColor,
                                                      fontSize: 14)),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      }

                      if (!state.rideArrivedStatus) {
                        return CustomRideBottomSheet(
                          onTap: () {
                            startLiveNavigation(
                                sourceLat: context
                                    .read<UpdateDriverParameterCubit>()
                                    .state
                                    .lat,
                                sourceLng: context
                                    .read<UpdateDriverParameterCubit>()
                                    .state
                                    .lng,
                                destLat: rideData?.pickupLocation?.lat ?? 0.0,
                                destLng: rideData?.pickupLocation?.lng ?? 0.0);
                          },
                          rideRequest: rideData!,
                          pickupString: "Go to PickUp",
                          acceptedText: "",
                          textActiveColor: blackColor,
                          textInactiveColor: blackColor,
                          isOnDutyRide: state.rideArrivedStatus,
                          onChanged: (value) {
                            if (value) {
                              _handleArrivedStatus();
                            }
                          },
                          titleText: "Customer Verified Location",
                          activeColor: themeColor,
                          inactiveColor: themeColor,
                          defaultText: "ARRIVED",
                          addressText: rideData!.pickupLocation?.pickupAddress,
                        );
                      } else if (!state.rideStartEndStatus &&
                          state.rideArrivedStatus) {
                        return CustomRideBottomSheetForStartRide(
                          onTap: () {},
                          rideRequest: rideData!,
                          pickupString: "Go to Drop",
                          acceptedText: "",
                          textActiveColor: blackColor,
                          textInactiveColor: whiteColor,
                          isOnDutyRide: state.rideStartEndStatus,
                          onChanged: (value) {
                            if (value) {
                              _handleStartRide();
                            }
                          },
                          titleText: "Customer Verified Location",
                          activeColor: greentext,
                          inactiveColor: greentext,
                          defaultText: "START RIDE",
                          addressText:
                              rideData!.dropoffLocation?.dropoffAddress ?? "",
                        );
                      }
                      return const SizedBox();
                    },
                    listener: (context, state) {},
                  ),
                  if (isOnDutyCompleted && rideData != null)
                    CustomBottomSheetForComplete(rideRequest: rideData!),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  void _updateInitialDriverParameters() {
    final driverParams = context.read<UpdateDriverParameterCubit>();
    driverParams.updateBookingId(bookingId: rideData?.bookingId ?? "");
    driverParams.updateDriverId(driverId: rideData!.selectedDriverId ?? "");
    driverParams.updateDriverDropOffLatAndLng(
      driverDropOffLat: rideData!.dropoffLocation?.lat ?? 0.0,
      driverDropOffLng: rideData!.dropoffLocation?.lng ?? 0.0,
    );
    driverParams.updateDriverPickupLatAndLng(
      driverPickupLat: rideData!.pickupLocation?.lat ?? 0.0,
      driverPickupLng: rideData!.pickupLocation?.lng ?? 0.0,
    );

    if (rideData?.status == "accepted") {
      context
          .read<RideStatusCubit>()
          .updateRideArrivedStatus(rideArrivedStatus: false);
    } else if (rideData?.status == "confirmed") {
      context.read<RideStatusCubit>()
        ..updateRideStartEndStatus(rideStartEndStatus: false)
        ..updateRideArrivedStatus(rideArrivedStatus: true);
    } else if (rideData?.status == "ongoing") {
      context.read<RideStatusCubit>()
        ..updateRideArrivedStatus(rideArrivedStatus: true)
        ..updateRideStartEndStatus(rideStartEndStatus: true);
      isOnDutyCompleted = true;
    }
  }

  void _updateMarkersAndPolylines(LatLng currentLocation) {
    context.read<UserMarkerCubitMapbox>().addOrUpdateMarker(
          point: Point(
            coordinates: Position(
              currentLocation.longitude, // longitude first
              currentLocation.latitude, // latitude second
            ),
          ),
          title: '',
          markerId: 'Driver_marker',
          iconPath: 'assets/images/car_marker.png',
          size: 90,
        );

    if (isOnDutyCompleted == true &&
        context.read<RideStatusCubit>().state.rideStartEndStatus == true) {
      context.read<UserMarkerCubitMapbox>().removeMarker("User_marker");
      context.read<UserMarkerCubitMapbox>().addOrUpdateMarker(
            point: Point(
              coordinates: Position(
                rideData!.dropoffLocation?.lng ?? 0.0,
                rideData!.dropoffLocation?.lat ?? 0.0,
              ),
            ),
            title: '',
            markerId: 'Drop_marker',
            iconPath: 'assets/images/drop_pin.png',
            size: 65,
          );

      context.read<GetPolylineMapBoxCubit>().getPolylineMapbox(
            sourceLat: currentLocation.latitude,
            sourceLng: currentLocation.longitude,
            isPickupRoute: false,
            destinationLat: rideData!.dropoffLocation!.lat ?? 0.0,
            destinationLng: rideData!.dropoffLocation!.lng ?? 0.0,
          );
    } else if (isOnDutyCompleted == false) {
      context.read<UserMarkerCubitMapbox>().addOrUpdateMarker(
            point: Point(
              coordinates: Position(
                rideData!.pickupLocation?.lng ?? 0.0,
                rideData!.pickupLocation?.lat ?? 0.0,
              ),
            ),
            title: '',
            markerId: 'User_marker',
            iconPath: 'assets/images/pin_user.png',
            size: 40,
          );

      context.read<GetPolylineMapBoxCubit>().getPolylineMapbox(
            sourceLat: currentLocation.latitude,
            sourceLng: currentLocation.longitude,
            isPickupRoute: true,
            destinationLat: rideData!.pickupLocation!.lat ?? 0.0,
            destinationLng: rideData!.pickupLocation!.lng ?? 0.0,
          );
    }
  }

  void _handleArrivedStatus() {
    final driverParams = context.read<UpdateDriverParameterCubit>();
    driverParams.removeBookingId();

    context.read<UpdateBookingIdCubit>()
      ..resetState()
      ..updateBookingId(rideId: widget.rideId ?? "");

    context.read<UpdateRideRequestCubit>().updatePendingRideRequests(
          rideId: widget.rideId ?? "",
          newStatus: "pick_up",
        );

    Future.delayed(const Duration(milliseconds: 200), () {
      if ((parcalData!.name ?? "").isEmpty &&
          (parcalData!.reciverNumber ?? "").isEmpty) {
        goTo(OtpVerifyRideScreen(
          // ignore: use_build_context_synchronously
          bookingId: context.read<UpdateBookingIdCubit>().state,
          userName: rideData?.customer?.userName ?? "",
        ));
        return;
      }

      goTo(ParcelImageScreen(
        // ignore: use_build_context_synchronously
        bookingId: context.read<UpdateBookingIdCubit>().state,
        userName: rideData?.customer?.userName ?? "",
      ));
    });
  }

  void _handleStartRide() {
    context
        .read<RideStatusCubit>()
        .updateRideStartEndStatus(rideStartEndStatus: true);

    final bookingId =
        context.read<UpdateDriverParameterCubit>().state.bookingId.isEmpty
            ? rideData?.bookingId ?? ""
            : context.read<UpdateDriverParameterCubit>().state.bookingId;

    if (bookingId.isNotEmpty) {
      context.read<UpdateRideRequestCubit>().updatePendingRideRequests(
          rideId: widget.rideId ?? "", newStatus: "ongoing");

      context.read<UpdateRideStatusInDatabaseCubit>().updateRideStatus(
            context: context,
            bookingId: bookingId,
            rideStatus: "Ongoing",
          );
    }
    _updateMarkersAndPolylines(currentLocation!);
    setState(() {
      isOnDutyCompleted = true;
      isLoad = false;
    });
  }

  Widget _buildMap(LatLng currentLocation) {
    final initialPoint = Point(
      coordinates:
          Position(currentLocation.longitude, currentLocation.latitude),
    );

    return Positioned(
      bottom: 150,
      left: 0,
      right: 0,
      top: 0,
      child: Stack(
        alignment: Alignment.center,
        children: [
          PersistentMapBox(
            initialPosition: initialPoint,
            myLocationEnabled: false,
            onMapCreated: (controller) async {
              if (!_isMapInitialized) {
                mapController = controller;
                _isMapInitialized = true;
                if (!_controller.isCompleted) {
                  _controller.complete(controller);
                }
              }
            },
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _isMapInitialized = false;
    _controller.future.then((controller) {
      // No dispose needed for MapboxMap
    }).catchError((_) {});
    super.dispose();
  }
}

class PersistentMapBox extends StatefulWidget {
  final Point initialPosition;
  final bool myLocationEnabled;
  final Function(MapboxMap) onMapCreated;
  const PersistentMapBox({
    super.key,
    required this.initialPosition,
    required this.myLocationEnabled,
    required this.onMapCreated,
  });
  @override
  PersistentMapBoxState createState() => PersistentMapBoxState();
}

class PersistentMapBoxState extends State<PersistentMapBox> {
  MapboxMap? _map;

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<UserMarkerCubitMapbox, UserMarkerStateMapbox>(
      builder: (context, markerState) {
        return BlocBuilder<GetPolylineMapBoxCubit, GetPolylineMapBoxState>(
          builder: (context, polylineState) {
            if (polylineState is GetPolylineMapBoxUpdated) {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                _moveCameraToFitPolylineAndMarkers(context);
              });
            }
            return MapWidget(
              textureView: false,
              onMapCreated: (map) async {
                _map = map;
                await context
                    .read<UserMarkerCubitMapbox>()
                    .setMapController(map);
                await context
                    .read<GetPolylineMapBoxCubit>()
                    .setMapController(map);
                widget.onMapCreated(map);
                final camera = CameraOptions(
                  center: widget.initialPosition,
                  zoom: 15.0,
                );
                await map.setCamera(camera);
              },
            );
          },
        );
      },
    );
  }

  Future<void> _moveCameraToFitPolylineAndMarkers(BuildContext context) async {
    if (_map == null) return;

    final Set<Position> coordinates = {};

    // --- Add all marker coordinates ---
    final markerCubitState = context.read<UserMarkerCubitMapbox>().state;
    if (markerCubitState is UserMarkerUpdatedMapbox) {
      for (final marker in markerCubitState.markers.values) {
        coordinates.add(marker.geometry.coordinates);
      }
    }

    // --- Add all polyline coordinates ---
    final polylineCubitState = context.read<GetPolylineMapBoxCubit>().state;
    if (polylineCubitState is GetPolylineMapBoxUpdated) {
      for (final pl in polylineCubitState.polylines) {
        final coords = pl.geometry.coordinates;
        coordinates.addAll(coords);
      }
    }

    if (coordinates.isEmpty) return;

    // --- Compute the bounding box ---
    final lats = coordinates.map((p) => p.lat).toList();
    final lngs = coordinates.map((p) => p.lng).toList();

    final minLat = lats.reduce(math.min);
    final maxLat = lats.reduce(math.max);
    final minLng = lngs.reduce(math.min);
    final maxLng = lngs.reduce(math.max);

    final bounds = CoordinateBounds(
      southwest: Point(coordinates: Position(minLng, minLat)),
      northeast: Point(coordinates: Position(maxLng, maxLat)),
      infiniteBounds: false,
    );

    try {
      // --- Calculate camera to fit bounds with padding ---
      final camera = await _map!.cameraForCoordinateBounds(
          bounds,
          mapbox.MbxEdgeInsets(
            top: 100,
            bottom: 200,
            left: 80,
            right: 80,
          ),
          0,
          25,
          140,
          mapbox.ScreenCoordinate(x: 0.0, y: 0.0) // ✅ correct
          );

      // --- Animate camera smoothly ---
      await _map!.flyTo(
        camera,
        MapAnimationOptions(duration: 2000), // 2 sec smooth animation
      );
    } catch (e) {}
  }
}
