import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../core/extensions/workspace.dart';
import '../../../core/services/data_store.dart';
import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../../domain/entities/document_image.dart';
import '../../cubits/auth/otp_verify_cubit.dart';
import '../../cubits/auth/resend_otp_cubit.dart';
import '../../cubits/auth/user_authenticate_cubit.dart';
import '../../cubits/realtime/manage_driver_cubit.dart';
import '../../cubits/register_vehicle/register_vehicle_document.dart';
import '../../cubits/register_vehicle/vehicle_register_cubit.dart';
import '../../widgets/custom_text_form_field.dart';
import '../../widgets/otp_box_field.dart';
import '../../widgets/primary_button.dart';
import '../bottom_bar/home_main.dart';
import '../setup_account/setup_initial_screen.dart';

// ignore: must_be_immutable
class OtpScreen extends StatefulWidget {
  final String? number;
  final String? countryCode;
  String? otpValue;
  final String? email;
  final bool? changeMobile;
  final bool? changeEmail;
  final String? defaultCountry;
  final String? routeString;
  bool? loginWithSocialMedia;

  OtpScreen(
      {super.key,
      this.number,
      this.routeString,
      this.countryCode,
      this.otpValue,
      this.email,
      this.changeMobile,
      this.changeEmail,
      this.defaultCountry,
      this.loginWithSocialMedia});

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    isNumeric = false;
    WidgetsBinding.instance.addPostFrameCallback((_) {});

    Future.delayed(
      const Duration(seconds: 1),
      () {
        textEditingOtpController.text = widget.otpValue!;
      },
    );
    startResendTimer();
  }

  int _remainingTime = 30;
  bool _isResendEnabled = true;
  late Timer _timer;

  void startResendTimer() {
    setState(() {
      _isResendEnabled = false;
    });

    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (_remainingTime > 0) {
          _remainingTime--;
        } else {
          _timer.cancel();
          _isResendEnabled = true;
          _remainingTime = 0;
        }
      });
    });
  }

  int extractMinutes(String message) {
    final match = RegExp(r'(\d+)').firstMatch(message);
    return int.tryParse(match?.group(1) ?? '') ?? 0;
  }

  String formatTimer(int totalSeconds) {
    final minutes = totalSeconds ~/ 60;
    final seconds = totalSeconds % 60;

    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  TextEditingController textEditingOtpController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    String timerText = _remainingTime.toString().padLeft(2, '0');

    return Align(
      alignment: Alignment.center,
      child: SizedBox(
        width: Dimensions.containerWidth,
        child: Scaffold(
            bottomSheet: isNumeric == true && Platform.isIOS
                ? KeyboardDoneButton(
                    onTap: () {
                      setState(() {
                        isNumeric = false;
                      });
                    },
                  )
                : null,
            resizeToAvoidBottomInset: isNumeric,
            backgroundColor: notifires.getbgcolor,
            body: MultiBlocListener(
                listeners: [
                  BlocListener<AuthUserAuthenticateCubit,
                      AuthUserAuthenticateState>(listener: (context, state) {
                    if (state is UserLoading) {
                      Widgets.showLoader(context);
                    } else if (state is UserSucesss) {
                      box.put('Remember', true);
                      box.put('Firstuser', true);
                      Widgets.hideLoder(context);

                      if (state.loginModel.data != null) {
                        context
                            .read<UpdateDriverParameterCubit>()
                            .updateDriverNameAndNumber(
                                driverName:
                                    state.loginModel.data!.firstName ?? "",
                                driverNumber:
                                    state.loginModel.data!.phone ?? "",
                                driverPhoneCountryCode:
                                    state.loginModel.data!.phoneCountry ?? "");

                        context
                            .read<UpdateAddEditVehicleIdCubit>()
                            .updateItemId(
                                vehicleAddEditTypeId:
                                    loginModel?.data?.itemId ?? 0);
                        context
                            .read<UpdateDriverParameterCubit>()
                            .updateDriverId(
                                driverId: state.loginModel.data!.fireStoreId
                                        ?.toString() ??
                                    "");
                      }

                      navigatorKey.currentContext!
                          .read<DocumentApprovedStatusCubit>()
                          .removeDocumentApprovedStatus();

                      context
                          .read<DocumentApprovedStatusCubit>()
                          .updateDocumentApprovedStatus(
                              docApprovedStatus: state.loginModel.data!
                                      .verificationDocumentStatus ??
                                  "");

                      if (widget.routeString == "Login") {
                        context.read<SetupStepCubit>().resetStep();
                        DocumentImageModel? documentImageModel;
                        box.put('Remember', true);
                        box.put('Firstuser', true);

                        final docStatus =
                            context.read<GetVehicleDocumentCubit>().state;
                        if (docStatus is GetDocumentSuccess) {
                          documentImageModel = docStatus.documentImageModel;
                        }

                        if (state.loginModel.data!.gender != null &&
                            state.loginModel.data!.gender!.isNotEmpty) {
                          if (state.loginModel.data!.itemTypeId != null) {
                            if (documentImageModel?.data?.drivingLicenceFront
                                            ?.drivingLicenceImage !=
                                        null &&
                                    documentImageModel
                                            ?.data
                                            ?.inspectionCertificate!
                                            .inspectionCertificateImage !=
                                        null &&
                                    documentImageModel
                                            ?.data
                                            ?.driverAuthorization!
                                            .driverAuthorizationImage !=
                                        null &&
                                    documentImageModel
                                            ?.data
                                            ?.hireServiceLicence!
                                            .hireServiceLicenceImage !=
                                        null ||
                                state.loginModel.data!
                                        .verificationDocumentStatus ==
                                    "approved") {
                              setState(() {});
                              box.put("driverId",
                                  state.loginModel.data?.fireStoreId ?? "");
                              box.put('Remember', true);
                              box.put('Firstuser', true);
                              goToWithClear(HomeMain(
                                  initialIndex: 0, route: widget.routeString));
                            } else {
                              Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          const SetupInitialScreen(
                                              stepIndex: 2)));
                            }
                          } else {
                            Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        const SetupInitialScreen(
                                            stepIndex: 1)));
                          }
                        } else {
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      const SetupInitialScreen(stepIndex: 0)));
                        }
                      }
                      context.read<AuthUserAuthenticateCubit>().resetState();
                    } else if (state is UserFailure) {
                      Widgets.hideLoder(context);
                      if (state.error.isNotEmpty) {
                        showErrorToastMessage(state.error);
                      }
                    }
                  }),
                  BlocListener<AuthOtpVerifyCubit, OtpVerifyState>(
                      listener: (context, state) {
                    if (state is OtpLoading) {
                      Widgets.showLoader(context);
                    } else if (state is OtpSuccess) {
                      box.put('Remember', true);
                      box.put('Firstuser', true);
                      Widgets.hideLoder(context);
                      context
                          .read<GetVehicleDocumentCubit>()
                          .getUploadDocument(context: context);

                      context.read<UpdateDriverParameterCubit>().updateDriverId(
                          driverId:
                              state.loginModel.data?.fireStoreId?.toString() ??
                                  "");

                      if (state.loginModel.data != null &&
                          state.loginModel.data?.itemId != null) {
                        context
                            .read<UpdateDriverParameterCubit>()
                            .updateDriverNameAndNumber(
                                driverName:
                                    state.loginModel.data!.firstName ?? "",
                                driverNumber:
                                    state.loginModel.data!.phone ?? "",
                                driverPhoneCountryCode:
                                    state.loginModel.data!.phoneCountry ?? "");
                        context
                            .read<UpdateAddEditVehicleIdCubit>()
                            .updateItemId(
                                vehicleAddEditTypeId:
                                    loginModel!.data!.itemId!);
                      }

                      if (widget.routeString == "SignUp") {
                        box.put('Remember', true);
                        box.put('Firstuser', true);
                        Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const SetupInitialScreen(
                                      stepIndex: 0,
                                    )));
                      }
                    } else if (state is OtpSuccessForChangePhoneSate) {
                      Widgets.hideLoder(context);

                      goBack();
                    } else if (state is OtpFailure) {
                      Widgets.hideLoder(context);
                      if (state.error.isNotEmpty) {
                        showErrorToastMessage(state.error);
                      }
                    }
                  }),
                  BlocListener<AuthResendOtpCubit, ResendOtpState>(
                      listener: (context, state) {
                    if (state is ResendOtpLoading) {
                      Widgets.showLoader(context);
                    } else if (state is ResendOtpSuccess) {
                      Widgets.hideLoder(context);
                      if (state.otpValue!.isNotEmpty) {
                        textEditingOtpController.text = state.otpValue!;
                        widget.otpValue = state.otpValue;
                      }
                    } else if (state is ResendOtpFailure) {
                      Widgets.hideLoder(context);
                      showErrorToastMessage(state.error);

                      int minutes = extractMinutes(state.error);
                      if (minutes > 0) {
                        setState(() {
                          _remainingTime = minutes * 60;
                          _isResendEnabled = false;
                        });
                      }
                    }
                  }),
                  BlocListener<GetVehicleDocumentCubit,
                      GetVehicleDocumentState>(listener: (context, state) {
                    if (state is GetDocumentSuccess) {
                      final documents = state.documentImageModel.data;

                      if (documents?.drivingLicenceFront?.drivingLicenceImage
                              ?.isNotEmpty ??
                          false) {
                        context
                            .read<GetDocVehicleFormCubit>()
                            .updateDrivingLicenceFront(
                              documents?.drivingLicenceFront
                                      ?.drivingLicenceImage ??
                                  "",
                              documents?.drivingLicenceFront
                                      ?.drivingLicenceStatus ??
                                  "",
                            );
                      }
                      if (documents?.drivingLicenceBack?.drivingLicenceImageBack
                              ?.isNotEmpty ??
                          false) {
                        context
                            .read<GetDocVehicleFormCubit>()
                            .updateDrivingLicenceBack(
                              documents?.drivingLicenceBack
                                      ?.drivingLicenceImageBack ??
                                  "",
                              documents?.drivingLicenceBack
                                      ?.drivingLicenceBackStatus ??
                                  "",
                            );
                      }

                      if (documents
                              ?.driverIdFront?.driverIdFrontImage?.isNotEmpty ??
                          false) {
                        context
                            .read<GetDocVehicleFormCubit>()
                            .updateDriverIdFront(
                              documents?.driverIdFront?.driverIdFrontImage ??
                                  "",
                              documents?.driverIdFront
                                      ?.driverIdFrontImageStatus ??
                                  "",
                            );
                      }
                      if (documents
                              ?.driverIdBack?.driverIdBackImage?.isNotEmpty ??
                          false) {
                        context
                            .read<GetDocVehicleFormCubit>()
                            .updateDriverIdBack(
                              documents?.driverIdBack?.driverIdBackImage ?? "",
                              documents
                                      ?.driverIdBack?.driverIdBackImageStatus ??
                                  "",
                            );
                      }

                      final stateAll =
                          context.read<GetDocVehicleFormCubit>().state;
                      List<String> statusList = [
                        stateAll.driverIdFrontStatus,
                        stateAll.driverIdBackStatus,
                        stateAll.drivingLicenceFrontStatus,
                        stateAll.drivingLicenceBackStatus,
                      ];

                      if (statusList.every((status) => status == "approved")) {
                        context
                            .read<DocumentApprovedStatusCubit>()
                            .updateDocumentApprovedStatus(
                                docApprovedStatus: "approved");
                        box.put("approved", true);
                      } else if (statusList.contains("rejected")) {
                        context
                            .read<DocumentApprovedStatusCubit>()
                            .updateDocumentApprovedStatus(
                                docApprovedStatus: "rejected");
                        box.put("approved", false);
                      } else {
                        context
                            .read<DocumentApprovedStatusCubit>()
                            .updateDocumentApprovedStatus(
                                docApprovedStatus: "pending");
                        context
                            .read<UpdateDriverParameterCubit>()
                            .updateDocApprovedStatus(
                                docApprovedStatus: "pending");
                        box.put("approved", false);
                      }
                    }
                  }),
                ],
                child: SafeArea(
                  child: LayoutBuilder(
                    builder: (context, constraints) {
                      final isSmallPhone = constraints.maxHeight < 700 ||
                          constraints.maxWidth < 360;
                      final horizontalPadding = isSmallPhone ? 16.0 : 24.0;

                      return SingleChildScrollView(
                        keyboardDismissBehavior:
                            ScrollViewKeyboardDismissBehavior.onDrag,
                        child: Padding(
                          padding: EdgeInsets.symmetric(
                            horizontal: horizontalPadding,
                            vertical: isSmallPhone
                                ? Dimensions.space16
                                : Dimensions.space24,
                          ),
                          child: Form(
                            key: _formKey,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                InkWell(
                                  borderRadius: BorderRadius.circular(20),
                                  onTap: () => goBack(),
                                  child: Container(
                                    width: 40,
                                    height: 40,
                                    decoration: BoxDecoration(
                                      color: notifires.getBoxColor,
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Icon(Icons.arrow_back,
                                        color: notifires.getwhiteblackColor,
                                        size: 20),
                                  ),
                                ),
                                SizedBox(height: isSmallPhone ? 20 : 32),
                                Container(
                                  width: isSmallPhone ? 64 : 76,
                                  height: isSmallPhone ? 64 : 76,
                                  decoration: BoxDecoration(
                                    color: themeColor.withValues(alpha: 0.14),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Icon(Icons.sms_outlined,
                                      color: themeColor,
                                      size: isSmallPhone ? 30 : 36),
                                ),
                                SizedBox(height: isSmallPhone ? 16 : 24),
                                Text("Verify your phone".translate(context),
                                    style: screenTitle(context)),
                                const SizedBox(height: Dimensions.space8),
                                Text(
                                    "We've sent a verification code to"
                                        .translate(context),
                                    style: screenSubtitle(context)),
                                const SizedBox(height: Dimensions.space4),
                                Text("${widget.countryCode} ${widget.number}",
                                    style: sectionTitleStyle(context)),
                                SizedBox(height: isSmallPhone ? 24 : 32),
                                Directionality(
                                  textDirection: TextDirection.ltr,
                                  child: OtpBoxField(
                                    controller: textEditingOtpController,
                                    onTap: () {
                                      isNumeric = true;
                                      setState(() {});
                                    },
                                    onChanged: (value) {},
                                  ),
                                ),
                                SizedBox(height: isSmallPhone ? 20 : 28),
                                Align(
                                  alignment: Alignment.center,
                                  child: _isResendEnabled
                                      ? Wrap(
                                          alignment: WrapAlignment.center,
                                          crossAxisAlignment:
                                              WrapCrossAlignment.center,
                                          spacing: 6,
                                          runSpacing: 4,
                                          children: [
                                            Text(
                                              "Didn't receive code?"
                                                  .translate(context),
                                              style: captionText(context),
                                            ),
                                            InkWell(
                                              onTap: () async {
                                                startResendTimer();
                                                setState(() {
                                                  _remainingTime = 30;
                                                  _isResendEnabled = false;
                                                });
                                                context
                                                    .read<AuthResendOtpCubit>()
                                                    .resendOtp(
                                                      context: context,
                                                      phone: widget.number,
                                                      phoneCountry: widget
                                                              .countryCode!
                                                              .startsWith("+")
                                                          ? widget.countryCode!
                                                          : "+${widget.countryCode!}",
                                                    );
                                              },
                                              child: Text(
                                                "Resend".translate(context),
                                                style: linkTextStyle(context),
                                              ),
                                            ),
                                          ],
                                        )
                                      : Wrap(
                                          alignment: WrapAlignment.center,
                                          crossAxisAlignment:
                                              WrapCrossAlignment.center,
                                          spacing: 6,
                                          runSpacing: 4,
                                          children: [
                                            Text(
                                              "Resend code in"
                                                  .translate(context),
                                              style: captionText(context),
                                            ),
                                            Text(
                                                formatTimer(
                                                    int.parse(timerText)),
                                                style: captionText(context)
                                                    .copyWith(
                                                        fontFamily:
                                                            "Poppins SemiBold",
                                                        fontWeight:
                                                            FontWeight.w600)),
                                          ],
                                        ),
                                ),
                                SizedBox(height: isSmallPhone ? 24 : 32),
                                PrimaryButton(
                                  text: "Continue".translate(context),
                                  onPressed: () {
                                    if (_formKey.currentState!.validate()) {
                                      if (textEditingOtpController
                                          .text.isEmpty) {
                                        showErrorToastMessage(
                                            "Please Enter the Otp"
                                                .translate(context));
                                        return;
                                      }
                                      if (widget.changeMobile == true) {
                                        context
                                            .read<AuthOtpVerifyCubit>()
                                            .otpVerificationForChangePhone({
                                          "phone": widget.number,
                                          "phone_country": widget.countryCode!
                                                  .startsWith('+')
                                              ? widget.countryCode!
                                              : '+${widget.countryCode!}',
                                          "otp_value":
                                              textEditingOtpController.text,
                                          "default_country":
                                              widget.defaultCountry,
                                        }, context);
                                        return;
                                      }

                                      if (widget.routeString == "Login") {
                                        context
                                            .read<AuthUserAuthenticateCubit>()
                                            .userAuthenticate(
                                                context: context,
                                                phoneNumber: widget.number!,
                                                phoneCountry: widget
                                                        .countryCode!
                                                        .startsWith("+")
                                                    ? widget.countryCode!
                                                    : "+${widget.countryCode!}",
                                                otpValue:
                                                    textEditingOtpController
                                                        .text);
                                      } else {
                                        context
                                            .read<AuthOtpVerifyCubit>()
                                            .otpVerification(
                                                context: context,
                                                phone: widget.number,
                                                otpValue:
                                                    textEditingOtpController
                                                        .text,
                                                countryCode: widget.countryCode!
                                                        .startsWith("+")
                                                    ? widget.countryCode!
                                                    : "+${widget.countryCode!}",
                                                email: widget.email,
                                                changeEmail: widget.changeEmail,
                                                changeMobile:
                                                    widget.changeMobile,
                                                defaultCountry:
                                                    widget.defaultCountry,
                                                loginWithGoogle: widget
                                                    .loginWithSocialMedia);
                                      }
                                    }
                                  },
                                ),
                                SizedBox(height: isSmallPhone ? 20 : 28),
                                Align(
                                  alignment: Alignment.center,
                                  child: Wrap(
                                    alignment: WrapAlignment.center,
                                    crossAxisAlignment:
                                        WrapCrossAlignment.center,
                                    spacing: 6,
                                    runSpacing: 4,
                                    children: [
                                      Text(
                                        "Wrong number?".translate(context),
                                        style: bodyText(context),
                                      ),
                                      InkWell(
                                          onTap: () {
                                            goBack();
                                          },
                                          child: Text(
                                            "Go Back".translate(context),
                                            style: linkTextStyle(context),
                                          )),
                                    ],
                                  ),
                                ),
                                SizedBox(height: isSmallPhone ? 16 : 24),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ))),
      ),
    );
  }
}
