import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on_driver/core/utils/translate.dart';

import '../../../core/extensions/workspace.dart';
import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../cubits/auth/email_otp_cubit.dart';
import '../../widgets/custom_text_form_field.dart';
import '../../widgets/otp_box_field.dart';
import '../../widgets/primary_button.dart';

// ignore: must_be_immutable
class EmailOtpScreen extends StatefulWidget {
  String? otpValue;
  final String? email;
  bool? loginWithSocialMedia;
  bool? changeEmail;
  EmailOtpScreen(
      {super.key,
      this.otpValue,
      this.email,
      this.loginWithSocialMedia,
      this.changeEmail});

  @override
  State<EmailOtpScreen> createState() => _EmailOtpScreenState();
}

class _EmailOtpScreenState extends State<EmailOtpScreen> {
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    isNumeric = false;

    Future.delayed(
      const Duration(seconds: 1),
      () {
        textEditingOtpController.text = widget.otpValue!;
      },
    );
    startResendTimer();
  }

  int _remainingTime = 30;
  bool _isResendEnabled = true;
  late Timer _timer;

  void startResendTimer() {
    setState(() {
      _isResendEnabled = false;
    });

    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (_remainingTime > 0) {
          _remainingTime--;
        } else {
          _timer.cancel();
          _isResendEnabled = true;
          _remainingTime = 0;
        }
      });
    });
  }

  String formatTimer(int totalSeconds) {
    final minutes = totalSeconds ~/ 60;
    final seconds = totalSeconds % 60;

    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  TextEditingController textEditingOtpController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    String timerText = _remainingTime.toString().padLeft(2, '0');

    return Align(
      alignment: Alignment.center,
      child: SizedBox(
        width: Dimensions.containerWidth,
        child: Scaffold(
            bottomSheet: isNumeric == true && Platform.isIOS
                ? KeyboardDoneButton(
                    onTap: () {
                      setState(() {
                        isNumeric = false;
                      });
                    },
                  )
                : null,
            resizeToAvoidBottomInset: isNumeric,
            backgroundColor: notifires.getbgcolor,
            body: BlocListener<EmailOtpCubit, EmailOtpState>(
              listener: (context, state) {
                if (state is EmailOtpLoading) {
                  Widgets.showLoader(context);
                } else if (state is OtpSuccessForChangeEmailSate) {
                  Widgets.hideLoder(context);
                  goBack();
                } else if (state is ResendEmailOtpSuccess) {
                  Widgets.hideLoder(context);
                  textEditingOtpController.text = state.otp;
                } else if (state is EmailOtpFailed) {
                  Widgets.hideLoder(context);
                  showErrorToastMessage(state.error);
                }
              },
              child: SafeArea(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final isSmallPhone = constraints.maxHeight < 700 ||
                        constraints.maxWidth < 360;
                    final horizontalPadding = isSmallPhone ? 16.0 : 24.0;

                    return SingleChildScrollView(
                      keyboardDismissBehavior:
                          ScrollViewKeyboardDismissBehavior.onDrag,
                      child: Padding(
                        padding: EdgeInsets.symmetric(
                          horizontal: horizontalPadding,
                          vertical: isSmallPhone
                              ? Dimensions.space16
                              : Dimensions.space24,
                        ),
                        child: Form(
                          key: _formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              InkWell(
                                borderRadius: BorderRadius.circular(20),
                                onTap: () => goBack(),
                                child: Container(
                                  width: 40,
                                  height: 40,
                                  decoration: BoxDecoration(
                                    color: notifires.getBoxColor,
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Icon(Icons.arrow_back,
                                      color: notifires.getwhiteblackColor,
                                      size: 20),
                                ),
                              ),
                              SizedBox(height: isSmallPhone ? 20 : 32),
                              Container(
                                width: isSmallPhone ? 64 : 76,
                                height: isSmallPhone ? 64 : 76,
                                decoration: BoxDecoration(
                                  color: themeColor.withValues(alpha: 0.14),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Icon(Icons.mark_email_read_outlined,
                                    color: themeColor,
                                    size: isSmallPhone ? 30 : 36),
                              ),
                              SizedBox(height: isSmallPhone ? 16 : 24),
                              Text("Verify your email".translate(context),
                                  style: screenTitle(context)),
                              const SizedBox(height: Dimensions.space8),
                              Text(
                                  "We've sent a verification code to"
                                      .translate(context),
                                  style: screenSubtitle(context)),
                              const SizedBox(height: Dimensions.space4),
                              Text(widget.email ?? "",
                                  style: sectionTitleStyle(context)),
                              SizedBox(height: isSmallPhone ? 24 : 32),
                              Directionality(
                                textDirection: TextDirection.ltr,
                                child: OtpBoxField(
                                  controller: textEditingOtpController,
                                  onTap: () {
                                    isNumeric = true;
                                    setState(() {});
                                  },
                                  onChanged: (value) {},
                                ),
                              ),
                              SizedBox(height: isSmallPhone ? 20 : 28),
                              Align(
                                alignment: Alignment.center,
                                child: _isResendEnabled
                                    ? Wrap(
                                        alignment: WrapAlignment.center,
                                        crossAxisAlignment:
                                            WrapCrossAlignment.center,
                                        spacing: 6,
                                        runSpacing: 4,
                                        children: [
                                          Text(
                                            "Didn't receive code?"
                                                .translate(context),
                                            style: captionText(context),
                                          ),
                                          InkWell(
                                            onTap: () async {
                                              context
                                                  .read<EmailOtpCubit>()
                                                  .resendOtpForChangeEmail({
                                                "email": widget.email,
                                                "default_currency_code": "",
                                                "selected_currency_code": "",
                                              });
                                              startResendTimer();
                                              setState(() {
                                                _remainingTime = 30;
                                                _isResendEnabled = false;
                                              });
                                            },
                                            child: Text(
                                              "Resend".translate(context),
                                              style: linkTextStyle(context),
                                            ),
                                          ),
                                        ],
                                      )
                                    : Wrap(
                                        alignment: WrapAlignment.center,
                                        crossAxisAlignment:
                                            WrapCrossAlignment.center,
                                        spacing: 6,
                                        runSpacing: 4,
                                        children: [
                                          Text(
                                              "Resend code in"
                                                  .translate(context),
                                              style: captionText(context)),
                                          Text(
                                              formatTimer(
                                                  int.parse(timerText)),
                                              style: captionText(context)
                                                  .copyWith(
                                                      fontFamily:
                                                          "Poppins SemiBold",
                                                      fontWeight:
                                                          FontWeight.w600)),
                                        ],
                                      ),
                              ),
                              SizedBox(height: isSmallPhone ? 24 : 32),
                              PrimaryButton(
                                text: "Continue".translate(context),
                                onPressed: () {
                                  if (_formKey.currentState!.validate()) {
                                    if (textEditingOtpController
                                        .text.isEmpty) {
                                      showErrorToastMessage(
                                          "Please Enter the Otp"
                                              .translate(context));
                                      return;
                                    }
                                    context
                                        .read<EmailOtpCubit>()
                                        .emailOtpVerifyForChangeEmail(
                                            widget.email ?? "",
                                            textEditingOtpController.text);
                                  }
                                },
                              ),
                              SizedBox(height: isSmallPhone ? 20 : 28),
                              Align(
                                alignment: Alignment.center,
                                child: Wrap(
                                  alignment: WrapAlignment.center,
                                  crossAxisAlignment:
                                      WrapCrossAlignment.center,
                                  spacing: 6,
                                  runSpacing: 4,
                                  children: [
                                    Text(
                                      "Wrong email?".translate(context),
                                      style: bodyText(context),
                                    ),
                                    InkWell(
                                        onTap: () {
                                          goBack();
                                        },
                                        child: Text(
                                          "Go Back".translate(context),
                                          style: linkTextStyle(context),
                                        )),
                                  ],
                                ),
                              ),
                              SizedBox(height: isSmallPhone ? 16 : 24),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            )),
      ),
    );
  }
}
