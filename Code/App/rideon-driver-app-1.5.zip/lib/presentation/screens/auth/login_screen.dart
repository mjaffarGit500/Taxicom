import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import 'package:ride_on_driver/presentation/cubits/general_cubit.dart';
import 'package:ride_on_driver/presentation/screens/auth/signup_screen.dart';
import 'package:ride_on_driver/presentation/screens/onboarding/language_select_screen.dart';
import '../../../core/extensions/workspace.dart';
import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../cubits/auth/login_cubit.dart';
import '../../cubits/auth/user_authenticate_cubit.dart';
import '../../widgets/custom_text_form_field.dart';
import '../../widgets/primary_button.dart';
import 'otp_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController textEditingLoginControllerPhoneNumber =
      TextEditingController();

  bool isChecked = false;
  bool _isLoginSubmitting = false;
  bool _isOtpRoutePushing = false;

  final _formKey = GlobalKey<FormState>();

  String selectedCountryCode = "+91";
  String defaultCountry = "IN";

  @override
  void initState() {
    isNumeric = false;
    context.read<SetCountryCubit>().clear();
     context.read<GeneralCubit>().fetchGeneralSetting(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    notifires = Provider.of<ColorNotifires>(context, listen: true);
    return PopScope(
      canPop: false,
      // ignore: deprecated_member_use
      onPopInvoked: (v) async {},
      child: Scaffold(
          bottomSheet: isNumeric == true && Platform.isIOS
              ? KeyboardDoneButton(
                  onTap: () {
                    setState(() {
                      isNumeric = false;
                    });
                  },
                )
              : null,
          resizeToAvoidBottomInset: true,
          backgroundColor: appWarmBackground,
          body: MultiBlocListener(
              listeners: [
                BlocListener<AuthLoginCubit, AuthLoginState>(
                    listener: (context, state) async {
                  if (state is LoginLoading) {
                    _isLoginSubmitting = true;
                    Widgets.showLoader(context);
                  } else if (state is LoginSuccess) {
                    if (_isOtpRoutePushing) {
                      return;
                    }

                    _isLoginSubmitting = false;
                    _isOtpRoutePushing = true;
                    Widgets.hideLoder(context);
                    try {
                      await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => OtpScreen(
                                    number:
                                        textEditingLoginControllerPhoneNumber
                                            .text,
                                    countryCode:
                                        state.loginModel.data?.phoneCountry ??
                                            "+91",
                                    defaultCountry:
                                        state.loginModel.data?.defaultCountry ??
                                            "IN",
                                    routeString: "Login",
                                    otpValue:
                                        state.loginModel.data?.resetToken??"",
                                  )));
                      context.read<AuthLoginCubit>().resetState();
                    } finally {
                      _isOtpRoutePushing = false;
                    }
                  } else if (state is LoginFailure) {
                    _isLoginSubmitting = false;
                    _isOtpRoutePushing = false;
                    Widgets.hideLoder(context);

                    showErrorToastMessage(state.error);
                  }
                })
              ],
              child: Stack(
                children: [
                  Positioned(
                    top: -60,
                    right: -60,
                    child: IgnorePointer(
                      child: Container(
                        width: 220,
                        height: 220,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          // ignore: deprecated_member_use
                          color: themeColor.withOpacity(0.10),
                        ),
                      ),
                    ),
                  ),
                  SafeArea(
                    child: LayoutBuilder(builder: (context, constraints) {
                      return SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        child: ConstrainedBox(
                          constraints:
                              BoxConstraints(minHeight: constraints.maxHeight),
                          child: IntrinsicHeight(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: Dimensions.space24,
                                  vertical: Dimensions.space16),
                              child: Form(
                                key: _formKey,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: languageButton(
                                        onTap: () {
                                          goTo(const SelectLanguageScreen(
                                            isBack: true,
                                          ));
                                        },
                                      ),
                                    ),
                                    const SizedBox(height: Dimensions.space24),
                                    Container(
                                      width: 72,
                                      height: 72,
                                      decoration: BoxDecoration(
                                        color:
                                            themeColor.withValues(alpha: 0.14),
                                        borderRadius: BorderRadius.circular(20),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.black
                                                .withValues(alpha: 0.05),
                                            blurRadius: 12,
                                            offset: const Offset(0, 4),
                                          ),
                                        ],
                                      ),
                                      padding: const EdgeInsets.all(12),
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(12),
                                        child: commonlyUserLogo(),
                                      ),
                                    ),
                                    const SizedBox(height: Dimensions.space24),
                                    Text("Welcome Back".translate(context),
                                        style: screenTitle(context)),
                                    const SizedBox(height: Dimensions.space8),
                                    Text(
                                        "Sign in to continue your driver journey"
                                            .translate(context),
                                        style: screenSubtitle(context)),
                                    const SizedBox(height: Dimensions.space32),
                                    BlocBuilder<SetCountryCubit,
                                            SetCountryState>(
                                        builder: (context, state) {
                                      return IntelPhoneFieldRefsAuth(
                                        onTap: () {
                                          isNumeric = true;
                                          setState(() {});
                                        },
                                        key: ValueKey(state.countryCode),
                                        defultcountry: state.countryCode,
                                        textEditingControllerCommons:
                                            textEditingLoginControllerPhoneNumber,
                                        oncountryChanged: (number) {
                                          context
                                              .read<SetCountryCubit>()
                                              .reset();
                                          textEditingLoginControllerPhoneNumber
                                              .clear();

                                          context
                                              .read<SetCountryCubit>()
                                              .setCountry(
                                                  dialCode:
                                                      "+${number.dialCode}",
                                                  countryCode: number.code);
                                        },
                                        hintText: "Phone no".translate(context),
                                        onChanged: (value) {
                                          return null;
                                        },
                                        validator: (phoneNumber) {
                                          if (phoneNumber == null ||
                                              phoneNumber.number.isEmpty) {
                                            return "Please enter your phone number"
                                                .translate(context);
                                          }
                                          int expectedLength = phoneLengths[
                                                  phoneNumber.countryISOCode] ??
                                              10;
                                          if (phoneNumber.number.length !=
                                              expectedLength) {
                                            return "${"Phone number must be".translate(context)} $expectedLength ${"digits".translate(context)}";
                                          }
                                          return null;
                                        },
                                      );
                                    }),
                                    const SizedBox(height: Dimensions.space24),
                                    PrimaryButton(
                                      text: "Login".translate(context),
                                      onPressed: () {
                                        isNumeric = false;
                                        setState(() {});
                                        if (_isLoginSubmitting ||
                                            _isOtpRoutePushing) {
                                          return;
                                        }

                                        if (_formKey.currentState!.validate()) {
                                          if (textEditingLoginControllerPhoneNumber
                                              .text.isEmpty) {
                                            showErrorToastMessage(
                                                "please enter the phone number"
                                                    .translate(context));
                                            return;
                                          }
                                          context.read<AuthLoginCubit>().login(
                                              context: context,
                                              phoneCountry: context
                                                      .read<SetCountryCubit>()
                                                      .state
                                                      .dialCode
                                                      .startsWith("+")
                                                  ? context
                                                      .read<SetCountryCubit>()
                                                      .state
                                                      .dialCode
                                                  : "+${context.read<SetCountryCubit>().state.dialCode}",
                                              phoneNumber:
                                                  textEditingLoginControllerPhoneNumber
                                                      .text);
                                        }
                                      },
                                    ),
                                    const Spacer(),
                                    const SizedBox(height: Dimensions.space24),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Text(
                                          "New to RideOn?".translate(context),
                                          style: bodyText(context),
                                        ),
                                        const SizedBox(width: 6),
                                        InkWell(
                                          onTap: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        const SignUp()));
                                          },
                                          child: Text(
                                            "Sign Up".translate(context),
                                            style: linkTextStyle(context),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: Dimensions.space16),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    }),
                  ),
                ],
              ))),
    );
  }
}
