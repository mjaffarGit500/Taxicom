import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import 'package:ride_on_driver/domain/entities/general_setting.dart';
import 'package:ride_on_driver/presentation/cubits/general_cubit.dart';
import 'package:ride_on_driver/presentation/screens/account/static_screen.dart';
import 'package:ride_on_driver/presentation/screens/onboarding/language_select_screen.dart';

import '../../../core/extensions/workspace.dart';
import '../../../core/utils/common_widget.dart';
import '../../../core/utils/theme/project_color.dart';
import '../../../core/utils/theme/theme_style.dart';
import '../../cubits/auth/signup_cubit.dart';
import '../../cubits/auth/user_authenticate_cubit.dart';
import '../../cubits/realtime/manage_driver_cubit.dart';
import '../../widgets/custom_text_form_field.dart';
import '../../widgets/form_validations.dart';
import '../../widgets/primary_button.dart';
import 'login_screen.dart';
import 'otp_screen.dart';

const int termsAndConditionsPageId = 11;

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  TextEditingController textEditingSignUpControllerName =
      TextEditingController();
  TextEditingController textEditingSignUpControllerEmail =
      TextEditingController();

  TextEditingController textEditingSingUpControllerPhoneNumber =
      TextEditingController();
  TextEditingController textEditingSignUpControllerPassword =
      TextEditingController();

  bool isChecked = false;
  bool _isSignUpSubmitting = false;
  bool _isOtpRoutePushing = false;

  @override
  void initState() {
    isNumeric = false;
    context.read<SetCountryCubit>().reset();
    super.initState();
  }

  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    notifires = Provider.of<ColorNotifires>(context, listen: true);
    return PopScope(
      canPop: false,
      // ignore: deprecated_member_use
      onPopInvoked: (v) async {},
      child: Scaffold(
          resizeToAvoidBottomInset: isNumeric,
          bottomSheet: isNumeric == true && Platform.isIOS
              ? KeyboardDoneButton(
                  onTap: () {
                    setState(() {
                      isNumeric = false;
                    });
                  },
                )
              : null,
          backgroundColor: appWarmBackground,
          body: MultiBlocListener(
              listeners: [
                BlocListener<AuthSignUpCubit, AuthSignUpState>(
                    listener: (context, state) async {
                  if (state is SignUpLoading) {
                    _isSignUpSubmitting = true;
                    Widgets.showLoader(context);
                  } else if (state is SignUpSuccess) {
                    if (_isOtpRoutePushing) {
                      return;
                    }

                    _isSignUpSubmitting = false;
                    _isOtpRoutePushing = true;
                    context.read<UpdateDriverParameterCubit>().updateDriverId(
                        driverId:
                            state.loginModel.data!.fireStoreId!.toString());
                    Widgets.hideLoder(context);
                    await Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => OtpScreen(
                                  number: state.loginModel.data?.phone??"",
                                  countryCode:
                                      state.loginModel.data?.phoneCountry??"",
                                  otpValue: state.loginModel.data?.otpValue??"",
                                  email: "",
                                  defaultCountry:
                                      state.loginModel.data?.defaultCountry??"",
                                  changeMobile: false,
                                  loginWithSocialMedia: false,
                                  routeString: "SignUp",
                                )));
                    context.read<AuthSignUpCubit>().resetState();
                    _isOtpRoutePushing = false;
                  } else if (state is SignUpFailure) {
                    _isSignUpSubmitting = false;
                    _isOtpRoutePushing = false;
                    Widgets.hideLoder(context);
                    showErrorToastMessage(state.error);
                  }
                })
              ],
              child: Stack(
                children: [
                  Positioned(
                    top: -60,
                    right: -60,
                    child: IgnorePointer(
                      child: Container(
                        width: 220,
                        height: 220,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: themeColor.withValues(alpha: 0.10),
                        ),
                      ),
                    ),
                  ),
                  SafeArea(
                    child: LayoutBuilder(builder: (context, constraints) {
                      return SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        child: ConstrainedBox(
                          constraints:
                              BoxConstraints(minHeight: constraints.maxHeight),
                          child: IntrinsicHeight(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: Dimensions.space24,
                                  vertical: Dimensions.space16),
                              child: Form(
                                key: _formKey,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: languageButton(
                                        onTap: () {
                                          goTo(const SelectLanguageScreen(
                                            isBack: true,
                                          ));
                                        },
                                      ),
                                    ),
                                    const SizedBox(height: Dimensions.space24),
                                    Container(
                                      width: 72,
                                      height: 72,
                                      decoration: BoxDecoration(
                                        color:
                                            themeColor.withValues(alpha: 0.14),
                                        borderRadius: BorderRadius.circular(20),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.black
                                                .withValues(alpha: 0.05),
                                            blurRadius: 12,
                                            offset: const Offset(0, 4),
                                          ),
                                        ],
                                      ),
                                      padding: const EdgeInsets.all(12),
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(12),
                                        child: commonlyUserLogo(),
                                      ),
                                    ),
                                    const SizedBox(height: Dimensions.space24),
                                    Text(
                                        "Create your account"
                                            .translate(context),
                                        style: screenTitle(context)),
                                    const SizedBox(height: Dimensions.space8),
                                    Text(
                                        "Sign up to start driving with RideOn"
                                            .translate(context),
                                        style: screenSubtitle(context)),
                                    const SizedBox(height: Dimensions.space32),
                                    TextFieldAdvanceForAuth(
                                      onTap: () {
                                        setState(() {
                                          isNumeric = false;
                                        });
                                      },
                                      inputAlignment: TextAlign.start,
                                      txt: "Name".translate(context),
                                      icons: Icon(
                                        Icons.person_outline,
                                        color: notifires.getGrey3whiteColor,
                                      ),
                                      textEditingControllerCommon:
                                          textEditingSignUpControllerName,
                                      inputType: TextInputType.name,
                                      validator: (value) {
                                        if (isValidName(value!)) {
                                          return null;
                                        } else {
                                          return "Name is invalid"
                                              .translate(context);
                                        }
                                      },
                                    ),
                                    const SizedBox(height: Dimensions.space16),
                                    BlocBuilder<SetCountryCubit,
                                            SetCountryState>(
                                        builder: (context, state) {
                                      return IntelPhoneFieldRefsAuth(
                                        onTap: () {
                                          setState(() {
                                            isNumeric = true;
                                          });
                                        },
                                        hintText: "Phone no".translate(context),
                                        key: ValueKey(state.countryCode),
                                        defultcountry: state.countryCode,
                                        textEditingControllerCommons:
                                            textEditingSingUpControllerPhoneNumber,
                                        oncountryChanged: (number) {
                                          context
                                              .read<SetCountryCubit>()
                                              .reset();
                                          textEditingSingUpControllerPhoneNumber
                                              .clear();
                                          context
                                              .read<SetCountryCubit>()
                                              .setCountry(
                                                  dialCode:
                                                      "+${number.dialCode}",
                                                  countryCode: number.code);
                                        },
                                        onChanged: (number) {
                                          return null;
                                        },
                                        validator: (phoneNumber) {
                                          if (phoneNumber == null ||
                                              phoneNumber.number.isEmpty) {
                                            return "Please enter your phone number"
                                                .translate(context);
                                          }
                                          int expectedLength = phoneLengths[
                                                  phoneNumber.countryISOCode] ??
                                              10;
                                          if (phoneNumber.number.length !=
                                              expectedLength) {
                                            return "${"Phone number must be"} $expectedLength ${"digits"}";
                                          }
                                          return null;
                                        },
                                      );
                                    }),
                                    const SizedBox(height: Dimensions.space16),
                                    TextFieldAdvanceForAuth(
                                      onTap: () {
                                        setState(() {
                                          isNumeric = false;
                                        });
                                      },
                                      inputAlignment: TextAlign.start,
                                      txt: "Email".translate(context),
                                      icons: Icon(
                                        Icons.mail_outline_outlined,
                                        color: notifires.getGrey3whiteColor,
                                      ),
                                      textEditingControllerCommon:
                                          textEditingSignUpControllerEmail,
                                      inputType: TextInputType.emailAddress,
                                      validator: (value) {
                                        return validateEmail(value!, context);
                                      },
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        SizedBox(
                                          width: 22,
                                          height: 22,
                                          child: Transform.scale(
                                            scale: 0.9,
                                            child: Checkbox(
                                              activeColor: themeColor,
                                              focusColor: whiteColor,
                                              value: isChecked,
                                              materialTapTargetSize:
                                                  MaterialTapTargetSize
                                                      .shrinkWrap,
                                              onChanged: (bool? newValue) {
                                                setState(() {
                                                  isChecked = newValue!;
                                                });
                                              },
                                              checkColor: whiteColor,
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        Dimensions.radiusSmall),
                                              ),
                                              side: BorderSide(
                                                  color: notifires
                                                      .getGrey3whiteColor,
                                                  width: 1.4),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 10),
                                        Expanded(
                                          child: BlocBuilder<StaticPagesCubit,
                                              SimpleState<List<StaticPage>>>(
                                            builder: (context, state) {
                                              final List<StaticPage> pages =
                                                  state.value;

                                              // Terms and Conditions page dhoondo
                                              StaticPage? termsPage;
                                              for (final page in pages) {
                                                if (page.id ==
                                                    termsAndConditionsPageId) {
                                                  termsPage = page;
                                                  break;
                                                }
                                              }

                                              // Agar Terms and Conditions nahi mila to simple text dikhao
                                              if (termsPage == null ||
                                                  termsPage.name == null ||
                                                  termsPage.name!.isEmpty) {
                                                return Text(
                                                  "By creating an account, you agree to our terms."
                                                      .translate(context),
                                                  style:
                                                      regular(context).copyWith(
                                                    color: notifires
                                                        .getGrey2whiteColor,
                                                    fontSize: 12.5,
                                                    height: 1.35,
                                                  ),
                                                );
                                              }

                                              // Agar mila to clickable dikhao
                                              return GestureDetector(
                                                onTap: () {
                                                  showModalBottomSheet(
                                                    useRootNavigator: true,
                                                    backgroundColor:
                                                        notifires.getbgcolor,
                                                    isScrollControlled: true,
                                                    useSafeArea: true,
                                                    context: context,
                                                    builder:
                                                        (BuildContext context) {
                                                      return StaticScreen(
                                                        name: termsPage!.name ??
                                                            "Terms and Conditions",
                                                        id: termsPage.id
                                                            .toString(),
                                                        isBack: true,
                                                      );
                                                    },
                                                  );
                                                },
                                                child: Text.rich(
                                                  TextSpan(
                                                    text:
                                                        "By creating an account, you agree to our "
                                                            .translate(context),
                                                    style: regular(context)
                                                        .copyWith(
                                                      color: notifires
                                                          .getGrey2whiteColor,
                                                      fontSize: 12.5,
                                                      height: 1.35,
                                                    ),
                                                    children: [
                                                      TextSpan(
                                                        text: (" ")
                                                            .translate(context),
                                                      ),
                                                      TextSpan(
                                                        text: (termsPage.name ??
                                                                "Terms and Conditions")
                                                            .translate(context),
                                                        style: regular(context)
                                                            .copyWith(
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: themeColor,
                                                          fontSize: 12.5,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              );
                                            },
                                          ),
                                        )
                                      ],
                                    ),
                                    const SizedBox(height: Dimensions.space24),
                                    PrimaryButton(
                                      text: "Sign Up".translate(context),
                                      onPressed: () {
                                        isNumeric = false;
                                        setState(() {});
                                        if (_isSignUpSubmitting ||
                                            _isOtpRoutePushing) {
                                          return;
                                        }

                                        if (_formKey.currentState!.validate()) {
                                          if (isChecked == false) {
                                            showErrorToastMessage(
                                                "Please select the terms and condition."
                                                    .translate(context));
                                            return;
                                          }
                                          if (textEditingSingUpControllerPhoneNumber
                                              .text.isEmpty) {
                                            showErrorToastMessage(
                                                "Fill valid mobile number"
                                                    .translate(context));
                                            return;
                                          }
                                          context
                                              .read<AuthSignUpCubit>()
                                              .signUp(
                                                context: context,
                                                name:
                                                    textEditingSignUpControllerName
                                                        .text,
                                                phoneCountry: context
                                                        .read<SetCountryCubit>()
                                                        .state
                                                        .dialCode
                                                        .startsWith("+")
                                                    ? context
                                                        .read<SetCountryCubit>()
                                                        .state
                                                        .dialCode
                                                    : "+${context.read<SetCountryCubit>().state.dialCode}",
                                                defaultCountry: context
                                                    .read<SetCountryCubit>()
                                                    .state
                                                    .countryCode,
                                                phoneNumber:
                                                    textEditingSingUpControllerPhoneNumber
                                                        .text,
                                                email:
                                                    textEditingSignUpControllerEmail
                                                        .text,
                                              );
                                        }
                                      },
                                    ),
                                    const Spacer(),
                                    const SizedBox(height: Dimensions.space24),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Text(
                                          "Already have an account?"
                                              .translate(context),
                                          style: bodyText(context),
                                        ),
                                        const SizedBox(width: 6),
                                        InkWell(
                                          onTap: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        const LoginScreen()));
                                          },
                                          child: Text(
                                            "Sign in".translate(context),
                                            style: linkTextStyle(context),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: Dimensions.space16),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    }),
                  ),
                ],
              ))),
    );
  }
}
