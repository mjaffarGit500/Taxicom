import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_map/flutter_map.dart';
import '../../../core/utils/common_widget.dart';

abstract class OSMGetPolylineState extends Equatable {
  @override
  List<Object?> get props => [];
}

class OSMGetPolylineInitial extends OSMGetPolylineState {}

class OSMGetPolylineLoading extends OSMGetPolylineState {
  final Set<Polyline> polylines;
  OSMGetPolylineLoading(this.polylines);

  @override
  List<Object?> get props => [polylines];
}

class OSMGetPolylineUpdated extends OSMGetPolylineState {
  final Set<Polyline> polylines;
  OSMGetPolylineUpdated({required this.polylines});

  @override
  List<Object?> get props => [polylines];
}

class OSMGetPolylineUpdatedError extends OSMGetPolylineState {
  final String error;
  OSMGetPolylineUpdatedError(this.error);

  @override
  List<Object?> get props => [error];
}

class OSMGetPolylineCubit extends Cubit<OSMGetPolylineState> {
  OSMGetPolylineCubit() : super(OSMGetPolylineInitial());

  final Map<String, Polyline> _polylines = {};

  Future<void> getPolyline({
    required double sourcelat,
    required double sourcelng,
    required double destinationlat,
    required double destinationlng,
    required bool isPickupRoute,
  }) async {
    try {
      if (sourcelat == 0.0 ||
          sourcelng == 0.0 ||
          destinationlat == 0.0 ||
          destinationlng == 0.0) {
        emit(OSMGetPolylineUpdatedError("Invalid coordinates"));
        return;
      }

      emit(OSMGetPolylineLoading(_polylines.values.toSet()));

      // OSRM public API URL
      final url = Uri.parse(
          "http://router.project-osrm.org/route/v1/driving/$sourcelng,$sourcelat;$destinationlng,$destinationlat?overview=full&geometries=geojson");

      final response = await http.get(url);
       if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['code'] != 'Ok' || data['routes'] == null || data['routes'].isEmpty) {
          emit(OSMGetPolylineUpdatedError("Failed to get route"));
          return;
        }

        // Extract coordinates from geojson
        final coords = data['routes'][0]['geometry']['coordinates'] as List;
        final polylineCoordinates = coords
            .map<LatLng>((point) => LatLng(point[1].toDouble(), point[0].toDouble()))
            .toList();

        final String polylineId = isPickupRoute
            ? "DriverPickupToUser"
            : "DriverDropoffToUser";

        // Remove the opposite polyline
        final String oppositePolylineId = isPickupRoute
            ? "DriverDropoffToUser"
            : "DriverPickupToUser";
        _polylines.remove(oppositePolylineId);

        // Remove existing polyline of same type
        _polylines.remove(polylineId);

        _addPolyLine(
          coordinates: polylineCoordinates,
          id: polylineId,
          color: isPickupRoute ? Colors.blue : Colors.green,
        );

        emit(OSMGetPolylineUpdated(polylines: _polylines.values.toSet()));
      } else {
        emit(OSMGetPolylineUpdatedError("Failed to fetch route - Status: ${response.statusCode}"));
      }
    } catch (e) {
      emit(OSMGetPolylineUpdatedError("Exception: $e"));
    }
  }

  void _addPolyLine({
    required List<LatLng> coordinates,
    required String id,
    required Color color,
  }) {
    final polyline = Polyline(
      points: coordinates,
      strokeWidth: 4,
      color: color,
    );
    _polylines[id] = polyline;
  }






  void clearPolyline(bool isPickupRoute) {
    final String polylineId = isPickupRoute
        ? "DriverPickupToUser"
        : "DriverDropoffToUser";

    _polylines.remove(polylineId);
    emit(OSMGetPolylineUpdated(polylines: _polylines.values.toSet()));
  }

  Set<Polyline> get currentPolylines => _polylines.values.toSet();

  bool hasPolyline(bool isPickupRoute) {
    final String polylineId = isPickupRoute
        ? "DriverPickupToUser"
        : "DriverDropoffToUser";
    return _polylines.containsKey(polylineId);
  }

  void resetPolylines() {
    _polylines.clear();
    emit(OSMGetPolylineInitial());
  }
}







// OSM Marker States
abstract class OSMMarkerState extends Equatable {
  @override
  List<Object?> get props => [];
}

class OSMMarkerInitial extends OSMMarkerState {}

class OSMMarkerUpdated extends OSMMarkerState {
  final Set<Marker> markers;

  OSMMarkerUpdated({required this.markers});

  @override
  List<Object?> get props => [markers];
}

class OSMMarkerCubit extends Cubit<OSMMarkerState> {
  OSMMarkerCubit() : super(OSMMarkerInitial());

  final Map<String, Marker> _markers = {}; // Use Map instead of Set for better control

  void deleteMarker(String markerId) {
    _markers.remove(markerId);
    emit(OSMMarkerUpdated(markers: _markers.values.toSet()));
  }

  void removeAllMarkers() {
    _markers.clear();
    emit(OSMMarkerInitial());
  }

  Future<void> addOrUpdateMarker(
      LatLng position,
      String title,
      String markerId,
      String imageAsset,
      double size,
      ) async {
    try {
      final Uint8List markerIcon = await getBytesFromAsset(imageAsset, size.toInt());

      // Create marker with consistent ID
      final marker = Marker(
        key: ValueKey(markerId),
        width: size,
        height: size,
        point: position,
        child: GestureDetector(
          behavior: HitTestBehavior.translucent,
          onTap: () {
            // Handle marker tap
          },
          child: Image.memory(markerIcon),
        ),
      );

      // Add or update marker
      _markers[markerId] = marker;

      emit(OSMMarkerUpdated(markers: _markers.values.toSet()));
    } catch (e) {}
  }

  Set<Marker> get currentMarkers => _markers.values.toSet();
}