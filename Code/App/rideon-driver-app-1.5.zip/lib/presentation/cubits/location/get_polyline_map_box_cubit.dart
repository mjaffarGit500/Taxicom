import 'dart:convert';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
import 'package:http/http.dart' as http;
import '../../../../core/services/config.dart';
import 'package:flutter/services.dart';
import 'dart:ui' as ui;

abstract class GetPolylineMapBoxState extends Equatable {
  const GetPolylineMapBoxState();

  @override
  List<Object?> get props => [];
}

class GetPolylineMapBoxInitial extends GetPolylineMapBoxState {}

class GetPolylineMapBoxLoading extends GetPolylineMapBoxState {
  final Set<PolylineAnnotation> polylines;

  const GetPolylineMapBoxLoading(this.polylines);

  @override
  List<Object?> get props => [polylines];
}

class GetPolylineMapBoxUpdated extends GetPolylineMapBoxState {
  final Set<PolylineAnnotation> polylines;

  const GetPolylineMapBoxUpdated({required this.polylines});

  @override
  List<Object?> get props => [polylines];
}

class GetPolylineMapBoxError extends GetPolylineMapBoxState {
  final String message;

  const GetPolylineMapBoxError(this.message);

  @override
  List<Object?> get props => [message];
}

class GetPolylineMapBoxCubit extends Cubit<GetPolylineMapBoxState> {
  GetPolylineMapBoxCubit() : super(GetPolylineMapBoxInitial());

  final Map<String, PolylineAnnotation> _polylines = {};
  PolylineAnnotationManager? _annotationManager;
  static const String _mapboxBaseUrl =
      'https://api.mapbox.com/directions/v5/mapbox/driving';

   Future<void> setMapController(MapboxMap map) async {
    _annotationManager =
        await map.annotations.createPolylineAnnotationManager();
  }

   Future<void> getPolylineMapbox({
    required double sourceLat,
    required double sourceLng,
    required double destinationLat,
    required double destinationLng,
    required bool isPickupRoute, // true for pickup, false for dropoff
  }) async {
    try {
      if (sourceLat == 0.0 ||
          sourceLng == 0.0 ||
          destinationLat == 0.0 ||
          destinationLng == 0.0) {
        emit(const GetPolylineMapBoxError("Invalid coordinates"));
        return;
      }

      emit(GetPolylineMapBoxLoading(_polylines.values.toSet()));

      final coordinates =
          '$sourceLng,$sourceLat;$destinationLng,$destinationLat';
      final url = Uri.parse(
        '$_mapboxBaseUrl/$coordinates?geometries=geojson&overview=full&access_token=${Config.mapboxToken}',
      );
       final response = await http.get(url);


      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['code'] != 'Ok' ||
            data['routes'] == null ||
            data['routes'].isEmpty) {
          emit(const GetPolylineMapBoxError("Failed to get route"));
          return;
        }

        final geometry = data['routes'][0]['geometry'];


        final String polylineId =
            isPickupRoute ? "DriverPickupToUser" : "DriverDropoffToUser";


        final String oppositePolylineId =
            isPickupRoute ? "DriverDropoffToUser" : "DriverPickupToUser";
        await _removePolylineById(oppositePolylineId);
         await _removePolylineById(polylineId);

        await _addPolyLine(
          geometry: geometry,
          id: polylineId,
          color: isPickupRoute ? 0xFF2196F3 : 0xFF4CAF50,
        );

        emit(GetPolylineMapBoxUpdated(polylines: _polylines.values.toSet()));
      } else {
        emit(GetPolylineMapBoxError(
            "Failed to fetch route (${response.statusCode})"));
      }
    } catch (e) {
      emit(GetPolylineMapBoxError("Exception: $e"));
    }
  }
  Future<void> _addPolyLine({
    required Map<String, dynamic> geometry,
    required String id,
    required int color,
  }) async {
    final lineString = _convertGeoJsonToLineString(geometry);
    if (lineString == null) {
      return;
    }

    if (_annotationManager == null) {
      return;
    }

    try {
      final polylineOptions = PolylineAnnotationOptions(
        geometry: lineString,
        lineColor: color,
        lineWidth: 5.0,
        lineOpacity: 1.0,
        lineJoin: LineJoin.ROUND,
      );
      final polylineAnnotation =
          await _annotationManager!.create(polylineOptions);
      _polylines[id] = polylineAnnotation;
    } catch (e) {}
  }

  Future<void> _removePolylineById(String id) async {
    final existing = _polylines[id];
    if (existing != null && _annotationManager != null) {
      await _annotationManager!.delete(existing);
      _polylines.remove(id);
    }
  }

  LineString? _convertGeoJsonToLineString(Map<String, dynamic> geometry) {
    try {
      if (geometry['type'] == 'LineString' && geometry['coordinates'] is List) {
        final coordinates = geometry['coordinates'] as List;
        final positions = coordinates.map((coord) {
          if (coord is List && coord.length >= 2) {
            return Position(coord[0].toDouble(), coord[1].toDouble());
          }
          return Position(0, 0);
        }).toList();

        return LineString(coordinates: positions);
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  Future<void> resetPolylines() async {
    try {
      if (_annotationManager != null) {
        try {
          await _annotationManager!.deleteAll();
        } catch (e) {}
      }

       _annotationManager = null;

      _polylines.clear();

      if (!isClosed) {
        emit(GetPolylineMapBoxInitial());
      }
    } catch (e) {}
  }


  void clear(){
    emit(GetPolylineMapBoxInitial());
  }

  Set<PolylineAnnotation> get currentPolylines => _polylines.values.toSet();
}

class MarkerData {
  Point point;
  String title;
  Uint8List image;

  MarkerData({
    required this.point,
    required this.title,
    required this.image,
  });
}

abstract class UserMarkerStateMapbox extends Equatable {
  @override
  List<Object?> get props => [];
}

class UserMarkerInitialMapbox extends UserMarkerStateMapbox {}

class UserMarkerUpdatedMapbox extends UserMarkerStateMapbox {
  final Map<String, PointAnnotation> markers;
  UserMarkerUpdatedMapbox({required this.markers});
  @override
  List<Object?> get props => [markers];
}

// ------------------- CUBIT -------------------
class UserMarkerCubitMapbox extends Cubit<UserMarkerStateMapbox> {
  UserMarkerCubitMapbox() : super(UserMarkerInitialMapbox());
  final Map<String, PointAnnotation> _markers = {};
  final Map<String, MarkerData> _pending = {};
  PointAnnotationManager? _annotationManager;

  Future<void> setMapController(MapboxMap map) async {
    _annotationManager = await map.annotations.createPointAnnotationManager();
    // Process any pending markers
    for (final entry in _pending.entries) {
      final markerId = entry.key;
      final data = entry.value;
      try {
        final pointAnnotationOptions = PointAnnotationOptions(
          geometry: data.point,
          image: data.image,
          textField: data.title,
          textOffset: [0, 2],
        );
        final pointAnnotation =
            await _annotationManager!.create(pointAnnotationOptions);
        _markers[markerId] = pointAnnotation;
      } catch (e) {}
    }
    _pending.clear();
    emit(UserMarkerUpdatedMapbox(markers: Map.from(_markers)));
  }

  Future<void> addOrUpdateMarker({
    required Point point,
    required String title,
    required String markerId,
    required String iconPath,
    int size = 80,
  }) async {
    // Remove old marker first
    await _removeMarker(markerId);
    try {
      final Uint8List imageBytes = await _getMarkerImage(iconPath, title, size);
      final data = MarkerData(point: point, title: title, image: imageBytes);
      if (_annotationManager != null) {
        final pointAnnotationOptions = PointAnnotationOptions(
          geometry: point,
          image: imageBytes,
          textField: title,
          textOffset: [0, 2],
        );
        final pointAnnotation =
            await _annotationManager!.create(pointAnnotationOptions);
        _markers[markerId] = pointAnnotation;
        emit(UserMarkerUpdatedMapbox(markers: Map.from(_markers)));
      } else {
        _pending[markerId] = data;
      }
    } catch (e) {}
  }

  Future<void> _removeMarker(String markerId) async {
    if (_annotationManager != null) {
      final marker = _markers[markerId];
      if (marker != null) {
        await _annotationManager!.delete(marker);
        _markers.remove(markerId);
        emit(UserMarkerUpdatedMapbox(markers: Map.from(_markers)));
      }
    } else {
      _pending.remove(markerId);
    }
  }

  void removeMarker(String markerId) {
    _removeMarker(markerId);
  }

  Future<void> updateMarkerPosition(String markerId, Point newPosition) async {
    if (_annotationManager != null) {
      final marker = _markers[markerId];
      if (marker != null) {
        marker.geometry = newPosition;
        await _annotationManager!.update(marker);
        emit(UserMarkerUpdatedMapbox(markers: Map.from(_markers)));
      }
    } else {
      final pendingData = _pending[markerId];
      if (pendingData != null) {
        pendingData.point = newPosition;
      }
    }
  }


  Future<void> clear() async {
    try {
      // Ensure annotation manager exists and map is still mounted
      if (_annotationManager != null) {
        try {
          await _annotationManager!.deleteAll();
        } catch (e) {}
      }

      _annotationManager = null; // reset manager

      _markers.clear();
      _pending.clear();

      if (!isClosed) {
        emit(UserMarkerInitialMapbox());
      }
    } catch (e) {}
  }
  void reset(){
    emit(UserMarkerInitialMapbox());
  }

  // ------------------- Helpers -------------------
  Future<Uint8List> _getMarkerImage(
      String iconPath, String title, int size) async {
    return await getBytesFromAsset(iconPath, size);
  }

  Future<Uint8List> getBytesFromAsset(String path, int width) async {
    final ByteData data = await rootBundle.load(path);
    final ui.Codec codec = await ui.instantiateImageCodec(
      data.buffer.asUint8List(),
      targetWidth: width,
    );
    final ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png))!
        .buffer
        .asUint8List();
  }
}


class MoveCubit extends Cubit<bool> {
  MoveCubit() : super(false); // initial state = false

  void setMove(bool value) => emit(value);

  void toggleMove() => emit(!state);
}
