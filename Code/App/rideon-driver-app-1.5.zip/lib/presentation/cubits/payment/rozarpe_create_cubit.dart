import 'package:equatable/equatable.dart';

import 'package:flutter/cupertino.dart';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on_driver/data/repositories/payment_repository.dart';

abstract class CreateRazorpayPaymentState extends Equatable {
  @override
  List<Object?> get props => [];
}

class CreateRazorpayPaymentInitial extends CreateRazorpayPaymentState {}

class CreateRazorpayPaymentLoading extends CreateRazorpayPaymentState {}

class CreateRazorpayPaymentSuccess extends CreateRazorpayPaymentState {
  final Map<String, dynamic> paymentData;

  CreateRazorpayPaymentSuccess(this.paymentData);

  @override
  List<Object?> get props => [paymentData];
}

class VerifyRazorpayPaymentSuccess extends CreateRazorpayPaymentState {
 final String message;


  VerifyRazorpayPaymentSuccess(this.message);

  @override
  List<Object?> get props => [message];
}

class CreateRazorpayPaymentFailure extends CreateRazorpayPaymentState {
  final String message;

  CreateRazorpayPaymentFailure(this.message);

  @override
  List<Object?> get props => [message];
}

class VerifyRazorpayPaymentFailure extends CreateRazorpayPaymentState {
  final String message;

  VerifyRazorpayPaymentFailure(this.message);

  @override
  List<Object?> get props => [message];
}

class CreateRazorpayPaymentCubit extends Cubit<CreateRazorpayPaymentState> {
  final PaymentRepository paymentRepository;

  CreateRazorpayPaymentCubit(this.paymentRepository)
      : super(CreateRazorpayPaymentInitial());

  Future<void> createPayment({
    required BuildContext context,
    required String amount,
  }) async {
    try {
      emit(CreateRazorpayPaymentLoading());

      final response = await paymentRepository.createRozerPePayment(postData: {
        "amount": amount,
        "currency": "INR",
      });

      if (response["status"] == 200) {
        emit(CreateRazorpayPaymentSuccess(response["data"]));
      } else {
        emit(CreateRazorpayPaymentFailure(
            response["message"] ?? "Something went wrong"));
      }
    } catch (e) {
      emit(CreateRazorpayPaymentFailure(e.toString()));
    }
  }
  Future<void> verifyPayment({
    required BuildContext context,
    required Map<String, dynamic> postData,
  }) async {
    try {
      emit(CreateRazorpayPaymentLoading());

      final response = await paymentRepository.verifyRozerPePayment(postData: postData);

      if (response["status"].toString() == "success") {

        
        emit(VerifyRazorpayPaymentSuccess("Payment Successful"));
      } else {
        emit(VerifyRazorpayPaymentFailure(
            response["message"] ?? "Something went wrong"));
      }
    } catch (e) {
      emit(VerifyRazorpayPaymentFailure(e.toString()));
    }
  }

  void reset() {
    emit(CreateRazorpayPaymentInitial());
  }
}
