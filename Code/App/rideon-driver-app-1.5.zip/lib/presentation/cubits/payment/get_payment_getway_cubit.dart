import 'package:equatable/equatable.dart';

import 'package:flutter/cupertino.dart';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on_driver/data/repositories/payment_repository.dart';
import 'package:ride_on_driver/domain/entities/online_payment_getway_model.dart';

 

abstract class GetPaymentGetWayState extends Equatable {
  @override
  List<Object?> get props => [];
}

class GetPaymentGetWayInitial extends GetPaymentGetWayState {}

class GetPaymentGetWayLoading extends GetPaymentGetWayState {}

class GetPaymentGetWaySuccess extends GetPaymentGetWayState {
  final PaymentGatewaysResponse paymentData;

  GetPaymentGetWaySuccess(this.paymentData);

  @override
  List<Object?> get props => [paymentData];
}

class GetPaymentGetWayFailure extends GetPaymentGetWayState {
  final String message;

  GetPaymentGetWayFailure(this.message);

  @override
  List<Object?> get props => [message];
}

class GetPaymentGetWayCubit extends Cubit<GetPaymentGetWayState> {
  final PaymentRepository paymentRepository;

  GetPaymentGetWayCubit(this.paymentRepository)
      : super(GetPaymentGetWayInitial());

  Future<void> getPaymentGetWay({
    required BuildContext context,
  }) async {
    try {
      emit(GetPaymentGetWayLoading());

      final response = await paymentRepository.getPaymentGetway(postData: {});
       if (response["status"] == 200) {
        emit(GetPaymentGetWaySuccess(
            PaymentGatewaysResponse.fromJson(response)));
      } else {
        emit(GetPaymentGetWayFailure(
            response["message"] ?? "Something went wrong"));
      }
    } catch (e) {
      emit(GetPaymentGetWayFailure(e.toString()));
    }
  }

  void reset() {
    emit(GetPaymentGetWayInitial());
  }
}
