import 'package:equatable/equatable.dart';

import 'package:flutter/cupertino.dart';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on_driver/data/repositories/payment_repository.dart';

  abstract class CreatePaytmPaymentState extends Equatable {
  @override
  List<Object?> get props => [];
}

class CreatePaytmPaymentInitial extends CreatePaytmPaymentState {}

class CreatePaytmPaymentLoading extends CreatePaytmPaymentState {}

class CreatePaytmPaymentSuccess extends CreatePaytmPaymentState {
  final Map<String, dynamic> paymentData;

  CreatePaytmPaymentSuccess(this.paymentData);

  @override
  List<Object?> get props => [paymentData];
}

class CreatePaytmPaymentFailure extends CreatePaytmPaymentState {
  final String message;

  CreatePaytmPaymentFailure(this.message);

  @override
  List<Object?> get props => [message];
}

class CreatePaytmPaymentCubit extends Cubit<CreatePaytmPaymentState> {
  final PaymentRepository paymentRepository;

  CreatePaytmPaymentCubit(this.paymentRepository)
      : super(CreatePaytmPaymentInitial());

  Future<void> createPayment({
    required BuildContext context,
    required String amount,
  }) async {
    try {
      emit(CreatePaytmPaymentLoading());

      final response = await paymentRepository.createPaytmPayment(postData: {
        "amount": amount,
        "currency": "INR",
         
      });

      if (response["status"] == 200||response["status"]=="success") {
        emit(CreatePaytmPaymentSuccess(response["data"]));
      } else {
        emit(CreatePaytmPaymentFailure(
            response["message"] ?? "Something went wrong"));
      }
    } catch (e) {
      emit(CreatePaytmPaymentFailure(e.toString()));
    }
  }

  void reset() {
    emit(CreatePaytmPaymentInitial());
  }
}
