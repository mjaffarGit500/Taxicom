// ignore_for_file: use_build_context_synchronously
import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ride_on_driver/presentation/cubits/account/update_profile_cubit.dart';
import '../../core/extensions/workspace.dart';
import '../../core/services/data_store.dart';
import '../../data/repositories/profile_repository.dart';
import '../../domain/entities/general_setting.dart';

abstract class GeneralState extends Equatable {
  @override
  List<Object?> get props => [];
}

class GeneralInitial extends GeneralState {}

class GeneralLoading extends GeneralState {}

class GeneralSuccess extends GeneralState {
  final GeneralDataModel generalDataModel;

  GeneralSuccess(
    this.generalDataModel,
  );
  @override
  List<Object?> get props => [generalDataModel];
}

class GeneralFailed extends GeneralState {
  final String error;

  GeneralFailed(this.error);
  @override
  List<Object?> get props => [
        error,
      ];
}

class GeneralCubit extends Cubit<GeneralState> {
  final ProfileRepository repositories;
  GeneralCubit(this.repositories) : super(GeneralInitial());

  Future<void> fetchGeneralSetting(BuildContext context) async {
    try {
      final response = await repositories.getGeneralData(postData: {});

      final ctx = navigatorKey.currentContext;
      if (ctx == null) return;

      if (response['status'] == 200) {
        box.put("generalSettings", response);

        GeneralDataModel generalModel = GeneralDataModel.fromJson(response);
        currency = generalModel.data?.metaData?.generalDefaultCurrency ?? "";

        box.put("currency", currency);

        ctx
            .read<FirebaseUpdateIntervalCubit>()
            .update(generalModel.data?.metaData?.firebaseUpdateInterval ?? "");
        ctx.read<BackgroundLocationIntervalCubit>().update(
            generalModel.data?.metaData?.backgroundLocationInterval ?? "");
        ctx
            .read<DriverSearchIntervalCubit>()
            .update(generalModel.data?.metaData?.driverSearchInterval ?? "60");
        ctx
            .read<MinimumNegativeCubit>()
            .update(generalModel.data?.metaData?.minimumNegative ?? "20");

          // ====================== STATIC PAGES ======================
        final staticPagesList = generalModel.data?.metaData?.staticPages ?? [];

        // Save to box
        box.put(
          "staticPages",
          staticPagesList.map((page) => page.toJson()).toList(),
        );

        // Update Cubit
        ctx.read<StaticPagesCubit>().update(staticPagesList);
        box.put("backgroundUpdatedLocation",
            ctx.read<BackgroundLocationIntervalCubit>().state.value);
        box.put("DriverSearchIntervalCubit",
            ctx.read<DriverSearchIntervalCubit>().state.value);
        box.put("firebaseUpdatedLocation",
            ctx.read<FirebaseUpdateIntervalCubit>().state.value);
        updateMapTypeFromMetaData(
          metaData: generalModel.data?.metaData,
          mapTypeCubit: ctx.read<MapTypeCubit>(),
        );

        emit(GeneralSuccess(GeneralDataModel.fromJson(response)));
      } else {
        emit(GeneralFailed(response['error']));
      }
    } catch (e) {
      emit(GeneralFailed("Something went wrong"));
    }
  }
}

abstract class SimpleState<T> extends Equatable {
  final T value;
  const SimpleState(this.value);

  @override
  List<Object?> get props => [value];
}

class SimpleInitial<T> extends SimpleState<T> {
  const SimpleInitial(super.value);
}

class FirebaseUpdateIntervalCubit extends Cubit<SimpleState<String?>> {
  FirebaseUpdateIntervalCubit() : super(const SimpleInitial(null));

  void update(String? val) => emit(SimpleInitial(val));
}

class BackgroundLocationIntervalCubit extends Cubit<SimpleState<String?>> {
  BackgroundLocationIntervalCubit() : super(const SimpleInitial(null));

  void update(String? val) => emit(SimpleInitial(val));
}

class DriverSearchIntervalCubit extends Cubit<SimpleState<String?>> {
  DriverSearchIntervalCubit() : super(const SimpleInitial(null));

  void update(String? val) => emit(SimpleInitial(val));
}

class MinimumNegativeCubit extends Cubit<SimpleState<String?>> {
  MinimumNegativeCubit() : super(const SimpleInitial(null));

  void update(String? val) => emit(SimpleInitial(val));
}
// ============================================================
// NEW: StaticPagesCubit
// ============================================================

class StaticPagesCubit extends Cubit<SimpleState<List<StaticPage>>> {
  StaticPagesCubit() : super(SimpleInitial(_loadFromBox()));

  /// Load from box when cubit is created
  static List<StaticPage> _loadFromBox() {
    try {
      final rawList = box.get("staticPages");
      if (rawList != null && rawList is List) {
        return rawList
            .map((e) => StaticPage.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      }
    } catch (e) {}
    return [];
  }

  void update(List<StaticPage> pages) {
    // Also keep box updated
    box.put("staticPages", pages.map((e) => e.toJson()).toList());
    emit(SimpleInitial(List<StaticPage>.from(pages)));
  }

  /// Helper method if you want to clear
  void clear() {
    box.delete("staticPages");
    emit(const SimpleInitial([]));
  }
}
