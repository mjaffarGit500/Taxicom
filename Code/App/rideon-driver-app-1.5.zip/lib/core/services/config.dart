class Config {
  static const googleKey = "YOUR_GOOGLE_MAPS_KEY";
  static const mapboxToken = "YOUR_MAPBOX_TOKEN";
  static const olaMapKey = "YOUR_OLA_MAPS_KEY";
  
  static const String oneSiginalAppid = "YOUR_ONESIGNAL_APP_ID";
  static const String oneSiginalApiKey = "YOUR_ONESIGNAL_API_KEY";
  static const String riderAppOneSiginalAppid = "YOUR_RIDER_ONESIGNAL_APP_ID";
  static const String riderAppOneSiginalApiKey = "YOUR_RIDER_ONESIGNAL_API_KEY";

  static const String baseDomain = "https://YOUR_DOMAIN.com";
  static const String publishableKey = "YOUR_PUBLISHABLE_KEY";

// Do not change any code below this line. ==================================================
  static const String version = '/api/v1/';
  static const String bearerVersion = '/api/';
  static const String baseUrl = '$baseDomain$version';
  static const String baseUrlForBearer = '$baseDomain$bearerVersion';
  static const String bootstrapToken = 'auth/bootstrap-token';
  static const String registerUser = 'userRegister';
  static const String socialLogin = 'socialLogin';
  static const String sendMobileLoginOtp = 'sendMobileLoginOtp';
  static const String userMobileLogin = 'userMobileLogin';
  static const String editProfile = 'editProfile';
  static const String deleteAccount = 'deleteAccount';
  static const String getAllCategories = 'getAllCategories';
  static const String fcmUpdate = 'fcmUpdate';
  static const String getMakes = 'getMakes';
  static const String addEditVerificationDocuments =
      'addEditVerificationDocuments';
  static const String getVendorWallet = 'getVendorWallet';
  static const String getVendorWalletTransactions =
      'getVendorWalletTransactions';
  static const String getPayoutTransactions = 'getPayoutTransactions';
  static const String getTotalPayoutAmount = 'getTotalPayoutAmount';
  static const String insertPayout = 'insertPayout';
  static const String getVerificationDocuments = 'getVerificationDocuments';
  static const String myItems = 'myItems';
  static const String editItem = 'editItem';
  static const String addEditItemImages = 'addEditItemImages';
  static const String generateToken = 'generateToken';
  static const String verifyResetToken = 'verifyResetToken';
  static const String userEmailLogin = 'userEmailLogin';
  static const String forgotPassword = 'forgotPassword';
  static const String resetPassword = 'resetPassword';
  static const String userLogin = 'userLogin';
  static const String userLogout = 'userLogout';
  static const String otpVerification = 'otpVerification';
  static const String resendOtp = 'ResendOtp';
  static const String resendToken = 'ResendToken';
  static const String resendTokenEmailChange = 'ResendTokenEmailChange';
  static const String checkMobileNumber = 'checkMobileNumber';
  static const String checkEmail = 'checkEmail';
  static const String changeEmail = 'changeEmail';
  static const String confirmBookingByHost = 'confirmBookingByHost';
  static const String uploadProfileImage = 'uploadProfileImage';
  static const String vendorbookingRecord = 'vendorbookingRecord';
  static const String updateBookingStatusByDriver =
      'updateBookingStatusByDriver';
  static const String changeMobileNumber = 'changeMobileNumber';
  static const String updatePaymentStatusByDriver =
      'updatePaymentStatusByDriver';
  static const String giveReviewByHost = 'giveReviewByHost';
  static const String getDriverEarings = 'getDriverEarings';
  static const String getDriverDashboardStats = 'getDriverDashboardStats';
  static const String getgeneralSettings = 'getgeneralSettings';
  static const String staticPage = 'StaticPage';
  static const String getPayoutType = 'get-payout-types';
  static const String getPayoutMethod = 'get-payout-methods';
  static const String addPaymentMethod = 'update-payout-method';
  static const String sos = 'sos';
  static const String paytemInitiate = 'wallet-recharges/paytm/initiate';
  static const String paytemVerify = 'wallet-recharges/paytm/verify';
  static const String phonepeInitiate = 'wallet-recharges/phonepe/initiate';
  static const String phonepeVerify = 'wallet-recharges/phonepe/verify';
  static const String razorpeInitiate = 'wallet-recharges/razorpay/initiate';
  static const String razorpeVerify = 'wallet-recharges/razorpay/verify';
  static const String getPaymentGateways = 'payment-gateways';
}