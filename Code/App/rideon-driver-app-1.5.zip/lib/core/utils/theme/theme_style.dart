import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';

import 'package:provider/provider.dart';
import 'package:ride_on_driver/core/utils/theme/project_color.dart';

//Dimensions //
class Dimensions {
  static double fontSizeExtraSmall = 10;
  static double fontSizeSmall = 12;
  static double fontSizeDefault = 14;
  static double fontSizeLarge = 20;
  static double fontSizeExtraLarge = 18;
  static double fontSizeOverLarge = 25;
  static double fontSizeLargeNew = 22;
  static double fontSizeExtraLargeNew = 25;
  static double fontSizeOverLargeNew = 30;
  static const double paddingSizeExtraSmall = 5.0;
  static const double paddingSizeSmall = 12.0;
  static const double paddingSizeDefault = 15.0;
  static const double paddingSizeLarge = 15.0;
  static const double paddingSizeExtraLarge = 25.0;
  static const double radiusSmall = 5.0;
  static const double radiusDefault = 10.0;
  static const double radiusLarge = 20.0;
  static const double radiusExtraLarge = 30.0;
  static const double webMaxWidth = 1170;
  static const int messageInputLength = 250;
  static double get containerWidth => 1200.0;
  static const double containerWidthAppbar = 1235.0;

  // Redesign tokens — shared spacing/radius/size scale for the
  // auth + driver-setup UI redesign. Reuse these instead of ad-hoc values.
  static const double space4 = 4.0;
  static const double space8 = 8.0;
  static const double space12 = 12.0;
  static const double space16 = 16.0;
  static const double space20 = 20.0;
  static const double space24 = 24.0;
  static const double space32 = 32.0;
  static const double space40 = 40.0;

  static const double radiusField = 16.0;
  static const double radiusCard = 16.0;
  static const double radiusButton = 16.0;
  static const double radiusSheet = 28.0;

  static const double fieldHeight = 58.0;
  static const double compactFieldHeight = 46.0;
  static const double buttonHeight = 52.0;
  static const double otpBoxSize = 48.0;
}

Color appBorderColor = const Color(0xffE5E5E5);
Color appSuccessColor = const Color.fromARGB(255, 19, 121, 56);
Color appErrorColor = const Color(0xffEF4444);
Color appMutedTextColor = const Color(0xff8A8A8A);
Color appDarkTextColor = const Color(0xff171717);
Color appWarmBackground = const Color(0xffFFFDF8);

final appBarNormal = TextStyle(
    fontFamily: 'Poppins Regular',
    fontWeight: FontWeight.w600,
    fontSize: 16,
    color: blackColor);

const smallHeadingMedium = TextStyle(
  fontFamily: 'Poppins Medium',
  fontWeight: FontWeight.w500,
  fontSize: 16,
);

final largeHeadingMedium = TextStyle(
  fontFamily: 'Poppins Medium',
  fontWeight: FontWeight.w700,
  fontSize: 20,
  color: blackColor,
);
final largeHeadingBlack = TextStyle(
  fontFamily: 'Poppins Black',
  fontWeight: FontWeight.w700,
  fontSize: 20,
  color: blackColor,
);

const appRegularText = TextStyle(
  fontFamily: 'Poppins Regular',
  fontWeight: FontWeight.normal,
  fontSize: 14,
);

const appRegularTextBold = TextStyle(
  fontFamily: 'Poppins Bold',
  fontWeight: FontWeight.bold,
  fontSize: 14,
);
const smallHeadingBold = TextStyle(
  fontFamily: 'Poppins Bold',
  fontWeight: FontWeight.bold,
  fontSize: 14,
);
const largeHeadingBold = TextStyle(
  fontFamily: 'Poppins Bold',
  fontWeight: FontWeight.bold,
  fontSize: 20,
);
const appSmallText = TextStyle(
  fontFamily: 'Poppins Medium',
  fontWeight: FontWeight.normal,
  fontSize: 12,
);

TextStyle heading1(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
    fontSize: 24,
    fontFamily: "Poppins Bold",
    color: notifires.getGrey2whiteColor,
  );
}

TextStyle heading2(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
      fontSize: 20,
      fontWeight: FontWeight.bold,
      fontFamily: "Poppins Bold",
      color: notifires.getGrey2whiteColor);
}

TextStyle heading3(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
      fontSize: 16,
      fontWeight: FontWeight.bold,
      fontFamily: "Poppins Bold",
      color: notifires.getGrey2whiteColor);
}

TextStyle regular2(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
      fontSize: 14,
      fontFamily: "Poppins Regular",
      color: notifires.getGrey2whiteColor);
}

TextStyle regular(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
      fontSize: 12,
      fontFamily: "Poppins Regular",
      color: notifires.getGrey2whiteColor);
}

TextStyle regularBlack(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
      fontSize: 14,
      fontFamily: "Poppins Regular",
      color: notifires.getwhiteblackColor);
}

TextStyle regular3(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
      fontSize: 16,
      fontFamily: "Poppins Regular",
      color: notifires.getGrey2whiteColor);
}

TextStyle boldstyle(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
      fontSize: 16,
      fontFamily: "Poppins Bold",
      color: notifires.getGrey2whiteColor);
}

TextStyle heading1Grey1(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
    fontSize: 24,
    fontWeight: FontWeight.bold,
    fontFamily: "Poppins Bold",
    color: notifires.getGrey1whiteColor,
  );
}

TextStyle headingBlackBold(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w300,
    fontFamily: "Poppins SemiBold",
    color: notifires.getwhiteblackColor,
  );
}

TextStyle headingBlack(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
    fontSize: 17,
    fontFamily: "Poppins Medium",
    color: notifires.getwhiteblackColor,
  );
}

TextStyle heading2Grey1(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
    fontSize: 17,
    fontFamily: "Poppins Medium",
    color: notifires.getGrey1whiteColor,
  );
}

TextStyle heading3Grey1(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
      fontSize: 14,
      fontFamily: "Poppins Medium",
      fontWeight: FontWeight.w500,
      color: notifires.getGrey1whiteColor);
}

// ---------------------------------------------------------------------------
// Redesign type scale — used by the Login/Signup/OTP/Driver-Setup redesign.
// Named by role (screenTitle, sectionTitle, ...) rather than size, so callers
// stay consistent even if the underlying values are tuned later.
// ---------------------------------------------------------------------------

TextStyle screenTitle(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
    fontSize: 28,
    fontFamily: "Poppins SemiBold",
    fontWeight: FontWeight.w600,
    color: notifires.getGrey2whiteColor,
    height: 1.2,
  );
}

TextStyle screenSubtitle(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
    fontSize: 15,
    fontFamily: "Poppins Regular",
    color: notifires.getGrey3whiteColor,
    height: 1.35,
  );
}

TextStyle sectionTitleStyle(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
    fontSize: 18,
    fontFamily: "Poppins SemiBold",
    fontWeight: FontWeight.w600,
    color: notifires.getGrey2whiteColor,
  );
}

TextStyle bodyText(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
    fontSize: 15,
    fontFamily: "Poppins Regular",
    color: notifires.getGrey2whiteColor,
  );
}

TextStyle inputTextStyle(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
    fontSize: 16,
    fontFamily: "Poppins Regular",
    color: notifires.getwhiteblackColor,
  );
}

TextStyle inputHintStyle(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
    fontSize: 16,
    fontFamily: "Poppins Regular",
    color: notifires.getGrey3whiteColor,
  );
}

TextStyle inputLabelStyle(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
    fontSize: 13,
    fontFamily: "Poppins Medium",
    fontWeight: FontWeight.w500,
    color: notifires.getGrey3whiteColor,
  );
}

const TextStyle buttonTextStyle = TextStyle(
  fontSize: 16,
  fontFamily: "Poppins SemiBold",
  fontWeight: FontWeight.w600,
);

TextStyle linkTextStyle(BuildContext context) {
  return const TextStyle(
    fontSize: 15,
    fontFamily: "Poppins SemiBold",
    fontWeight: FontWeight.w600,
    color: Color(0xffFFC629),
  );
}

TextStyle captionText(BuildContext context) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
    fontSize: 12,
    fontFamily: "Poppins Regular",
    color: notifires.getGrey3whiteColor,
  );
}

TextStyle errorTextStyle(BuildContext context) {
  return TextStyle(
    fontSize: 12,
    fontFamily: "Poppins Regular",
    color: appErrorColor,
  );
}

TextStyle stepLabelStyle(BuildContext context, {required bool active}) {
  final notifires = Provider.of<ColorNotifires>(context);
  return TextStyle(
    fontSize: 12,
    fontFamily: active ? "Poppins SemiBold" : "Poppins Regular",
    fontWeight: active ? FontWeight.w600 : FontWeight.normal,
    color: active ? notifires.getwhiteblackColor : notifires.getGrey3whiteColor,
  );
}

