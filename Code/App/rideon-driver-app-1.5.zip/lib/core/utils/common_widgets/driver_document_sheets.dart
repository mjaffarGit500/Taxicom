import 'dart:async';
import 'dart:io';
import '../common_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:ride_on_driver/presentation/widgets/primary_button.dart';
import 'package:ride_on_driver/core/utils/theme/project_color.dart';
import 'package:ride_on_driver/core/utils/theme/theme_style.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../presentation/cubits/register_vehicle/make_model_cubit.dart';

class CustomBottomSheetDriver extends StatefulWidget {
  final VoidCallback onTap;
  final String? title;
  final String? description;
  final String? frontImageUrl;
  final String? backImageUrl;

  const CustomBottomSheetDriver({
    super.key,
    required this.onTap,
    this.title,
    this.description,
    this.frontImageUrl,
    this.backImageUrl,
  });

  @override
  State<CustomBottomSheetDriver> createState() =>
      _CustomBottomSheetDriverState();
}

class _CustomBottomSheetDriverState extends State<CustomBottomSheetDriver> {
  XFile? frontImage;
  XFile? backImage;
  final ImagePicker picker = ImagePicker();
  bool isLoading = false;

  Future<void> _pickImage({
    required Function(XFile, String?) onSelect,
    required ImageSource source,
  }) async {
    try {
      setState(() => isLoading = true);
      final picked = await picker.pickImage(source: source);
      if (picked != null && mounted) {
        final base64String = await compressAndUploadImage(picked.path);
        onSelect(picked, base64String);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error selecting photo: $e")),
        );
      }
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  Future<void> showPickerDialog(Function(XFile, String?) onSelect) async {
    await showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: Text("Take a Photo".translate(context)),
              onTap: () {
                Navigator.pop(context);
                _pickImage(onSelect: onSelect, source: ImageSource.camera);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: Text("Choose from Gallery".translate(context)),
              onTap: () {
                Navigator.pop(context);
                _pickImage(onSelect: onSelect, source: ImageSource.gallery);
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      snap: true,
      initialChildSize: 0.85,
      minChildSize: 0.75,
      maxChildSize: 0.95,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: const [
              BoxShadow(color: Colors.black26, blurRadius: 10, spreadRadius: 2),
            ],
          ),
          padding: const EdgeInsets.all(16),
          child: Stack(
            children: [
              ListView(
                controller: scrollController,
                children: [
                  // Header
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              widget.title?.translate(context) ??
                                  "Driving License".translate(context),
                              style: const TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.w600),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              widget.description?.translate(context) ??
                                  "Please upload both front and back images",
                              style: const TextStyle(
                                  fontSize: 14, color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // Front License
                  buildImageSection(
                    label: "Front License".translate(context),
                    file: frontImage,
                    fallbackUrl: widget.frontImageUrl,
                    onSelect: (file, base64) {
                      setState(() => frontImage = file);

                      context
                          .read<DriverLicenseImageCubit>()
                          .updateFrontImage(base64 ?? "");
                    },
                    onDelete: () => setState(() => frontImage = null),
                  ),

                  const SizedBox(height: 20),

                  buildImageSection(
                    label: "Back License".translate(context),
                    file: backImage,
                    fallbackUrl: widget.backImageUrl,
                    onSelect: (file, base64) {
                      setState(() => backImage = file);
                      context
                          .read<DriverLicenseImageCubit>()
                          .updateBackImage(base64 ?? "");
                    },
                    onDelete: () => setState(() => backImage = null),
                  ),

                  const SizedBox(height: 80),
                ],
              ),

              // Bottom Upload Button
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                  color: Colors.white,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          ((frontImage != null || backImage != null) &&
                                  ((frontImage != null ||
                                          (widget.frontImageUrl?.isNotEmpty ??
                                              false)) &&
                                      (backImage != null ||
                                          (widget.backImageUrl?.isNotEmpty ??
                                              false))))
                              ? Colors.black
                              : Colors.grey,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      minimumSize: const Size(double.infinity, 50),
                    ),
                    onPressed: ((frontImage != null || backImage != null) &&
                            ((frontImage != null ||
                                    (widget.frontImageUrl?.isNotEmpty ??
                                        false)) &&
                                (backImage != null ||
                                    (widget.backImageUrl?.isNotEmpty ??
                                        false))) &&
                            !isLoading)
                        ? widget.onTap
                        : null,
                    child: isLoading
                        ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                                color: Colors.white, strokeWidth: 2),
                          )
                        : Text(
                            "Upload".translate(context),
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w600),
                          ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget buildImageSection({
    required String label,
    required XFile? file,
    required String? fallbackUrl,
    required Function(XFile, String?) onSelect,
    required VoidCallback onDelete,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Label + Change button
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label,
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
            if (file != null || (fallbackUrl?.isNotEmpty ?? false))
              InkWell(
                onTap: isLoading ? null : () => showPickerDialog(onSelect),
                child: const Text("Change >",
                    style: TextStyle(color: Colors.blue)),
              ),
          ],
        ),
        const SizedBox(height: 10),

        // Image Container
        GestureDetector(
          onTap: isLoading ? null : () => showPickerDialog(onSelect),
          child: Container(
            height: 180,
            width: double.infinity,
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.grey.shade300),
              image: file != null
                  ? DecorationImage(
                      image: FileImage(File(file.path)), fit: BoxFit.contain)
                  : (fallbackUrl?.isNotEmpty ?? false)
                      ? DecorationImage(
                          image: NetworkImage(fallbackUrl!),
                          fit: BoxFit.contain,
                        )
                      : null,
            ),
            child: Stack(
              children: [
                if (file == null && (fallbackUrl?.isEmpty ?? true))
                  const Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.upload_rounded,
                            size: 40, color: Colors.grey),
                        SizedBox(height: 8),
                        Text("Tap to upload"),
                      ],
                    ),
                  ),
                if (file != null)
                  Align(
                    alignment: Alignment.topRight,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: CircleAvatar(
                        radius: 18,
                        // ignore: deprecated_member_use
                        backgroundColor: Colors.black.withOpacity(0.5),
                        child: IconButton(
                          icon: const Icon(Icons.delete_outline,
                              size: 18, color: Colors.white),
                          onPressed: isLoading ? null : onDelete,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class CustomBottomSheetDocument extends StatefulWidget {
  final VoidCallback onTap;
  final String? title;
  final String frontStatus;
  final String backStatus;
  final String? description;
  final String frontLabel;
  final String backLabel;
  final String? frontImageUrl;
  final String? backImageUrl;
  final Function(String base64, bool isFront) onImageUpdate;

  const CustomBottomSheetDocument({
    super.key,
    required this.onTap,
    required this.frontStatus,
    required this.backStatus,
    this.title,
    this.description,
    required this.frontLabel,
    required this.backLabel,
    this.frontImageUrl,
    this.backImageUrl,
    required this.onImageUpdate, // cubit update callback
  });

  @override
  State<CustomBottomSheetDocument> createState() =>
      _CustomBottomSheetDocumentState();
}

class _CustomBottomSheetDocumentState extends State<CustomBottomSheetDocument> {
  XFile? frontImage;
  XFile? backImage;
  final ImagePicker picker = ImagePicker();
  bool isLoading = false;

  Future<void> _pickImage({
    required Function(XFile, String?) onSelect,
    required ImageSource source,
  }) async {
    try {
      setState(() => isLoading = true);
      final picked = await picker.pickImage(source: source);
      if (picked != null && mounted) {
        final base64String = await compressAndUploadImage(picked.path);
        onSelect(picked, base64String);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error selecting photo: $e")),
        );
      }
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  Future<void> showPickerDialog(Function(XFile, String?) onSelect) async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: whiteColor,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
              top: Radius.circular(Dimensions.radiusSheet))),
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(Dimensions.space20,
              Dimensions.space12, Dimensions.space20, Dimensions.space20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: appBorderColor,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              const SizedBox(height: Dimensions.space20),
              _documentPickerOption(
                icon: Icons.cloud_upload_outlined,
                title: "Upload from files".translate(context),
                subtitle: "PDF, JPG or PNG".translate(context),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(onSelect: onSelect, source: ImageSource.gallery);
                },
              ),
              const SizedBox(height: Dimensions.space12),
              _documentPickerOption(
                icon: Icons.camera_alt_outlined,
                title: "Take a photo".translate(context),
                subtitle: "Use your camera".translate(context),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(onSelect: onSelect, source: ImageSource.camera);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _documentPickerOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(Dimensions.radiusCard),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(Dimensions.space16),
        decoration: BoxDecoration(
          color: whiteColor,
          borderRadius: BorderRadius.circular(Dimensions.radiusCard),
          border: Border.all(color: appBorderColor),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: themeColor.withValues(alpha: 0.14),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: themeColor, size: 20),
            ),
            const SizedBox(width: Dimensions.space12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: bodyText(context)),
                  Text(subtitle, style: captionText(context)),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: notifires.getGrey3whiteColor),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool isReadyToUpload = ((frontImage != null || backImage != null) &&
        ((frontImage != null || (widget.frontImageUrl?.isNotEmpty ?? false)) &&
            (backImage != null || (widget.backImageUrl?.isNotEmpty ?? false))));
    final bool showUploadButton =
        getDocStatus(widget.frontStatus, widget.backStatus) != "approved";

    return DraggableScrollableSheet(
      snap: true,
      initialChildSize: 0.85,
      minChildSize: 0.75,
      maxChildSize: 0.95,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: whiteColor,
            borderRadius: const BorderRadius.vertical(
                top: Radius.circular(Dimensions.radiusSheet)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.12),
                blurRadius: 20,
              ),
            ],
          ),
          child: Stack(
            children: [
              ListView(
                controller: scrollController,
                padding: EdgeInsets.fromLTRB(
                  Dimensions.space20,
                  Dimensions.space12,
                  Dimensions.space20,
                  showUploadButton ? 100 : Dimensions.space20,
                ),
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: appBorderColor,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                  const SizedBox(height: Dimensions.space20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              widget.title?.translate(context) ??
                                  "Document".translate(context),
                              style: sectionTitleStyle(context),
                            ),
                            const SizedBox(height: Dimensions.space4),
                            Text(
                              widget.description?.translate(context) ??
                                  "Please upload both front and back images"
                                      .translate(context),
                              style: captionText(context),
                            ),
                          ],
                        ),
                      ),
                      InkWell(
                        borderRadius: BorderRadius.circular(20),
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: notifires.getBoxColor,
                            shape: BoxShape.circle,
                          ),
                          child: Icon(Icons.close,
                              size: 18, color: notifires.getwhiteblackColor),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: Dimensions.space24),
                  buildImageSection(
                    label: widget.frontLabel,
                    status: widget.frontStatus,
                    file: frontImage,
                    fallbackUrl: widget.frontImageUrl,
                    onSelect: (file, base64) {
                      setState(() => frontImage = file);
                      widget.onImageUpdate(base64 ?? "", true);
                    },
                    onDelete: () => setState(() => frontImage = null),
                  ),
                  const SizedBox(height: Dimensions.space20),
                  buildImageSection(
                    label: widget.backLabel,
                    status: widget.backStatus,
                    file: backImage,
                    fallbackUrl: widget.backImageUrl,
                    onSelect: (file, base64) {
                      setState(() => backImage = file);
                      widget.onImageUpdate(base64 ?? "", false);
                    },
                    onDelete: () => setState(() => backImage = null),
                  ),
                ],
              ),
              if (showUploadButton)
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: Container(
                    padding: EdgeInsets.fromLTRB(
                      Dimensions.space20,
                      Dimensions.space12,
                      Dimensions.space20,
                      Dimensions.space12 +
                          MediaQuery.of(context).padding.bottom,
                    ),
                    decoration: BoxDecoration(
                      color: whiteColor,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.06),
                          blurRadius: 12,
                          offset: const Offset(0, -2),
                        ),
                      ],
                    ),
                    child: PrimaryButton(
                      text: "Upload",
                      isLoading: isLoading,
                      onPressed:
                          (isReadyToUpload && !isLoading) ? widget.onTap : null,
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  Widget buildImageSection({
    required String label,
    required String status, // "approved" | "pending" | "rejected"
    required XFile? file,
    required String? fallbackUrl,
    required Function(XFile, String?) onSelect,
    required VoidCallback onDelete,
  }) {
    bool isApproved = status.toLowerCase() == "approved";
    bool isRejected = status.toLowerCase() == "rejected";
    bool isPending = status.toLowerCase() == "pending";

    IconData statusIcon;
    Color statusColor;
    String statusText;

    if (isApproved) {
      statusIcon = Icons.verified_rounded;
      statusColor = appSuccessColor;
      statusText = "Approved";
    } else if (isRejected) {
      statusIcon = Icons.error_rounded;
      statusColor = appErrorColor;
      statusText = "Rejected";
    } else if (isPending) {
      statusIcon = Icons.hourglass_bottom_rounded;
      statusColor = themeColor;
      statusText = "Pending";
    } else {
      statusIcon = Icons.hourglass_bottom_rounded;
      statusColor = themeColor;
      statusText = "";
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label.translate(context),
                style: sectionTitleStyle(context).copyWith(fontSize: 15)),
            if (!isApproved &&
                (file != null || (fallbackUrl?.isNotEmpty ?? false)))
              GestureDetector(
                onTap: isLoading ? null : () => showPickerDialog(onSelect),
                child: Text("change".translate(context),
                    style: linkTextStyle(context)),
              ),
          ],
        ),
        const SizedBox(height: Dimensions.space8),
        GestureDetector(
          onTap: (isApproved || isLoading)
              ? null
              : () => showPickerDialog(onSelect),
          child: Container(
            height: 180,
            width: double.infinity,
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              color: notifires.getBoxColor,
              borderRadius: BorderRadius.circular(Dimensions.radiusCard),
              border: Border.all(color: appBorderColor),
            ),
            child: Stack(
              children: [
                if (file != null)
                  Positioned.fill(
                    child: Image.file(File(file.path), fit: BoxFit.cover),
                  )
                else if (fallbackUrl?.isNotEmpty ?? false)
                  Positioned.fill(
                    child: myNetworkImage(fallbackUrl!),
                  )
                else
                  Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.cloud_upload_outlined,
                            size: 32, color: themeColor),
                        const SizedBox(height: Dimensions.space8),
                        Text("Tap to upload".translate(context),
                            style: captionText(context)),
                      ],
                    ),
                  ),
                if (!isApproved && file != null)
                  Positioned(
                    top: 8,
                    right: 8,
                    child: InkWell(
                      onTap: isLoading ? null : onDelete,
                      borderRadius: BorderRadius.circular(20),
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: whiteColor,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.15),
                              blurRadius: 4,
                            ),
                          ],
                        ),
                        child: Icon(CupertinoIcons.delete,
                            size: 18, color: appErrorColor),
                      ),
                    ),
                  ),
                if ((file == null && (fallbackUrl?.isNotEmpty ?? false)) &&
                    statusText.isNotEmpty)
                  Positioned(
                    bottom: 8,
                    left: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: statusColor,
                        borderRadius: BorderRadius.circular(50),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(statusIcon, size: 14, color: Colors.white),
                          const SizedBox(width: Dimensions.space4),
                          Text(
                            statusText.translate(context),
                            style: const TextStyle(
                              color: Colors.white,
                              fontFamily: "Poppins SemiBold",
                              fontWeight: FontWeight.w600,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

