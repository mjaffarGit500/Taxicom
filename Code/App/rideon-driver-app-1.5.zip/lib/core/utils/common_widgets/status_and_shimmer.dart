import 'dart:async';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shimmer/shimmer.dart';
import 'package:ride_on_driver/core/utils/theme/project_color.dart';
import 'package:ride_on_driver/core/utils/theme/theme_style.dart';
import '../../extensions/workspace.dart';

class DocumentStatusBottomSheet extends StatelessWidget {
  final String status;

  const DocumentStatusBottomSheet({super.key, required this.status});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 200,
      decoration: BoxDecoration(
          color: notifires.getblackwhiteColor,
          borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(0), topRight: Radius.circular(0))),
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          status == "rejected"
              ? const Icon(
                  Icons.cancel,
                  color: Colors.red,
                  size: 50,
                )
              : const Icon(Icons.access_time,
                  color: Colors.orangeAccent, size: 50),
          const SizedBox(height: 10),
          Flexible(
            child: Text(
              textAlign: TextAlign.center,
              status == "rejected"
                  ? "Oops! Your documents were rejected. Please head to the edit section to update your documents."
                  : "Your documents are still under review. We’ll notify you once the verification is complete.",
              style: heading2Grey1(context).copyWith(fontSize: 16),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

Widget buildShimmerLoader() {
  return ListView.builder(
    padding: const EdgeInsets.all(16),
    itemCount: 6,
    itemBuilder: (_, __) {
      return Shimmer.fromColors(
        baseColor: Colors.grey[300]!,
        highlightColor: Colors.grey[100]!,
        child: Card(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          margin: const EdgeInsets.only(bottom: 12),
          child: ListTile(
            leading: Container(
              width: 30,
              height: 30,
              color: Colors.white,
            ),
            title: Container(
              width: 80,
              height: 14,
              color: Colors.white,
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 100,
                  height: 12,
                  margin: const EdgeInsets.only(top: 4),
                  color: Colors.white,
                ),
                Container(
                  width: 60,
                  height: 12,
                  margin: const EdgeInsets.only(top: 4),
                  color: Colors.white,
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

Future<Uint8List> getBytesFromAsset(String path, int width) async {
  ByteData data = await rootBundle.load(path);
  ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List(),
      targetWidth: width);
  ui.FrameInfo fi = await codec.getNextFrame();
  return (await fi.image.toByteData(format: ui.ImageByteFormat.png))!
      .buffer
      .asUint8List();
}

Widget myNetworkImage(String? image,
    {double height = 150.0, double width = 150.0}) {
  if (image != null && Uri.tryParse(image)?.hasAbsolutePath == true) {
    // Valid URL, proceed with loading
    return SizedBox(
      width: width,
      height: height,
      child: Image.network(
        image,
        fit: BoxFit.cover,
        loadingBuilder: (BuildContext context, Widget child,
            ImageChunkEvent? loadingProgress) {
          if (loadingProgress == null) {
            return child;
          } else {
            return const Padding(
              padding: EdgeInsets.all(8.0),
              child: Center(child: CircularProgressIndicator()),
            );
          }
        },
        errorBuilder: (context, exception, stackTrace) {
          return getErrorImage();
        },
      ),
    );
  } else {
    return getErrorImage();
  }
}

Widget getErrorImage() {
  return Padding(
    padding: const EdgeInsets.all(4),
    child: Image.asset(
      "assets/images/app_icons.png",
      fit: BoxFit.contain,
    ),
  );
}

Color getStatusColor(String status) {
  switch (status) {
    case 'Completed':
      return greentext;
    case 'Cancelled':
      return redColor;
    case 'Declined':
      return redColor;
    default:
      return Colors.black54;
  }
}

Color getStatusBackground(String status) {
  // ignore: deprecated_member_use
  return getStatusColor(status).withOpacity(0.2);
}

Widget buildLocationRow({
  required IconData icon,
  required Color color,
  required Color bgColor,
  required String text,
  required BuildContext context,
}) {
  return Row(
    children: [
      ClipOval(
        child: Container(
          height: 25,
          width: 25,
          color: bgColor,
          child: Icon(icon, color: color, size: 16),
        ),
      ),
      const SizedBox(width: 10),
      Expanded(
        child: Text(
          text,
          style: regular(context).copyWith(color: grey1),
        ),
      ),
    ],
  );
}

void goToWithClear(Widget screen) {
  navigatorKey.currentState!.pushAndRemoveUntil(
    PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) => screen,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(1.0, 0.0);
        const end = Offset.zero;
        const curve = Curves.easeInOut;

        var tween =
            Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
        var offsetAnimation = animation.drive(tween);

        return SlideTransition(
          position: offsetAnimation,
          child: child,
        );
      },
      transitionDuration: const Duration(milliseconds: 400),
    ),
    (route) => false,
  );
}

void goToWithReplacement(Widget screen) {
  navigatorKey.currentState!.pushReplacement(
    PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) => screen,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(1.0, 0.0);
        const end = Offset.zero;
        const curve = Curves.easeIn;

        var tween =
            Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
        var offsetAnimation = animation.drive(tween);

        return SlideTransition(
          position: offsetAnimation,
          child: child,
        );
      },
      transitionDuration: const Duration(milliseconds: 400),
    ),
  );
}

Widget myAssetImage(String? image, {double? height, double? width}) {
  if (image != null && image.isNotEmpty) {
    return SizedBox(
      width: width,
      height: height,
      child: Image.asset(
        image,
        fit: BoxFit.contain,
      ),
    );
  } else {
    return getErrorImage();
  }
}

