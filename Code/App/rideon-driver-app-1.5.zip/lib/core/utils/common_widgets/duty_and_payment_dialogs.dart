import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import 'package:ride_on_driver/core/utils/theme/project_color.dart';
import 'package:ride_on_driver/core/utils/theme/theme_style.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../presentation/cubits/logout_cubit.dart';

Future<void> showDutyConfirmationDialog({
  required BuildContext context,
  required bool goingOnline,
  required VoidCallback onConfirmed,
}) {
  return showDialog(
    context: context,
    barrierDismissible: false,
    builder: (context) {
      return Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        elevation: 0,
        backgroundColor: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset(
                "assets/images/appIcons.png",
                height: 50,
              ),
              const SizedBox(height: 20),
              Text(
                goingOnline
                    ? "Go Online?".translate(context)
                    : "Go Offline?".translate(context),
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: goingOnline ? greentext : redColor,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                goingOnline
                    ? "You are about to go ON DUTY. Riders will now be able to see and book you."
                        .translate(context)
                    : "You are about to go OFF DUTY. You will not receive any more bookings."
                        .translate(context),
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 14, color: Colors.black87),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.grey[300],
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Text(
                        "Cancel".translate(context),
                        style: TextStyle(color: notifires.getGrey1whiteColor),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        onConfirmed();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: goingOnline ? greentext : themeColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Text(
                        "Confirm".translate(context),
                        style: TextStyle(color: blackColor),
                      ),
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      );
    },
  );
}

class PaymentConfirmationDialogs extends StatefulWidget {
  final String? desc;
  final String? firstButtontext;
  final String? secondButtontext;
  final String? text;
  final Function()? onPressed;

  const PaymentConfirmationDialogs({
    super.key,
    this.desc,
    this.firstButtontext,
    this.secondButtontext,
    this.text,
    this.onPressed,
  });

  @override
  PaymentConfirmationDialogsState createState() =>
      PaymentConfirmationDialogsState();
}

class PaymentConfirmationDialogsState
    extends State<PaymentConfirmationDialogs> {
  @override
  Widget build(BuildContext context) {
    return Dialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 50, vertical: 30),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.0),
      ),
      elevation: 10,
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              // ignore: deprecated_member_use
              color: Colors.black.withOpacity(0.08),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: greentext,
              ),
              child: Icon(
                Icons.payments_outlined,
                size: 34,
                color: whiteColor,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              widget.text?.translate(context) ?? "Confirm Payment",
              textAlign: TextAlign.center,
              style: heading3Grey1(context),
            ),
            if (widget.desc != null) ...[
              const SizedBox(height: 6),
              Text(
                widget.desc!,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 13,
                  color: Colors.grey.shade600,
                ),
              ),
            ],
            const SizedBox(height: 18),
            SizedBox(
              height: 40,
              child: Row(
                children: [
                  Expanded(
                    child: InkWell(
                      borderRadius: BorderRadius.circular(10),
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: notifires.getBoxColor,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                              color: notifires.getBoxColor.withOpacity(0.3),
                              width: 1),
                        ),
                        child: Text(
                          "Cancel".translate(context),
                          style: TextStyle(
                            color: notifires.getGrey1whiteColor,
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: InkWell(
                      borderRadius: BorderRadius.circular(10),
                      onTap: widget.onPressed,
                      child: Container(
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: themeColor,
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                              color: themeColor.withValues(alpha: .3),
                              blurRadius: 6,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Text(
                          widget.secondButtontext?.translate(context) ??
                              "Confirm".translate(context),
                          style: heading3Grey1(context),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

Widget commonlyUserlogoAlert() {
  return Center(
    child: ClipOval(
        child: Container(
      width: 50,
      height: 50,
      decoration: BoxDecoration(color: blackColor),
      child: Image.asset('assets/images/appIcons.png', fit: BoxFit.fill),
    )),
  );
}

void loginExpireAlertToExitFromApp({required BuildContext context}) {
  int countdown = 3;
  late Timer timer;

  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (context) {
      return StatefulBuilder(
        builder: (context, setState) {
          timer = Timer.periodic(const Duration(seconds: 1), (t) {
            if (countdown > 1) {
              countdown--;
              setState(() {});
            } else {
              t.cancel();
              Navigator.of(context).pop();
              context.read<LogoutCubit>().logout(context);
            }
          });

          return AlertDialog(
            content: SingleChildScrollView(
              child: ListBody(
                children: <Widget>[
                  commonlyUserlogoAlert(),
                  const SizedBox(height: 5),
                  Text(
                    'Your token is Expired. Please login again.'
                        .translate(context),
                    textAlign: TextAlign.center,
                    style: headingBlack(context).copyWith(color: blackColor),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Redirecting to login in $countdown seconds...'
                        .translate(context),
                    textAlign: TextAlign.center,
                    style: headingBlack(context).copyWith(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Colors.redAccent,
                    ),
                  ),
                ],
              ),
            ),
            actions: const [SizedBox(height: 8)],
          );
        },
      );
    },
  ).then((_) {
    if (timer.isActive) {
      timer.cancel();
    }
  });
}

