import 'dart:async';
import 'dart:io';
import '../common_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:ride_on_driver/presentation/widgets/primary_button.dart';
import 'package:shimmer/shimmer.dart';
import 'package:ride_on_driver/core/utils/theme/project_color.dart';
import 'package:ride_on_driver/core/utils/theme/theme_style.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../presentation/cubits/register_vehicle/make_model_cubit.dart';

class VehicleInformationShimmer extends StatelessWidget {
  const VehicleInformationShimmer({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: notifires.getbgcolor,
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Vehicle Image Card Shimmer
            Shimmer.fromColors(
              baseColor: Colors.grey[300]!,
              highlightColor: Colors.grey[100]!,
              child: Container(
                height: 200,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Stack(
                  children: [
                    // Background shimmer
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    // Overlay content shimmer
                    Positioned(
                      bottom: 20,
                      left: 20,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            height: 24,
                            width: 120,
                            decoration: BoxDecoration(
                              color: Colors.grey[400],
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Container(
                            height: 16,
                            width: 80,
                            decoration: BoxDecoration(
                              color: Colors.grey[400],
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 32),

            // Vehicle Details Title Shimmer
            Shimmer.fromColors(
              baseColor: Colors.grey[300]!,
              highlightColor: Colors.grey[100]!,
              child: Container(
                height: 24,
                width: 140,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),

            const SizedBox(height: 20),

            // Vehicle Details Grid Shimmer
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 2.2,
              children: List.generate(6, (index) => _buildDetailCardShimmer()),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailCardShimmer() {
    return Shimmer.fromColors(
      baseColor: Colors.grey[300]!,
      highlightColor: Colors.grey[100]!,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              // ignore: deprecated_member_use
              color: Colors.grey.withOpacity(0.1),
              spreadRadius: 1,
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            // Icon shimmer
            Container(
              height: 32,
              width: 32,
              decoration: BoxDecoration(
                color: Colors.grey[400],
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            const SizedBox(width: 12),
            // Text content shimmer
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 12,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.grey[400],
                      borderRadius: BorderRadius.circular(6),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    height: 16,
                    width: 80,
                    decoration: BoxDecoration(
                      color: Colors.grey[500],
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

String getDocStatus(String front, String back) {
  if (front == "approved" && back == "approved") {
    return "approved";
  } else if (front == "rejected" || back == "rejected") {
    return "rejected";
  } else if (front == "pending" && back == "pending") {
    return "pending";
  } else {
    return ""; // Default case (ek Approved aur ek Pending)
  }
}

class CustomBottomSheetVechicle extends StatefulWidget {
  final VoidCallback onTap;
  final String? title;
  final String? descrption;
  final String? imageUrl;
  // ignore: non_constant_identifier_names
  final String SourceType;

  const CustomBottomSheetVechicle(
      {super.key,
      required this.onTap,
      // ignore: non_constant_identifier_names
      required this.SourceType,
      this.title,
      this.imageUrl,
      this.descrption});

  @override
  State<CustomBottomSheetVechicle> createState() =>
      _CustomBottomSheetVechicleState();
}

class _CustomBottomSheetVechicleState extends State<CustomBottomSheetVechicle> {
  Future<bool> _requestCameraPermission(BuildContext context) async {
    if (Platform.isIOS) {
      final status = await Permission.camera.request();
      if (status.isDenied || status.isPermanentlyDenied) {
        // ignore: use_build_context_synchronously
        _showPermissionDeniedDialog(context);
        return false;
      }
    }
    return true;
  }

  void _showPermissionDeniedDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Camera Permission Required".translate(context)),
        content: Text(
          "Camera access is needed to take photos. Please enable it in Settings."
              .translate(context),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel".translate(context)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              openAppSettings();
            },
            child: Text("Open Settings".translate(context)),
          ),
        ],
      ),
    );
  }

  Widget _buildPreview({
    required BuildContext context,
    required double previewSize,
    required XFile? localImage,
    required String? existingImageUrl,
    required VoidCallback onDelete,
  }) {
    if (localImage == null) {
      context.read<CheckSelectedCubit>().checkSelectedValue(false);
      if (existingImageUrl.toString().isNotEmpty) {
        return _PreviewCard(
          previewSize: previewSize,
          child: customImageContainer(existingImageUrl ?? "", previewSize),
          onDelete: onDelete,
        );
      }
      return _UploadPlaceholder(previewSize: previewSize);
    }

    context.read<CheckSelectedCubit>().checkSelectedValue(true);
    return _PreviewCard(
      previewSize: previewSize,
      onDelete: onDelete,
      child: Image.file(
        File(localImage.path),
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline, size: 28, color: Colors.red),
                const SizedBox(height: Dimensions.space8),
                Text("Failed to load image".translate(context),
                    style: captionText(context)),
              ],
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.sizeOf(context).height;
    final double previewSize = screenHeight / 5;

    return BlocBuilder<CheckSelectedCubit, bool>(builder: (context, state) {
      return DraggableScrollableSheet(
        snap: false,
        initialChildSize: state == true ? 0.7 : 0.58,
        minChildSize: state == true ? 0.7 : 0.58,
        maxChildSize: state == true ? 0.7 : 0.58,
        builder: (context, scrollController) {
          return Container(
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(Dimensions.radiusSheet),
                topRight: Radius.circular(Dimensions.radiusSheet),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.06),
                  blurRadius: 16,
                  spreadRadius: 0,
                ),
              ],
            ),
            padding: const EdgeInsets.symmetric(horizontal: Dimensions.space20),
            child: ListView(
              controller: scrollController,
              children: [
                const SizedBox(height: Dimensions.space12),
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: appBorderColor,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ),
                const SizedBox(height: Dimensions.space20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: themeColor.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(Icons.upload_file_outlined,
                          color: themeColor, size: 20),
                    ),
                    const SizedBox(width: Dimensions.space12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text(
                            softWrap: true,
                            textAlign: TextAlign.start,
                            widget.title ?? "",
                            style: sectionTitleStyle(context)
                                .copyWith(fontSize: 16),
                          ),
                          const SizedBox(height: Dimensions.space4),
                          Text(
                            textAlign: TextAlign.start,
                            widget.descrption ?? "",
                            style: captionText(context),
                            softWrap: true,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: Dimensions.space8),
                    InkWell(
                      borderRadius: BorderRadius.circular(20),
                      onTap: () {
                        goBack();
                        setState(() {});
                      },
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: notifires.getBoxColor,
                          shape: BoxShape.circle,
                        ),
                        child: Icon(Icons.close,
                            size: 18, color: notifires.getwhiteblackColor),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: Dimensions.space20),
                BlocBuilder<CheckSelectedCubit, bool>(
                    builder: (context, state) {
                  final bool showChange =
                      state == true || widget.imageUrl.toString().isNotEmpty;
                  if (!showChange) return const SizedBox();
                  return Align(
                    alignment: Alignment.centerRight,
                    child: InkWell(
                      onTap: () {
                        selectImageWithSource(ImageSource.gallery,
                            context: context,
                            status: "change",
                            imgSource: widget.SourceType);
                      },
                      child: Padding(
                        padding:
                            const EdgeInsets.only(bottom: Dimensions.space8),
                        child: Text("${"change".translate(context)} ›",
                            style: linkTextStyle(context)),
                      ),
                    ),
                  );
                }),
                Center(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(Dimensions.radiusCard),
                    onTap: () {
                      selectImageWithSource(ImageSource.gallery,
                          context: context,
                          status: "Add",
                          imgSource: widget.SourceType);
                    },
                    child: widget.SourceType == "VehicleImg"
                        ? BlocBuilder<UpdateImage, XFile?>(
                            builder: (context, image) => _buildPreview(
                              context: context,
                              previewSize: previewSize,
                              localImage: image,
                              existingImageUrl: widget.imageUrl,
                              onDelete: () =>
                                  context.read<UpdateImage>().removeImage(),
                            ),
                          )
                        : widget.SourceType == "licence"
                            ? BlocBuilder<UpdateLicenceImage, XFile?>(
                                builder: (context, image) => _buildPreview(
                                  context: context,
                                  previewSize: previewSize,
                                  localImage: image,
                                  existingImageUrl: widget.imageUrl,
                                  onDelete: () => context
                                      .read<UpdateLicenceImage>()
                                      .removeImage(),
                                ),
                              )
                            : BlocBuilder<UpdateDocImage, XFile?>(
                                builder: (context, image) => _buildPreview(
                                  context: context,
                                  previewSize: previewSize,
                                  localImage: image,
                                  existingImageUrl: widget.imageUrl,
                                  onDelete: () => context
                                      .read<UpdateDocImage>()
                                      .removeImage(),
                                ),
                              ),
                  ),
                ),
                const SizedBox(height: Dimensions.space20),
                Row(
                  children: [
                    Expanded(child: Divider(color: appBorderColor)),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: Dimensions.space12),
                      child: Text("or".translate(context),
                          style: captionText(context)),
                    ),
                    Expanded(child: Divider(color: appBorderColor)),
                  ],
                ),
                const SizedBox(height: Dimensions.space20),
                PrimaryButton(
                    icon: Icons.camera_alt_outlined,
                    text: "Open Camera & Take Photo",
                    onPressed: () async {
                      if (await _requestCameraPermission(context)) {
                        // ignore: use_build_context_synchronously
                        selectImageWithSource(ImageSource.camera,
                            context: context,
                            status: "Add",
                            imgSource: widget.SourceType);
                      }
                    }),
                const SizedBox(height: Dimensions.space24),
                BlocBuilder<CheckSelectedCubit, bool>(
                    builder: (context, state) {
                  return state == true
                      ? PrimaryButton(text: "Done", onPressed: widget.onTap)
                      : const SizedBox();
                }),
                const SizedBox(height: Dimensions.space20),
              ],
            ),
          );
        },
      );
    });
  }
}

class _UploadPlaceholder extends StatelessWidget {
  final double previewSize;

  const _UploadPlaceholder({required this.previewSize});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: previewSize,
      width: previewSize + 50,
      decoration: BoxDecoration(
        color: notifires.getBoxColor,
        borderRadius: BorderRadius.circular(Dimensions.radiusCard),
        border: Border.all(color: appBorderColor),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.add_circle_outline, size: 30, color: themeColor),
          const SizedBox(height: Dimensions.space8),
          Text("Select a file".translate(context), style: bodyText(context)),
          const SizedBox(height: Dimensions.space4),
          Text("JPG • PNG • PDF".translate(context),
              style: captionText(context)),
        ],
      ),
    );
  }
}

class _PreviewCard extends StatelessWidget {
  final double previewSize;
  final Widget child;
  final VoidCallback onDelete;

  const _PreviewCard({
    required this.previewSize,
    required this.child,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          height: previewSize,
          width: previewSize + 50,
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(Dimensions.radiusCard),
            border: Border.all(color: appBorderColor),
          ),
          child: child,
        ),
        Positioned(
          right: 8,
          top: 8,
          child: InkWell(
            onTap: onDelete,
            borderRadius: BorderRadius.circular(20),
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: whiteColor,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.15),
                    blurRadius: 4,
                  ),
                ],
              ),
              child:
                  Icon(CupertinoIcons.delete, color: appErrorColor, size: 18),
            ),
          ),
        ),
      ],
    );
  }
}

class CustomBottomSheetVehicleLicense extends StatefulWidget {
  final VoidCallback onTap;
  final String? title;
  final String? description;
  final String? frontImageUrl;
  final String? backImageUrl;
  final String sourceType;

  const CustomBottomSheetVehicleLicense({
    super.key,
    required this.onTap,
    required this.sourceType,
    this.title,
    this.description,
    this.frontImageUrl,
    this.backImageUrl,
  });

  @override
  State<CustomBottomSheetVehicleLicense> createState() =>
      _CustomBottomSheetVehicleLicenseState();
}

class _CustomBottomSheetVehicleLicenseState
    extends State<CustomBottomSheetVehicleLicense> {
  XFile? frontImage;
  XFile? backImage;
  final ImagePicker picker = ImagePicker();
  bool isLoading = false;

  Future<bool> _requestCameraPermission() async {
    if (Platform.isIOS) {
      final status = await Permission.camera.request();
      if (status.isDenied || status.isPermanentlyDenied) {
        _showPermissionDeniedDialog();
        return false;
      }
    }
    return true;
  }

  void _showPermissionDeniedDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Camera Permission Required".translate(context)),
        content: Text(
          "Camera access is needed to take photos. Please enable it in Settings."
              .translate(context),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel".translate(context)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              openAppSettings();
            },
            child: Text("Open Settings".translate(context)),
          ),
        ],
      ),
    );
  }

  Future<void> showPickerDialog(Function(XFile, String?) onSelect) async {
    await showModalBottomSheet(
      backgroundColor: notifires.getbgcolor,
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: Text("Take a Photo".translate(context)),
              onTap: () async {
                Navigator.pop(context);
                if (await _requestCameraPermission()) {
                  try {
                    setState(() => isLoading = true);
                    final picked = await picker.pickImage(
                      source: ImageSource.camera,
                      preferredCameraDevice: CameraDevice.rear,
                    );
                    if (picked != null && mounted) {
                      final base64String =
                          await compressAndUploadImage(picked.path);
                      onSelect(picked, base64String);
                    }
                  } catch (e) {
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                            content: Text(
                                "${"Error taking photo".translate(context)}: $e")),
                      );
                    }
                  } finally {
                    if (mounted) setState(() => isLoading = false);
                  }
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: Text("Choose from Gallery".translate(context)),
              onTap: () async {
                Navigator.pop(context);
                try {
                  setState(() => isLoading = true);
                  final picked =
                      await picker.pickImage(source: ImageSource.gallery);
                  if (picked != null && mounted) {
                    final base64String =
                        await compressAndUploadImage(picked.path);
                    onSelect(picked, base64String);
                  }
                } catch (e) {
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Error selecting photo: $e')),
                    );
                  }
                } finally {
                  if (mounted) setState(() => isLoading = false);
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<LicenseSelectionCubit, LicenseImageState>(
      builder: (context, state) {
        return DraggableScrollableSheet(
          snap: true,
          initialChildSize: 0.85,
          minChildSize: 0.75,
          maxChildSize: 0.95,
          builder: (context, scrollController) {
            return Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: const [
                  BoxShadow(
                      color: Colors.black26, blurRadius: 10, spreadRadius: 2),
                ],
              ),
              padding: const EdgeInsets.all(16),
              child: Stack(
                children: [
                  ListView(
                    controller: scrollController,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  widget.title?.translate(context) ??
                                      "Vehicle License".translate(context),
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  widget.description?.translate(context) ??
                                      "Please upload both front and back images",
                                  style: const TextStyle(
                                      fontSize: 14, color: Colors.grey),
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.close),
                            onPressed: () => Navigator.pop(context),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      BlocBuilder<UpdateLicenceImage, XFile?>(
                          builder: (context, image) {
                        return buildImageSection(
                          label: "Front License".translate(context),
                          file: image ?? frontImage,
                          fallbackUrl: widget.frontImageUrl,
                          onSelect: (file, base64) async {
                            setState(() => frontImage = file);
                            if (base64 != null) {
                              context
                                  .read<LicenseSelectionCubit>()
                                  .setFrontImage(file, base64);
                              context
                                  .read<UpdateLicenceImage>()
                                  .updateImage(file);
                              context
                                  .read<VehicleFormCubit>()
                                  .updateVehicleLicenceBase64Img(
                                      base64.toString());
                            }
                            context
                                .read<LicenseSelectionCubit>()
                                .setFrontSelected(true);
                          },
                          onDelete: () {
                            setState(() => frontImage = null);
                            context
                                .read<LicenseSelectionCubit>()
                                .setFrontImage(null, null);
                            context
                                .read<LicenseSelectionCubit>()
                                .setFrontSelected(false);
                            context.read<UpdateLicenceImage>().removeImage();
                            context
                                .read<VehicleFormCubit>()
                                .removeVehicleLicenceBase64Img();
                          },
                        );
                      }),
                      const SizedBox(height: 20),
                      BlocBuilder<UpdateLicenceImage2, XFile?>(
                          builder: (context, image) {
                        return buildImageSection(
                          label: "Back License".translate(context),
                          file: image ?? backImage,
                          fallbackUrl: widget.backImageUrl,
                          onSelect: (file, base64) async {
                            setState(() => backImage = file);
                            if (base64 != null) {
                              context
                                  .read<LicenseSelectionCubit>()
                                  .setBackImage(file, base64);
                              context
                                  .read<UpdateLicenceImage2>()
                                  .updateImage(file);
                              context
                                  .read<VehicleFormCubit>()
                                  .updateVehicleLicenceBase64Img2(
                                      base64.toString());
                            }
                            context
                                .read<LicenseSelectionCubit>()
                                .setBackSelected(true);
                          },
                          onDelete: () {
                            setState(() => backImage = null);
                            context
                                .read<LicenseSelectionCubit>()
                                .setBackImage(null, null);
                            context
                                .read<LicenseSelectionCubit>()
                                .setBackSelected(false);
                            context.read<UpdateLicenceImage2>().removeImage();
                            context
                                .read<VehicleFormCubit>()
                                .removeVehicleLicenceBase64Img2();
                          },
                        );
                      }),
                      const SizedBox(height: 80),
                    ],
                  ),
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          vertical: 16, horizontal: 16),
                      color: Colors.white,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor:
                              state.frontSelected && state.backSelected
                                  ? Colors.black
                                  : Colors.grey,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          minimumSize: const Size(double.infinity, 50),
                        ),
                        onPressed: state.frontSelected &&
                                state.backSelected &&
                                !isLoading
                            ? widget.onTap
                            : null,
                        child: isLoading
                            ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2,
                                ),
                              )
                            : Text(
                                "Upload License".translate(context),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget buildImageSection({
    required String label,
    required XFile? file,
    required String? fallbackUrl,
    required Function(XFile, String?) onSelect,
    required VoidCallback onDelete,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 16,
              ),
            ),
            if (file != null || (fallbackUrl != null && fallbackUrl.isNotEmpty))
              InkWell(
                onTap: isLoading ? null : () => showPickerDialog(onSelect),
                child: Text(
                  "${"Change".translate(context)} >",
                  style: regular2(context),
                ),
              ),
          ],
        ),
        const SizedBox(height: 10),
        GestureDetector(
          onTap: isLoading ? null : () => showPickerDialog(onSelect),
          child: Container(
            height: 180,
            width: double.infinity,
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.grey.shade300),
              image: file != null
                  ? DecorationImage(
                      image: FileImage(File(file.path)), fit: BoxFit.contain)
                  : fallbackUrl != null && fallbackUrl.isNotEmpty
                      ? DecorationImage(
                          image: NetworkImage(fallbackUrl), fit: BoxFit.contain)
                      : null,
            ),
            child: Stack(
              children: [
                if (file == null &&
                    (fallbackUrl == null || fallbackUrl.isEmpty))
                  Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.upload_rounded,
                            size: 40, color: Colors.grey),
                        const SizedBox(height: 8),
                        Text("Tap to upload".translate(context),
                            style: regular(context)),
                      ],
                    ),
                  ),
                if (file != null)
                  Align(
                    alignment: Alignment.topRight,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: CircleAvatar(
                        radius: 18,
                        backgroundColor: Colors.black.withValues(alpha: 0.5),
                        child: IconButton(
                          icon: const Icon(Icons.delete_outline,
                              size: 18, color: Colors.white),
                          onPressed: isLoading ? null : onDelete,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

