import 'dart:io';
import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:ride_on_driver/core/extensions/workspace.dart';
import 'package:ride_on_driver/core/utils/theme/project_color.dart';
import 'package:ride_on_driver/core/utils/theme/theme_style.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import 'package:ride_on_driver/presentation/cubits/logout_cubit.dart';
import 'package:ride_on_driver/presentation/screens/auth/login_screen.dart';
import '../../../presentation/cubits/account/delete_account_cubit.dart';
 
class DeleteConfirmationDialogs extends StatelessWidget {
  final String? desc;
  final String? firstButtontext;
  final String? secondButtontext;

  const DeleteConfirmationDialogs({
    super.key,
    this.desc,
    this.firstButtontext,
    this.secondButtontext,
  });


  @override
  Widget build(BuildContext context) {
    return BlocListener<DeleteAccountCubit, DeleteAccountState>(
      listener: (context, state) {
        if (state is DeleteAccountLoading) {
          Widgets.showLoader(context); // Your custom loader
        } else {
          Widgets.hideLoder(context);
          if (state is DeleteAccountSuccess) {
            showToastMessage(state.message);
            Navigator.pop(context);
            logout(navigatorKey.currentContext!);
          
          } else if (state is DeleteAccountFailed) {
            showToastMessage(state.error);
          }
        }
      },
      child: Dialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        backgroundColor: Colors.transparent,
        elevation: 6,
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: notifires.getboxcolor,
            borderRadius: BorderRadius.circular(20.0),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.15),
                blurRadius: 20,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.warning_amber_rounded, size: 80, color: themeColor),
              const SizedBox(height: 16),
              Text(
                "Are you sure you want to delete your account?"
                    .translate(context),
                textAlign: TextAlign.center,
                style: regular(context).copyWith(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: notifires.getGrey2whiteColor,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                "This action is permanent and cannot be undone."
                    .translate(context),
                textAlign: TextAlign.center,
                style: regular(context).copyWith(
                  fontSize: 14,
                  color: notifires.getGrey2whiteColor.withOpacity(0.7),
                ),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: notifires.getBoxColor,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                          side: BorderSide(
                            color:
                                notifires.getGrey2whiteColor.withOpacity(0.4),
                          ),
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        child: Text(
                          "Cancel".translate(context),
                          style: heading3Grey1(context),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        context
                            .read<DeleteAccountCubit>()
                            .deleteAccount(context);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: themeColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        child: Text(
                          "Yes, Delete".translate(context),
                          style: heading3Grey1(context).copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}

buildShowDialog(BuildContext context) {
  return showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: blackColor.withValues(alpha: 0.3),
      builder: (BuildContext context) {
        return Center(
            child:
                CircularProgressIndicator(color: yelloColor, strokeWidth: 3));
      });
}

class Widgets {
  static bool isLoadingShowing = false;

  static void showLoader(BuildContext context) async {
    if (isLoadingShowing) {
      return;
    }
    isLoadingShowing = true;
    showDialog(
        context: context,
        barrierDismissible: false,
        useSafeArea: true,
        builder: (BuildContext context) {
          return AnnotatedRegion(
            value: SystemUiOverlayStyle(
              statusBarColor: Colors.black.withValues(alpha: 0.2),
            ),
            child: SafeArea(
              child: PopScope(
                canPop: false,
                onPopInvokedWithResult: (didPop, result) {
                  return;
                },
                child: Center(
                    child: CircularProgressIndicator(
                  color: yelloColor2,
                )),
              ),
            ),
          );
        });
  }

  static void hideLoder(BuildContext context) {
    if (isLoadingShowing) {
      isLoadingShowing = false;
      Navigator.of(context).pop();
    }
  }
}

// ignore: prefer_typing_uninitialized_variables
var closeLoading;
showLoading() {
  closeLoading = BotToast.showLoading();
}

showErrorToastMessage(String message) {
  late CancelFunc closeToast;
  closeToast = BotToast.showCustomText(
    duration: const Duration(milliseconds: 1800),
    align: Alignment.bottomCenter.add(const Alignment(0, -0.12)),
    toastBuilder: (context) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 15),
        child: CustomToastMessages(
          message: message.toString(),
          error: true,
          onClose: closeToast,
        ),
      );
    },
  );
}
  logout(BuildContext context) async {
  await clearData(context,true);
  Navigator.pushAndRemoveUntil(
    navigatorKey.currentContext!,
    MaterialPageRoute(builder: (context) => const LoginScreen()),
    (Route<dynamic> route) => false,
  );
}

showToastMessage(String message) {
  late CancelFunc closeToast;
  closeToast = BotToast.showCustomText(
    align: Alignment.bottomCenter.add(const Alignment(0, -0.12)),
    toastBuilder: (_) => Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: CustomToastMessages(
        message: message,
        error: false,
        onClose: closeToast,
      ),
    ),
    duration: const Duration(milliseconds: 1800),
  );
}

class CustomToastMessages extends StatefulWidget {
  final String message;
  final bool? error;
  final VoidCallback? onClose;

  const CustomToastMessages({
    super.key,
    required this.message,
    this.error,
    this.onClose,
  });

  @override
  _CustomToastMessagesState createState() => _CustomToastMessagesState();
}

class _CustomToastMessagesState extends State<CustomToastMessages> {
  @override
  Widget build(BuildContext context) {
    final bool isError = widget.error ?? false;
    final Color accent = isError ? redColor : greentext;
    final Color surface = notifires.getcardcolor;
    final Color textColor = notifires.getGrey1whiteColor;

    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0.96, end: 1.0),
      duration: const Duration(milliseconds: 280),
      curve: Curves.easeOutCubic,
      builder: (context, scale, child) {
        return Transform.scale(scale: scale, child: child);
      },
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 350),
        child: Material(
          color: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
            decoration: BoxDecoration(
              color: surface,
              borderRadius: BorderRadius.circular(13),
              border: Border.all(
                color: accent.withOpacity(0.18),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.08),
                  blurRadius: 10,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Subtle accent indicator
                Container(
                  width: 3,
                  height: 28,
                  margin: const EdgeInsets.only(right: 8),
                  decoration: BoxDecoration(
                    color: accent,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Container(
                  width: 30,
                  height: 30,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: accent.withOpacity(0.12),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    isError ? Icons.error_outline_rounded : Icons.check_rounded,
                    size: 17,
                    color: accent,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    widget.message.translate(context),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600,
                      color: textColor,
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: widget.onClose,
                  child: Container(
                    width: 28,
                    height: 28,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: accent.withOpacity(0.10),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.close_rounded,
                      color: accent,
                      size: 16,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class CustomBottomSheet extends StatelessWidget {
  final VoidCallback? onClose;

  const CustomBottomSheet({
    super.key,
    this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
          horizontal: Dimensions.space20, vertical: Dimensions.space20),
      child: SizedBox(
          height: 280,
          width: double.infinity,
          child: Container(
              decoration: BoxDecoration(color: notifires.getbgcolor),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: Dimensions.space40),
                  Container(
                    width: 72,
                    height: 72,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: appSuccessColor.withValues(alpha: 0.12),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(Icons.check_circle_rounded,
                        color: appSuccessColor, size: 40),
                  ),
                  const SizedBox(height: Dimensions.space20),
                  Text(
                    "Uploaded successfully".translate(context),
                    style: sectionTitleStyle(context).copyWith(fontSize: 20),
                  ),
                  const SizedBox(height: Dimensions.space12),
                  Text(
                    textAlign: TextAlign.center,
                    "Upload successfull Your document has \nbeen received"
                        .translate(context),
                    style: captionText(context),
                  )
                ],
              ))),
    );
  }
}

void showDynamicBottomSheets(BuildContext context,
    {required String title,
    required String description,
    required String firstButtontxt,
    required String secondButtontxt,
    required final VoidCallback onpressed,
    required final VoidCallback onpressed1}) {
  showModalBottomSheet(
    isScrollControlled: false,
    constraints:
        const BoxConstraints.expand(width: double.infinity, height: 240),
    context: context,
    builder: (context) {
      return DynamicBottomSheetContent(
        title: title,
        description: description,
        firstButtontxt: firstButtontxt,
        secondButtontxt: secondButtontxt,
        onpressed: onpressed,
        onpressed1: onpressed1,
      );
    },
  );
}

class DynamicBottomSheetContent extends StatefulWidget {
  final String title;
  final String description;
  final String firstButtontxt;
  final String secondButtontxt;
  final VoidCallback onpressed;
  final VoidCallback onpressed1;

  const DynamicBottomSheetContent(
      {super.key,
      required this.title,
      required this.description,
      required this.firstButtontxt,
      required this.secondButtontxt,
      required this.onpressed,
      required this.onpressed1});

  @override
  State<DynamicBottomSheetContent> createState() =>
      _DynamicBottomSheetContentState();
}

class _DynamicBottomSheetContentState extends State<DynamicBottomSheetContent> {
  bool isCancelSelected = true; // Initially, the "Cancel" button is selected
  bool isDeleteSelected = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      // height:100,
      decoration: BoxDecoration(
          color: notifires.getblackwhiteColor,
          borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(0), topRight: Radius.circular(0))),
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Flexible(
              child: Text(widget.title.translate(context),
                  style: heading2Grey1(context).copyWith())),
          const SizedBox(height: 20),
          Divider(
            height: 1,
            color: notifires.getGrey3whiteColor,
          ),
          const SizedBox(height: 15),
          Flexible(
              child: Text(widget.description.translate(context),
                  style: heading3Grey1(context))),
          const SizedBox(height: 30),
          Expanded(
            child: SizedBox(
              width: double.infinity,
              // height: 20,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Flexible(
                    child: ConstrainedBox(
                      constraints: BoxConstraints.expand(
                          height: 60,
                          width: MediaQuery.of(context).size.width * 0.38),
                      child: ElevatedButton(
                        onPressed: widget.onpressed,
                        style: ElevatedButton.styleFrom(
                          elevation: 0,
                          backgroundColor: notifires.getBoxColor,
                          shape: RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.circular(Dimensions.radiusLarge),
                          ),
                        ),
                        child: Text(widget.firstButtontxt.translate(context),
                            style: heading3(context)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 25),
                  Flexible(
                    child: ConstrainedBox(
                      constraints: BoxConstraints.expand(
                          height: 60,
                          width: MediaQuery.of(context).size.width * 0.38),
                      child: ElevatedButton(
                        onPressed: widget.onpressed1,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: themeColor,
                          shape: RoundedRectangleBorder(
                            side: BorderSide(width: 1.0, color: themeColor),
                            borderRadius:
                                BorderRadius.circular(Dimensions.radiusLarge),
                          ),
                        ),
                        child: Text(widget.secondButtontxt.translate(context),
                            style: heading3(context)
                                .copyWith(color: Colors.white)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}

void showOpenAppSettingsDialog(BuildContext context, String message) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Platform.isIOS
          ? CupertinoAlertDialog(
              title: const Text("Permission Required"),
              content: Text(
                message,
              ),
              actions: <Widget>[
                CupertinoDialogAction(
                  child: const Text("Cancel"),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
                CupertinoDialogAction(
                  child: const Text(
                    "Open Settings",
                    // style: regular2(context).copyWith()
                  ),
                  onPressed: () {
                    openAppSettings();
                    Navigator.of(context).pop();
                  },
                ),
              ],
            )
          : AlertDialog(
              backgroundColor: notifires.getbgcolor,
              title: Text(
                "Permission Required",
                style: heading3Grey1(context).copyWith(
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              content: Text(
                message,
                style: regular2(context).copyWith(),
              ),
              actions: <Widget>[
                TextButton(
                  child: Text(
                    "Cancel",
                    style: heading3Grey1(context).copyWith(
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
                TextButton(
                  child: Text(
                    "Open Settings",
                    style: heading3Grey1(context).copyWith(
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  onPressed: () {
                    openAppSettings();
                    Navigator.of(context).pop();
                  },
                ),
              ],
            );
    },
  );
}

dialogExit(BuildContext context) {
  return showDialog<void>(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        backgroundColor: notifires.getboxcolor,
        content: SingleChildScrollView(
          child: ListBody(
            children: <Widget>[
              Icon(
                Icons.error,
                size: 75,
                color: redColor,
              ),
              Text(
                "Do you want to exit?".translate(context),
                textAlign: TextAlign.center,
                style: headingBlack(context)
                    .copyWith(color: notifires.getwhiteblackColor),
              )
            ],
          ),
        ),
        actions: <Widget>[
          Column(
            children: [
              Row(
                children: [
                  Expanded(
                      child: InkWell(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: Container(
                              margin: const EdgeInsets.only(left: 8, right: 8),
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                  border: Border.all(color: grey5),
                                  color: grey4,
                                  borderRadius: BorderRadius.circular(10)),
                              child: Center(
                                  child: Text(
                                "Cancel".translate(context),
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold),
                              ))))),
                  Expanded(
                      child: InkWell(
                          onTap: () {
                            Navigator.pop(context);

                            SystemNavigator.pop();
                          },
                          child: Container(
                              margin: const EdgeInsets.only(left: 8, right: 8),
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                  border: Border.all(color: blackColor),
                                  color: blackColor,
                                  borderRadius: BorderRadius.circular(10)),
                              child: Center(
                                  child: Text(
                                "Exit".translate(context),
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold),
                              ))))),
                ],
              ),
              const SizedBox(
                height: 8,
              )
            ],
          )
        ],
      );
    },
  );
}
