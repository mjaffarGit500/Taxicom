import 'package:animated_toggle_switch/animated_toggle_switch.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ride_on_driver/core/utils/theme/project_color.dart';
import 'package:ride_on_driver/core/utils/theme/theme_style.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../extensions/workspace.dart';

Widget commonlyUserLogo() {
  return Image.asset(
    appLogo,
    height: 110,
  );
}

class CustomsButtons extends StatelessWidget {
  final String text;
  final Color? textColor;
  final Color backgroundColor;
  final Icon? icon;
  final VoidCallback onPressed;
  final double? width;
  final double? height;
  final Color? borderColor;
  final bool? alignment;
  final double? fontSize;

  const CustomsButtons(
      {super.key,
      this.alignment,
      this.fontSize,
      required this.text,
      this.borderColor,
      this.width,
      this.height,
      required this.backgroundColor,
      required this.onPressed,
      this.icon,
      this.textColor});

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: BoxConstraints.expand(
          width: width ?? double.infinity, height: height ?? 50.0),
      child: ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
              padding:
                  const EdgeInsets.only(left: 5, right: 5, top: 10, bottom: 10),
              backgroundColor: backgroundColor,
              elevation: 0,
              shape: RoundedRectangleBorder(
                  side: BorderSide(
                      color: borderColor ?? Colors.transparent, width: 1),
                  borderRadius: BorderRadius.circular(8))),
          child: Row(
            mainAxisAlignment: alignment == true
                ? MainAxisAlignment.start
                : MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              if (icon != null) const SizedBox(width: 10),
              if (icon != null) icon!,
              const SizedBox(width: 10),
              Text(
                text.translate(context),
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
                style: headingBlackBold(context).copyWith(
                    color: textColor,
                    fontSize: fontSize ?? 14,
                    fontWeight: FontWeight.w400),
              ),
            ],
          )),
    );
  }
}

class CustomAppBars extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final Color backgroundColor;
  final Color? iconColor;
  final Color titleColor;
  final VoidCallback? onBackButtonPressed;
  final List<Widget>? actions;
  final double elevation;
  final bool? centerTitle;

  const CustomAppBars(
      {super.key,
      required this.title,
      required this.backgroundColor,
      this.iconColor,
      required this.titleColor,
      this.onBackButtonPressed,
      this.actions,
      this.elevation = 0.0,
      this.centerTitle});

  @override
  Widget build(BuildContext context) {
    notifires = Provider.of<ColorNotifires>(context, listen: true);
    return AppBar(
      centerTitle: true,
      backgroundColor: backgroundColor,
      surfaceTintColor: backgroundColor,
      elevation: elevation,
      leadingWidth: 85,
      leading: GestureDetector(
        onTap: onBackButtonPressed ??
            () {
              Navigator.pop(context);
            },
        child: Padding(
          padding:
              const EdgeInsets.only(left: 20, top: 8, bottom: 8, right: 20),
          child: PhysicalModel(
            color: Colors.transparent,
            shadowColor: Colors.transparent,
            elevation: 1.0,
            borderRadius: BorderRadius.circular(8),
            child: Container(
              alignment: Alignment.center,
              height: 40,
              width: 40,
              decoration: BoxDecoration(
                  color: notifires.getblackwhiteColor,
                  borderRadius: BorderRadius.circular(30)),
              child: Icon(Icons.arrow_back_ios_new,
                  color: notifires.getGrey3whiteColor),
            ),
          ),
        ),
      ),
      title: Text(title.translate(context),
          style: heading2Grey1(context).copyWith(color: titleColor)),
      actions: actions,
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}


void goTo(Widget screen) {
  navigatorKey.currentState!.push(
    PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) => screen,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        return FadeTransition(
          opacity: animation,
          child: child,
        );
      },
    ),
  );
}

void goBack() {
  navigatorKey.currentState!.pop();
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final VoidCallback? onBackTap;
  final List<Widget>? actions;
  final bool? isCenterTitle;
  final bool? isBackButton;
  final Color? backgroundColor;
  final Color? titleColor;
  final double? fontSize;
  const CustomAppBar({
    super.key,
    required this.title,
    this.titleColor,
    this.onBackTap,
    this.fontSize,
    this.backgroundColor,
    this.isCenterTitle,
    this.isBackButton,
    this.actions,
  });

  @override
  Widget build(BuildContext context) {
    return AppBar(
      elevation: 0,
      surfaceTintColor: Colors.white,
      backgroundColor: Colors.white,
      centerTitle: isCenterTitle ?? true,
      leadingWidth: 70,
      title: Text(title.translate(context),
          style: headingBlack(context).copyWith(
              fontSize: fontSize ?? 18, color: titleColor ?? blackColor)),
      leading: isBackButton == true
          ? const SizedBox()
          : Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Transform.translate(
                offset: const Offset(0, 0),
                child: InkWell(
                  onTap: onBackTap ?? () => Navigator.of(context).pop(),
                  child: Container(
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: backgroundColor ?? notifires.getbgcolor,
                          border:
                              Border.all(color: notifires.getGrey3whiteColor)),
                      child: Transform.translate(
                        offset: const Offset(0, 0),
                        child: Icon(Icons.arrow_back,
                            size: 20, color: notifires.getwhiteblackColor),
                      )),
                ),
              ),
            ),
      actions: actions ?? [],
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(56);
}

class CustomToggleSwitch extends StatelessWidget {
  final bool current;
  final Function(bool) onChanged;

  const CustomToggleSwitch({
    super.key,
    required this.current,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedToggleSwitch<bool>.dual(
      current: current,
      first: false,
      second: true,
      textMargin: const EdgeInsets.all(0),
      height: 50,
      style: ToggleStyle(
        indicatorColor: Colors.white,
        backgroundColor: Colors.white,
        borderColor: current ? greentext : redColor,
        boxShadow: [
          const BoxShadow(
            color: Colors.black12,
            blurRadius: 8,
            spreadRadius: 2,
            offset: Offset(0, 4),
          ),
        ],
      ),
      borderWidth: 2.0,
      onChanged: onChanged,
      iconBuilder: (value) => value
          ? Icon(Icons.check_circle, color: greentext, size: 24)
          : Icon(Icons.donut_large, color: redColor, size: 24),
      textBuilder: (value) => value
          ? Transform.translate(
              offset: Offset(
                  Localizations.localeOf(context).languageCode == 'ar'
                      ? -10
                      : 10,
                  0),
              child: Text(
                "ON DUTY".translate(context),
                style: headingBlackBold(context)
                    .copyWith(color: greentext, fontSize: 14),
              ),
            )
          : Transform.translate(
              offset: Offset(
                  Localizations.localeOf(context).languageCode == 'ar'
                      ? 10
                      : -10,
                  0),
              child: Text(
                "OFF DUTY".translate(context),
                style: headingBlackBold(context)
                    .copyWith(color: redColor, fontSize: 14),
              ),
            ),
    );
  }
}

class CustomSlideButton extends StatefulWidget {
  final bool isOnRide;
  final Function(bool) onChanged;
  final String acceptedText;
  final String defaultText;
  final Color activeColor;
  final Color inactiveColor;
  final Color iconColor;
  final Duration animationDuration;
  final double knobWidth;
  final Color? iconBoxColor;
  final Color? textInactiveColor;
  final Color? textActiveColor;

  const CustomSlideButton({
    super.key,
    required this.isOnRide,
    required this.onChanged,
    this.iconBoxColor,
    this.textActiveColor,
    this.textInactiveColor,
    this.acceptedText = "ACCEPTED",
    this.defaultText = "ACCEPT RIDE",
    this.activeColor = Colors.red,
    this.inactiveColor = Colors.grey,
    this.iconColor = Colors.black,
    this.animationDuration = const Duration(milliseconds: 300),
    this.knobWidth = 60,
  });

  @override
  State<CustomSlideButton> createState() => _CustomSlideButtonState();
}

String toTitleCaseFromCamel(String text) {
  if (text.isEmpty) return text;
  final buffer = StringBuffer();
  for (int i = 0; i < text.length; i++) {
    var char = text[i];
    if (i == 0) {
      buffer.write(char.toUpperCase());
    } else if (char.toUpperCase() == char && char != ' ') {
      buffer.write(' $char');
    } else {
      buffer.write(char);
    }
  }
  return buffer.toString();
}

class _CustomSlideButtonState extends State<CustomSlideButton>
    with SingleTickerProviderStateMixin {
  double _dragPosition = 0.0;
  late double _maxDrag;
  late AnimationController _controller;
  bool _isDragging = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: widget.animationDuration,
      value: widget.isOnRide ? 1.0 : 0.0,
    );
  }

  @override
  void didUpdateWidget(CustomSlideButton oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!_isDragging && widget.isOnRide != oldWidget.isOnRide) {
      _controller.animateTo(
        widget.isOnRide ? 1.0 : 0.0,
        curve: Curves.easeInOut,
      );
    }
  }

  void _onDragStart(DragStartDetails details) {
    _isDragging = true;
  }

  void _onDragUpdate(DragUpdateDetails details) {
    setState(() {
      _dragPosition += details.delta.dx;
      _dragPosition = _dragPosition.clamp(0, _maxDrag);
      _controller.value = _dragPosition / _maxDrag;
    });
  }

  void _onDragEnd(DragEndDetails details) {
    _isDragging = false;
    final shouldAccept = _controller.value > 0.6;
    _controller.animateTo(shouldAccept ? 1.0 : 0.0, curve: Curves.easeOut);
    if (shouldAccept != widget.isOnRide) {
      widget.onChanged(shouldAccept);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (_, constraints) {
        final totalWidth = constraints.maxWidth;
        _maxDrag = totalWidth - widget.knobWidth;
        final knobLeft = _controller.value * _maxDrag;

        return Container(
          height: 56,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            color: widget.isOnRide ? widget.activeColor : widget.inactiveColor,
          ),
          child: Stack(
            children: [
              // Centered Text
              Center(
                child: Text(
                  widget.isOnRide
                      ? widget.acceptedText.toString().translate(context)
                      : widget.defaultText.toString().translate(context),
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: widget.isOnRide
                        ? widget.textActiveColor ?? Colors.white
                        : widget.textInactiveColor ?? Colors.white,
                  ),
                ),
              ),

              // Sliding knob
              Positioned(
                left: knobLeft,
                child: GestureDetector(
                  onHorizontalDragStart: _onDragStart,
                  onHorizontalDragUpdate: _onDragUpdate,
                  onHorizontalDragEnd: _onDragEnd,
                  child: Container(
                    width: widget.knobWidth,
                    height: 56,
                    decoration: BoxDecoration(
                      color: widget.iconBoxColor ??
                          Colors.white.withValues(alpha: 0.2),
                      borderRadius: const BorderRadius.horizontal(
                        left: Radius.circular(14),
                        right: Radius.circular(14),
                      ),
                    ),
                    alignment: Alignment.center,
                    child: Icon(
                      widget.isOnRide
                          ? Icons.check
                          : Localizations.localeOf(context).languageCode == 'ar'
                              ? Icons.arrow_back_ios_rounded
                              : Icons.arrow_forward_ios_rounded,
                      color: widget.iconColor,
                      size: 24,
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}



