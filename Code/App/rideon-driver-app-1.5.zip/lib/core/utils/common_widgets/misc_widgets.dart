import 'dart:async';
import '../common_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:ride_on_driver/presentation/cubits/localizations_cubit.dart';
import 'package:shimmer/shimmer.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:ride_on_driver/core/utils/theme/project_color.dart';
import 'package:ride_on_driver/core/utils/theme/theme_style.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../presentation/cubits/dashboard/dashboard_cubit.dart';

class EarningsSummaryCard extends StatelessWidget {
  const EarningsSummaryCard({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.2,
      minChildSize: 0.2,
      maxChildSize: 0.2,
      builder: (context, scrollController) {
        return BlocBuilder<DashboardCubit, DashboardState>(
            builder: (context, state) {
          return Container(
            alignment: Alignment.center,
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Earnings",
                          style:
                              headingBlackBold(context).copyWith(fontSize: 18)),
                      state is DashboardSuceess
                          ? Text(
                              state.totalEarning ?? "",
                              style: regularBlack(context),
                            )
                          : Text(
                              "0",
                              style: regularBlack(context),
                            ),
                    ],
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Ratings",
                          style:
                              headingBlackBold(context).copyWith(fontSize: 18)),
                      state is DashboardSuceess
                          ? Text(
                              state.totalRating.toString(),
                              style: regularBlack(context),
                            )
                          : Text(
                              "0",
                              style: regularBlack(context),
                            ),
                    ],
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Total Order's",
                          style:
                              headingBlackBold(context).copyWith(fontSize: 18)),
                      state is DashboardSuceess
                          ? Text(
                              state.totalOrder.toString(),
                              style: regularBlack(context),
                            )
                          : Text(
                              "0",
                              style: regularBlack(context),
                            ),
                    ],
                  ),
                ],
              ),
            ),
          );
        });
      },
    );
  }
}

Widget forMapLoadingShimmer() {
  return SizedBox(
    height: double.maxFinite,
    width: double.maxFinite,
    child: Shimmer.fromColors(
      baseColor: Colors.grey[300]!,
      highlightColor: Colors.grey[100]!,
      child: Container(
        width: double.infinity,
        height: double.infinity,
        color: Colors.white,
      ),
    ),
  );
}

class MapShimmerScreen extends StatelessWidget {
  const MapShimmerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Stack(
                children: [
                  Shimmer.fromColors(
                    baseColor: Colors.grey[300]!,
                    highlightColor: Colors.grey[100]!,
                    child: Container(
                      width: double.infinity,
                      height: double.infinity,
                      color: Colors.white,
                    ),
                  ),
                  Positioned(
                    top: 16,
                    left: 16,
                    child: Shimmer.fromColors(
                      baseColor: Colors.grey[300]!,
                      highlightColor: Colors.grey[100]!,
                      child: Container(
                        width: 40,
                        height: 40,
                        decoration: const BoxDecoration(
                          color: Colors.white,
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 16,
                    right: 16,
                    child: Shimmer.fromColors(
                      baseColor: Colors.grey[300]!,
                      highlightColor: Colors.grey[100]!,
                      child: Container(
                        width: 40,
                        height: 40,
                        decoration: const BoxDecoration(
                          color: Colors.white,
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 72,
                    right: 16,
                    child: Shimmer.fromColors(
                      baseColor: Colors.grey[300]!,
                      highlightColor: Colors.grey[100]!,
                      child: Container(
                        width: 40,
                        height: 40,
                        decoration: const BoxDecoration(
                          color: Colors.white,
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 32,
                    left: 0,
                    right: 0,
                    child: Center(
                      child: Shimmer.fromColors(
                        baseColor: Colors.amber[400]!,
                        highlightColor: Colors.amber[200]!,
                        child: Container(
                          width: 200,
                          height: 48,
                          decoration: BoxDecoration(
                            color: Colors.amber,
                            borderRadius: BorderRadius.circular(24),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Bottom section
            Container(
              color: Colors.white,
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Customer verification section
                  Row(
                    children: [
                      // Profile image shimmer
                      Shimmer.fromColors(
                        baseColor: Colors.grey[300]!,
                        highlightColor: Colors.grey[100]!,
                        child: Container(
                          width: 64,
                          height: 64,
                          decoration: const BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Shimmer.fromColors(
                          baseColor: Colors.grey[300]!,
                          highlightColor: Colors.grey[100]!,
                          child: Container(
                            height: 24,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),

                  const Divider(height: 32),

                  // Pickup location title
                  Shimmer.fromColors(
                    baseColor: Colors.grey[300]!,
                    highlightColor: Colors.grey[100]!,
                    child: Container(
                      width: 120,
                      height: 20,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Address section
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Location icon shimmer
                      Shimmer.fromColors(
                        baseColor: Colors.green[300]!,
                        highlightColor: Colors.green[100]!,
                        child: Container(
                          width: 32,
                          height: 32,
                          decoration: const BoxDecoration(
                            color: Colors.green,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),

                      // Address text shimmer
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Shimmer.fromColors(
                              baseColor: Colors.grey[300]!,
                              highlightColor: Colors.grey[100]!,
                              child: Container(
                                height: 20,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Shimmer.fromColors(
                              baseColor: Colors.grey[300]!,
                              highlightColor: Colors.grey[100]!,
                              child: Container(
                                height: 20,
                                width: 200,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Call button shimmer
                      Shimmer.fromColors(
                        baseColor: Colors.grey[800]!,
                        highlightColor: Colors.grey[600]!,
                        child: Container(
                          width: 48,
                          height: 48,
                          decoration: const BoxDecoration(
                            color: Colors.black,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),

                  // Arrived button shimmer
                  Shimmer.fromColors(
                    baseColor: themeColor,
                    highlightColor: themeColor,
                    child: Container(
                      width: double.infinity,
                      height: 56,
                      decoration: BoxDecoration(
                        color: themeColor,
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CustomGoogleMap extends StatefulWidget {
  final LatLng initialPosition;
  final Set<Marker> markers;
  final Set<Polyline> polylines;
  final CameraPosition? initialCameraPosition;
  final Function(LatLng)? onMapTap;
  final Function(LatLng)? onMapLongPress;
  final MapType mapType;
  final bool myLocationEnabled;
  final bool zoomControlsEnabled;
  final String? mapStyle;
  final VoidCallback? zoomIn; // Optional JSON string for custom map style
  final VoidCallback? zoomOut; // Optional JSON string for custom map style
  final VoidCallback? currentLocation;
  final Function(GoogleMapController)? onMapCreated;

  const CustomGoogleMap(
      {super.key,
      required this.initialPosition,
      this.markers = const {},
      this.polylines = const {},
      this.initialCameraPosition,
      this.onMapTap,
      this.onMapLongPress,
      this.mapType = MapType.normal,
      this.myLocationEnabled = true,
      this.zoomControlsEnabled = true,
      this.mapStyle,
      this.zoomIn,
      this.zoomOut,
      this.currentLocation,
      this.onMapCreated});

  @override
  State<CustomGoogleMap> createState() => _CustomGoogleMapState();
}

class _CustomGoogleMapState extends State<CustomGoogleMap> {
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        GoogleMap(
          key: ValueKey('google_map_${DateTime.timestamp().microsecond}'),
          initialCameraPosition: widget.initialCameraPosition ??
              CameraPosition(
                target: widget.initialPosition,
                zoom: 14,
              ),
          markers: widget.markers,
          polylines: widget.polylines,
          mapType: widget.mapType,
          myLocationEnabled: widget.myLocationEnabled,
          zoomControlsEnabled: widget.zoomControlsEnabled,
          onTap: widget.onMapTap,
          onLongPress: widget.onMapLongPress,
          onMapCreated: widget.onMapCreated,
        ),
        Positioned(
          top: 100,
          right: 16,
          child: Column(
            children: [
              _MapButton(icon: Icons.zoom_in, onTap: widget.zoomIn ?? () {}),
              const SizedBox(height: 8),
              _MapButton(icon: Icons.zoom_out, onTap: widget.zoomOut ?? () {}),
              const SizedBox(height: 8),
              widget.currentLocation == null
                  ? const SizedBox()
                  : _MapButton(
                      icon: Icons.location_on,
                      onTap: widget.currentLocation ?? () {}),
            ],
          ),
        ),
      ],
    );
  }
}

class _MapButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _MapButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 2,
      borderRadius: BorderRadius.circular(8),
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, size: 24),
        ),
      ),
    );
  }
}

String getCurrentFormattedTime() {
  final now = DateTime.now();
  final hour = now.hour > 12
      ? now.hour - 12
      : now.hour == 0
          ? 12
          : now.hour;
  final period = now.hour >= 12 ? "PM" : "AM";
  final formattedTime =
      "${hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')} $period";
  return formattedTime;
}

DateTime parseTime(String timeString) {
  final now = DateTime.now();
  final format = RegExp(r'(\d+):(\d+)\s*(AM|PM)');
  final match = format.firstMatch(timeString.toUpperCase());

  if (match != null) {
    int hour = int.parse(match.group(1)!);
    int minute = int.parse(match.group(2)!);
    final period = match.group(3);

    if (period == 'PM' && hour != 12) hour += 12;
    if (period == 'AM' && hour == 12) hour = 0;

    return DateTime(now.year, now.month, now.day, hour, minute);
  } else {
    throw FormatException("Invalid time format: $timeString");
  }
}

int calculateMinutesBetween(String startTime, String endTime) {
  final start = parseTime(startTime);
  final end = parseTime(endTime);

  return end.difference(start).inMinutes;
}

Future<void> launchDialPad(String phoneNumber) async {
  final Uri phoneUri = Uri(
    scheme: 'tel',
    path: phoneNumber.replaceAll(' ', ''),
  );

  if (await canLaunchUrl(phoneUri)) {
    await launchUrl(phoneUri, mode: LaunchMode.externalApplication);
  } else {
    throw 'Could not launch dialer for $phoneNumber';
  }
}

customImageContainer(String imageUrl, double imageHeight) {
  return Stack(
    children: [
      Container(
        height: imageHeight,
        width: imageHeight + 50,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: grey4, width: 2)),
        child: myNetworkImage(imageUrl),
      ),
    ],
  );
}

Future<void> startLiveNavigation({
  required double sourceLat,
  required double sourceLng,
  required double destLat,
  required double destLng,
}) async {
  final Uri googleNavigationUri = Uri.parse(
    "google.navigation:q=$destLat,$destLng&mode=d", // mode=d for driving
  );

  if (await canLaunchUrl(googleNavigationUri)) {
    await launchUrl(googleNavigationUri, mode: LaunchMode.externalApplication);
  } else {
    // fallback: open route in maps if navigation fails
    final fallbackUri = Uri.parse("https://www.google.com/maps/dir/?api=1"
        "&origin=$sourceLat,$sourceLng"
        "&destination=$destLat,$destLng"
        "&travelmode=driving");
    await launchUrl(fallbackUri, mode: LaunchMode.externalApplication);
  }
}

class LoadingDropdownPlaceholder extends StatelessWidget {
  const LoadingDropdownPlaceholder({super.key});

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: Colors.grey.shade300,
      highlightColor: Colors.grey.shade100,
      child: Container(
        height: 55,
        padding: const EdgeInsets.symmetric(horizontal: 15),
        decoration: BoxDecoration(
          color: Colors.grey.shade300,
          borderRadius: BorderRadius.circular(12),
        ),
        alignment: Alignment.centerLeft,
        child: Row(
          children: [
            Container(
              height: 12,
              width: 120,
              color: Colors.grey.shade400,
            ),
            const Spacer(),
            Icon(Icons.arrow_drop_down, color: Colors.grey.shade400),
          ],
        ),
      ),
    );
  }
}

Widget languageButton({
  required VoidCallback onTap,
}) {
  return InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(20),
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      decoration: BoxDecoration(
        color: whiteColor.withValues(alpha: .85),
        border: Border.all(color: appBorderColor),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.language, color: appDarkTextColor, size: 16),
          const SizedBox(width: 6),
          BlocBuilder<LCodeCubit, String>(builder: (context, state) {
            return Text(
              state.toUpperCase(),
              style: TextStyle(
                fontFamily: "Poppins SemiBold",
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: appDarkTextColor,
              ),
            );
          }),
          Icon(Icons.keyboard_arrow_down_rounded,
              color: appDarkTextColor, size: 16),
        ],
      ),
    ),
  );
}

class ParcelInfoWidget extends StatelessWidget {
  final String name;
  final String weight;
  final String receiverName;
  final String receiverPhone;
  final String pickupInstructions;

  const ParcelInfoWidget({
    super.key,
    required this.name,
    required this.weight,
    required this.receiverName,
    required this.receiverPhone,
    required this.pickupInstructions,
  });

  bool get _shouldHide =>
      name.trim().isEmpty &&
      receiverName.trim().isEmpty &&
      receiverPhone.trim().isEmpty;

  @override
  Widget build(BuildContext context) {
    if (_shouldHide) return const SizedBox();

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF3E6),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFFFD8B5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Title
          Text(
            "Parcel Details".translate(context),
            style: heading1Grey1(context).copyWith(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: Colors.deepOrange,
            ),
          ),

          const SizedBox(height: 10),

          // Grid rows
          Row(
            children: [
              Expanded(
                  child: _infoCard("Item".translate(context), name,
                      Icons.inventory_2_outlined)),
              const SizedBox(width: 8),
              Expanded(
                  child: _infoCard(
                      "Weight".translate(context),
                      "$weight ${"Kg".translate(context)}",
                      Icons.scale_outlined)),
            ],
          ),

          const SizedBox(height: 8),

          Row(
            children: [
              Expanded(
                  child: _infoCard("Receiver".translate(context), receiverName,
                      Icons.person_outline)),
              const SizedBox(width: 8),
              Expanded(
                  child: _infoCard("Phone".translate(context), receiverPhone,
                      Icons.call_outlined)),
            ],
          ),

          if (pickupInstructions.trim().isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(
              "${"Instruction".translate(context)}: $pickupInstructions",
              style: const TextStyle(
                fontSize: 11,
                color: Colors.brown,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _infoCard(String title, String value, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFFFFE0C2)),
      ),
      child: Row(
        children: [
          Icon(icon, size: 16, color: Colors.deepOrange),
          const SizedBox(width: 6),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 10,
                    color: Colors.grey,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
