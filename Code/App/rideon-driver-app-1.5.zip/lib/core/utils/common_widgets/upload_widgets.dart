import 'dart:async';
import 'dart:convert';
import 'dart:io';
import '../common_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:ride_on_driver/core/utils/theme/project_color.dart';
import 'package:ride_on_driver/core/utils/theme/theme_style.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../presentation/cubits/register_vehicle/make_model_cubit.dart';

class UploadItem extends StatefulWidget {
  final String title;
  final String subtitle;
  final VoidCallback onUploadPressed;
  final IconData? iconData;
  final String? assetImagePath;
  final String? status; // "approved" | "pending" | "rejected" | ""

  const UploadItem({
    super.key,
    required this.title,
    this.assetImagePath,
    required this.subtitle,
    this.iconData,
    this.status,
    required this.onUploadPressed,
  });

  @override
  State<UploadItem> createState() => _UploadItemState();
}

class _UploadItemState extends State<UploadItem> {
  @override
  Widget build(BuildContext context) {
    final String status = widget.status ?? "";
    final bool isApproved = status == "approved";
    final bool isPending = status == "pending";
    final bool isRejected = status == "rejected";
    final bool hasFile = isApproved || isPending || isRejected;

    final Color statusColor = isApproved
        ? appSuccessColor
        : isRejected
            ? appErrorColor
            : themeColor;

    final IconData leadingIcon = widget.iconData ??
        (isApproved
            ? Icons.check_circle
            : isRejected
                ? Icons.error_outline
                : Icons.description_outlined);

    return InkWell(
      borderRadius: BorderRadius.circular(Dimensions.radiusCard),
      onTap: widget.onUploadPressed,
      child: Container(
        margin: const EdgeInsets.only(bottom: Dimensions.space12),
        padding: const EdgeInsets.all(Dimensions.space16),
        decoration: BoxDecoration(
          color: whiteColor,
          borderRadius: BorderRadius.circular(Dimensions.radiusCard),
          border: Border.all(
              color: hasFile
                  ? statusColor.withValues(alpha: 0.4)
                  : appBorderColor),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: statusColor.withValues(alpha: 0.14),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(leadingIcon, color: statusColor, size: 20),
            ),
            const SizedBox(width: Dimensions.space12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    widget.title.translate(context),
                    style: sectionTitleStyle(context).copyWith(fontSize: 15),
                    softWrap: true,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    widget.subtitle.translate(context),
                    style: captionText(context),
                    softWrap: true,
                  ),
                  const SizedBox(height: Dimensions.space4),
                  Text(
                    (isApproved
                            ? "Uploaded"
                            : isPending
                                ? "Pending"
                                : isRejected
                                    ? "Rejected"
                                    : "Add document")
                        .translate(context),
                    style: linkTextStyle(context)
                        .copyWith(color: hasFile ? statusColor : themeColor),
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: notifires.getGrey3whiteColor),
          ],
        ),
      ),
    );
  }
}


Future<void> selectImageWithSource(ImageSource source,
    // ignore: non_constant_identifier_names
    {String? status,
    String? imgSource,
    BuildContext? context}) async {
  try {
    final imagePicker = ImagePicker();
    XFile? pickedImage = await imagePicker.pickImage(source: source);

    await Future.delayed(const Duration(milliseconds: 150));

    if (pickedImage == null) {
      return;
    }

    final base64Img = await compressAndUploadImage(pickedImage.path);

    if (imgSource == "VehicleImg") {
      // ignore: use_build_context_synchronously
      context!.read<UpdateImage>().updateImage(pickedImage);
      // ignore: use_build_context_synchronously
      context
          .read<VehicleFormCubit>()
          .updateVehicleBase64Img(base64Img.toString());
    } else if (imgSource == "Document") {
      // ignore: use_build_context_synchronously
      context!.read<UpdateDocImage>().updateImage(pickedImage);
      // ignore: use_build_context_synchronously
      context
          .read<VehicleFormCubit>()
          .updateVehicleDocBase64Img(base64Img.toString());
    } else if (imgSource == "licence") {
      // ignore: use_build_context_synchronously
      context!.read<UpdateLicenceImage>().updateImage(pickedImage);
      // ignore: use_build_context_synchronously
      context
          .read<VehicleFormCubit>()
          .updateVehicleLicenceBase64Img(base64Img.toString());
    } else if (imgSource == "common") {
      // ignore: use_build_context_synchronously
      context!.read<UpdateImageCommon>().updateImage(pickedImage);
      // ignore: use_build_context_synchronously
      context.read<UpdateImageCommonBase64Img>().updateImage(base64Img);
    }
  } on PlatformException {
    if (Platform.isIOS) {
      showErrorToastMessage(
        "Please check the app settings and grant the necessary permissions."
            // ignore: use_build_context_synchronously
            .translate(context!),
      );
    }
  }
}

int fileSizeThreshold = 1024 * 1024;
int goodQuality = 85;
int badQuality = 50;
int maxWidth = 800;
int maxHeight = 600;

Future<String> compressAndUploadImage(String imagePath) async {
  var imageFile = File(imagePath);
  int originalSize = await imageFile.length();
  int quality = originalSize > fileSizeThreshold ? badQuality : goodQuality;
  var compressedImage = await FlutterImageCompress.compressWithFile(
    imagePath,
    quality: quality,
    minWidth: maxWidth,
    minHeight: maxHeight,
  );

  // ignore: unused_local_variable
  int compressedSize = compressedImage!.length;

  var base64Image = base64Encode(compressedImage);

  String format = '';
  if (compressedImage.length > 8) {
    if (compressedImage[0] == 0xFF && compressedImage[1] == 0xD8) {
      format = 'jpeg';
    } else if (compressedImage[0] == 0x89 && compressedImage[1] == 0x50) {
      format = 'png';
    }
  }

  String finalBase64 = "data:image/$format;base64,$base64Image";
  return finalBase64;
}

