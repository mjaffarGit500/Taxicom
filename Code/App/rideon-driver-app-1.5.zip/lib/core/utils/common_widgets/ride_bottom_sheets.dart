import 'dart:async';
import '../common_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import 'package:ride_on_driver/presentation/screens/ride/chat_screen.dart';
import 'package:ride_on_driver/core/utils/theme/project_color.dart';
import 'package:ride_on_driver/core/utils/theme/theme_style.dart';
import 'package:ride_on_driver/core/utils/translate.dart';
import '../../../domain/entities/realtime_ride_request.dart';
import '../../../presentation/cubits/realtime/listen_ride_request_cubit.dart';
import '../../../presentation/cubits/realtime/manage_driver_cubit.dart';
import '../../../presentation/cubits/realtime/ride_status_cubit.dart';
import '../../../presentation/screens/bottom_bar/home_main.dart';
import '../../extensions/workspace.dart';

Future<void> cancelRideRequestByError({
  required String rideId,
  required String bookingId,
  required BuildContext context,
}) async {
  try {
    goToWithClear(const HomeMain(initialIndex: 0));
    if (rideId.isEmpty) {
      throw Exception('Ride ID cannot be empty');
    }

    context.read<UpdateRideRequestCubit>().updatePendingRideRequests(
          rideId: context.read<UpdateDriverParameterCubit>().state.rideId,
          newStatus: "rejected",
        );
    context.read<UpdateRideStatusInDatabaseCubit>().updateRideStatus(
          context: context,
          bookingId: bookingId,
          rideStatus: "Rejected",
        );

    context.read<UpdateRideRequestCubit>().removeRideRequest(
        skipStatus: true,
        rideId: rideId,
        driverId: loginModel?.data?.fireStoreId ?? "");
  } catch (e) {
    // Emit error state

    throw Exception('Failed to cancel ride request: $e');
  }
}

Future<void> cancelRideRequestWhenLogout({
  required String rideId,
  required BuildContext context,
}) async {
  try {
    if (rideId.isEmpty) {
      throw Exception('Ride ID cannot be empty');
    }

    context.read<UpdateRideRequestCubit>().updatePendingRideRequests(
          rideId: context.read<UpdateDriverParameterCubit>().state.rideId,
          newStatus: "rejected",
        );

    context.read<UpdateRideRequestCubit>().removeRideRequest(
        skipStatus: true,
        rideId: rideId,
        driverId: loginModel?.data?.fireStoreId ?? "");
  } catch (e) {
    // Emit error state

    // throw Exception('Failed to cancel ride request: $e');
  }
}

class CustomRideBottomSheetForStartRide extends StatefulWidget {
  final RealTimeRideRequest rideRequest;
  final String titleText;
  final VoidCallback onTap;
  final Color activeColor;
  final Color inactiveColor;
  final String acceptedText;
  final String defaultText;
  final String? addressText;
  final bool isOnDutyRide;
  final Color? textInactiveColor;
  final Color? textActiveColor;
  final Function(bool) onChanged;
  final String? pickupString;

  const CustomRideBottomSheetForStartRide(
      {super.key,
      required this.rideRequest,
      required this.titleText,
      required this.onTap,
      this.pickupString,
      required this.isOnDutyRide,
      required this.activeColor,
      this.textActiveColor,
      this.textInactiveColor,
      required this.onChanged,
      required this.inactiveColor,
      required this.acceptedText,
      required this.defaultText,
      required this.addressText});

  @override
  CustomRideBottomSheetForStartRideState createState() =>
      CustomRideBottomSheetForStartRideState();
}

class CustomRideBottomSheetForStartRideState
    extends State<CustomRideBottomSheetForStartRide> {
  static const Color _sheetDark = Color(0xFF2A1E1A);
  static const Color _sheetBrown = Color(0xFF8A5A10);

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        DraggableScrollableSheet(
          initialChildSize: 0.42,
          minChildSize: 0.36,
          maxChildSize: 0.6,
          builder: (context, scrollController) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: Container(
                    decoration: const BoxDecoration(
                      color: Color(0xFFFFFCF5),
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(28),
                        topRight: Radius.circular(28),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black26,
                          blurRadius: 10,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: SingleChildScrollView(
                      controller: scrollController,
                      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Center(
                            child: Container(
                              width: 54,
                              height: 5,
                              decoration: BoxDecoration(
                                color: Colors.grey.shade300,
                                borderRadius: BorderRadius.circular(30),
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),
                          Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(18),
                              border: Border.all(
                                  color: themeColor.withValues(alpha: 0.2)),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(2),
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        themeColor,
                                        themeColor,
                                      ],
                                    ),
                                    shape: BoxShape.circle,
                                  ),
                                  child: ClipOval(
                                    child: Container(
                                      height: 52,
                                      width: 52,
                                      color: notifires.getBoxColor,
                                      child: myNetworkImage(widget
                                          .rideRequest.customer?.userPhoto),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        widget.rideRequest.customer?.userName ??
                                            "",
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: headingBlackBold(context)
                                            .copyWith(
                                                fontSize: 14,
                                                color: _sheetDark),
                                      ),
                                      const SizedBox(height: 4),
                                      Row(
                                        children: [
                                          Icon(Icons.star_rounded,
                                              color: orangeColor, size: 14),
                                          const SizedBox(width: 4),
                                          Text(
                                            widget
                                                        .rideRequest
                                                        .customer
                                                        ?.userRating
                                                        ?.isNotEmpty ==
                                                    true
                                                ? widget.rideRequest.customer!
                                                    .userRating!
                                                : "0.0",
                                            style: regular2(context).copyWith(
                                              fontSize: 11,
                                              color: Colors.grey.shade700,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 8),
                                InkWell(
                                  onTap: () {
                                    launchDialPad(
                                        "${widget.rideRequest.customer?.userPhoneCountry} ${widget.rideRequest.customer?.userPhone}");
                                  },
                                  child: Container(
                                    height: 38,
                                    width: 38,
                                    decoration: BoxDecoration(
                                      color: themeColor,
                                      shape: BoxShape.circle,
                                    ),
                                    child: Icon(
                                      Icons.call,
                                      color: blackColor,
                                      size: 18,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                InkWell(
                                  onTap: () {
                                    goTo(DriverChatScreen(
                                      rideRequest: widget.rideRequest,
                                      driverId: driverId,
                                    ));
                                  },
                                  child: Container(
                                    height: 38,
                                    width: 38,
                                    decoration: BoxDecoration(
                                      color: greentext,
                                      shape: BoxShape.circle,
                                    ),
                                    child: Icon(Icons.chat,
                                        color: whiteColor, size: 18),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 14),
                          Text(
                            "Drop Location".translate(context),
                            style: regular2(context).copyWith(
                              color: _sheetBrown,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                  color: greentext.withValues(alpha: 0.18)),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: 32,
                                  height: 32,
                                  decoration: BoxDecoration(
                                    color: greentext.withValues(alpha: 0.12),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Icon(Icons.location_on_outlined,
                                      color: greentext, size: 18),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    widget.addressText ?? "",
                                    style: headingBlack(context)
                                        .copyWith(fontSize: 12),
                                    softWrap: true,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.fromLTRB(14, 14, 14, 16),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withValues(alpha: 0.06),
                                  blurRadius: 12,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Main Action".translate(context),
                                  style: regular(context).copyWith(
                                    fontSize: 11,
                                    color: _sheetBrown,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  "Slide when pickup is complete and trip should begin"
                                      .translate(context),
                                  style: headingBlackBold(context).copyWith(
                                    fontSize: 13,
                                    color: _sheetDark,
                                  ),
                                ),
                                const SizedBox(height: 14),
                                CustomSlideButton(
                                    textActiveColor: widget.textActiveColor,
                                    textInactiveColor: widget.textInactiveColor,
                                    activeColor: widget.activeColor,
                                    inactiveColor: widget.inactiveColor,
                                    isOnRide: widget.isOnDutyRide,
                                    acceptedText: widget.acceptedText,
                                    defaultText: widget.defaultText,
                                    iconColor: widget.textInactiveColor!,
                                    onChanged: widget.onChanged),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ],
    );
  }
}

