<?php

namespace App\Rules;

use App\Models\Language;
use Closure;
use Illuminate\Contracts\Validation\ValidationRule;

class ValidTranslatable implements ValidationRule
{
    public function __construct(protected bool $requireAll = true) {}

    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        if (is_string($value) || is_null($value)) {
            return;
        }

        if (! is_array($value)) {
            $fail(__('validation.array', ['attribute' => $attribute]));

            return;
        }

        $activeLocales = $this->getActiveLocales();
        $defaultLocale = config('global.primary_language', 'en');

        if ($this->requireAll) {
            foreach ($activeLocales as $locale) {
                if (empty($value[$locale] ?? null)) {
                    $fail(__('validation.required_for_locale', ['attribute' => $attribute, 'locale' => $locale]));
                }
            }
        } else {
            if (empty($value[$defaultLocale] ?? null)) {
                $fail(__('validation.required_for_locale', ['attribute' => $attribute, 'locale' => $defaultLocale]));
            }
        }
    }

    protected function getActiveLocales(): array
    {
        $available = array_keys(config('global.available_languages', []));

        if (! empty($available)) {
            return $available;
        }

        return Language::where('language_status', 1)->pluck('short_name')->all();
    }
}
