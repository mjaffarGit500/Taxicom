<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;

final class ValidRichText implements ValidationRule
{
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        $values = is_array($value) ? $value : [$value];
        $limit = (int) config('rich_text.max_input_length', 60_000);

        foreach ($values as $entry) {
            if ($entry !== null && ! is_string($entry)) {
                $fail(__('validation.string', ['attribute' => $attribute]));

                return;
            }

            if (is_string($entry) && strlen($entry) > $limit) {
                $fail(__('validation.max.string', ['attribute' => $attribute, 'max' => $limit]));

                return;
            }
        }
    }
}
