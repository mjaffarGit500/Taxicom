<?php

namespace App\Models;

use App\Models\Traits\Translatable;
use Illuminate\Database\Eloquent\Model;

class SosNumber extends Model
{
    use Translatable;

    protected $translatable = [
        'name',
        'description',
    ];

    protected $with = [
        'translations',
    ];

    protected $fillable = ['name', 'sos_number', 'status', 'description'];
}
