<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SocialLoginAssertion extends Model
{
    protected $hidden = [
        'token_hash',
    ];

    protected $fillable = [
        'token_hash',
        'provider',
        'expires_at',
    ];

    protected $casts = [
        'expires_at' => 'datetime',
    ];
}
