<?php

namespace App\Models\Traits;

use App\Security\RichTextSanitizer;

trait HasRichText
{
    public function getRichTextFields(): array
    {
        return $this->richText ?? [];
    }

    public function sanitizeRichTextField(string $field, ?string $value): ?string
    {
        if (! in_array($field, $this->getRichTextFields(), true)) {
            return $value;
        }

        return app(RichTextSanitizer::class)->sanitize($value);
    }
}
