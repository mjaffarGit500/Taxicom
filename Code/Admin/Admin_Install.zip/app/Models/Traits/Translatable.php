<?php

namespace App\Models\Traits;

use App\Models\Translation;
use Illuminate\Database\Eloquent\Relations\MorphMany;

trait Translatable
{
    public static function bootTranslatable(): void
    {
        static::saved(function ($model) {
            if (request()->isMethod('post') || request()->isMethod('put') || request()->isMethod('patch')) {
                foreach ($model->getTranslatableFields() as $field) {
                    $translations = request()->input($field);
                    if (is_array($translations)) {
                        foreach ($translations as $locale => $value) {
                            if (! is_null($value)) {
                                if (method_exists($model, 'sanitizeRichTextField')) {
                                    $value = $model->sanitizeRichTextField($field, $value);
                                }

                                $model->translations()->updateOrCreate(
                                    ['locale' => $locale, 'field' => $field],
                                    ['value' => $value]
                                );
                            }
                        }
                    }
                }
            }
        });
    }

    public function translations(): MorphMany
    {
        return $this->morphMany(Translation::class, 'translatable');
    }

    public function getTranslatableFields(): array
    {
        return $this->translatable ?? [];
    }

    public function toArray()
    {
        $array = parent::toArray();
        unset($array['translations']);

        foreach ($this->getTranslatableFields() as $field) {
            if (array_key_exists($field, $array)) {
                $array[$field] = $this->getTranslation($field);
            }
        }

        return $array;
    }

    public function getTranslation(string $field, ?string $locale = null): ?string
    {
        $locale = $locale ?? app()->getLocale();
        $defaultLocale = config('global.primary_language', 'en');

        $translation = $this->translations
            ->where('locale', $locale)
            ->where('field', $field)
            ->first();

        if ($translation) {
            return $this->sanitizeTranslatedValue($field, $translation->value);
        }

        if ($locale !== $defaultLocale) {
            $translation = $this->translations
                ->where('locale', $defaultLocale)
                ->where('field', $field)
                ->first();

            if ($translation) {
                return $this->sanitizeTranslatedValue($field, $translation->value);
            }
        }

        return $this->sanitizeTranslatedValue($field, $this->getRawOriginal($field) ?? null);
    }

    public function getTranslatedAttribute(string $field): ?string
    {
        return $this->getTranslation($field);
    }

    public function getTranslationForLocale(string $field, string $locale): ?string
    {
        $translation = $this->translations
            ->where('locale', $locale)
            ->where('field', $field)
            ->first();

        return $this->sanitizeTranslatedValue($field, $translation?->value);
    }

    private function sanitizeTranslatedValue(string $field, ?string $value): ?string
    {
        if (method_exists($this, 'sanitizeRichTextField')) {
            return $this->sanitizeRichTextField($field, $value);
        }

        return $value;
    }

    public function scopeWhereTranslation($query, string $field, string $value, ?string $locale = null)
    {
        $locale = $locale ?? app()->getLocale();

        return $query->whereHas('translations', function ($q) use ($field, $value, $locale) {
            $q->where('field', $field)
                ->where('locale', $locale)
                ->where('value', 'like', "%{$value}%");
        });
    }
}
