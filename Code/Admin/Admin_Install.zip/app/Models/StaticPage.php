<?php

namespace App\Models;

use App\Casts\SanitizedRichText;
use App\Models\Traits\HasRichText;
use App\Models\Traits\Translatable;
use DateTimeInterface;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Image\Enums\Fit;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class StaticPage extends Model implements HasMedia
{
    use HasFactory, HasRichText, InteractsWithMedia, Translatable;

    public $table = 'static_pages';

    protected $translatable = [
        'name',
        'content',
    ];

    protected $richText = [
        'content',
    ];

    protected $casts = [
        'content' => SanitizedRichText::class,
    ];

    protected $with = [
        'translations',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    public const STATUS_SELECT = [
        '1' => 'Active',
        '0' => 'Inactive',
    ];

    protected $fillable = [
        'name',
        'content',
        'status',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }

    public function registerMediaConversions(?Media $media = null): void
    {
        $this->addMediaConversion('thumb')->fit(Fit::Crop, 50, 50);
        $this->addMediaConversion('preview')->fit(Fit::Crop, 120, 120);
    }

    public function getTranslatedNameAttribute(): ?string
    {
        return $this->getTranslation('name');
    }

    public function getTranslatedContentAttribute(): ?string
    {
        return $this->getTranslation('content');
    }
}
