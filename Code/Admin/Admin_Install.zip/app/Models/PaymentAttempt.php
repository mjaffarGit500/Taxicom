<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PaymentAttempt extends Model
{
    public const ACTIVE_STATUSES = ['created', 'pending'];

    protected $fillable = [
        'public_id',
        'owner_id',
        'booking_id',
        'purpose',
        'gateway',
        'amount_minor',
        'currency',
        'status',
        'active_key',
        'provider_order_id',
        'provider_transaction_id',
        'provider_metadata',
        'expires_at',
        'applied_at',
    ];

    protected $casts = [
        'amount_minor' => 'integer',
        'provider_metadata' => 'array',
        'expires_at' => 'datetime',
        'applied_at' => 'datetime',
    ];

    public function booking()
    {
        return $this->belongsTo(Booking::class);
    }

    public function owner()
    {
        return $this->belongsTo(AppUser::class, 'owner_id');
    }

    protected static function booted(): void
    {
        static::updating(function (PaymentAttempt $attempt) {
            if ($attempt->getOriginal('provider_order_id') === null) {
                return;
            }

            foreach (['owner_id', 'purpose', 'booking_id', 'gateway', 'amount_minor', 'currency'] as $field) {
                if ($attempt->isDirty($field)) {
                    throw new \RuntimeException('Bound payment attempt attributes are immutable.');
                }
            }
        });
    }
}
