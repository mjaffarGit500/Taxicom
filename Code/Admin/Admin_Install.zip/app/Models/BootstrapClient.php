<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;

class BootstrapClient extends Authenticatable
{
    use HasApiTokens;

    public const MOBILE_CLIENT = 'rideon-mobile';

    protected $fillable = [
        'name',
        'enabled',
    ];

    protected $casts = [
        'enabled' => 'boolean',
    ];
}
