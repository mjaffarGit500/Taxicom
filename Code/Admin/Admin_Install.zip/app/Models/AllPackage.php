<?php

namespace App\Models;

use App\Casts\SanitizedRichText;
use App\Models\Traits\HasRichText;
use App\Models\Traits\Translatable;
use DateTimeInterface;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Image\Enums\Fit;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class AllPackage extends Model implements HasMedia
{
    use HasFactory, HasRichText, InteractsWithMedia, Translatable;

    public $table = 'all_packages';

    protected $translatable = [
        'package_name',
        'package_description',
    ];

    protected $richText = [
        'package_description',
    ];

    protected $casts = [
        'package_description' => SanitizedRichText::class,
    ];

    protected $with = [
        'translations',
    ];

    protected $appends = [
        'package_image',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    public const STATUS_SELECT = [
        '1' => 'Active',
        '0' => 'InActive',
    ];

    protected $fillable = [
        'package_name',
        'package_total_day',
        'package_price',
        'package_description',
        'status',
        'max_item',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }

    public function registerMediaConversions(?Media $media = null): void
    {
        $this->addMediaConversion('thumb')->fit(Fit::Crop, 50, 50);
        $this->addMediaConversion('preview')->fit(Fit::Crop, 120, 120);
    }

    public function getPackageImageAttribute()
    {
        $file = $this->getMedia('package_image')->last();
        if ($file) {
            $file->url = $file->getUrl();
            $file->thumbnail = $file->getUrl('thumb');
            $file->preview = $file->getUrl('preview');
        }

        return $file;
    }
}
