<?php

namespace App\Models;

use App\Models\Traits\Translatable;
use Illuminate\Database\Eloquent\Model;

class BookingCancellationReason extends Model
{
    use Translatable;

    public $table = 'booking_cancellation_reasons';

    protected $primaryKey = 'order_cancellation_id';

    protected $translatable = [
        'reason',
    ];

    protected $with = [
        'translations',
    ];

    protected $fillable = [
        'order_cancellation_id ',
        'reason',
        'user_type',
        'status',
        'created_at',
        'created_at',
        'updated_at',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    protected $casts = [
        'status' => 'string',

    ];

    public function appUser()
    {
        return $this->belongsTo(AppUser::class, 'user_type');
    }
}
