<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Media extends Model
{
    protected $table = 'media';

    protected $casts = [
        'model_id' => 'string',
        'size' => 'string',
        'order_column' => 'string',

    ];
}
