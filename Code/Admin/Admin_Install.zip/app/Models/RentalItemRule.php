<?php

namespace App\Models;

use App\Models\Traits\Translatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RentalItemRule extends Model
{
    use HasFactory, Translatable;

    protected $table = 'rental_item_rules';

    protected $translatable = [
        'rule_name',
    ];

    protected $with = [
        'translations',
    ];

    protected $fillable = [
        'rule_name',
        'status',
        'module',
    ];

    public function moduleGet()
    {
        return $this->belongsTo(Module::class, 'module');
    }

    public static function getRuleNamesByIds($ids)
    {
        return RentalItemRule::whereIn('id', $ids)->pluck('rule_name')->toArray();
    }
}
