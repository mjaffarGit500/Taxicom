<?php

namespace App\Models;

use App\Casts\SanitizedRichText;
use App\Models\Modern\Item;
use App\Models\Traits\HasRichText;
use App\Models\Traits\Translatable;
use DateTimeInterface;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Image\Enums\Fit;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class City extends Model implements HasMedia
{
    use HasFactory, HasRichText, InteractsWithMedia, Translatable;

    public $table = 'cities';

    protected $translatable = [
        'city_name',
        'description',
    ];

    protected $richText = [
        'description',
    ];

    protected $casts = [
        'description' => SanitizedRichText::class,
    ];

    protected $with = [
        'translations',
    ];

    protected $appends = [
        'image',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    public const STATUS_SELECT = [
        '1' => 'Active',
        '0' => 'InAvtice',
    ];

    protected $fillable = [
        'city_name',
        'description',
        'country_code',
        'status',
        'latitude',
        'longtitude',
        'region',
        'module',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }

    public function registerMediaConversions(?Media $media = null): void
    {
        $this->addMediaConversion('thumb')->fit(Fit::Crop, 50, 50);
        $this->addMediaConversion('preview')->fit(Fit::Crop, 120, 120);
    }

    public function placeItems()
    {
        return $this->hasMany(Item::class, 'place_id', 'id');
    }

    public function getImageAttribute()
    {
        $file = $this->getMedia('image')->last();
        if ($file) {
            $file->url = $file->getUrl();
            $file->thumbnail = $file->getUrl('thumb');
            $file->preview = $file->getUrl('preview');
        }

        return $file;
    }
}
