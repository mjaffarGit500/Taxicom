<?php

namespace App\Http\Middleware;

use App\Models\AppUser;
use App\Models\BootstrapClient;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureMobilePrincipal
{
    public function handle(Request $request, Closure $next): Response
    {
        abort_unless(
            $request->user() instanceof AppUser || $request->user() instanceof BootstrapClient,
            Response::HTTP_FORBIDDEN
        );

        return $next($request);
    }
}
