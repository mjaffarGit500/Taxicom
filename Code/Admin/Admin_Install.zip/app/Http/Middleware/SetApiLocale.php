<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class SetApiLocale
{
    public function handle(Request $request, Closure $next): Response
    {
        $locale = $this->resolveLocale($request) ?? config('global.primary_language', 'en');

        app()->setLocale($locale);

        $request->attributes->set('resolved_locale', $locale);

        return $next($request);
    }

    public function resolveLocale(Request $request): ?string
    {
        $available = array_keys(config('global.available_languages', []));

        $locale = $request->has('lang')
            ? $request->input('lang')
            : ($request->hasHeader('X-locale') ? $request->header('X-locale') : null);

        $locale = $this->normalizeLocale($locale);

        if ($locale && in_array($locale, $available)) {
            return $locale;
        }

        return null;
    }

    protected function normalizeLocale(mixed $locale): ?string
    {
        if (! is_string($locale)) {
            return null;
        }

        $locale = strtolower(trim($locale));
        $locale = substr($locale, 0, 2);

        return $locale === '' ? null : $locale;
    }
}
