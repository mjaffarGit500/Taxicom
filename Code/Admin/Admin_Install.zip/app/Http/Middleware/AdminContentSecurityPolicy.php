<?php

namespace App\Http\Middleware;

use App\Security\CspNonce;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

final class AdminContentSecurityPolicy
{
    public function __construct(private readonly CspNonce $nonce) {}

    public function handle(Request $request, Closure $next): Response
    {
        $this->nonce->value();
        $response = $next($request);

        if (! $this->isScopedRequest($request) || ! $this->isHtmlResponse($response)) {
            return $response;
        }

        // Prevent CDNs and other intermediaries from rewriting protected HTML.
        // For example, Cloudflare Email Address Obfuscation injects a decoder
        // after Laravel has generated the CSP nonce, so that script cannot be
        // safely authorized by the nonce-based policy.
        $response->headers->addCacheControlDirective('no-transform');

        $mode = (string) config('csp.admin_mode', 'off');

        if (! in_array($mode, ['report-only', 'enforce'], true)) {
            return $response;
        }

        $header = $mode === 'report-only'
            ? 'Content-Security-Policy-Report-Only'
            : 'Content-Security-Policy';

        $response->headers->set($header, $this->policy());

        return $response;
    }

    private function isScopedRequest(Request $request): bool
    {
        if ($request->is('install', 'install/*', 'api/*', 'webhook/*', 'wallet/*', 'privacy*')) {
            return false;
        }

        if ($request->is('admin', 'admin/*', 'profile', 'profile/*', 'login', 'password/*', 'user/email-templates/*', 'vendor', 'vendor/*')) {
            return true;
        }

        $name = $request->route()?->getName();

        return is_string($name)
            && (str_starts_with($name, 'admin.') || str_starts_with($name, 'vendor.') || str_starts_with($name, 'profile.'));
    }

    private function isHtmlResponse(Response $response): bool
    {
        if ($response->isRedirection()) {
            return false;
        }

        return str_contains(strtolower((string) $response->headers->get('Content-Type')), 'text/html');
    }

    private function policy(): string
    {
        $nonce = "'nonce-{$this->nonce->value()}'";
        $scripts = implode(' ', array_merge([$nonce, "'strict-dynamic'", "'self'"], config('csp.script_hosts', [])));
        $styles = implode(' ', array_merge([$nonce, "'self'"], config('csp.style_hosts', [])));

        $directives = [
            "default-src 'self'",
            "script-src {$scripts}",
            "style-src-elem {$styles}",
            "style-src-attr 'unsafe-inline'",
            "object-src 'none'",
            "base-uri 'self'",
            "frame-ancestors 'none'",
            "form-action 'self'",
            "frame-src 'self' https://www.google.com https://recaptcha.google.com",
            "font-src 'self' data: https://cdnjs.cloudflare.com https://fonts.gstatic.com",
            "connect-src 'self' https: wss:",
            "worker-src 'self' blob:",
            "media-src 'self' blob:",
            "img-src 'self' data: blob: https:",
        ];

        if (app()->environment('production')) {
            $directives[] = 'upgrade-insecure-requests';
        }

        return implode('; ', $directives);
    }
}
