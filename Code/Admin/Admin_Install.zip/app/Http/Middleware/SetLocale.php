<?php

namespace App\Http\Middleware;

use Closure;

class SetLocale
{
    public function handle($request, Closure $next)
    {
        $available = config('global.available_languages', []);

        if (request('change_language')) {
            $requested = request('change_language');
            if (array_key_exists($requested, $available)) {
                session()->put('language', $requested);
                $language = $requested;
            }
        } elseif (session('language')) {
            $language = session('language');
        }

        if (! isset($language) || ($language !== null && ! array_key_exists($language, $available))) {
            $language = config('global.primary_language', 'en');
        }

        app()->setLocale($language);

        $direction = $language === 'ar' ? 'rtl' : 'ltr';
        view()->share('locale_direction', $direction);
        view()->share('current_locale', $language);

        return $next($request);
    }
}
