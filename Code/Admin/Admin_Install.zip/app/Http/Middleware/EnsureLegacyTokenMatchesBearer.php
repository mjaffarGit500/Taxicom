<?php

namespace App\Http\Middleware;

use App\Models\AppUser;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureLegacyTokenMatchesBearer
{
    public function handle(Request $request, Closure $next): Response
    {
        $principal = $request->user();
        $legacyToken = $request->input('token');

        if ($legacyToken !== null) {
            if (! $principal instanceof AppUser
                || ! is_string($principal->token)
                || $principal->token === ''
                || ! is_string($legacyToken)
                || ! hash_equals($principal->token, $legacyToken)) {
                abort(403, 'The bearer token and legacy user token do not match.');
            }
        }

        return $next($request);
    }
}
