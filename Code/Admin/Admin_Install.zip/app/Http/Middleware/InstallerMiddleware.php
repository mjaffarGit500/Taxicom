<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class InstallerMiddleware
{
    private const STEP_REQUIREMENTS = [
        'installer.index' => 0,
        'installer.verify-key' => 0,
        'installer.requirements' => 1,
        'installer.permissions' => 2,
        'installer.purchaseValidation' => 3,
        'installer.purchaseValidation.store' => 3,
        'installer.purchaseValidation-error' => 3,
        'installer.database' => 4,
        'installer.database.store' => 4,
        'installer.database-error' => 4,
        'installer.migrate' => 5,
        'installer.database.migrate' => 5,
        'installer.database.forcemigrate' => 5,
        'installer.admin' => 6,
        'installer.admin.store' => 5,
        'installer.finish' => 7,
    ];

    private const STEP_ROUTES = [
        0 => 'installer.index',
        1 => 'installer.requirements',
        2 => 'installer.permissions',
        3 => 'installer.purchaseValidation',
        4 => 'installer.database',
        5 => 'installer.migrate',
        6 => 'installer.admin',
        7 => 'installer.finish',
    ];

    public function handle(Request $request, Closure $next): Response
    {
        if ($this->isInstalled() && !$this->isUnlocked()) {
            return redirect('/login');
        }

        $routeName = $request->route()?->getName();
        $requiredStep = self::STEP_REQUIREMENTS[$routeName] ?? 0;
        $completedStep = (int) session('installer_step', 0);

        if ($completedStep < $requiredStep) {
            $redirectRoute = self::STEP_ROUTES[$completedStep] ?? 'installer.index';

            return redirect()->route($redirectRoute)
                ->with('warning', 'Please complete the current step before proceeding.');
        }

        return $next($request);
    }

    private function isInstalled(): bool
    {
        return file_exists(storage_path('app/installed'));
    }

    private function isUnlocked(): bool
    {
        return env('APP_INSTALLER_UNLOCK') === 'true';
    }
}
