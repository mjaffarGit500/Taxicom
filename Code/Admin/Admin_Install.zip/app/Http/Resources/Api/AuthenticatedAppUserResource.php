<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Resources\Json\JsonResource;

class AuthenticatedAppUserResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            // Transitional legacy API credential. Remove with the body-token flow.
            'token' => $this->token,
            'firestore_id' => $this->firestore_id,
            'first_name' => $this->first_name,
            'middle' => $this->middle,
            'last_name' => $this->last_name,
            'email' => $this->email,
            'phone' => $this->phone,
            'phone_country' => $this->phone_country,
            'default_country' => $this->default_country,
            'gender' => $this->gender,
            'birthdate' => $this->birthdate,
            'wallet' => $this->wallet,
            'verified' => $this->verified,
            'document_verify' => $this->document_verify,
            'phone_verify' => $this->phone_verify,
            'email_verify' => $this->email_verify,
            'login_type' => $this->login_type,
            'user_type' => $this->user_type,
            'host_status' => $this->host_status,
            'ave_host_rate' => $this->ave_host_rate,
            'avr_guest_rate' => $this->avr_guest_rate,
            'status' => $this->status,
            'package_id' => $this->package_id,
            'profile_image' => $this->profile_image,
            'identity_image' => $this->identity_image,
            'driving_licence' => $this->driving_licence,
            'driver_authorization' => $this->driver_authorization,
            'hire_service_licence' => $this->hire_service_licence,
            'inspection_certificate' => $this->inspection_certificate,
            'item_id' => $this->when(isset($this->item_id), $this->item_id),
            'item_type_id' => $this->when(
                array_key_exists('item_type_id', $this->resource->getAttributes()),
                $this->item_type_id
            ),
            'remaining_items' => $this->when(isset($this->remaining_items), $this->remaining_items),
            'verification_document_status' => $this->when(
                isset($this->verification_document_status),
                $this->verification_document_status
            ),
            'firebase_auth' => $this->when(isset($this->firebase_auth), $this->firebase_auth),
        ];
    }
}
