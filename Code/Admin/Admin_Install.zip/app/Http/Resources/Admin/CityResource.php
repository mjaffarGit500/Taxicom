<?php

namespace App\Http\Resources\Admin;

use Illuminate\Http\Resources\Json\JsonResource;

class CityResource extends JsonResource
{
    public function toArray($request)
    {
        $data = parent::toArray($request);
        unset($data['translations']);

        $data['translated_city_name'] = $this->getTranslation('city_name');
        $data['translated_description'] = $this->getTranslation('description');

        return $data;
    }
}
