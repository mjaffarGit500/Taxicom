<?php

namespace App\Http\Resources\Admin;

use Illuminate\Http\Resources\Json\JsonResource;

class StaticPageResource extends JsonResource
{
    public function toArray($request)
    {
        $data = parent::toArray($request);
        unset($data['translations']);

        $data['translated_name'] = $this->getTranslation('name');
        $data['translated_content'] = $this->getTranslation('content');

        return $data;
    }
}
