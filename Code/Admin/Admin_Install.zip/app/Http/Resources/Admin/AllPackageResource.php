<?php

namespace App\Http\Resources\Admin;

use Illuminate\Http\Resources\Json\JsonResource;

class AllPackageResource extends JsonResource
{
    public function toArray($request)
    {
        $data = parent::toArray($request);
        unset($data['translations']);

        $data['translated_package_name'] = $this->getTranslation('package_name');
        $data['translated_package_description'] = $this->getTranslation('package_description');

        return $data;
    }
}
