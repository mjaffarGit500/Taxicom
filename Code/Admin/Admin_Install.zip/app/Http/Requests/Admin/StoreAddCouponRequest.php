<?php

namespace App\Http\Requests\Admin;

use App\Rules\ValidRichText;
use Gate;
use Illuminate\Foundation\Http\FormRequest;

class StoreAddCouponRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('add_coupon_create');
    }

    public function rules()
    {
        return [
            'coupon_title' => [
                'string',
                'required',
            ],
            'coupon_subtitle' => [
                'string',
                'nullable',
            ],
            'coupon_image' => [
                'string',
                'nullable',
            ],
            'coupon_expiry_date' => [
                'date_format:'.config('panel.date_format'),
                'nullable',
            ],
            'coupon_code' => [
                'string',
                'required',
            ],
            'coupon_value' => [
                'required',
            ],
            'coupon_description' => [
                'nullable',
                new ValidRichText,
            ],
        ];
    }
}
