<?php

namespace App\Http\Requests\Admin;

use App\Models\Module;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class MassDestroyModuleRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('deleteAny', Module::class) ?? false;
    }

    public function rules(): array
    {
        return [
            'ids' => ['required', 'array'],
            'ids.*' => [
                'integer',
                'distinct',
                Rule::exists('module', 'id')->whereNull('deleted_at'),
            ],
        ];
    }
}
