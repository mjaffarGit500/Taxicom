<?php

namespace App\Http\Requests\Admin;

use App\Rules\ValidTranslatable;
use Gate;
use Illuminate\Foundation\Http\FormRequest;

class UpdateSliderRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('slider_edit');
    }

    public function rules()
    {
        return [
            'heading' => [
                'required',
                new ValidTranslatable,
            ],
            'subheading' => [
                'nullable',
                new ValidTranslatable(false),
            ],
            'image' => [
                'array',
                'required',
            ],
            'image.*' => [
                'required',
            ],
        ];
    }
}
