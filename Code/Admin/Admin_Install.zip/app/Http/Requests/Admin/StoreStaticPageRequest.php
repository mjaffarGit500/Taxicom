<?php

namespace App\Http\Requests\Admin;

use App\Rules\ValidTranslatable;
use App\Rules\ValidRichText;
use Gate;
use Illuminate\Foundation\Http\FormRequest;

class StoreStaticPageRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('static_page_create');
    }

    public function rules()
    {
        return [
            'name' => [
                'required',
                new ValidTranslatable,
            ],
            'content' => [
                'nullable',
                new ValidTranslatable(false),
                new ValidRichText,
            ],
        ];
    }
}
