<?php

namespace App\Http\Requests\Admin;

use App\Rules\ValidTranslatable;
use Gate;
use Illuminate\Foundation\Http\FormRequest;

class UpdateItemRulesRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('item_rules_edit');
    }

    public function rules()
    {
        return [
            'rule_name' => [
                'required',
                new ValidTranslatable,
            ],
            'status' => [
                'required',
            ],
            'module' => [
                'required',
            ],
        ];
    }
}
