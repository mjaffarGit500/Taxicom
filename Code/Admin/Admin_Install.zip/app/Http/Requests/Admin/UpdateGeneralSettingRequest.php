<?php

namespace App\Http\Requests\Admin;

use App\Models\GeneralSetting;
use Illuminate\Foundation\Http\FormRequest;

class UpdateGeneralSettingRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('updateAny', GeneralSetting::class) ?? false;
    }

    public function rules()
    {
        return [
            'meta_key' => [
                'string',
                'required',
            ],
            'meta_value' => [
                'string',
                'required',
            ],
        ];
    }
}
