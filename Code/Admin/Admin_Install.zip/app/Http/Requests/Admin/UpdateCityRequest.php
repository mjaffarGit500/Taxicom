<?php

namespace App\Http\Requests\Admin;

use App\Rules\ValidTranslatable;
use App\Rules\ValidRichText;
use Gate;
use Illuminate\Foundation\Http\FormRequest;

class UpdateCityRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('city_edit');
    }

    public function rules()
    {
        return [
            'city_name' => [
                'required',
                new ValidTranslatable,
            ],
            'description' => [
                'nullable',
                new ValidTranslatable(false),
                new ValidRichText,
            ],
            'status' => [
                'required',
            ],
        ];
    }
}
