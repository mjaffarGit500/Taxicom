<?php

namespace App\Http\Requests\Admin;

use App\Rules\ValidTranslatable;
use Gate;
use Illuminate\Foundation\Http\FormRequest;

class StoreItemRulesRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('item_rules_create');
    }

    public function rules()
    {
        return [
            'rule_name' => [
                'required',
                new ValidTranslatable,
            ],
            'status' => [
                'required',
            ],
            'module' => [
                'required',
            ],

        ];
    }
}
