<?php

namespace App\Http\Requests\Admin;

use App\Rules\ValidTranslatable;
use App\Rules\ValidRichText;
use Gate;
use Illuminate\Foundation\Http\FormRequest;

class StoreAllPackageRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('all_package_create');
    }

    public function rules()
    {
        return [
            'package_name' => [
                'required',
                new ValidTranslatable,
            ],
            'package_description' => [
                'nullable',
                new ValidTranslatable(false),
                new ValidRichText,
            ],
            'package_total_day' => [
                'required',
                'integer',
                'min:-2147483648',
                'max:2147483647',
            ],
            'package_price' => [
                'required',
            ],
            'status' => [
                'required',
            ],
            'max_item' => [
                'required',
                'integer',
                'min:-2147483648',
                'max:2147483647',
            ],
        ];
    }
}
