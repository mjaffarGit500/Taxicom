<?php

namespace App\Http\Requests\Admin;

use App\Models\Module;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateModuleStatusRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('updateStatus', Module::class) ?? false;
    }

    public function rules(): array
    {
        return [
            'pid' => [
                'required',
                'integer',
                Rule::exists('module', 'id')->whereNull('deleted_at'),
            ],
            'type' => ['required', Rule::in(['status', 'default_module'])],
            'status' => ['required', 'boolean'],
        ];
    }
}
