<?php

namespace App\Http\Requests\Admin;

use Gate;
use Illuminate\Foundation\Http\FormRequest;

class StoreAppUserRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('app_user_create');
    }

    public function rules()
    {
        $isDriver = $this->input('user_type') === 'driver';

        $driverRules = $isDriver ? [
            'car_type' => ['required', 'numeric'],
            'make' => ['required', 'numeric'],
            'model' => ['required', 'string'],
            'year' => ['required', 'numeric'],
            'registration_number' => ['required', 'string'],
            'driving_licence_front' => ['required', 'string'],
            'driving_licence_back' => ['required', 'string'],
            'driver_id_front' => ['required', 'string'],
            'driver_id_back' => ['required', 'string'],
        ] : [];

        return array_merge([
            'first_name' => [
                'string',
                'required',
            ],
            'middle' => [
                'string',
                'nullable',
            ],
            'last_name' => [
                'string',
                'nullable',
            ],
            'email' => [
                'required',

            ],
            'phone' => [
                'string',
                'required',

            ],
            'phone_country' => [
                'string',
                'nullable',
            ],
            'default_country' => [
                'string',
                'nullable',
            ],
            'gender' => [
                'string',
                'nullable',
            ],
            'password' => ['nullable'],
        ], $driverRules);
    }
}
