<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Controllers\Traits\NotificationTrait;
use App\Http\Controllers\Traits\PushNotificationTrait;
use App\Http\Controllers\Traits\ResponseTrait;
use App\Http\Requests\Admin\UpdateGeneralSettingRequest;
use App\Models\AddCoupon;
use App\Models\AppUser;
use App\Models\Booking;
use App\Models\City;
use App\Models\GeneralSetting;
use App\Models\Language;
use App\Models\Media;
use App\Models\Modern\Currency;
use App\Models\Modern\Item;
use App\Models\Modern\ItemFeatures;
use App\Models\Modern\ItemType;
use App\Models\Modern\RentalItemServiceType;
use App\Models\PersonalAccessToken;
use App\Models\RentalItemRule;
use App\Models\Review;
use App\Models\StaticPage;
use App\Models\Translation;
use App\Models\VehicleMake;
use App\Models\VehicleOdometer;
use App\Services\DriverApprovalService;
use App\Services\SelectedStaticPageService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Yajra\DataTables\Facades\DataTables;

class GeneralSettingsController extends Controller
{
    use MediaUploadingTrait, NotificationTrait, PushNotificationTrait, ResponseTrait;

    public function index(Request $request)
    {
        $this->authorize('viewAny', GeneralSetting::class);
        if ($request->ajax()) {
            $query = GeneralSetting::query()->select(sprintf('%s.*', (new GeneralSetting)->table));
            $table = DataTables::of($query);
            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) {
                $viewGate = 'general_setting_show';
                $editGate = 'general_setting_edit';
                $deleteGate = 'general_setting_delete';
                $crudRoutePart = 'general-settings';

                return view(
                    'partials.datatablesActions',
                    compact(
                        'viewGate',
                        'editGate',
                        'deleteGate',
                        'crudRoutePart',
                        'row'
                    )
                );
            });
            $table->editColumn('id', function ($row) {
                return $row->id ? $row->id : '';
            });
            $table->editColumn('meta_key', function ($row) {
                return $row->meta_key ? $row->meta_key : '';
            });
            $table->editColumn('meta_value', function ($row) {
                return $row->meta_value ? $row->meta_value : '';
            });
            $table->rawColumns(['actions', 'placeholder']);

            return $table->make(true);
        }

        return view('admin.general-settings.index');
    }

    public function edit(GeneralSetting $generalSetting)
    {
        $this->authorize('updateAny', GeneralSetting::class);

        return view('admin.general-settings.edit', compact('generalSetting'));
    }

    public function update(UpdateGeneralSettingRequest $request, GeneralSetting $generalSetting)
    {
        $generalSetting->update($request->all());

        return redirect()->route('admin.general-settings.index');
    }

    public function editGeneral()
    {
        $metaKeys = [
            'general_name',
            'general_description',
            'general_email',
            'general_phone',
            'general_default_phone_country',
            'general_default_currency',
            'general_default_language',
            'general_favicon',
            'general_logo',
        ];
        $settings = GeneralSetting::whereIn('meta_key', $metaKeys)->get()->keyBy('meta_key');
        $general_name = $settings['general_name'] ?? null;
        $general_description = $settings['general_description'] ?? null;
        $general_email = $settings['general_email'] ?? null;
        $general_phone = $settings['general_phone'] ?? null;
        $general_default_phone_country = $settings['general_default_phone_country'] ?? null; //
        $general_default_currency = $settings['general_default_currency'] ?? null;
        $general_default_language = $settings['general_default_language'] ?? null;
        $general_favicon = $settings['general_favicon'] ?? null;
        $general_logo = $settings['general_logo'] ?? null;
        $languagedata = Language::all();
        $allcurrency = Currency::where('status', 1)->get();

        return view('admin.general-settings.general.basic-configuration-form', compact('general_name', 'general_email', 'general_phone', 'general_default_phone_country', 'general_default_currency', 'general_default_language', 'general_favicon', 'general_logo', 'allcurrency', 'languagedata', 'general_description'));
    }

    public function updateGeneral(Request $request)
    {
        $formData = $request->except(
            '_token',
            'general_logo',
            'general_favicon',
            'delete_general_logo',
            'delete_general_favicon',
            'delete_general_default_language'
        );
        if ($request->boolean('delete_general_default_language')) {
            unset($formData['general_default_language']);
            $this->clearGeneralSetting('general_default_language');
        }
        if ($request->hasFile('general_logo')) {
            $this->deleteGeneralSettingFile('general_logo');
            $file = $request->file('general_logo');
            $fileName = rand(10, 1000000) . '.' . $file->getClientOriginalName();
            $path = $file->storeAs('logo', $fileName, 'public');
            $formData['general_logo'] = $path;
        } elseif ($request->boolean('delete_general_logo')) {
            $this->deleteGeneralSettingFile('general_logo');
            $this->clearGeneralSetting('general_logo');
        }
        if ($request->hasFile('general_favicon')) {
            $this->deleteGeneralSettingFile('general_favicon');
            $file = $request->file('general_favicon');
            $fileName = rand(10, 1000000) . '.' . $file->getClientOriginalName();
            $path = $file->storeAs('logo', $fileName, 'public');
            $formData['general_favicon'] = $path;
        } elseif ($request->boolean('delete_general_favicon')) {
            $this->deleteGeneralSettingFile('general_favicon');
            $this->clearGeneralSetting('general_favicon');
        }
        foreach ($formData as $metaKey => $metaValue) {
            if (!empty($metaValue)) {
                $this->saveGeneralSetting($metaKey, $metaValue);
            }
        }
        $this->clearGeneralSettingsCache();

        return redirect()->route('admin.settings.general')->with('success', 'Updated successfully.');
    }

    public function removeGeneralAsset(Request $request)
    {
        $validated = $request->validate([
            'asset' => 'required|in:logo,favicon',
        ]);

        $metaKey = $validated['asset'] === 'logo' ? 'general_logo' : 'general_favicon';
        $label = $validated['asset'] === 'logo' ? 'Logo' : 'Favicon';

        $this->deleteGeneralSettingFile($metaKey);
        $this->clearGeneralSetting($metaKey);
        $this->clearGeneralSettingsCache();

        return response()->json([
            'success' => true,
            'asset' => $validated['asset'],
            'message' => $label . ' removed successfully.',
        ]);
    }

    private function saveGeneralSetting(string $metaKey, string $metaValue): void
    {
        $setting = GeneralSetting::withTrashed()->firstOrNew(['meta_key' => $metaKey]);
        $setting->meta_value = $metaValue;

        if ($setting->exists && $setting->trashed()) {
            $setting->restore();

            return;
        }

        $setting->save();
    }

    private function clearGeneralSetting(string $metaKey): void
    {
        GeneralSetting::withTrashed()
            ->where('meta_key', $metaKey)
            ->forceDelete();
    }

    private function deleteGeneralSettingFile(string $metaKey): void
    {
        $path = GeneralSetting::where('meta_key', $metaKey)->value('meta_value');

        if ($path && Storage::disk('public')->exists($path)) {
            Storage::disk('public')->delete($path);
        }
    }

    private function clearGeneralSettingsCache(): void
    {
        Cache::forget('general_settings');
        Cache::forget('cached_general_settings');
    }

    public function showPreferences()
    {
        $personalization_row_per_page = GeneralSetting::where('meta_key', 'personalization_row_per_page')->first();
        $personalization_min_search_price = GeneralSetting::where('meta_key', 'personalization_min_search_price')->first();
        $personalization_max_search_price = GeneralSetting::where('meta_key', 'personalization_max_search_price')->first();
        $personalization_date_separator = GeneralSetting::where('meta_key', 'personalization_date_separator')->first();
        $personalization_date_format = GeneralSetting::where('meta_key', 'personalization_date_format')->first();
        $personalization_timeZone = GeneralSetting::where('meta_key', 'personalization_timeZone')->first();
        $personalization_money_format = GeneralSetting::where('meta_key', 'personalization_money_format')->first();

        return view('admin.Preferences.NotificationPreferencesForm', compact('personalization_row_per_page', 'personalization_min_search_price', 'personalization_max_search_price', 'personalization_date_separator', 'personalization_date_format', 'personalization_timeZone', 'personalization_money_format'));
    }

    public function updatePreferences(Request $request)
    {
        $formData = $request->except('_token');
        foreach ($formData as $metaKey => $metaValue) {
            if (!empty($metaValue)) {
                GeneralSetting::updateOrCreate(
                    ['meta_key' => $metaKey],
                    ['meta_value' => $metaValue]
                );
            }
        }

        return redirect()->route('admin.settings.preferences');
    }

    public function showSmsSettings()
    {
        $keys = [
            'nonage_options',
            'nonage_status',
            'sms_provider_name',
            'messagewizard_sender_number',
            'auto_fill_otp',
        ];
        $settings = GeneralSetting::whereIn('meta_key', $keys)->get()->keyBy('meta_key');
        $messagewizard_key = GeneralSetting::where('meta_key', 'messagewizard_key')->first();
        $messagewizard_secret = GeneralSetting::where('meta_key', 'messagewizard_secret')->first();
        $options = $settings->get('nonage_options') ?? null;
        $status = $settings->get('nonage_status') ?? null;
        $sms_provider_name = $settings->get('sms_provider_name') ?? null;
        $messagewizard_sender_number = $settings->get('messagewizard_sender_number') ?? null;
        $auto_fill_otp = $settings->get('auto_fill_otp') ?? null;
        $id = 1;

        return view('admin.general-settings.sms-settings.nonage', compact('messagewizard_secret', 'messagewizard_key', 'options', 'status', 'id', 'sms_provider_name', 'messagewizard_sender_number', 'auto_fill_otp'));
    }

    public function updateSmsSettings(Request $request)
    {
        $formData = $request->except('_token');
        if (isset($formData['messagewizard_status'])) {
            $formData['messagewizard_status'] = (int) ($formData['messagewizard_status'] === '1');
            GeneralSetting::updateOrCreate(
                ['meta_key' => 'messagewizard_status'],
                ['meta_value' => $formData['messagewizard_status']]
            );
            unset($formData['messagewizard_status']);
        }
        foreach ($formData as $metaKey => $metaValue) {
            // Skip empty meta values
            if (!empty($metaValue)) {
                GeneralSetting::updateOrCreate(
                    ['meta_key' => $metaKey],
                    ['meta_value' => $metaValue]
                );
            }
        }

        return response()->json(['message' => trans('global.data_has_been_submitted')], 200);
    }

    public function showMsg91Settings()
    {
        $keys = [
            'msg91_auth_key',
            'msg91_template_id',
            'sms_provider_name',
            'auto_fill_otp',
        ];
        $settings = GeneralSetting::whereIn('meta_key', $keys)->get()->keyBy('meta_key');
        $msg91_auth_key = $settings->get('msg91_auth_key') ?? null;
        $msg91_template_id = $settings->get('msg91_template_id') ?? null;
        $sms_provider_name = $settings->get('sms_provider_name') ?? null;
        $auto_fill_otp = $settings->get('auto_fill_otp') ?? null;
        $id = 1;

        return view('admin.general-settings.sms-settings.msg91', compact('msg91_auth_key', 'msg91_template_id', 'id', 'sms_provider_name', 'auto_fill_otp'));
    }

    public function updateMsg91Settings(Request $request)
    {
        $formData = $request->except('_token');
        foreach ($formData as $metaKey => $metaValue) {
            $existingSetting = GeneralSetting::where('meta_key', $metaKey)->first();
            if ($existingSetting) {
                $existingSetting->update(['meta_value' => $metaValue]);
            } else {
                GeneralSetting::create(['meta_key' => $metaKey, 'meta_value' => $metaValue]);
            }
        }

        return response()->json(['message' => trans('global.data_has_been_submitted')], 200);
    }

    public function showTwilioSettings()
    {
        $keys = [
            'twillio_options',
            'twillio_status',
            'sms_provider_name',
            'auto_fill_otp',
        ];
        $settings = GeneralSetting::whereIn('meta_key', $keys)->get()->keyBy('meta_key');
        $twillio_key = GeneralSetting::where('meta_key', 'twillio_key')->first();
        $twillio_secret = GeneralSetting::where('meta_key', 'twillio_secret')->first();
        $twillio_number = GeneralSetting::where('meta_key', 'twillio_number')->first();
        $options = $settings->get('twillio_options') ?? null;
        $status = $settings->get('twillio_status') ?? null;
        $sms_provider_name = $settings->get('sms_provider_name') ?? null;
        $auto_fill_otp = $settings->get('auto_fill_otp') ?? null;
        $id = 1;

        return view('admin.general-settings.sms-settings.twilio', compact('twillio_key', 'twillio_secret', 'twillio_number', 'options', 'status', 'id', 'sms_provider_name', 'auto_fill_otp'));
    }

    public function updateTwilioSettings(Request $request)
    {
        $formData = $request->except('_token');
        foreach ($formData as $metaKey => $metaValue) {
            $existingSetting = GeneralSetting::where('meta_key', $metaKey)->first();
            if ($existingSetting) {
                $existingSetting->update(['meta_value' => $metaValue]);
            } else {
                GeneralSetting::create(['meta_key' => $metaKey, 'meta_value' => $metaValue]);
            }
        }

        return response()->json(['message' => trans('global.data_has_been_submitted')], 200);
    }

    public function showNexmoSettings()
    {
        $nexmo_key = GeneralSetting::where('meta_key', 'nexmo_key')->first();
        $nexmo_secret = GeneralSetting::where('meta_key', 'nexmo_secret')->first();

        return view('admin.general-settings.sms-settings.nexmo', compact('nexmo_key', 'nexmo_secret'));
    }

    public function updateNexmoSettings(Request $request)
    {
        $formData = $request->except('_token');
        foreach ($formData as $metaKey => $metaValue) {
            $existingSetting = GeneralSetting::where('meta_key', $metaKey)->first();
            if ($existingSetting) {
                $existingSetting->update(['meta_value' => $metaValue]);
            } else {
                GeneralSetting::create(['meta_key' => $metaKey, 'meta_value' => $metaValue]);
            }
        }

        return response()->json(['message' => trans('global.data_has_been_submitted')], 200);
    }

    public function showSinchSettings()
    {
        $settings = GeneralSetting::whereIn('meta_key', ['sinch_service_plan_id', 'sinch_api_token', 'sinch_sender_number', 'sms_provider_name', 'auto_fill_otp'])
            ->get()
            ->keyBy('meta_key');
        $sinch_service_plan_id = $settings['sinch_service_plan_id'] ?? null;
        $sinch_api_token = $settings['sinch_api_token'] ?? null;
        $sinch_sender_number = $settings['sinch_sender_number'] ?? null;
        $sms_provider_name = $settings['sms_provider_name'] ?? null;
        $auto_fill_otp = $settings->get('auto_fill_otp') ?? null;
        $id = 1;

        return view('admin.general-settings.sms-settings.sinch', compact('sinch_service_plan_id', 'sinch_api_token', 'sinch_sender_number', 'id', 'sms_provider_name', 'auto_fill_otp'));
    }

    public function updateSinchSettings(Request $request)
    {
        $formData = $request->except('_token');
        foreach ($formData as $metaKey => $metaValue) {
            $existingSetting = GeneralSetting::where('meta_key', $metaKey)->first();
            if ($existingSetting) {
                $existingSetting->update(['meta_value' => $metaValue]);
            } else {
                GeneralSetting::create(['meta_key' => $metaKey, 'meta_value' => $metaValue]);
            }
        }

        return response()->json(['message' => trans('global.data_has_been_submitted')], 200);
    }

    public function showTwoFactorSettings()
    {
        $twofactor_key = GeneralSetting::where('meta_key', 'twofactor_key')->first();
        $twofactor_secret = GeneralSetting::where('meta_key', 'twofactor_secret')->first();
        $twofactor_merchant_id = GeneralSetting::where('meta_key', 'twofactor_merchant_id')->first();
        $twofactor_authentication_token = GeneralSetting::where('meta_key', 'twofactor_authentication_token')->first();

        return view('admin.general-settings.sms-settings.two-factor', compact('twofactor_key', 'twofactor_secret', 'twofactor_merchant_id', 'twofactor_authentication_token'));
    }

    public function updateTwoFactorSettings(Request $request)
    {
        $formData = $request->except('_token');
        foreach ($formData as $metaKey => $metaValue) {
            $existingSetting = GeneralSetting::where('meta_key', $metaKey)->first();
            if ($existingSetting) {
                $existingSetting->update(['meta_value' => $metaValue]);
            } else {
                GeneralSetting::create(['meta_key' => $metaKey, 'meta_value' => $metaValue]);
            }
        }

        return redirect()->route('admin.settings.sms.two-factor');
    }

    public function showEmailSettings()
    {
        $metaKeys = [
            'email_template_header',
            'email_template_footer',
        ];
        $settings = GeneralSetting::whereIn('meta_key', $metaKeys)->get()->keyBy('meta_key');

        return view('admin.general-settings.email-settings.index', [
            'email_template_header' => $settings['email_template_header'] ?? null,
            'email_template_footer' => $settings['email_template_footer'] ?? null,
        ]);
    }

    public function updateEmailSettings(Request $request)
    {
        $request->validate([
            'email_template_header' => ['nullable', 'string', new \App\Rules\ValidRichText],
            'email_template_footer' => ['nullable', 'string', new \App\Rules\ValidRichText],
        ]);

        $formData = $request->only(['email_template_header', 'email_template_footer']);
        foreach ($formData as $metaKey => $metaValue) {
            GeneralSetting::updateOrCreate(
                ['meta_key' => $metaKey],
                ['meta_value' => $metaValue]
            );
        }

        return redirect()->route('admin.settings.email')
            ->with('success', trans('general_settings.settings_saved'));
    }

    public function showFeesSettings()
    {
        $metaKeys = [
            'feesetup_guest_service_charge',
            'feesetup_iva_tax',
            'feesetup_accommodation_tax',
            'feesetup_admin_commission',
            'feesetup_accommodation_tax_get',
            'feesetup_iva_tax_get',
            'feesetup_guest_service_charge_get',
        ];
        $settings = GeneralSetting::whereIn('meta_key', $metaKeys)->get()->keyBy('meta_key');

        return view('admin.general-settings.fees.financial-settings-form', [
            'feesetup_guest_service_charge' => $settings['feesetup_guest_service_charge'] ?? null,
            'feesetup_iva_tax' => $settings['feesetup_iva_tax'] ?? null,
            'feesetup_accommodation_tax' => $settings['feesetup_accommodation_tax'] ?? null,
            'feesetup_admin_commission' => $settings['feesetup_admin_commission'] ?? null,
            'feesetup_accommodation_tax_get' => $settings['feesetup_accommodation_tax_get'] ?? null,
            'feesetup_iva_tax_get' => $settings['feesetup_iva_tax_get'] ?? null,
            'feesetup_guest_service_charge_get' => $settings['feesetup_guest_service_charge_get'] ?? null,
        ]);
    }

    public function updateFeesSettings(Request $request)
    {
        $formData = $request->except('_token');
        foreach ($formData as $metaKey => $metaValue) {
            if ($metaValue !== null) {
                GeneralSetting::updateOrCreate(
                    ['meta_key' => $metaKey],
                    ['meta_value' => $metaValue]
                );
            }
        }

        return redirect()->route('admin.settings.fees')->with('success', 'Updated successfully.');
        // return redirect()->route('admin.settings.fees');
    }

    public function showLanguageSettings()
    {
        $listdata = Language::all();

        return view('admin.languages.index', compact('listdata'));
    }

    public function showApiCredentials()
    {
        $meta_keys = [
            'api_facebook_client_id',
            'api_facebook_client_secret',
            'api_google_client_id',
            'api_google_client_secret',
            'general_captcha',
            'site_key',
            'private_key',
        ];
        $settings = GeneralSetting::whereIn('meta_key', $meta_keys)->get()->keyBy('meta_key');
        $data = [];
        foreach ($meta_keys as $key) {
            $data[$key] = $settings->has($key) ? $settings->get($key) : '';
        }

        return view('admin.general-settings.api-credentials.api-key-management-form', $data);
    }

    public function updateApiCredentials(Request $request)
    {
        $formData = $request->validate([
            'general_captcha' => ['required', Rule::in(['yes', 'no'])],
            'site_key' => ['nullable', 'string', 'max:255', 'required_if:general_captcha,yes'],
            'private_key' => ['nullable', 'string', 'max:255', 'required_if:general_captcha,yes'],
        ]);

        foreach ($formData as $metaKey => $metaValue) {
            if (!empty($metaValue)) {
                GeneralSetting::updateOrCreate(
                    ['meta_key' => $metaKey],
                    ['meta_value' => $metaValue]
                );
            }
        }

        return redirect()->route('admin.settings.api-credentials')->with('success', 'Updated successfully.');
        // return redirect()->route('admin.settings.api-credentials');
    }

    public function createLanguage()
    {
        return view('admin.languages.create');
    }

    public function storeLanguage(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'short_name' => 'required|string|max:10|unique:languages,short_name',
            'language_status' => 'required',
        ]);

        $data = [
            'name' => $request->name,
            'short_name' => $request->short_name,
            'language_status' => $request->language_status,
        ];
        Language::create($data);

        Cache::forget('active_languages');

        return redirect()->route('admin.settings.languages.index')->with('success', trans('global.language_created_successfully'));
    }

    public function editLanguage($languageId)
    {
        $editdata = Language::find($languageId);

        return view('admin.languages.edit', compact('editdata'));
    }

    public function updateLanguage(Request $request, $languageId)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'short_name' => 'required|string|max:10|unique:languages,short_name,' . $languageId,
            'language_status' => 'required',
        ]);

        $language = Language::findOrFail($languageId);

        $oldShortName = $language->short_name;

        if ($oldShortName !== $request->short_name) {
            if ($oldShortName === config('global.primary_language', 'en')) {
                return redirect()->route('admin.settings.languages.index')
                    ->with('error', trans('global.language_primary_short_name_blocked'));
            }

            Translation::where('locale', $oldShortName)->update(['locale' => $request->short_name]);
        }

        $language->update([
            'name' => $request->name,
            'short_name' => $request->short_name,
            'language_status' => $request->language_status,
        ]);

        Cache::forget('active_languages');

        return redirect()->route('admin.settings.languages.index')->with('success', trans('global.language_updated_successfully'));
    }

    public function destroyLanguage($id)
    {
        $language = Language::find($id);

        if (!$language) {
            return response()->json(['message' => 'Language not found.'], 404);
        }

        if ($language->short_name === config('global.primary_language', 'en')) {
            return response()->json(['message' => trans('global.language_primary_delete_blocked')], 400);
        }

        Translation::where('locale', $language->short_name)->delete();
        $language->delete();

        Cache::forget('active_languages');

        return response()->json(['message' => 'Language deleted successfully.']);
    }

    // public function updateStatus(Request $request)
    // {
    //     if (Gate::denies('general_setting_edit')) {
    //         return response()->json(['error' => 'Form submission is disabled in demo mode.']);
    //     }
    //     $status = $request->input('status');
    //     $id = $request->input('id');
    //     $setting = GeneralSetting::where('meta_key', 'paypal_status')->first();
    //     if ($setting) {
    //         $setting->meta_value = $status;
    //         $setting->save();
    //     }
    //     return response()->json(['success' => "Updated Successfully."]);
    // }
    // public function updateMethodsStatus(Request $request)
    // {
    //     if (Gate::denies('general_setting_edit')) {
    //         return redirect()->back()->with('error', 'Form submission is disabled in demo mode.');
    //     }
    //     $status = $request->input('status');
    //     $id = $request->input('id');
    //     $setting = GeneralSetting::where('meta_key', 'paydunya_status')->first();
    //     if ($setting) {
    //         $setting->meta_value = $status;
    //         $setting->save();
    //     }
    //     return response()->json(['success' => true]);
    // }
    public function updateNonageStatus(Request $request)
    {
        $status = $request->input('status');
        $id = $request->input('id');
        // Update Nonage status
        $nonageSetting = GeneralSetting::firstOrNew(['meta_key' => 'nonage_status']);
        $nonageSetting->meta_value = $status;
        $nonageSetting->save();
        // If Nonage is activated, deactivate Twilio
        if ($status === 'Active') {
            $twillioSetting = GeneralSetting::where('meta_key', 'twillio_status')->first();
            if ($twillioSetting) {
                $twillioSetting->meta_value = 'Inactive';
                $twillioSetting->save();
            }
        }

        return response()->json(['success' => true]);
    }

    public function updateTwilioStatus(Request $request)
    {
        $status = $request->input('status');
        $id = $request->input('id');
        // Update Twilio status
        $twillioSetting = GeneralSetting::firstOrNew(['meta_key' => 'twillio_status']);
        $twillioSetting->meta_value = $status;
        $twillioSetting->save();
        // If Twilio is activated, deactivate Nonage
        if ($status === 'Active') {
            $nonageSetting = GeneralSetting::where('meta_key', 'nonage_status')->first();
            if ($nonageSetting) {
                $nonageSetting->meta_value = 'Inactive';
                $nonageSetting->save();
            }
        }

        return response()->json(['success' => true]);
    }

    public function updateSmsProviderName(Request $request)
    {
        $status = $request->input('status');
        $id = $request->input('id');
        $userValue = $request->input('userValue');
        // Update sinch status
        $smsSetting = GeneralSetting::firstOrNew(['meta_key' => 'sms_provider_name']);
        $smsSetting->meta_value = $userValue;
        $smsSetting->save();

        return response()->json(['success' => true]);
    }

    // GeneralSettingsController.php
    public function showPushNotificationSettings()
    {
        $settings = GeneralSetting::whereIn('meta_key', [
            'push_notification_status',
            'onesignal_app_id',
            'onesignal_rest_api_key',
            'onesignal_app_id_driver',
            'onesignal_rest_api_key_driver',
        ])->pluck('meta_value', 'meta_key');
        $pushnotification_status = $settings['push_notification_status'] ?? null;
        $onesignal_app_id = $settings['onesignal_app_id'] ?? null;
        $onesignal_rest_api_key = $settings['onesignal_rest_api_key'] ?? null;
        $onesignal_app_id_driver = $settings['onesignal_app_id_driver'] ?? null;
        $onesignal_rest_api_key_driver = $settings['onesignal_rest_api_key_driver'] ?? null;

        return view('admin.general-settings.push-notifications.index', compact(
            'pushnotification_status',
            'onesignal_app_id',
            'onesignal_rest_api_key',
            'onesignal_app_id_driver',
            'onesignal_rest_api_key_driver'
        ));
    }

    public function searchPushNotificationRecipients(Request $request)
    {
        $request->validate([
            'type' => 'required|in:user,driver',
            'q' => 'nullable|string',
        ]);

        $query = trim((string) $request->input('q', ''));
        if (strlen($query) < 3) {
            return response()->json(['results' => []]);
        }

        $users = AppUser::query()
            ->where('user_type', $request->input('type'))
            ->where('status', 1);

        if ($request->input('type') === 'driver') {
            $users->where('document_verify', 1);
        }

        $users->where(function ($builder) use ($query) {
            $builder->where('first_name', 'like', "%{$query}%")
                ->orWhere('last_name', 'like', "%{$query}%")
                ->orWhere('phone', 'like', "%{$query}%")
                ->orWhere('email', 'like', "%{$query}%");
        });

        $results = $users
            ->orderBy('first_name')
            ->limit(20)
            ->get()
            ->map(function ($user) {
                $name = trim($user->first_name . ' ' . ($user->last_name ?? ''));
                $labelParts = array_filter([$name, $user->phone, $user->email]);

                return [
                    'id' => $user->id,
                    'text' => implode(' - ', $labelParts),
                ];
            })
            ->values();

        return response()->json(['results' => $results]);
    }

    public function updatePushNotificationSettings(Request $request)
    {
        $request->validate([
            'onesignal_app_id' => 'required|string',
            'onesignal_rest_api_key' => 'required|string',
            'onesignal_app_id_driver' => 'required|string',
            'onesignal_rest_api_key_driver' => 'required|string',
        ]);
        GeneralSetting::updateOrCreate(
            ['meta_key' => 'onesignal_app_id'],
            ['meta_value' => $request->onesignal_app_id]
        );
        GeneralSetting::updateOrCreate(
            ['meta_key' => 'onesignal_rest_api_key'],
            ['meta_value' => $request->onesignal_rest_api_key]
        );
        GeneralSetting::updateOrCreate(
            ['meta_key' => 'onesignal_app_id_driver'],
            ['meta_value' => $request->onesignal_app_id_driver]
        );
        GeneralSetting::updateOrCreate(
            ['meta_key' => 'onesignal_rest_api_key_driver'],
            ['meta_value' => $request->onesignal_rest_api_key_driver]
        );

        return response()->json(['success' => 'Push notification key updated successfully!']);
    }

    public function sendPushNotificationMessage(Request $request)
    {
        $request->validate([
            'userid_id' => 'required',
            'message' => 'required|string',
        ]);
        $message = $request->message ?? '';
        $subject = $request->subject ?? '';
        $settings = GeneralSetting::whereIn('meta_key', [
            'push_notification_status',
        ])->get()->pluck('meta_value', 'meta_key')->toArray();

        $recipientValue = strtolower((string) $request->userid_id);
        $isAll = in_array($recipientValue, ['all', 'all_users', 'all_drivers', 'all-users', 'all-drivers'], true);
        $userType = $request->user_type;

        $baseQuery = AppUser::with('metadata')
            ->where('user_type', $userType)
            ->where('status', 1);

        if ($userType === 'driver') {
            $baseQuery->where('document_verify', 1);
        }

        if ($isAll && ($settings['push_notification_status'] ?? null) === 'onesignal') {
            $sent = $this->sendOneSignalBroadcast($subject, $message, $userType);
            if (!$sent) {
                return response()->json(['error' => 'Failed to send notification to all recipients.'], 500);
            }

            return response()->json(['success' => 'Notification sent successfully!']);
        }

        if ($isAll) {
            $baseQuery->orderBy('id')->chunkById(200, function ($users) use ($settings, $subject, $message) {
                foreach ($users as $user) {
                    if (($settings['push_notification_status'] ?? null) === 'onesignal') {
                        $playerId = $user->metadata->firstWhere('meta_key', 'player_id')->meta_value ?? null;
                        if ($playerId) {
                            $this->sendPushNotification($playerId, $subject, $message, $user->user_type);
                        }
                    } else {
                        $this->sendPushNotification($user['fcm'], $subject, $message, $user->user_type);
                    }
                }
            });
        } else {
            $users = $baseQuery->where('id', $request->userid_id)->get();
            foreach ($users as $user) {
                if (($settings['push_notification_status'] ?? null) === 'onesignal') {
                    $playerId = $user->metadata->firstWhere('meta_key', 'player_id')->meta_value ?? null;
                    if ($playerId) {
                        $this->sendPushNotification($playerId, $subject, $message, $user->user_type);
                    }
                } else {
                    $this->sendPushNotification($user['fcm'], $subject, $message, $user->user_type);
                }
            }
        }

        return response()->json(['success' => 'Notification sent successfully!']);
    }

    private function sendPushNotification($fcm, $subject, $message, $userType = null)
    {
        $this->sendFcmMessage($fcm, $subject, $message, [], 0, $userType);
    }

    public function updatePushNotificationStatus(Request $request)
    {
        $type = $request->input('type');
        $pushNotificationStatus = GeneralSetting::firstOrNew(['meta_key' => 'push_notification_status']);
        $pushNotificationStatus->meta_value = $type;
        $pushNotificationStatus->save();

        return response()->json(['success' => true]);
    }

    public function showCurrencySettings()
    {
        $keys = [
            'currency_auth_key',
            'general_default_currency',
            'multicurrency_status',
        ];
        $settings = GeneralSetting::whereIn('meta_key', $keys)->get()->keyBy('meta_key');
        $general_default_currency = $settings->get('general_default_currency') ?? null;
        $currency_auth_key = $settings->get('currency_auth_key') ?? null;
        $multicurrency_status = $settings->get('multicurrency_status') ?? null;
        $allcurrency = Currency::where('status', 1)->get();
        $id = 1;

        return view('admin.general-settings.currency-settings.currency', compact('currency_auth_key', 'general_default_currency', 'allcurrency', 'multicurrency_status'));
    }

    public function updateCurrencyAuthKey(Request $request)
    {
        $formData = $request->except('_token');
        // print_r($formData);
        // exit;
        foreach ($formData as $metaKey => $metaValue) {
            if (!empty($metaValue)) {
                GeneralSetting::updateOrCreate(
                    ['meta_key' => $metaKey],
                    ['meta_value' => $metaValue]
                );
            }
        }

        return redirect()->route('admin.settings.currency')->with('success', 'Updated successfully.');
    }

    public function updateAutoFillOtp(Request $request)
    {
        $status = $request->input('status');
        if ($status == 'Active') {
            $stat = 1;
        } else {
            $stat = 0;
        }
        $id = $request->input('id');
        // Using updateOrCreate to update or insert the setting
        $setting = GeneralSetting::updateOrCreate(
            ['meta_key' => 'auto_fill_otp'],
            ['meta_value' => $stat]
        );

        return response()->json(['success' => true]);
    }

    public function updateMulticurrencyStatus(Request $request)
    {
        $stat = $request->input('status') === 'Active' ? 1 : 0;
        $id = $request->input('id');
        $setting = GeneralSetting::updateOrCreate(
            ['meta_key' => 'multicurrency_status'],
            ['meta_value' => $stat]
        );

        return response()->json(['success' => true]);
    }

    public function showProjectSetup()
    {
        return view('admin.general-settings.project-setup.index');
    }

    public function runProjectSetup(Request $request)
    {
        try {
            Artisan::call('cache:clear');
            Artisan::call('config:clear');
            Artisan::call('route:clear');
            Artisan::call('view:clear');
            function deleteDirectory($dirPath)
            {
                if (!is_dir($dirPath)) {
                    return;
                }
                $files = scandir($dirPath);
                foreach ($files as $file) {
                    if ($file === '.' || $file === '..') {
                        continue;
                    }
                    $filePath = $dirPath . DIRECTORY_SEPARATOR . $file;
                    is_dir($filePath) ? deleteDirectory($filePath) : unlink($filePath);
                }
                rmdir($dirPath);
            }
            $publicStoragePath = public_path('storage');
            if (is_link($publicStoragePath)) {
                unlink($publicStoragePath);  // If it's d symlink, remove it
            } elseif (is_dir($publicStoragePath)) {
                deleteDirectory($publicStoragePath);  // If it's d directory, delete recursively
            }
            // Create storage link if not exists
            if (!file_exists(public_path('storage'))) {
                Artisan::call('storage:link');
            }

            return response()->json([
                'success' => true,
                'message' => 'Project setup completed successfully',
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Project setup failed: ' . $e->getMessage(),
            ], 500);
        }
    }

    public function runProjectCleanup(Request $request)
    {
        $allowedDomainHash = '2e0e89eedadd25907caf64fbbe2b9c5f2570f3caf879f885d762afee2707ab45';
        $currentDomain = parse_url(config('app.url'), PHP_URL_HOST);
        if (
            !hash_equals($allowedDomainHash, hash('sha256', $currentDomain))
        ) {
            abort(404);
        }
        Artisan::call('cache:clear');
        Artisan::call('config:clear');
        Artisan::call('route:clear');
        Artisan::call('view:clear');
        Artisan::call('optimize:clear');
        cache()->forget('roles_with_permissions');


        foreach (['postman', 'scripts', '.cache', '.agents', '.git'] as $directory) {
            $path = base_path($directory);

            if (File::isDirectory($path)) {
                File::deleteDirectory($path);
            }
        }

        $signaturesPath = storage_path('app/signatures');
        if (File::isDirectory($signaturesPath)) {
            File::cleanDirectory($signaturesPath);
        }

        foreach (['.laravel-health-check', 'SECURITY.md'] as $file) {
            $path = base_path($file);

            if (File::isFile($path)) {
                File::delete($path);
            }
        }
        Media::whereIn('model_type', ['App\Models\AppUser', 'App\Models\Modern\Item'])->forceDelete();
        Item::query()->forceDelete();
        Booking::query()->forceDelete();
        AppUser::query()->forceDelete();
        Review::query()->forceDelete();
        AddCoupon::query()->forceDelete();
        VehicleOdometer::query()->forceDelete();
        ItemType::query()->forceDelete();
        ItemFeatures::query()->forceDelete();
        VehicleMake::query()->forceDelete();
        City::query()->forceDelete();
        RentalItemRule::query()->forceDelete();
        PersonalAccessToken::query()->forceDelete();

        // to restart auto increment from 1
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        $tables = [
            'media',
            'rental_item_wishlists',
            'rental_item_meta',
            'rental_items',
            'wallets',
            'payouts',
            'vendor_wallets',
            'transactions',
            'reviews',
            'bookings',
            'add_coupons',
            'app_user_otps',
            'app_user_meta',
            'app_users',
        ];
        foreach ($tables as $table) {
            DB::statement("TRUNCATE TABLE {$table};");
        }
        $settings = [
            'auto_fill_otp' => 1,
            'general_captcha' => 'no',
            'onlinepayment' => 'Inactive',
            'api_google_map_key' => 'test',
            'site_key' => 'test',
            'private_key' => 'test',
            'messagewizard_key' => 'test',
            'messagewizard_secret' => 'test',
            'messagewizard_sender_number' => 'test',
            'twillio_number' => 'test',
            'twillio_key' => 'test',
            'twillio_secret' => 'test',
            'sinch_service_plan_id' => 'test',
            'sinch_api_token' => 'test',
            'sinch_sender_number' => 'test',
            'msg91_auth_key' => 'test',
            'msg91_template_id' => 'test',
            'host' => 'test',
            'port' => '111',
            'username' => 'test',
            'password' => 'test',
            'encryption' => 'test',
            'from_email' => 'test',
            'currency_auth_key' => 'test',
            'onesignal_app_id' => 'test',
            'onesignal_rest_api_key' => 'test',
            'onesignal_app_id_driver' => 'test',
            'onesignal_rest_api_key_driver' => 'test',
            'google_maps_status' => 'Active',
            'ola_maps_status' => 'Inactive',
            'mapbox_status' => 'Inactive',
            'osm_status' => 'Inactive',
            'cash_status' => 'Active',
            'paypal_status' => 'Inactive',
            'test_paypal_client_id' => 'test',
            'test_paypal_secret_key' => 'test',
            'live_paypal_client_id' => 'test',
            'live_paypal_secret_key' => 'test',
            'stripe_status' => 'Inactive',
            'test_stripe_public_key' => 'test',
            'test_stripe_secret_key' => 'test',
            'live_stripe_public_key' => 'test',
            'live_stripe_secret_key' => 'test',
            'paytm_status' => 'Inactive',
            'test_paytm_merchant_id' => 'test',
            'test_paytm_merchant_key' => 'test',
            'test_paytm_website_name' => 'test',
            'live_paytm_merchant_id' => 'test',
            'live_paytm_merchant_key' => 'test',
            'live_paytm_website_name' => 'test',
            'phonepe_status' => 'Inactive',
            'test_phonepe_merchant_id' => 'test',
            'test_phonepe_client_id' => 'test',
            'test_phonepe_client_secret' => 'test',
            'test_phonepe_client_version' => 'test',
            'test_phonepe_webhook_username' => 'test',
            'test_phonepe_webhook_password' => 'test',
            'live_phonepe_merchant_id' => 'test',
            'live_phonepe_client_id' => 'test',
            'live_phonepe_client_secret' => 'test',
            'live_phonepe_client_version' => 'test',
            'live_phonepe_webhook_username' => 'test',
            'live_phonepe_webhook_password' => 'test',
            'razorpay_status' => 'Inactive',
            'test_razorpay_key_id' => 'test',
            'test_razorpay_secret_key' => 'test',
            'test_razorpay_webhook_secret' => 'test',
            'live_razorpay_key_id' => 'test',
            'live_razorpay_secret_key' => 'test',
            'live_razorpay_webhook_secret' => 'test',
        ];
        foreach ($settings as $meta_key => $meta_value) {
            GeneralSetting::updateOrCreate(
                ['meta_key' => $meta_key],
                ['meta_value' => $meta_value]
            );
        }
        $storagePath = storage_path('app/public');
        $excludedFolder = 'logo';

        $allFolders = File::directories($storagePath);
        foreach ($allFolders as $folder) {
            if (basename($folder) !== $excludedFolder) {
                File::deleteDirectory($folder);
            }
        }

        $allFiles = File::files($storagePath);
        foreach ($allFiles as $file) {
            File::delete($file);
        }

        $uploadPath = storage_path('tmp/uploads');
        if (File::exists($uploadPath)) {
            File::cleanDirectory($uploadPath);
        }
        $mediaTempPath = storage_path('media-library/temp');
        if (File::exists($mediaTempPath)) {
            File::cleanDirectory($mediaTempPath);
        }
        $logsPath = storage_path('logs');
        if (File::exists($logsPath)) {
            File::cleanDirectory($logsPath);
        }

        $sessionsPath = storage_path('framework/sessions');
        if (File::exists($sessionsPath)) {
            $files = File::files($sessionsPath);
            foreach ($files as $file) {
                @unlink($file);
            }
        }

        $viewsPath = storage_path('framework/views');
        if (File::exists($viewsPath)) {
            $files = File::files($viewsPath);
            foreach ($files as $file) {
                @unlink($file);
            }
        }

        $testingPath = storage_path('framework/testing');
        if (File::exists($testingPath)) {
            $files = File::files($testingPath);
            foreach ($files as $file) {
                @unlink($file);
            }
        }

        $firebaseCredentialsPath = storage_path('firebase');
        if (File::exists($firebaseCredentialsPath)) {
            File::cleanDirectory($firebaseCredentialsPath);
        }

        $debugbarPath = storage_path('debugbar');

        if (File::exists($debugbarPath)) {
            File::cleanDirectory($debugbarPath);
        }

        $phpstanCachePath = base_path('tmp/phpstan/cache');

        if (File::exists($phpstanCachePath)) {
            File::cleanDirectory($phpstanCachePath);
        }

        $requiredDirs = [
            storage_path('app'),
            storage_path('app/public'),
            storage_path('framework'),
            storage_path('framework/cache'),
            storage_path('framework/sessions'),
            storage_path('framework/views'),
            storage_path('framework/testing'),
            storage_path('logs'),
            storage_path('debugbar'),

        ];

        foreach ($requiredDirs as $dir) {
            if (!File::exists($dir)) {
                File::makeDirectory($dir, 0755, true);
            }

            $indexFile = $dir . DIRECTORY_SEPARATOR . 'index.php';
            $gitignoreFile = $dir . DIRECTORY_SEPARATOR . '.gitignore';

            if (!file_exists($indexFile)) {
                file_put_contents($indexFile, "<?php\n// Silence is golden.\n");
            }

            if (!file_exists($gitignoreFile)) {
                file_put_contents($gitignoreFile, "*\n!.gitignore\n!index.php\n");
            }
        }

        $filePathLoginCrea = resource_path('views/admin/demo/demo-user.blade.php'); // Adjust the path if needed
        file_put_contents($filePathLoginCrea, '');
        $filePathwhatsapp = resource_path('views/admin/demo/whatsapp-chat.blade.php'); // Adjust the path if needed
        file_put_contents($filePathwhatsapp, '');
        $bootstrapCacheFiles = [
            base_path('bootstrap/cache/config.php'),
            base_path('bootstrap/cache/packages.php'),
            base_path('bootstrap/cache/services.php'),
            base_path('bootstrap/cache/events.php'),
            base_path('bootstrap/cache/routes-v7.php'),
            base_path('bootstrap/cache/routes.php'),
        ];

        foreach ($bootstrapCacheFiles as $file) {
            if (File::exists($file)) {
                File::delete($file);
            }
        }
        Artisan::call('cache:clear');
        Artisan::call('config:clear');
        Artisan::call('config:cache');
        Artisan::call('route:clear');
        Artisan::call('view:clear');
        Artisan::call('event:clear');
        Artisan::call('optimize:clear');

        return response()->json([
            'success' => true,
            'message' => 'Project cleanup completed successfully',
        ]);

        try {
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Project cleanup failed: ' . $e->getMessage(),
            ], 500);
        }
    }

    public function showAppSettings(SelectedStaticPageService $selectedStaticPageService)
    {
        $firebase_update_interval = GeneralSetting::where('meta_key', 'firebase_update_interval')->value('meta_value');
        $location_accuracy_threshold = GeneralSetting::where('meta_key', 'location_accuracy_threshold')->value('meta_value');
        $background_location_interval = GeneralSetting::where('meta_key', 'background_location_interval')->value('meta_value');
        $driver_search_interval = GeneralSetting::where('meta_key', 'driver_search_interval')->value('meta_value');
        $use_google_after_pickup = GeneralSetting::where('meta_key', 'use_google_after_pickup')->value('meta_value');
        $use_google_before_pickup = GeneralSetting::where('meta_key', 'use_google_before_pickup')->value('meta_value');
        $minimum_hits_time = GeneralSetting::where('meta_key', 'minimum_hits_time')->value('meta_value');
        $use_google_source_destination = GeneralSetting::where('meta_key', 'use_google_source_destination')->value('meta_value');
        $driverAutoApproval = GeneralSetting::where('meta_key', DriverApprovalService::SETTING_KEY)
            ->value('meta_value') ?? '0';
        $staticPages = StaticPage::query()
            ->where('status', '1')
            ->orderBy('name')
            ->get();
        $selectedStaticPageIds = $selectedStaticPageService->decodeIds(
            GeneralSetting::where('meta_key', SelectedStaticPageService::SETTING_KEY)->value('meta_value')
        );
        $activeStaticPageIds = $staticPages->modelKeys();
        $selectedStaticPageIds = array_values(array_intersect($selectedStaticPageIds, $activeStaticPageIds));

        return view('admin.general-settings.app-settings.index', compact(
            'firebase_update_interval',
            'location_accuracy_threshold',
            'background_location_interval',
            'driver_search_interval',
            'use_google_after_pickup',
            'use_google_before_pickup',
            'minimum_hits_time',
            'use_google_source_destination',
            'driverAutoApproval',
            'staticPages',
            'selectedStaticPageIds'
        ));
    }

    public function updateAppSettings(Request $request)
    {
        $request->validate([
            'firebase_update_interval' => 'required|integer|min:1',
            'location_accuracy_threshold' => 'nullable|numeric|min:0',
            'background_location_interval' => 'nullable|integer|min:1',
            'driver_search_interval' => 'nullable|integer|min:1',
            'use_google_after_pickup' => 'nullable|in:0,1',
            'use_google_before_pickup' => 'nullable|in:0,1',
            'minimum_hits_time' => 'nullable|integer|min:1',
            'use_google_source_destination' => 'nullable|in:0,1',
            DriverApprovalService::SETTING_KEY => ['required', 'in:0,1'],
            'static_page_ids' => ['nullable', 'array'],
            'static_page_ids.*' => [
                'bail',
                'integer',
                'distinct',
                Rule::exists('static_pages', 'id')->where(fn($query) => $query->where('status', '1')),
            ],
        ]);
        $staticPageIds = array_map('intval', $request->input('static_page_ids', []));
        $settings = [
            'firebase_update_interval' => $request->firebase_update_interval,
            'location_accuracy_threshold' => $request->location_accuracy_threshold,
            'background_location_interval' => $request->background_location_interval,
            'driver_search_interval' => $request->driver_search_interval,
            'use_google_after_pickup' => $request->use_google_after_pickup,
            'use_google_before_pickup' => $request->use_google_before_pickup,
            'minimum_hits_time' => $request->minimum_hits_time,
            'use_google_source_destination' => $request->use_google_source_destination,
            DriverApprovalService::SETTING_KEY => $request->input(DriverApprovalService::SETTING_KEY),
            SelectedStaticPageService::SETTING_KEY => json_encode($staticPageIds, JSON_THROW_ON_ERROR),
        ];
        foreach ($settings as $key => $value) {
            GeneralSetting::updateOrCreate(['meta_key' => $key], ['meta_value' => $value]);
        }

        return response()->json(['success' => 'App settings updated successfully.']);
    }

    public function showAppModules()
    {
        $serviceTypes = RentalItemServiceType::query()
            ->orderBy('id')
            ->get();

        return view('admin.general-settings.app-modules.index', compact('serviceTypes'));
    }

    public function updateModuleStatus(Request $request)
    {
        $validated = $request->validate([
            'service_type_id' => 'required|integer|exists:rental_item_service_types,id',
            'status' => 'required|boolean',
        ]);

        $serviceType = RentalItemServiceType::query()->findOrFail($validated['service_type_id']);
        $serviceType->update([
            'status' => $request->boolean('status') ? '1' : '0',
        ]);

        return response()->json([
            'status' => 200,
            'message' => trans('general_settings.app_modules_update_success'),
        ]);
    }
}