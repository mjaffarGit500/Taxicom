<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\EmailSmsNotification;
use App\Rules\ValidRichText;
use App\Security\RichTextSanitizer;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EmailController extends Controller
{
    public function template($id)
    {
        abort_if(Gate::denies('email_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $emaildata = EmailSmsNotification::findOrFail($id);
        $AllEmailRecord = EmailSmsNotification::all();

        return view('admin.email_templates.index', compact('emaildata', 'AllEmailRecord'));
    }

    public function templatecreate(Request $request, $id)
    {
        abort_if(Gate::denies('email_update'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $request->validate([
            'body' => ['nullable', new ValidRichText],
            'vendorbody' => ['nullable', new ValidRichText],
            'adminbody' => ['nullable', new ValidRichText],
        ]);

        $emaildata = EmailSmsNotification::findOrFail($id);

        $type = $request->input('type', 'user');

        if ($type === 'admin') {
            $emaildata->update($request->only([
                'adminsubject',
                'adminbody',
                'adminemailsent',
                'adminsmssent',
                'adminpushsent',
                'adminsms',
                'adminpush_notification',
            ]));
        } elseif ($type === 'vendor') {
            $emaildata->update($request->only([
                'vendorsubject',
                'vendorbody',
                'vendoremailsent',
                'vendorsmssent',
                'vendorpushsent',
                'vendorsms',
                'vendorpush_notification',
            ]));
        } else {
            $emaildata->update($request->only([
                'subject',
                'body',
                'emailsent',
                'smssent',
                'pushsent',
                'sms',
                'push_notification',
            ]));
        }

        return redirect()->back()->with('success', trans('global.data_has_been_submitted'));
    }

    public function preview(Request $request, RichTextSanitizer $sanitizer)
    {
        abort_if(Gate::denies('email_update'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $validated = $request->validate([
            'html' => ['nullable', 'string', new ValidRichText],
        ]);

        return response()->json([
            'html' => $sanitizer->sanitize($validated['html'] ?? ''),
        ]);
    }
}
