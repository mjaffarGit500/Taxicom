<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Requests\Admin\MassDestroyStaticPageRequest;
use App\Http\Requests\Admin\StoreStaticPageRequest;
use App\Http\Requests\Admin\UpdateStaticPageRequest;
use App\Models\StaticPage;
use Gate;
use Illuminate\Http\Request;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;

class StaticPageController extends Controller
{
    use MediaUploadingTrait;

    public function index(Request $request)
    {
        abort_if(Gate::denies('static_page_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if ($request->ajax()) {
            $query = StaticPage::query()->select(sprintf('%s.*', (new StaticPage)->table));
            $table = Datatables::of($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');

            $table->editColumn('actions', function ($row) {
                $viewGate = 'static_page_show';
                $editGate = 'static_page_edit';
                $deleteGate = 'static_page_delete';
                $crudRoutePart = 'static_pages';

                return view('admin.static_pages.partials.actions', compact(
                    'viewGate',
                    'editGate',
                    'deleteGate',
                    'crudRoutePart',
                    'row'
                ));
            });

            $table->editColumn('id', function ($row) {
                return $row->id ? $row->id : '';
            });
            $table->editColumn('name', function ($row) {
                return $row->getTranslation('name') ? $row->getTranslation('name') : '';
            });
            $table->editColumn('status', function ($row) {
                return StaticPage::STATUS_SELECT[(int) $row->status] ?? '';
            });
            $table->addColumn('status_value', function ($row) {
                return (int) $row->status;
            });

            $table->rawColumns(['actions', 'placeholder']);

            return $table->make(true);
        }

        return view('admin.static_pages.index');
    }

    public function create()
    {
        abort_if(Gate::denies('static_page_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.static_pages.create');
    }

    public function store(StoreStaticPageRequest $request)
    {
        $data = $request->except(['name', 'content']);
        $data['name'] = $request->name[config('global.primary_language', 'en')] ?? '';
        $data['content'] = $request->content[config('global.primary_language', 'en')] ?? '';
        $staticPage = StaticPage::create($data);

        if ($media = $request->input('ck-media', false)) {
            Media::whereIn('id', $media)->update(['model_id' => $staticPage->id]);
        }

        return redirect()->route('admin.static_pages.index');
    }

    public function edit(StaticPage $staticPage)
    {
        abort_if(Gate::denies('static_page_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.static_pages.edit', compact('staticPage'));
    }

    public function update(UpdateStaticPageRequest $request, StaticPage $staticPage)
    {
        $data = $request->except(['name', 'content']);
        $data['name'] = $request->name[config('global.primary_language', 'en')] ?? '';
        $data['content'] = $request->content[config('global.primary_language', 'en')] ?? '';
        $staticPage->update($data);

        return redirect()->route('admin.static_pages.index');
    }

    public function show(StaticPage $staticPage)
    {
        abort_if(Gate::denies('static_page_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.static_pages.show', compact('staticPage'));
    }

    public function destroy(StaticPage $staticPage)
    {
        abort_if(Gate::denies('static_page_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $staticPage->delete();

        return response()->json([
            'status' => 'success',
            'message' => trans('global.delete_success'),
        ]);
    }

    public function massDestroy(MassDestroyStaticPageRequest $request)
    {
        abort_if(Gate::denies('static_page_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $staticPages = StaticPage::find(request('ids'));

        foreach ($staticPages as $staticPage) {
            $staticPage->delete();
        }

        return response()->json([
            'message' => trans('global.entries_deleted'),
        ]);
    }

    public function storeCKEditorImages(Request $request)
    {
        abort_if(Gate::denies('static_page_create') && Gate::denies('static_page_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $model = new StaticPage;
        $model->id = $request->input('crud_id', 0);
        $model->exists = true;
        $media = $model->addMediaFromRequest('upload')->toMediaCollection('ck-media');

        return response()->json(['id' => $media->id, 'url' => $media->getUrl()], Response::HTTP_CREATED);
    }

    public function updateStatus(Request $request)
    {
        if (Gate::denies('static_page_edit')) {
            return response()->json([
                'status' => 403,
                'message' => "You don't have permission to perform this action.",
            ], 403);
        }

        $product_status = StaticPage::where('id', $request->pid)->update(['status' => $request->status]);
        if ($product_status) {
            return response()->json([
                'status' => 200,
                'message' => trans('global.status_updated_successfully'),
            ]);
        } else {
            return response()->json([
                'status' => 500,
                'message' => 'something went wrong. Please try again.',
            ]);
        }
    }
}
