<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\GeneralSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class PaymentMethodController extends Controller
{
    protected $paymentMethods = [
        'paypal' => [
            'meta_keys' => [
                'test_paypal_client_id',
                'test_paypal_secret_key',
                'test_paypal_merchant_id',
                'test_paypal_webhook_id',
                'live_paypal_client_id',
                'live_paypal_secret_key',
                'live_paypal_merchant_id',
                'live_paypal_webhook_id',
                'paypal_options',
                'paypal_status',
                'paypal_logo',
                'onlinepayment',
            ],
            'view' => 'admin.general-settings.payment-methods.form',
            'options_field' => 'paypal_options',
            'status_field' => 'paypal_status',
            'title' => 'PayPal',
            'fields' => ['client_id', 'secret_key', 'merchant_id', 'webhook_id'],
        ],
        'stripe' => [
            'meta_keys' => [
                'test_stripe_public_key',
                'test_stripe_secret_key',
                'test_stripe_webhook_secret',
                'live_stripe_public_key',
                'live_stripe_secret_key',
                'live_stripe_webhook_secret',
                'stripe_options',
                'stripe_status',
                'stripe_logo',
                'onlinepayment',
            ],
            'view' => 'admin.general-settings.payment-methods.form',
            'options_field' => 'stripe_options',
            'status_field' => 'stripe_status',
            'title' => 'Stripe',
            'fields' => ['public_key', 'secret_key', 'webhook_secret'],
        ],
        'razorpay' => [
            'meta_keys' => [
                'test_razorpay_key_id',
                'test_razorpay_secret_key',
                'test_razorpay_webhook_secret',
                'live_razorpay_key_id',
                'live_razorpay_secret_key',
                'live_razorpay_webhook_secret',
                'razorpay_options',
                'razorpay_status',
                'razorpay_logo',
                'onlinepayment',
            ],
            'view' => 'admin.general-settings.payment-methods.form',
            'options_field' => 'razorpay_options',
            'status_field' => 'razorpay_status',
            'title' => 'Razorpay',
            'fields' => ['key_id', 'secret_key', 'webhook_secret'],
        ],
        'paytm' => [
            'meta_keys' => [
                'test_paytm_merchant_id',
                'test_paytm_merchant_key',
                'test_paytm_website_name',
                'live_paytm_merchant_id',
                'live_paytm_merchant_key',
                'live_paytm_website_name',
                'paytm_options',
                'paytm_status',
                'paytm_logo',
                'onlinepayment',
            ],
            'view' => 'admin.general-settings.payment-methods.form',
            'options_field' => 'paytm_options',
            'status_field' => 'paytm_status',
            'title' => 'Paytm',
            'fields' => ['merchant_id', 'merchant_key', 'website_name'],
        ],
        'phonepe' => [
            'meta_keys' => [
                'test_phonepe_merchant_id',
                'test_phonepe_client_id',
                'test_phonepe_client_secret',
                'test_phonepe_client_version',
                'test_phonepe_webhook_username',
                'test_phonepe_webhook_password',
                'live_phonepe_merchant_id',
                'live_phonepe_client_id',
                'live_phonepe_client_secret',
                'live_phonepe_client_version',
                'live_phonepe_webhook_username',
                'live_phonepe_webhook_password',
                'phonepe_options',
                'phonepe_status',
                'phonepe_logo',
                'onlinepayment',
            ],
            'view' => 'admin.general-settings.payment-methods.form',
            'options_field' => 'phonepe_options',
            'status_field' => 'phonepe_status',
            'title' => 'PhonePe',
            'fields' => ['merchant_id', 'client_id', 'client_secret', 'client_version', 'webhook_username', 'webhook_password'],
        ],
        'transbank' => [
            'meta_keys' => [
                'test_transbank_client_id',
                'test_transbank_secret_key',
                'live_transbank_client_id',
                'live_transbank_secret_key',
                'transbank_options',
                'transbank_status',
                'transbank_logo',
                'onlinepayment',
            ],
            'view' => 'admin.general-settings.payment-methods.form',
            'options_field' => 'transbank_options',
            'status_field' => 'transbank_status',
            'title' => 'Transbank',
            'fields' => ['client_id', 'secret_key'],
        ],
        'paystack' => [
            'meta_keys' => [
                'test_paystack_public_key',
                'test_paystack_secret_key',
                'live_paystack_public_key',
                'live_paystack_secret_key',
                'paystack_options',
                'paystack_status',
                'paystack_logo',
                'onlinepayment',
            ],
            'view' => 'admin.general-settings.payment-methods.form',
            'options_field' => 'paystack_options',
            'status_field' => 'paystack_status',
            'title' => 'Paystack',
            'fields' => ['public_key', 'secret_key'],
        ],
        'flutterwave' => [
            'meta_keys' => [
                'test_flutterwave_public_key',
                'test_flutterwave_secret_key',
                'live_flutterwave_public_key',
                'live_flutterwave_secret_key',
                'flutterwave_options',
                'flutterwave_status',
                'flutterwave_logo',
                'onlinepayment',
            ],
            'view' => 'admin.general-settings.payment-methods.form',
            'options_field' => 'flutterwave_options',
            'status_field' => 'flutterwave_status',
            'title' => 'Flutterwave',
            'fields' => ['public_key', 'secret_key'],
        ],
        'paydunya' => [
            'meta_keys' => [
                'test_payaunya_master_key',
                'test_payaunya_private_key',
                'test_payaunya_status',
                'test_payaunya_token',
                'test_paydunya_master_key',
                'test_paydunya_private_key',
                'test_paydunya_token',
                'test_paydunya_currency',
                'live_payaunya_master_key',
                'live_payaunya_private_key',
                'live_payaunya_status',
                'live_payaunya_token',
                'live_paydunya_master_key',
                'live_paydunya_private_key',
                'live_paydunya_token',
                'live_paydunya_currency',
                'payaunya_options',
                'paydunya_status',
                'paydunya_logo',
                'onlinepayment',
            ],
            'view' => 'admin.general-settings.payment-methods.form',
            'options_field' => 'payaunya_options',
            'status_field' => 'paydunya_status',
            'title' => 'Payaunya',
            'fields' => ['master_key', 'private_key', 'token', 'currency'],
        ],
        'cash' => [
            'meta_keys' => [
                'cash_status',
                'cash_logo',
                'onlinepayment',
            ],
            'view' => 'admin.general-settings.payment-methods.form',
            'options_field' => null,
            'status_field' => 'cash_status',
            'title' => 'Cash',
            'fields' => [],
        ],
    ];

    public function index($method)
    {
        if (! isset($this->paymentMethods[$method])) {
            abort(404, 'Payment method not found');
        }

        $config = $this->paymentMethods[$method];
        $settings = GeneralSetting::whereIn('meta_key', $config['meta_keys'])
            ->get()
            ->keyBy('meta_key');

        $viewData = [
            'method' => $method,
            'title' => $config['title'],
            'options_field' => $config['options_field'],
            'status_field' => $config['status_field'],
            'fields_per_method' => $config['fields'] ?? [],
        ];

        foreach ($config['meta_keys'] as $key) {
            $viewData[$key] = $settings->get($key);
        }
        $status = $settings->get($config['status_field']);

        return view($config['view'], array_merge($viewData, [
            'status' => $status, // pass explicitly
        ]));
    }

    public function update(Request $request, $method)
    {
        if (! isset($this->paymentMethods[$method])) {
            return redirect()->back()->with('error', 'Payment method not found.');
        }

        $config = $this->paymentMethods[$method];
        $logoKey = $method.'_logo';

        if ($request->hasFile($logoKey)) {
            $this->deletePaymentMethodLogo($logoKey);
            $file = $request->file($logoKey);
            $fileName = rand(10, 1000000).'.'.$file->getClientOriginalExtension();
            $path = $file->storeAs('payment-logos', $fileName, 'public');
            GeneralSetting::updateOrCreate(
                ['meta_key' => $logoKey],
                ['meta_value' => $path]
            );
        } elseif ($request->boolean('delete_'.$logoKey)) {
            $this->deletePaymentMethodLogo($logoKey);
            GeneralSetting::where('meta_key', $logoKey)->delete();
        }

        $formData = $request->except(array_merge(['_token', $logoKey, 'delete_'.$logoKey]));
        foreach ($formData as $metaKey => $metaValue) {
            if (! empty($metaValue)) {
                GeneralSetting::updateOrCreate(
                    ['meta_key' => $metaKey],
                    ['meta_value' => $metaValue]
                );
            }
        }

        return redirect()->back()->with('success', 'Updated successfully');
    }

    public function updateStatus(Request $request, $method)
    {
        if (! isset($this->paymentMethods[$method])) {
            return response()->json([
                'status' => 400,
                'message' => trans('global.something_went_wrong'),
            ]);
        }

        $statusField = $this->paymentMethods[$method]['status_field'] ?? null;

        if (! $statusField) {
            return response()->json([
                'status' => 400,
                'message' => trans('global.something_went_wrong'),
            ]);

        }
        $status = strtolower($request->status) === '1' ? 'Active' : 'Inactive';
        GeneralSetting::updateOrCreate(
            ['meta_key' => $statusField],
            ['meta_value' => $status]
        );

        return response()->json([
            'status' => 200,
            'message' => trans('global.status_updated_successfully'),
        ]);
    }

    public function updateOnlineStatus(Request $request)
    {
        $status = $request->input('status');

        GeneralSetting::updateOrCreate(
            ['meta_key' => 'onlinepayment'],
            ['meta_value' => $status]
        );

        return response()->json(['success' => 'Updated Successfully']);
    }

    public function removeLogo(Request $request, $method)
    {
        if (! isset($this->paymentMethods[$method])) {
            return response()->json(['message' => 'Payment method not found.'], 404);
        }

        $logoKey = $method.'_logo';
        $this->deletePaymentMethodLogo($logoKey);
        GeneralSetting::where('meta_key', $logoKey)->delete();

        return response()->json([
            'status' => 200,
            'message' => ucfirst($method).' logo removed successfully.',
            'asset' => $logoKey,
        ]);
    }

    private function deletePaymentMethodLogo(string $metaKey): void
    {
        $path = GeneralSetting::where('meta_key', $metaKey)->value('meta_value');
        if ($path && Storage::disk('public')->exists($path)) {
            Storage::disk('public')->delete($path);
        }
    }
}
