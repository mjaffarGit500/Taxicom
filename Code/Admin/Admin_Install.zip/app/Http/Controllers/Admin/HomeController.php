<?php

namespace App\Http\Controllers\Admin;

use App\Models\AppUser;
use App\Models\Booking;
use App\Models\GeneralSetting;
use App\Models\Modern\Item;
use App\Models\Module;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class HomeController
{
    public function index(Request $request)
    {

        $module = Cache::remember('default_module', 3600, function () {
            return Module::where('default_module', '1')->firstOrFail();
        });

        $moduleId = $module->id;
        $moduleName = $module->name;
        $currency = Cache::remember('general_default_currency', 3600, function () {
            return GeneralSetting::where('meta_key', 'general_default_currency')->first();
        });

        $installerWarning = installerExists();
        [$rangeStart, $rangeEnd] = $this->resolveDashboardRange($request);
        $selectedFilter = strtolower((string) $request->query('filter', 'month'));
        $currentYear = (int) Carbon::now()->year;
        $years = range($currentYear, $currentYear - 19);
        $taxiCardMode = strtolower((string) $request->query('taxi_mode', 'year'));
        $revenueCardMode = strtolower((string) $request->query('revenue_mode', 'year'));
        $taxiCardYear = (int) $request->query('taxi_year', $request->query('year', $currentYear));
        $revenueCardYear = (int) $request->query('revenue_year', $request->query('year', $currentYear));
        $rangeFromYmd = $rangeStart->format('Y-m-d');
        $rangeToYmd = $rangeEnd->format('Y-m-d');
        $rangeLabel = $rangeFromYmd . ' - ' . $rangeToYmd;

        $taxiStats = $this->fetchTaxiParcelStats($moduleId, $taxiCardMode, $taxiCardYear);
        $revenueStats = $this->fetchRevenueStats($moduleId, $revenueCardMode, $revenueCardYear);
        $cardStatsPayload = [
            'taxi' => $taxiStats,
            'revenue' => $revenueStats,
        ];

        if ($request->boolean('cards_ajax')) {
            return response()->json($cardStatsPayload);
        }

        $metrics = $this->fetchDashboardMetrics($moduleId, $rangeStart, $rangeEnd);
        [$recentTaxi, $recentParcel] = $this->fetchRecentActivity($moduleId, $rangeStart, $rangeEnd);

        $topDrivers = $this->fetchTopDrivers($moduleId, $rangeStart, $rangeEnd);
        $topRiders = $this->fetchTopRiders($moduleId, $rangeStart, $rangeEnd);

        $financialCounts = $this->fetchFinancialCounters($moduleId, $rangeStart, $rangeEnd);
        $metricDateParams = [
            'filter' => $selectedFilter,
            'from' => $rangeFromYmd,
            'to' => $rangeToYmd,
        ];
        $metricCards = $this->buildMetricCards($metrics, $financialCounts, $metricDateParams);

        $latestUsersData = $this->getLatestUsersData();
        $latestBookingsData = $this->getLatestBookingsData($moduleId);

        return view('home', compact(
            'metrics',
            'currency',
            'moduleName',
            'moduleId',
            'latestUsersData',
            'latestBookingsData',
            'installerWarning',
            'rangeStart',
            'rangeEnd',
            'rangeLabel',
            'rangeFromYmd',
            'rangeToYmd',
            'selectedFilter',
            'years',
            'currentYear',
            'taxiCardMode',
            'taxiCardYear',
            'revenueCardMode',
            'revenueCardYear',
            'recentTaxi',
            'recentParcel',
            'topDrivers',
            'topRiders',
            'cardStatsPayload',
            'metricCards',
        ));
    }

    private function fetchDashboardMetrics($moduleId, Carbon $rangeStart, Carbon $rangeEnd)
    {
        $driverMetrics = Cache::remember('driver_metrics_' . $rangeStart->format('Ymd') . '_to_' . $rangeEnd->format('Ymd'), 300, function () use ($rangeStart, $rangeEnd) {
            $today = Carbon::today()->toDateString();

            return AppUser::selectRaw("
                COUNT(*) as total_drivers,
                SUM(CASE WHEN user_type = 'driver' AND status = 1 THEN 1 ELSE 0 END) as active_drivers,
                SUM(CASE WHEN user_type = 'driver' AND status = 0 THEN 1 ELSE 0 END) as inactive_drivers,
                SUM(CASE WHEN user_type = 'driver' AND host_status = '2' THEN 1 ELSE 0 END) as requested_drivers,
                SUM(CASE WHEN user_type = 'driver' AND DATE(created_at) = ? THEN 1 ELSE 0 END) as today_new_drivers
            ", [$today])
                ->where('user_type', 'driver')
                ->whereBetween('created_at', [$rangeStart, $rangeEnd])
                ->first();
        });

        // Fetch ride (item) metrics
        $riderMetrics = Cache::remember('rider_metrics_' . $rangeStart->format('Ymd') . '_to_' . $rangeEnd->format('Ymd'), 300, function () use ($rangeStart, $rangeEnd) {
            $today = Carbon::today()->toDateString();

            return AppUser::selectRaw("
        COUNT(*) as total_riders,
        SUM(CASE WHEN user_type = 'user' AND status = 1 THEN 1 ELSE 0 END) as active_riders,
        SUM(CASE WHEN user_type = 'user' AND status = 0 THEN 1 ELSE 0 END) as inactive_riders,
        SUM(CASE WHEN user_type = 'user' AND DATE(created_at) = ? THEN 1 ELSE 0 END) as today_new_riders
    ", [$today])
                ->where('user_type', 'user')
                ->whereBetween('created_at', [$rangeStart, $rangeEnd])
                ->first();
        });

        // Fetch booking (ride status) metrics
        // Cache::forget("booking_metrics_{$moduleId}");
        $bookingMetrics = Cache::remember("booking_metrics_{$moduleId}_" . $rangeStart->format('Ymd') . '_to_' . $rangeEnd->format('Ymd'), 300, function () use ($moduleId, $rangeStart, $rangeEnd) {
            $today = Carbon::today()->toDateString();

            return Booking::query()->selectRaw("
        COUNT(*) as total_paid_bookings,
        SUM(CASE WHEN status = 'Ongoing' THEN 1 ELSE 0 END) as running_rides,
        SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) as completed_rides,
        SUM(CASE WHEN status = 'Cancelled' THEN 1 ELSE 0 END) as cancelled_rides,
        SUM(CASE WHEN status = 'Rejected' THEN 1 ELSE 0 END) as rejected_rides,
        SUM(CASE WHEN status = 'Ongoing' AND DATE(created_at) = ? THEN 1 ELSE 0 END) as today_running_rides,
        SUM(CASE WHEN status = 'Completed' AND DATE(created_at) = ? THEN 1 ELSE 0 END) as today_completed_rides,
        COALESCE(SUM(total), 0) as total_income,
        COALESCE(SUM(admin_commission), 0) as total_revenue,
        SUM(CASE WHEN DATE(created_at) = ? THEN admin_commission ELSE 0 END) as today_revenue
    ", [
                $today,        // for today_running_rides
                $today,        // for today_completed_rides
                $today,
            ])
                ->where('module', $moduleId)
                ->where('payment_status', 'paid')
                ->whereNull('deleted_at')
                ->whereBetween('created_at', [$rangeStart, $rangeEnd])
                ->first();
        });

        return [
            'total_drivers' => [
                'chart_title' => 'total drivers',
                'total_number' => $driverMetrics->total_drivers,
            ],
            'total_active_drivers' => [
                'chart_title' => 'total active drivers',
                'total_number' => $driverMetrics->active_drivers,
            ],
            'total_inactive_drivers' => [
                'chart_title' => 'total inactive drivers',
                'total_number' => $driverMetrics->inactive_drivers,
            ],
            'total_requested_drivers' => [
                'chart_title' => 'total requested drivers',
                'total_number' => $driverMetrics->requested_drivers,
            ],
            'total_riders' => [
                'chart_title' => 'total riders',
                'total_number' => $riderMetrics->total_riders,
            ],
            'total_active_riders' => [
                'chart_title' => 'total active riders',
                'total_number' => $riderMetrics->active_riders,
            ],
            'today_new_riders' => [
                'chart_title' => 'today new riders',
                'total_number' => $riderMetrics->today_new_riders,
            ],
            'total_paid_bookings' => [
                'chart_title' => 'total paid bookings',
                'total_number' => $bookingMetrics->total_paid_bookings,
            ],
            'running_rides' => [
                'chart_title' => 'running rides',
                'total_number' => $bookingMetrics->running_rides,
            ],
            'completed_rides' => [
                'chart_title' => 'completed rides',
                'total_number' => $bookingMetrics->completed_rides,
            ],
            'cancelled_rides' => [
                'chart_title' => 'cancelled rides',
                'total_number' => $bookingMetrics->cancelled_rides,
            ],
            'rejected_rides' => [
                'chart_title' => 'rejected rides',
                'total_number' => $bookingMetrics->rejected_rides,
            ],
            'today_new_drivers' => [
                'chart_title' => 'today new drivers',
                'total_number' => $driverMetrics->today_new_drivers,
            ],
            'today_running_rides' => [
                'chart_title' => 'today running rides',
                'total_number' => $bookingMetrics->today_running_rides,
            ],
            'today_completed_rides' => [
                'chart_title' => 'today completed rides',
                'total_number' => $bookingMetrics->today_completed_rides,
            ],
            'total_revenue' => [
                'chart_title' => 'total revenue',
                'total_number' => $bookingMetrics->total_revenue,
            ],
            'today_revenue' => [
                'chart_title' => 'todays revenue',
                'total_number' => $bookingMetrics->today_revenue,
            ],
            'total_income' => [
                'chart_title' => 'total income',
                'total_number' => $bookingMetrics->total_income,
            ],
        ];
    }

    private function resolveDashboardRange(Request $request): array
    {
        $filter = strtolower((string) $request->query('filter', 'today'));
        $now = Carbon::now();

        if ($filter === 'week') {
            return [$now->copy()->startOfWeek()->startOfDay(), $now->copy()->endOfWeek()->endOfDay()];
        }

        if ($filter === 'month') {
            return [$now->copy()->startOfMonth()->startOfDay(), $now->copy()->endOfMonth()->endOfDay()];
        }

        if ($filter === 'year') {
            return [$now->copy()->startOfYear()->startOfDay(), $now->copy()->endOfYear()->endOfDay()];
        }

        if ($filter === 'custom') {
            $from = $request->query('from');
            $to = $request->query('to');

            if ($from && $to) {
                try {
                    $start = Carbon::parse($from)->startOfDay();
                    $end = Carbon::parse($to)->endOfDay();

                    if ($start->lte($end)) {
                        return [$start, $end];
                    }
                } catch (\Throwable $e) {
                    // fall through to default today range
                }
            }
        }

        return [$now->copy()->startOfDay(), $now->copy()->endOfDay()];
    }

    private function resolveCardRange(string $mode, int $year): array
    {
        $now = Carbon::now();
        $safeYear = $year > 0 ? $year : (int) $now->year;
        $mode = strtolower($mode);

        if ($mode === 'today') {
            $day = min((int) $now->day, Carbon::createFromDate($safeYear, (int) $now->month, 1)->daysInMonth);
            $date = Carbon::createFromDate($safeYear, (int) $now->month, $day);
            return [$date->copy()->startOfDay(), $date->copy()->endOfDay()];
        }

        if ($mode === 'week') {
            $week = (int) $now->isoWeek();
            $start = Carbon::now()->setISODate($safeYear, $week)->startOfWeek()->startOfDay();
            return [$start, $start->copy()->endOfWeek()->endOfDay()];
        }

        if ($mode === 'month') {
            $start = Carbon::createFromDate($safeYear, (int) $now->month, 1)->startOfMonth()->startOfDay();
            return [$start, $start->copy()->endOfMonth()->endOfDay()];
        }

        $start = Carbon::createFromDate($safeYear, 1, 1)->startOfYear()->startOfDay();

        return [$start, $start->copy()->endOfYear()->endOfDay()];
    }

    private function basePaidBookingsQuery(int $moduleId)
    {
        return Booking::query()
            ->where('module', $moduleId)
            ->where('payment_status', 'paid')
            ->whereNull('deleted_at');
    }

    private function parcelNameCondition(string $column = 'rental_item_service_types.name'): string
    {
        return "(LOWER(COALESCE({$column}, '')) LIKE '%parcel%' OR LOWER(COALESCE({$column}, '')) LIKE '%delivery%' OR LOWER(COALESCE({$column}, '')) LIKE '%package%')";
    }

    private function applyParcelFilter($query): void
    {
        $query->whereHas('extension.serviceType', function ($serviceTypeQuery) {
            $serviceTypeQuery->whereRaw($this->parcelNameCondition('name'));
        });
    }

    private function applyTaxiFilter($query): void
    {
        $query->where(function ($nestedQuery) {
            $nestedQuery->whereDoesntHave('extension.serviceType')
                ->orWhereHas('extension.serviceType', function ($serviceTypeQuery) {
                    $serviceTypeQuery->whereRaw('NOT ' . $this->parcelNameCondition('name'));
                });
        });
    }

    private function recentBookingBaseQuery(int $moduleId, Carbon $rangeStart, Carbon $rangeEnd, bool $fallback)
    {
        $query = Booking::query()
            ->select([
                'id',
                'token',
                'host_id',
                'userid',
                'status',
                'total',
                'created_at',
                'module',
            ])
            ->with([
                'host:id,first_name,last_name,phone_country,phone,email,ave_host_rate,avr_guest_rate',
                'user:id,first_name,last_name,phone_country,phone,email,ave_host_rate,avr_guest_rate',
                'host.media',
                'user.media',
                'extension:booking_id,service_type_id',
                'extension.serviceType:id,name',
            ])
            ->where('module', $moduleId)
            ->where('payment_status', 'paid')
            ->whereNull('deleted_at');

        if (!$fallback) {
            $query->whereBetween('created_at', [$rangeStart, $rangeEnd]);
        }

        return $query;
    }

    private function fetchRecentActivity(int $moduleId, Carbon $rangeStart, Carbon $rangeEnd): array
    {
        $rangeKey = $rangeStart->format('YmdHis') . '_to_' . $rangeEnd->format('YmdHis');

        $load = function ($type, $fallback = false) use ($moduleId, $rangeStart, $rangeEnd) {
            $query = $this->recentBookingBaseQuery($moduleId, $rangeStart, $rangeEnd, $fallback);
            if ($type === 'parcel') {
                $this->applyParcelFilter($query);
            } else {
                $this->applyTaxiFilter($query);
            }

            return $query->latest()->limit(5)->get();
        };

        $recentTaxi = Cache::remember("dashboard_recent_taxi_{$moduleId}_{$rangeKey}", 120, function () use ($load) {
            return $load('taxi', false);
        });

        $recentParcel = Cache::remember("dashboard_recent_parcel_{$moduleId}_{$rangeKey}", 120, function () use ($load) {
            return $load('parcel', false);
        });

        if ($recentTaxi->isEmpty() && $recentParcel->isEmpty()) {
            $recentTaxi = Cache::remember("dashboard_recent_taxi_{$moduleId}_fallback", 120, function () use ($load) {
                return $load('taxi', true);
            });

            $recentParcel = Cache::remember("dashboard_recent_parcel_{$moduleId}_fallback", 120, function () use ($load) {
                return $load('parcel', true);
            });
        }

        return [$recentTaxi, $recentParcel];
    }

    private function fetchTaxiParcelStats(int $moduleId, string $mode, int $year): array
    {
        [$start, $end] = $this->resolveCardRange($mode, $year);
        $cacheKey = "dashboard_taxi_parcel_stats_{$moduleId}_{$mode}_{$year}_" . $start->format('Ymd') . "_" . $end->format('Ymd');

        return Cache::remember($cacheKey, 180, function () use ($moduleId, $start, $end) {
            $parcelCondition = $this->parcelNameCondition('rental_item_service_types.name');

            $stats = DB::table('bookings')
                ->leftJoin('booking_extensions', 'booking_extensions.booking_id', '=', 'bookings.id')
                ->leftJoin('rental_item_service_types', 'rental_item_service_types.id', '=', 'booking_extensions.service_type_id')
                ->where('bookings.module', $moduleId)
                ->where('bookings.payment_status', 'paid')
                ->whereNull('bookings.deleted_at')
                ->whereBetween('bookings.created_at', [$start, $end])
                ->selectRaw("\n                    COUNT(bookings.id) as total_rides,\n                    SUM(CASE WHEN {$parcelCondition} THEN 1 ELSE 0 END) as parcel_trips,\n                    SUM(CASE WHEN {$parcelCondition} THEN bookings.total ELSE 0 END) as parcel_revenue,\n                    SUM(CASE WHEN {$parcelCondition} AND bookings.status = 'Cancelled' THEN 1 ELSE 0 END) as parcel_cancelled,\n                    SUM(CASE WHEN NOT {$parcelCondition} THEN 1 ELSE 0 END) as taxi_trips,\n                    SUM(CASE WHEN NOT {$parcelCondition} THEN bookings.total ELSE 0 END) as taxi_revenue,\n                    SUM(CASE WHEN NOT {$parcelCondition} AND bookings.status = 'Cancelled' THEN 1 ELSE 0 END) as taxi_cancelled\n                ")
                ->first();

            $totalRides = (int) ($stats->total_rides ?? 0);
            $taxiTrips = (int) ($stats->taxi_trips ?? 0);
            $parcelTrips = (int) ($stats->parcel_trips ?? 0);

            return [
                'taxiPercent' => $totalRides > 0 ? round(($taxiTrips / $totalRides) * 100, 1) : 0,
                'parcelPercent' => $totalRides > 0 ? round(($parcelTrips / $totalRides) * 100, 1) : 0,
                'totalRides' => $totalRides,
                'taxiTrips' => $taxiTrips,
                'parcelTrips' => $parcelTrips,
                'taxiRevenue' => (float) ($stats->taxi_revenue ?? 0),
                'parcelRevenue' => (float) ($stats->parcel_revenue ?? 0),
                'taxiCancelled' => (int) ($stats->taxi_cancelled ?? 0),
                'parcelCancelled' => (int) ($stats->parcel_cancelled ?? 0),
            ];
        });
    }

    private function fetchRevenueStats(int $moduleId, string $mode, int $year): array
    {
        [$start, $end] = $this->resolveCardRange($mode, $year);
        $cacheKey = "dashboard_revenue_stats_{$moduleId}_{$mode}_{$year}_" . $start->format('Ymd') . "_" . $end->format('Ymd');

        return Cache::remember($cacheKey, 180, function () use ($moduleId, $start, $end) {
            $taxColumn = $this->bookingHasColumn('tax') ? 'tax' : ($this->bookingHasColumn('iva_tax') ? 'iva_tax' : null);
            $taxSelect = $taxColumn ? "COALESCE(SUM({$taxColumn}),0) as tax" : '0 as tax';
            $driverCommissionColumn = $this->bookingHasColumn('driver_commission')
                ? 'driver_commission'
                : ($this->bookingHasColumn('vendor_commission') ? 'vendor_commission' : null);
            $driverCommissionSelect = $driverCommissionColumn
                ? "COALESCE(SUM({$driverCommissionColumn}),0) as driver_commission"
                : '0 as driver_commission';

            $stats = DB::table('bookings')
                ->where('module', $moduleId)
                ->where('payment_status', 'paid')
                ->whereNull('deleted_at')
                ->whereBetween('created_at', [$start, $end])
                ->selectRaw("COUNT(*) as total_rides, COALESCE(SUM(total),0) as total_revenue, COALESCE(SUM(admin_commission),0) as admin_commission, {$driverCommissionSelect}, {$taxSelect}")
                ->first();

            $totalRides = (int) ($stats->total_rides ?? 0);
            $totalRevenue = (float) ($stats->total_revenue ?? 0);
            $avgRevenue = $totalRides > 0 ? ($totalRevenue / $totalRides) : 0;

            return [
                'totalRevenue' => $totalRevenue,
                'totalRides' => $totalRides,
                'avgRevenue' => $avgRevenue,
                'adminCommission' => (float) ($stats->admin_commission ?? 0),
                'driverCommission' => $driverCommissionColumn
                    ? (float) ($stats->driver_commission ?? 0)
                    : max(0, $totalRevenue - (float) ($stats->admin_commission ?? 0)),
                'tax' => (float) ($stats->tax ?? 0),
                'chartSeries' => [
                    (float) ($stats->admin_commission ?? 0),
                    $driverCommissionColumn
                    ? (float) ($stats->driver_commission ?? 0)
                    : max(0, $totalRevenue - (float) ($stats->admin_commission ?? 0)),
                    (float) ($stats->tax ?? 0),
                ],
            ];
        });
    }

    private function fetchTopDrivers(int $moduleId, Carbon $rangeStart, Carbon $rangeEnd)
    {
        $rangeKey = $rangeStart->format('YmdHis') . '_to_' . $rangeEnd->format('YmdHis');

        return Cache::remember("dashboard_top_drivers_{$moduleId}_{$rangeKey}", 180, function () use ($moduleId, $rangeStart, $rangeEnd) {
            $rows = $this->topGroupedRows($moduleId, 'host_id', 'drivers', $rangeStart, $rangeEnd);
            if ($rows->isEmpty()) {
                $rows = $this->topGroupedRows($moduleId, 'host_id', 'drivers', null, null);
            }

            return $this->mapTopPeople($rows, 'driver');
        });
    }

    private function fetchTopRiders(int $moduleId, Carbon $rangeStart, Carbon $rangeEnd)
    {
        $rangeKey = $rangeStart->format('YmdHis') . '_to_' . $rangeEnd->format('YmdHis');

        return Cache::remember("dashboard_top_riders_{$moduleId}_{$rangeKey}", 180, function () use ($moduleId, $rangeStart, $rangeEnd) {
            $rows = $this->topGroupedRows($moduleId, 'userid', 'riders', $rangeStart, $rangeEnd);
            if ($rows->isEmpty()) {
                $rows = $this->topGroupedRows($moduleId, 'userid', 'riders', null, null);
            }

            return $this->mapTopPeople($rows, 'rider');
        });
    }

    private function topGroupedRows(int $moduleId, string $column, string $type, ?Carbon $start, ?Carbon $end)
    {
        $query = DB::table('bookings')
            ->where('module', $moduleId)
            ->where('payment_status', 'paid')
            ->whereNull('deleted_at')
            ->whereNotNull($column);

        if ($start && $end) {
            $query->whereBetween('created_at', [$start, $end]);
        }

        if ($type === 'drivers') {
            return $query->selectRaw("{$column} as person_id, COUNT(*) as trips, COALESCE(SUM(total), 0) as amount")
                ->groupBy($column)
                ->orderByDesc('trips')
                ->limit(10)
                ->get();
        }

        return $query->selectRaw("{$column} as person_id, COUNT(*) as trips, COALESCE(SUM(total), 0) as amount")
            ->groupBy($column)
            ->orderByDesc('trips')
            ->limit(10)
            ->get();
    }

    private function mapTopPeople($rows, string $kind)
    {
        $ids = $rows->pluck('person_id')->filter()->values();
        if ($ids->isEmpty()) {
            return collect();
        }

        $users = AppUser::query()
            ->with('media')
            ->select(['id', 'first_name', 'last_name', 'phone_country', 'phone', 'email', 'ave_host_rate', 'avr_guest_rate'])
            ->whereIn('id', $ids)
            ->get()
            ->keyBy('id');

        return $rows->map(function ($row) use ($users, $kind) {
            $user = $users->get((int) $row->person_id);
            if (!$user) {
                return null;
            }

            $name = trim(($user->first_name ?? '') . ' ' . ($user->last_name ?? ''));
            $fallbackInitial = $kind === 'driver' ? 'D' : 'R';
            $initialSource = $name !== '' ? $name : $fallbackInitial;
            $initial = strtoupper(function_exists('mb_substr') ? mb_substr($initialSource, 0, 1) : substr($initialSource, 0, 1));
            $avatar = $user->profile_image ? $user->profile_image->getUrl('thumb') : '';

            $payload = [
                'id' => (int) $user->id,
                'name' => $name,
                'phone_country' => $user->phone_country,
                'phone' => $user->phone,
                'email' => $user->email,
                'avatar' => $avatar,
                'has_avatar' => !empty($avatar),
                'initial' => $initial,
                'trips' => (int) $row->trips,
                'rating' => $kind === 'driver'
                    ? (float) ($user->ave_host_rate ?? $user->avr_guest_rate ?? 0)
                    : (float) ($user->avr_guest_rate ?? $user->ave_host_rate ?? 0),
            ];

            if ($kind === 'driver') {
                $payload['earnings'] = (float) ($row->amount ?? 0);
                $payload['url'] = route('admin.drivers.profile', ['driver_id' => $user->id]);
            } else {
                $payload['spend'] = (float) ($row->amount ?? 0);
                $payload['url'] = route('admin.app_users.show', $user->id);
            }

            return $payload;
        })->filter()->values();
    }

    private function fetchFinancialCounters(int $moduleId, Carbon $rangeStart, Carbon $rangeEnd): array
    {
        $rangeKey = $rangeStart->format('YmdHis') . '_to_' . $rangeEnd->format('YmdHis');

        return Cache::remember("dashboard_financial_counts_{$moduleId}_{$rangeKey}", 180, function () use ($moduleId, $rangeStart, $rangeEnd) {
            $paymentExpr = $this->paymentModeSqlExpression();
            $commissionColumn = $this->bookingHasColumn('driver_commission')
                ? 'driver_commission'
                : ($this->bookingHasColumn('vendor_commission') ? 'vendor_commission' : null);
            $base = DB::table('bookings')
                ->where('module', $moduleId)
                ->where('payment_status', 'paid')
                ->whereNull('deleted_at')
                ->whereBetween('created_at', [$rangeStart, $rangeEnd]);

            $pendingPayouts = 0;
            if ($this->bookingHasColumn('payout_status') && $commissionColumn) {
                $pendingPayouts = (clone $base)
                    ->whereRaw("LOWER(COALESCE(payout_status, '')) = 'pending'")
                    ->sum($commissionColumn);
            }

            $offlinePayment = (clone $base)
                ->whereRaw("LOWER({$paymentExpr}) LIKE '%cash%' OR LOWER({$paymentExpr}) LIKE '%offline%'")
                ->count();

            $onlinePayment = (clone $base)
                ->whereRaw("{$paymentExpr} <> ''")
                ->whereRaw("LOWER({$paymentExpr}) NOT LIKE '%cash%'")
                ->whereRaw("LOWER({$paymentExpr}) NOT LIKE '%offline%'")
                ->count();

            return [
                'pending_payouts' => (float) $pendingPayouts,
                'offline_payment' => (int) $offlinePayment,
                'online_payment' => (int) $onlinePayment,
            ];
        });
    }

    private function buildMetricCards(array $metrics, array $financialCounts, array $metricDateParams): array
    {
        $totalRevenue = (float) ($metrics['total_income']['total_number'] ?? 0);
        $adminCommission = (float) ($metrics['total_revenue']['total_number'] ?? 0);
        $driverCommission = max(0, $totalRevenue - $adminCommission);

        return [
            [
                'key' => 'total_rides',
                'icon' => 'ion-android-bicycle',
                'value' => (float) ($metrics['total_rides']['total_number'] ?? 0),
                'is_money' => false,
                'label' => trans('dashboard.total_rides'),
                'link' => route('admin.bookings.index', $metricDateParams),
            ],
            [
                'key' => 'total_drivers',
                'icon' => 'ion-model-s',
                'value' => (float) ($metrics['total_drivers']['total_number'] ?? 0),
                'is_money' => false,
                'label' => trans('dashboard.total_drivers'),
                'link' => route('admin.drivers.index', $metricDateParams),
            ],
            [
                'key' => 'total_requested_drivers',
                'icon' => 'ion-person-add',
                'value' => (float) ($metrics['total_requested_drivers']['total_number'] ?? 0),
                'is_money' => false,
                'label' => trans('dashboard.total_requested_drivers'),
                'link' => route('admin.drivers.index', array_merge(['host_status' => '2'], $metricDateParams)),
            ],
            [
                'key' => 'total_riders',
                'icon' => 'ion-person-stalker',
                'value' => (float) ($metrics['total_riders']['total_number'] ?? 0),
                'is_money' => false,
                'label' => trans('dashboard.total_riders'),
                'link' => route('admin.app_users.index', $metricDateParams),
            ],
            [
                'key' => 'today_running_rides',
                'icon' => 'ion-android-bicycle',
                'value' => (float) ($metrics['today_running_rides']['total_number'] ?? 0),
                'is_money' => false,
                'label' => trans('dashboard.today_running_rides'),
                'link' => route('admin.bookings.index', array_merge(['status' => 'ongoing'], $metricDateParams)),
            ],
            [
                'key' => 'total_revenue_label',
                'icon' => 'ion-social-usd',
                'value' => $totalRevenue,
                'is_money' => true,
                'label' => trans('dashboard.total_revenue'),
                'link' => route('admin.finance.index', $metricDateParams),
            ],
            [
                'key' => 'admin_commission',
                'icon' => 'ion-cash',
                'value' => $adminCommission,
                'is_money' => true,
                'label' => trans('dashboard.admin_commission'),
                'link' => route('admin.finance.index', $metricDateParams),
            ],
            [
                'key' => 'driver_commission',
                'icon' => 'ion-card',
                'value' => $driverCommission,
                'is_money' => true,
                'label' => trans('dashboard.driver_commission'),
                'link' => route('admin.finance.index', $metricDateParams),
            ],
            // [
            //     'key' => 'pending_payouts',
            //     'icon' => 'ion-clock',
            //     'value' => (float) ($financialCounts['pending_payouts'] ?? 0),
            //     'is_money' => true,
            //     'label' => trans('dashboard.pending_payouts'),
            //     'link' => route('admin.payouts.index', $metricDateParams),
            // ],
            // [
            //     'key' => 'offline_payment',
            //     'icon' => 'ion-cash',
            //     'value' => (float) ($financialCounts['offline_payment'] ?? 0),
            //     'is_money' => false,
            //     'label' => trans('dashboard.offline_payment'),
            //     'link' => route('admin.bookings.index', $metricDateParams),
            // ],
            // [
            //     'key' => 'online_payment',
            //     'icon' => 'ion-earth',
            //     'value' => (float) ($financialCounts['online_payment'] ?? 0),
            //     'is_money' => false,
            //     'label' => trans('dashboard.online_payment'),
            //     'link' => route('admin.bookings.index', $metricDateParams),
            // ],
            // [
            //     'key' => 'rejected_by_drivers',
            //     'icon' => 'ion-close',
            //     'value' => (float) ($metrics['rejected_rides']['total_number'] ?? 0),
            //     'is_money' => false,
            //     'label' => trans('dashboard.rejected_by_drivers'),
            //     'link' => route('admin.bookings.index', array_merge(['status' => 'rejected'], $metricDateParams)),
            // ],
        ];
    }

    private function bookingHasColumn(string $column): bool
    {
        return Cache::remember("dashboard_bookings_column_exists_{$column}", 3600, function () use ($column) {
            return Schema::hasColumn('bookings', $column);
        });
    }

    private function paymentModeSqlExpression(): string
    {
        if ($this->bookingHasColumn('payment_mode')) {
            return "COALESCE(payment_mode, payment_method, '')";
        }

        return "COALESCE(payment_method, '')";
    }

    private function getLatestUsersData()
    {
        return Cache::remember('latest_users_data', 3600, function () {
            $startDate = Carbon::now()->subWeek()->startOfDay();
            $endDate = Carbon::now()->endOfDay();

            return AppUser::selectRaw('DATE(created_at) as date, COUNT(*) as count')
                ->whereBetween('created_at', [$startDate, $endDate])
                ->groupBy('date')
                ->orderBy('date')
                ->get()
                ->map(function ($record) {
                    return [
                        'date' => $record->date,
                        'count' => $record->count,
                    ];
                });
        });
    }

    private function getLatestBookingsData($moduleId)
    {
        return Cache::remember("latest_bookings_data_{$moduleId}", 3600, function () use ($moduleId) {
            $startDate = Carbon::now()->subWeek()->startOfDay();
            $endDate = Carbon::now()->endOfDay();

            return Booking::selectRaw('DATE(created_at) as date, COUNT(*) as count')
                ->where('module', $moduleId)
                ->whereBetween('created_at', [$startDate, $endDate])
                ->groupBy('date')
                ->orderBy('date')
                ->get()
                ->map(function ($record) {
                    return [
                        'date' => $record->date,
                        'count' => $record->count,
                    ];
                });
        });
    }

    public function deleteInstaller()
    {
        $files = [
            app_path('Http/Controllers/InstallerController.php'),
            base_path('installer/rideon.sql'),
        ];

        foreach ($files as $file) {
            if (file_exists($file)) {
                unlink($file);
            }
        }

        $installerViewDir = resource_path('views/installer');

        if (is_dir($installerViewDir)) {
            $this->deleteDirectory($installerViewDir);
        }

        return back()->with('success', 'Installer files deleted successfully.');
    }

    private function deleteDirectory($dir)
    {
        if (!is_dir($dir)) {
            return;
        }

        $items = scandir($dir);

        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }

            $path = $dir . DIRECTORY_SEPARATOR . $item;

            if (is_dir($path)) {
                $this->deleteDirectory($path);
            } else {
                @unlink($path);
            }
        }

        @rmdir($dir);
    }
}