<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Requests\Admin\StoreItemRulesRequest;
use App\Http\Requests\Admin\UpdateItemRulesRequest;
use App\Models\Module;
use App\Models\RentalItemRule;
use App\Services\TranslationService;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ItemRulesController extends Controller
{
    use MediaUploadingTrait;

    public function index(Request $request)
    {
        abort_if(Gate::denies('item_rules_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $module = Module::where('default_module', '1')->first();
        $query = RentalItemRule::with('moduleGet')->orderBy('id', 'desc');
        if ($module) {
            $query->where('module', $module->id);
        }

        $itemRulesData = $query->get();

        return view('admin.item_rules.index', compact('itemRulesData'));

    }

    public function create()
    {
        abort_if(Gate::denies('item_rules_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $defaultModule = Module::where('default_module', '1')->first();
        $defaultModuleId = $defaultModule ? $defaultModule->id : null;

        return view('admin.item_rules.create', compact('defaultModuleId'));
    }

    public function store(StoreItemRulesRequest $request)
    {
        abort_if(Gate::denies('item_rules_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $data = $request->all();
        $data['rule_name'] = TranslationService::valueForDefault($request->rule_name) ?? '';
        $itemRule = RentalItemRule::create($data);

        return redirect()->route('admin.item_rules.index');
    }

    public function edit($id)
    {
        abort_if(Gate::denies('item_rules_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $defaultModule = Module::where('default_module', '1')->first();
        $defaultModuleId = $defaultModule ? $defaultModule->id : null;
        $itemRoledata = RentalItemRule::where('id', $id)->firstOrFail();

        return view('admin.item_rules.edit', compact('itemRoledata', 'defaultModuleId'));
    }

    public function update(UpdateItemRulesRequest $request, RentalItemRule $itemRule)
    {
        abort_if(Gate::denies('item_rules_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $data = $request->all();
        $data['rule_name'] = TranslationService::valueForDefault($request->rule_name) ?? '';
        $itemRule->update($data);

        return redirect()->route('admin.item_rules.index');
    }

    public function show($id)
    {
        abort_if(Gate::denies('item_rules_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $itemRoledata = RentalItemRule::where('id', $id)->firstOrFail();

        return view('admin.item_rules.show', compact('itemRoledata'));
    }

    public function updateStatus(Request $request)
    {
        if (Gate::denies('item_rules_edit')) {
            return response()->json(['message' => "You don't have permission to perform this action."]);
        }
        $product_status = RentalItemRule::where('id', $request->pid)->update(['status' => $request->status]);
        if ($product_status) {
            return response()->json([
                'status' => 200,
                'message' => trans('global.status_updated_successfully'),
            ]);
        } else {
            return response()->json([
                'status' => 500,
                'message' => 'something went wrong. Please try again.',
            ]);
        }

    }

    public function destroy($id)
    {
        abort_if(Gate::denies('item_rules_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $itemRules = RentalItemRule::find($id);

        if (! $itemRules) {
            return response()->json(['message' => 'Item rule not found'], Response::HTTP_NOT_FOUND);
        }
        $itemRules->delete();

        return response()->json(['message' => 'Item rule deleted successfully'], 200);
    }

    public function allDelete(Request $request)
    {
        abort_if(Gate::denies('item_rules_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $ids = $request->input('ids');
        if (! empty($ids)) {
            try {

                RentalItemRule::whereIn('id', $ids)->delete();

                return response()->json(['message' => 'Items deleted successfully'], 200);
            } catch (\Exception $e) {
                return response()->json(['message' => 'Something went wrong'], 500);
            }
        }

        return response()->json(['message' => 'No entries selected'], 400);
    }
}
