<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Requests\Admin\MassDestroyModuleRequest;
use App\Http\Requests\Admin\StoreModuleRequest;
use App\Http\Requests\Admin\UpdateModuleRequest;
use App\Http\Requests\Admin\UpdateModuleStatusRequest;
use App\Models\Module;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;

class ModuleController extends Controller
{
    use MediaUploadingTrait;

    public function index()
    {
        $module = Module::All();

        return view('admin.module.index', compact('module'));
    }

    public function create()
    {
        return view('admin.module.create');
    }

    public function store(StoreModuleRequest $request)
    {
        $module = Module::create($request->all());
        if ($request->input('front_image', false)) {
            if (! $module->front_image || $request->input('front_image') !== $module->front_image->file_name) {
                if ($module->front_image) {
                    $module->front_image->delete();
                }
                $module->addMedia(storage_path('tmp/uploads/'.basename($request->input('front_image'))))->toMediaCollection('front_image');
            }
        } elseif ($module->front_image) {
            $module->front_image->delete();
        }

        return redirect()->route('admin.modules.index');
    }

    public function edit(Module $module)
    {

        return view('admin.module.edit', compact('module'));
    }

    public function update(UpdateModuleRequest $request, Module $module)
    {
        $module->update($request->validated());
        if ($request->input('front_image', false)) {
            if (! $module->front_image || $request->input('front_image') !== $module->front_image->file_name) {
                if ($module->front_image) {
                    $module->front_image->delete();
                }
                $module->addMedia(storage_path('tmp/uploads/'.basename($request->input('front_image'))))->toMediaCollection('front_image');
            }
        } elseif ($module->front_image) {
            $module->front_image->delete();
        }

        return redirect()->route('admin.modules.index');
    }

    public function show(Module $module)
    {
        return view('admin.module.show', compact('module'));
    }

    public function destroy(Module $module)
    {
        $module->delete();

        return back();
    }

    public function massDestroy(MassDestroyModuleRequest $request)
    {
        $modules = Module::query()->whereIn('id', $request->validated()['ids'])->get();

        foreach ($modules as $module) {
            $module->delete();
        }

        return response(null, Response::HTTP_NO_CONTENT);
    }

    public function updateStatus(UpdateModuleStatusRequest $request)
    {
        $validated = $request->validated();
        $field = match ($validated['type']) {
            'status' => 'status',
            'default_module' => 'default_module',
        };
        $status = $request->boolean('status');

        DB::transaction(function () use ($field, $status, $validated) {
            $module = Module::query()->lockForUpdate()->findOrFail($validated['pid']);

            if ($field === 'default_module' && $status) {
                Module::query()->where('id', '!=', $module->getKey())->update(['default_module' => 0]);
            }

            $module->update([$field => (int) $status]);
        });

        return response()->json([
            'status' => 200,
            'message' => trans('global.'.($field === 'default_module' ? 'default_updated_successfully' : 'status_updated_successfully')),
        ]);

    }
}
