<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\BookingCancellationReason;
use App\Models\Module;
use App\Rules\ValidTranslatable;
use App\Services\TranslationService;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CancellationReasonController extends Controller
{
    public function index(Request $request)
    {
        abort_if(Gate::denies('cancellation_reasons_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $module = Module::where('default_module', '1')->first();
        $moduleName = $module ? $module->name : '';

        $query = BookingCancellationReason::with('appUser')->orderBy('order_cancellation_id', 'desc');
        if ($module) {
            $query->where('module', $module->id);
        }

        $contactdata = $query->get();

        return view('admin.cancellation_reasons.index', compact('contactdata', 'moduleName'));
    }

    public function create()
    {
        abort_if(Gate::denies('cancellation_reasons_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $modules = Module::orderBy('name')->get();

        return view('admin.cancellation_reasons.create', compact('modules'));
    }

    public function store(Request $request)
    {
        abort_if(Gate::denies('cancellation_reasons_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $validated = $request->validate([
            'reason' => ['required', new ValidTranslatable],
            'user_type' => 'required|in:host,user',
            'status' => 'required|in:0,1',
            'module' => 'required|exists:modules,id',
        ]);

        $booking = new BookingCancellationReason;
        $booking->reason = TranslationService::valueForDefault($validated['reason']) ?? '';
        $booking->user_type = $validated['user_type'];
        $booking->status = $validated['status'];
        $booking->module = $validated['module'];
        $booking->save();

        return redirect()->route('admin.cancellation_reasons.index');
    }

    public function edit($orderCancellationId)
    {
        abort_if(Gate::denies('cancellation_reasons_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $cancellationdata = BookingCancellationReason::where('order_cancellation_id', $orderCancellationId)->firstOrFail();

        return view('admin.cancellation_reasons.edit', compact('cancellationdata'));
    }

    public function update(Request $request, $orderCancellationId)
    {
        abort_if(Gate::denies('cancellation_reasons_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $validated = $request->validate([
            'reason' => ['required', new ValidTranslatable],
            'user_type' => 'required|in:host,user',
            'status' => 'required|in:0,1',
        ]);

        $item = BookingCancellationReason::where('order_cancellation_id', $orderCancellationId)->firstOrFail();
        $item->update([
            'reason' => TranslationService::valueForDefault($validated['reason']) ?? '',
            'status' => $validated['status'],
            'user_type' => $validated['user_type'],
        ]);

        return redirect()->route('admin.cancellation_reasons.index');
    }

    public function updateStatus(Request $request)
    {
        if (Gate::denies('cancellation_reasons_edit')) {
            return response()->json([
                'status' => 403,
                'message' => "You don't have permission to perform this action.",
            ], 403);
        }

        $request->validate([
            'status' => 'required|in:0,1',
            'pid' => 'required',
        ]);

        $productStatus = BookingCancellationReason::where('order_cancellation_id', $request->pid)
            ->update(['status' => $request->status]);

        if ($productStatus) {
            return response()->json([
                'status' => 200,
                'message' => trans('global.status_updated_successfully'),
            ]);
        }

        return response()->json([
            'status' => 500,
            'message' => 'something went wrong. Please try again.',
        ]);
    }

    public function destroy($orderCancellationId)
    {
        abort_if(Gate::denies('cancellation_reasons_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $currentModule = Module::where('default_module', '1')->first();
        $cancellation = BookingCancellationReason::where('order_cancellation_id', $orderCancellationId)->firstOrFail();

        if ($currentModule && $cancellation->module !== $currentModule->id) {
            return response()->json([
                'status' => 404,
                'message' => 'Cancellation reason not found.',
            ]);
        }

        $cancellation->delete();

        return response()->json([
            'status' => 200,
            'message' => 'Cancellation reason deleted successfully.',
        ]);
    }

    public function deleteAll(Request $request)
    {
        abort_if(Gate::denies('cancellation_reasons_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $ids = $request->input('ids', []);
        if (! empty($ids)) {
            try {
                BookingCancellationReason::whereIn('order_cancellation_id', $ids)->delete();

                return response()->json(['message' => 'Items deleted successfully'], 200);
            } catch (\Exception $e) {
                \Log::error('Deletion error: '.$e->getMessage());

                return response()->json(['message' => 'Something went wrong'], 500);
            }
        }

        return response()->json(['message' => 'No entries selected'], 400);
    }
}
