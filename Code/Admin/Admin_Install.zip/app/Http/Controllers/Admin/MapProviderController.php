<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\GeneralSetting;
use Illuminate\Http\Request;

class MapProviderController extends Controller
{
    protected $mapProviders = [
        'google' => [
            'meta_keys' => [
                'google_maps_status',
                'api_google_map_key',
            ],
            'status_field' => 'google_maps_status',
            'title' => 'Google Maps',
            'help_url' => 'https://console.cloud.google.com/google/maps-apis/start',
            'help_text' => 'Create a Maps JavaScript API key in the Google Cloud Console.',
        ],
        'ola' => [
            'meta_keys' => [
                'ola_maps_status',
                'ola_maps_api_key',
                'ola_maps_client_id',
                'ola_maps_client_secret',
            ],
            'status_field' => 'ola_maps_status',
            'title' => 'Ola Maps',
            'help_url' => 'https://cloud.olakrutrim.com/signIn',
            'help_text' => 'Create credentials in the Ola Maps Developer Portal (Krutrim Cloud).',
        ],
        'mapbox' => [
            'meta_keys' => [
                'mapbox_status',
                'mapbox_access_token',
            ],
            'status_field' => 'mapbox_status',
            'title' => 'Mapbox',
            'help_url' => 'https://console.mapbox.com/account/access-tokens',
            'help_text' => 'Create a public access token (pk.*) in the Mapbox account console.',
        ],
        'osm' => [
            'meta_keys' => [
                'osm_status',
            ],
            'status_field' => 'osm_status',
            'title' => 'OpenStreetMap',
            'help_url' => 'https://wiki.openstreetmap.org/wiki/Tile_servers',
            'help_text' => 'OSM uses free public tile servers. No API key required.',
        ],
    ];

    public function index()
    {
        $allMetaKeys = collect($this->mapProviders)
            ->flatMap(fn ($config) => $config['meta_keys'])
            ->unique()
            ->toArray();

        $settings = GeneralSetting::whereIn('meta_key', $allMetaKeys)
            ->get()
            ->keyBy('meta_key');

        $providers = [];
        foreach ($this->mapProviders as $key => $config) {
            $statusSetting = $settings->get($config['status_field']);
            $providers[] = [
                'key' => $key,
                'title' => $config['title'],
                'help_text' => $config['help_text'] ?? '',
                'help_url' => $config['help_url'] ?? null,
                'status' => $statusSetting->meta_value ?? 'Inactive',
            ];
        }

        return view('admin.general-settings.maps.form', compact('providers'));
    }

    public function updateStatus(Request $request, $provider)
    {
        if (! isset($this->mapProviders[$provider])) {
            return response()->json([
                'status' => 400,
                'message' => trans('global.something_went_wrong'),
            ]);
        }

        $statusField = $this->mapProviders[$provider]['status_field'] ?? null;

        if (! $statusField) {
            return response()->json([
                'status' => 400,
                'message' => trans('global.something_went_wrong'),
            ]);
        }

        $status = strtolower($request->status) === '1' ? 'Active' : 'Inactive';

        if ($status === 'Active') {
            foreach ($this->mapProviders as $key => $config) {
                $sf = $config['status_field'] ?? null;
                if ($sf) {
                    GeneralSetting::updateOrCreate(
                        ['meta_key' => $sf],
                        ['meta_value' => $key === $provider ? 'Active' : 'Inactive']
                    );
                }
            }
        } else {
            GeneralSetting::updateOrCreate(
                ['meta_key' => $statusField],
                ['meta_value' => 'Inactive']
            );
        }

        return response()->json([
            'status' => 200,
            'message' => trans('global.status_updated_successfully'),
        ]);
    }
}
