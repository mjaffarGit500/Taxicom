<?php

namespace App\Http\Controllers\Auth;

use App\Contracts\AdminCaptchaVerifier;
use App\Http\Controllers\Controller;
use App\Models\GeneralSetting;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Throwable;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(private readonly AdminCaptchaVerifier $captchaVerifier)
    {
        $this->middleware('guest')->except('logout');
    }

    protected function validateLogin(Request $request): void
    {
        $request->validate([
            $this->username() => ['required', 'string', 'email', 'max:255'],
            'password' => ['required', 'string', 'max:4096'],
        ]);

        $captcha = $this->captchaVerifier->configuration();
        if (! $captcha->enabled) {
            return;
        }

        $request->validate([
            'g-recaptcha-response' => ['required', 'string', 'max:4096'],
        ], [
            'g-recaptcha-response.required' => 'CAPTCHA verification failed. Please try again.',
            'g-recaptcha-response.string' => 'CAPTCHA verification failed. Please try again.',
            'g-recaptcha-response.max' => 'CAPTCHA verification failed. Please try again.',
        ]);

        $result = $this->captchaVerifier->verify(
            $captcha,
            (string) $request->input('g-recaptcha-response'),
            $request->ip()
        );

        if (! $result->successful) {
            throw ValidationException::withMessages([
                'g-recaptcha-response' => ['CAPTCHA verification failed. Please try again.'],
            ]);
        }
    }

    protected function attemptLogin(Request $request): bool
    {
        try {
            return $this->guard()->attempt(
                $this->credentials($request),
                $request->boolean('remember')
            );
        } catch (Throwable $exception) {
            report($exception);

            throw ValidationException::withMessages([
                $this->username() => [trans('auth.failed')],
            ]);
        }
    }

    public function showLoginForm()
    {
        $settings = GeneralSetting::query()->whereIn('meta_key', [
            'general_name',
            'general_description',
            'general_logo',
            'general_favicon',
            'general_loginBackgroud',
        ])->pluck('meta_value', 'meta_key'); // returns [meta_key => meta_value]
        $captcha = $this->captchaVerifier->configuration();

        return view('auth.login', [
            'logoUrl' => '/storage/'.($settings['general_logo'] ?? 'default_logo.png'),
            'siteName' => $settings['general_name'] ?? '',
            'tagLine' => $settings['general_description'] ?? '',
            'faviconUrl' => '/storage/'.($settings['general_favicon'] ?? 'default_favicon.png'),
            'loginBackgroud' => '/storage/'.($settings['general_loginBackgroud'] ?? 'default_bg.png'),
            'general_captcha' => $captcha->enabled ? 'yes' : 'no',
            'site_key' => $captcha->siteKey,
        ]);
    }
}
