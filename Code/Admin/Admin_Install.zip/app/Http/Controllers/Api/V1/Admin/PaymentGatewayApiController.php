<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MiscellaneousTrait;
use App\Http\Controllers\Traits\ResponseTrait;
use App\Models\GeneralSetting;

class PaymentGatewayApiController extends Controller
{
    use MiscellaneousTrait, ResponseTrait;

    protected array $gateways = [
        [
            'name' => 'stripe',
            'method' => 'stripe',
            'display_name' => 'Stripe',
            'status_key' => 'stripe_status',
            'mode_key' => 'stripe_options',
            'public_key_test' => 'test_stripe_public_key',
            'public_key_live' => 'live_stripe_public_key',
            'logo_key' => 'stripe_logo',
        ],
        [
            'name' => 'paypal',
            'method' => 'paypal',
            'display_name' => 'PayPal',
            'status_key' => 'paypal_status',
            'mode_key' => 'paypal_options',
            'public_key_test' => 'test_paypal_client_id',
            'public_key_live' => 'live_paypal_client_id',
            'logo_key' => 'paypal_logo',
        ],
        [
            'name' => 'razorpay',
            'method' => 'razorpay',
            'display_name' => 'Razorpay',
            'status_key' => 'razorpay_status',
            'mode_key' => 'razorpay_options',
            'public_key_test' => 'test_razorpay_key_id',
            'public_key_live' => 'live_razorpay_key_id',
            'logo_key' => 'razorpay_logo',
        ],
        [
            'name' => 'paytm',
            'method' => 'paytm',
            'display_name' => 'Paytm',
            'status_key' => 'paytm_status',
            'mode_key' => 'paytm_options',
            'public_key_test' => 'test_paytm_merchant_id',
            'public_key_live' => 'live_paytm_merchant_id',
            'logo_key' => 'paytm_logo',
        ],
        [
            'name' => 'phonepe',
            'method' => 'phonepe',
            'display_name' => 'PhonePe',
            'status_key' => 'phonepe_status',
            'mode_key' => 'phonepe_options',
            'public_key_test' => 'test_phonepe_client_id',
            'public_key_live' => 'live_phonepe_client_id',
            'logo_key' => 'phonepe_logo',
        ],
        [
            'name' => 'transbank',
            'method' => 'transbank',
            'display_name' => 'Transbank',
            'status_key' => 'transbank_status',
            'mode_key' => 'transbank_options',
            'public_key_test' => 'test_transbank_client_id',
            'public_key_live' => 'live_transbank_client_id',
            'logo_key' => 'transbank_logo',
        ],
        [
            'name' => 'paystack',
            'method' => 'paystack',
            'display_name' => 'Paystack',
            'status_key' => 'paystack_status',
            'mode_key' => 'paystack_options',
            'public_key_test' => 'test_paystack_public_key',
            'public_key_live' => 'live_paystack_public_key',
            'logo_key' => 'paystack_logo',
        ],
        [
            'name' => 'flutterwave',
            'method' => 'flutterwave',
            'display_name' => 'Flutterwave',
            'status_key' => 'flutterwave_status',
            'mode_key' => 'flutterwave_options',
            'public_key_test' => 'test_flutterwave_public_key',
            'public_key_live' => 'live_flutterwave_public_key',
            'logo_key' => 'flutterwave_logo',
        ],
        [
            'name' => 'paydunya',
            'method' => 'paydunya',
            'display_name' => 'Paydunya',
            'status_key' => 'paydunya_status',
            'mode_key' => null,
            'public_key_test' => null,
            'public_key_live' => null,
            'logo_key' => 'paydunya_logo',
        ],
        [
            'name' => 'cash',
            'method' => 'cash',
            'display_name' => 'Cash',
            'status_key' => 'cash_status',
            'mode_key' => null,
            'public_key_test' => null,
            'public_key_live' => null,
            'logo_key' => 'cash_logo',
        ],
    ];

    public function index()
    {
        try {
            $onlinePayment = $this->getGeneralSettingValue('onlinepayment');

            if ($onlinePayment !== 'Active') {
                return $this->addSuccessResponse(200, 'Online payment is disabled', []);
            }

            $allKeys = array_merge(
                ['onlinepayment'],
                array_column($this->gateways, 'status_key'),
                array_column($this->gateways, 'mode_key'),
                array_column($this->gateways, 'public_key_test'),
                array_column($this->gateways, 'public_key_live'),
                array_column($this->gateways, 'logo_key'),
            );

            $allKeys = array_filter($allKeys);

            $settings = GeneralSetting::whereIn('meta_key', $allKeys)
                ->pluck('meta_value', 'meta_key')
                ->toArray();

            $baseUrl = rtrim(config('app.url'), '/');
            $activeGateways = [];

            foreach ($this->gateways as $gateway) {
                $status = $settings[$gateway['status_key']] ?? null;

                if ($status !== 'Active') {
                    continue;
                }

                $mode = $gateway['mode_key'] ? ($settings[$gateway['mode_key']] ?? 'test') : null;
                $publicKey = null;

                if ($gateway['mode_key'] && $gateway['public_key_test'] && $gateway['public_key_live']) {
                    $publicKey = $mode === 'live'
                        ? ($settings[$gateway['public_key_live']] ?? null)
                        : ($settings[$gateway['public_key_test']] ?? null);
                }

                $logoValue = $settings[$gateway['logo_key']] ?? null;
                $logoUrl = $logoValue ? $baseUrl . '/storage/' . $logoValue : null;

                $activeGateways[] = [
                    'name' => $gateway['name'],
                    'method' => $gateway['method'],
                    'display_name' => $gateway['display_name'],
                    'logo' => $logoUrl,
                    'public_key' => $publicKey,
                    'payment_url' => in_array(
                        $gateway['method'],
                        ['stripe', 'paypal'],
                        true
                    )
                        ? route('payment.checkout', ['method' => $gateway['method']])
                        : null,
                    'wallet_recharge_url' => in_array(
                        $gateway['method'],
                        ['stripe', 'paypal'],
                        true
                    )
                        ? route('wallet_recharge_checkout', ['method' => $gateway['method']])
                        : null,
                ];
            }

            return $this->addSuccessResponse(200, 'Payment gateways fetched successfully', $activeGateways);
        } catch (\Exception $e) {
            return $this->addErrorResponse(500, trans('front.something_wrong'));
        }
    }
}
