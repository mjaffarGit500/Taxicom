<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MiscellaneousTrait;
use App\Http\Controllers\Traits\ResponseTrait;
use App\Models\AppUser;
use App\Models\Booking;
use App\Models\PaymentAttempt;
use App\Payments\PaymentAttemptService;
use App\Payments\PaymentFinalizationService;
use App\Payments\PaymentWebhookService;
use App\Payments\VerifiedPayment;
use App\Services\RazorpayService;
use App\Services\VendorWalletRechargeService;
use Illuminate\Contracts\Cache\LockTimeoutException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class RazorpayApiController extends Controller
{
    use MiscellaneousTrait, ResponseTrait;

    private RazorpayService $razorpayService;

    private VendorWalletRechargeService $walletRechargeService;

    private PaymentAttemptService $paymentAttempts;

    private PaymentFinalizationService $paymentFinalizer;

    private PaymentWebhookService $webhooks;

    public function __construct(
        RazorpayService $razorpayService,
        VendorWalletRechargeService $walletRechargeService,
        PaymentAttemptService $paymentAttempts,
        PaymentFinalizationService $paymentFinalizer,
        PaymentWebhookService $webhooks
    ) {
        $this->razorpayService = $razorpayService;
        $this->walletRechargeService = $walletRechargeService;
        $this->paymentAttempts = $paymentAttempts;
        $this->paymentFinalizer = $paymentFinalizer;
        $this->webhooks = $webhooks;
    }

    /**
     * POST /api/v1/payments/razorpay/initiate
     *
     * Creates a Razorpay order and returns the data needed by the Flutter razorpay_flutter SDK.
     */
    public function initiatePayment(Request $request): JsonResponse
    {
        $request->validate([
            'booking_id' => 'required|integer|exists:bookings,id',
            'token' => 'required|exists:app_users,token',
        ]);

        $userId = $this->checkUserByToken($request->token);
        if (! $userId) {
            return $this->addErrorResponse(419, trans('global.token_not_match'), '');
        }

        $bookingId = $request->input('booking_id');
        $bookingData = Booking::where('id', $bookingId)->where('userid', $userId)->first();

        if (! $bookingData) {
            return response()->json([
                'status' => 'error',
                'message' => 'Booking not found.',
            ], 404);
        }

        if ($bookingData->payment_status === 'paid') {
            return response()->json([
                'status' => 'error',
                'message' => 'Booking is already paid.',
            ], 422);
        }

        if ($this->getGeneralSettingValue('razorpay_status') !== 'Active') {
            return response()->json([
                'status' => 'error',
                'message' => 'Payment initiation failed.',
            ], 502);
        }

        $attempt = $this->paymentAttempts->forBooking($bookingData, (int) $userId, 'razorpay');
        $result = $this->razorpayOrder($attempt, 'pay_'.bin2hex(random_bytes(12)));

        if ($result['status'] === 'error') {
            Log::error('Razorpay initiate failed', ['bookingId' => $bookingId, 'message' => $result['message']]);

            return response()->json([
                'status' => 'error',
                'message' => $result['message'] ?? 'Payment initiation failed.',
            ], 502);
        }

        $appUser = AppUser::find($userId);

        return response()->json([
            'status' => 200,
            'data' => [
                'razorpay_order_id' => $result['orderId'],
                'razorpay_key_id' => $this->razorpayService->getKeyId(),
                'amount' => $result['amount'],
                'currency' => $result['currency'],
                'customer_name' => trim(($appUser->first_name ?? '').' '.($appUser->last_name ?? '')),
                'customer_email' => $appUser->email ?? '',
                'customer_contact' => $appUser->phone ?? '',
                'booking_id' => $bookingId,
            ],
        ]);
    }

    public function initiateWalletRecharge(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'token' => 'required|string',
            'amount' => 'required|numeric|gt:0',
            'currency' => 'required|string|size:3',
        ]);

        $vendor = $this->walletRechargeService->findVendorByToken($validated['token']);

        if (! $vendor) {
            return $this->addErrorResponse(419, trans('global.token_not_match'), '');
        }

        if ($this->getGeneralSettingValue('razorpay_status') !== 'Active') {
            return response()->json([
                'status' => 'error',
                'message' => 'Payment initiation failed.',
            ], 502);
        }

        $currency = strtoupper($validated['currency']);
        $attempt = $this->paymentAttempts->forWallet(
            (int) $vendor->id,
            'vendor_wallet',
            'razorpay',
            $validated['amount'],
            $currency
        );
        $reference = $this->walletRechargeService->createReference((int) $vendor->id);
        $result = $this->razorpayOrder($attempt, $reference);

        if ($result['status'] === 'error') {
            Log::error('Razorpay wallet recharge initiate failed', [
                'vendorId' => $vendor->id,
                'reference' => $reference,
                'message' => $result['message'],
            ]);

            return response()->json([
                'status' => 'error',
                'message' => $result['message'] ?? 'Payment initiation failed.',
            ], 502);
        }

        return response()->json([
            'status' => 200,
            'data' => [
                'razorpay_order_id' => $result['orderId'],
                'razorpay_key_id' => $this->razorpayService->getKeyId(),
                'amount' => $result['amount'],
                'currency' => $result['currency'],
                'customer_name' => trim(($vendor->first_name ?? '').' '.($vendor->last_name ?? '')),
                'customer_email' => $vendor->email ?? '',
                'customer_contact' => $vendor->phone ?? '',
                'wallet_reference' => $reference,
            ],
        ]);
    }

    /**
     * POST /api/v1/payments/razorpay/verify
     *
     * Verifies the payment signature after the Flutter SDK returns a result.
     */
    public function verifyPayment(Request $request): JsonResponse
    {
        $request->validate([
            'booking_id' => 'required|integer|exists:bookings,id',
            'razorpay_order_id' => 'required|string',
            'razorpay_payment_id' => 'required|string',
            'razorpay_signature' => 'required|string',
            'token' => 'required|exists:app_users,token',
        ]);

        $userId = $this->checkUserByToken($request->token);
        if (! $userId) {
            return $this->addErrorResponse(419, trans('global.token_not_match'), '');
        }

        $bookingId = $request->input('booking_id');

        $booking = Booking::where('id', $bookingId)->where('userid', $userId)->first();
        if (! $booking) {
            return response()->json([
                'status' => 'error',
                'message' => 'Booking not found.',
            ], 404);
        }

        $wasPaid = $booking->payment_status === 'paid';

        $attempt = $this->paymentAttempts->findByProviderOrder('razorpay', $request->input('razorpay_order_id'));
        if (! $attempt || (int) $attempt->owner_id !== (int) $userId || (int) $attempt->booking_id !== (int) $bookingId) {
            return response()->json([
                'status' => 'error',
                'message' => 'Payment verification failed.',
            ], 400);
        }

        $isValid = $this->razorpayService->verifyPaymentSignature([
            'razorpay_order_id' => (string) $attempt->provider_order_id,
            'razorpay_payment_id' => $request->input('razorpay_payment_id'),
            'razorpay_signature' => $request->input('razorpay_signature'),
        ]);

        if (! $isValid) {
            Log::warning('Razorpay signature verification failed', [
                'bookingId' => $bookingId,
                'orderId' => $request->input('razorpay_order_id'),
                'paymentId' => $request->input('razorpay_payment_id'),
            ]);

            return response()->json([
                'status' => 'error',
                'message' => 'Payment signature verification failed.',
            ], 400);
        }

        $verified = $this->verifiedPayment(
            $attempt,
            $request->input('razorpay_payment_id')
        );
        if (! $verified) {
            return response()->json([
                'status' => 'error',
                'message' => 'Payment verification failed.',
            ], 400);
        }

        $saveResult = $this->paymentFinalizer->finalize($verified);
        if ($saveResult === PaymentFinalizationService::ALREADY_APPLIED
            || ($saveResult === PaymentFinalizationService::REQUIRES_REVIEW && $wasPaid)) {
            return response()->json([
                'status' => 'success',
                'data' => ['result' => 'already_verified'],
            ]);
        }

        if ($saveResult === PaymentFinalizationService::REQUIRES_REVIEW) {
            Log::error('Razorpay payment requires reconciliation', ['bookingId' => $bookingId]);

            return response()->json([
                'status' => 'error',
                'message' => 'Failed to update booking status.',
            ], 500);
        }

        return response()->json([
            'status' => 'success',
            'data' => ['result' => 'success'],
        ]);
    }

    public function verifyWalletRecharge(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'token' => 'required|string',
            'razorpay_order_id' => 'required|string',
            'razorpay_payment_id' => 'required|string',
            'razorpay_signature' => 'required|string',
        ]);

        $vendor = $this->walletRechargeService->findVendorByToken($validated['token']);

        if (! $vendor) {
            return $this->addErrorResponse(419, trans('global.token_not_match'), '');
        }

        if (! $this->razorpayService->verifyPaymentSignature([
            'razorpay_order_id' => $validated['razorpay_order_id'],
            'razorpay_payment_id' => $validated['razorpay_payment_id'],
            'razorpay_signature' => $validated['razorpay_signature'],
        ])) {
            return response()->json([
                'status' => 'error',
                'message' => 'Payment signature verification failed.',
            ], 400);
        }

        $attempt = $this->paymentAttempts->findByProviderOrder('razorpay', $validated['razorpay_order_id']);
        if (! $attempt || (int) $attempt->owner_id !== (int) $vendor->id || $attempt->purpose !== 'vendor_wallet') {
            return response()->json([
                'status' => 'error',
                'message' => 'Wallet recharge does not belong to this vendor.',
            ], 403);
        }

        $orderResult = $this->razorpayService->fetchOrder((string) $attempt->provider_order_id);
        if ($orderResult['status'] === 'error') {
            return response()->json([
                'status' => 'error',
                'message' => $orderResult['message'] ?? 'Payment verification failed.',
            ], 502);
        }

        $order = $orderResult['data'];
        if (! hash_equals((string) $attempt->provider_order_id, (string) ($order['id'] ?? ''))
            || (int) ($order['amount'] ?? -1) !== (int) $attempt->amount_minor
            || ! hash_equals($attempt->currency, strtoupper((string) ($order['currency'] ?? '')))) {
            return response()->json([
                'status' => 'error',
                'message' => 'Payment verification failed.',
            ], 400);
        }

        if (($order['status'] ?? null) !== 'paid') {
            return response()->json([
                'status' => 'success',
                'data' => ['result' => $order['status'] ?? 'pending'],
            ]);
        }

        $verified = $this->verifiedPayment($attempt, $validated['razorpay_payment_id']);
        if (! $verified) {
            return response()->json([
                'status' => 'error',
                'message' => 'Payment verification failed.',
            ], 400);
        }

        $creditResult = $this->paymentFinalizer->finalize($verified);
        if ($creditResult === PaymentFinalizationService::REQUIRES_REVIEW) {
            return response()->json([
                'status' => 'error',
                'message' => 'Payment verification failed.',
            ], 400);
        }

        return response()->json([
            'status' => 'success',
            'data' => ['result' => $creditResult === PaymentFinalizationService::APPLIED ? 'credited' : 'already_processed'],
        ]);
    }

    /**
     * POST /api/payments/razorpay/webhook
     *
     * Razorpay calls this server-to-server after payment completes.
     * No Sanctum auth — authenticated via HMAC-SHA256 signature verification.
     */
    public function handleWebhook(Request $request): JsonResponse
    {
        $rawBody = $request->getContent();
        $receivedSignature = $request->header('X-Razorpay-Signature');

        if (! $receivedSignature) {
            Log::warning('Razorpay webhook missing signature header');

            return response()->json(['status' => 'missing signature'], 400);
        }

        if (! $this->razorpayService->verifyWebhookSignature($rawBody, $receivedSignature)) {
            Log::warning('Razorpay webhook signature verification failed');

            return response()->json(['status' => 'invalid signature'], 401);
        }

        $webhookEvent = $this->webhooks->register(
            'razorpay',
            $request->header('X-Razorpay-Event-Id'),
            $rawBody
        );
        if (! $webhookEvent) {
            return response()->json([
                'status' => $attempt->purpose === 'vendor_wallet'
                    ? 'already_processed'
                    : 'already processed',
            ]);
        }

        $payload = json_decode($rawBody, true);

        if (! is_array($payload)) {
            Log::warning('Razorpay webhook invalid payload');

            return response()->json(['status' => 'invalid payload'], 400);
        }

        $event = $payload['event'] ?? null;

        if ($event !== 'order.paid') {
            Log::info('Razorpay webhook ignored event', ['event' => $event]);
            $this->webhooks->processed($webhookEvent, 'recorded_only');

            return response()->json(['status' => 'event ignored']);
        }

        $orderEntity = $payload['payload']['order']['entity'] ?? null;
        $paymentEntity = $payload['payload']['payment']['entity'] ?? null;

        if (! is_array($orderEntity)) {
            Log::warning('Razorpay webhook missing order entity');

            return response()->json(['status' => 'missing order entity'], 400);
        }

        $razorpayOrderId = $orderEntity['id'] ?? null;

        if (! $razorpayOrderId) {
            Log::warning('Razorpay webhook missing order id');

            return response()->json(['status' => 'missing order id'], 400);
        }

        $attempt = $this->paymentAttempts->findByProviderOrder('razorpay', $razorpayOrderId);
        if (! $attempt) {
            Log::warning('Razorpay webhook booking not found', ['razorpayOrderId' => $razorpayOrderId]);

            return response()->json(['status' => 'booking not found'], 404);
        }

        $paymentId = $paymentEntity['id'] ?? null;
        $paymentStatus = $paymentEntity['status'] ?? null;

        if ($paymentStatus === 'captured' && ! $paymentId) {
            return response()->json(['status' => 'missing payment id'], 400);
        }

        if ($paymentStatus === 'captured') {
            $verified = $this->verifiedPayment($attempt, (string) $paymentId, $webhookEvent->provider_event_id);
            if (! $verified) {
                $this->webhooks->processed($webhookEvent, 'binding_failed');

                return response()->json(['status' => 'payment not captured']);
            }

            $result = $this->paymentFinalizer->finalize($verified);
            $this->webhooks->processed($webhookEvent, $result);
            Log::info('Razorpay webhook payment confirmed', ['attemptId' => $attempt->id]);

            if ($result === PaymentFinalizationService::REQUIRES_REVIEW) {
                return response()->json([
                    'status' => $attempt->purpose === 'vendor_wallet'
                        ? 'payment not captured'
                        : 'booking update failed',
                ], $attempt->purpose === 'vendor_wallet' ? 200 : 500);
            }

            if ($attempt->purpose === 'vendor_wallet') {
                return response()->json([
                    'status' => $result === PaymentFinalizationService::APPLIED
                        ? 'credited'
                        : 'already_processed',
                ]);
            }

            return response()->json(['status' => 'success']);
        }

        Log::info('Razorpay webhook payment not captured', [
            'attemptId' => $attempt->id,
            'paymentStatus' => $paymentStatus,
        ]);
        $this->webhooks->processed($webhookEvent, 'not_captured');

        return response()->json(['status' => 'payment not captured']);
    }

    private function verifiedPayment($attempt, string $paymentId, ?string $eventId = null): ?VerifiedPayment
    {
        $orderResult = $this->razorpayService->fetchOrder((string) $attempt->provider_order_id);
        $paymentResult = $this->razorpayService->fetchPayment($paymentId);
        if ($orderResult['status'] === 'error' || $paymentResult['status'] === 'error') {
            return null;
        }

        $order = $orderResult['data'];
        $payment = $paymentResult['data'];
        $amount = (int) ($payment['amount'] ?? 0);
        $currency = strtoupper((string) ($payment['currency'] ?? ''));
        if (($payment['status'] ?? null) !== 'captured'
            || ! hash_equals((string) $attempt->provider_order_id, (string) ($payment['order_id'] ?? ''))
            || ! hash_equals((string) $attempt->provider_order_id, (string) ($order['id'] ?? ''))
            || $amount !== (int) $attempt->amount_minor
            || ! hash_equals($attempt->currency, $currency)) {
            return null;
        }

        return new VerifiedPayment(
            (int) $attempt->id,
            'razorpay',
            (string) $attempt->provider_order_id,
            $paymentId,
            $amount,
            $currency,
            'captured',
            $eventId
        );
    }

    private function razorpayOrder(PaymentAttempt $attempt, string $receipt): array
    {
        try {
            return $this->paymentAttempts->withProviderOrderLock(
                $attempt,
                function (PaymentAttempt $locked) use ($receipt) {
                    if ($locked->provider_order_id) {
                        return [
                            'status' => 'success',
                            'orderId' => $locked->provider_order_id,
                            'amount' => $locked->amount_minor,
                            'currency' => $locked->currency,
                        ];
                    }

                    $result = $this->razorpayService->createOrder(
                        (int) $locked->amount_minor,
                        $locked->currency,
                        $receipt
                    );
                    if ($result['status'] !== 'error') {
                        $this->paymentAttempts->attachProviderOrder($locked, $result['orderId']);
                    }

                    return $result;
                }
            );
        } catch (LockTimeoutException) {
            return ['status' => 'error', 'message' => 'Payment initiation failed.'];
        }
    }
}
