<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MiscellaneousTrait;
use App\Http\Controllers\Traits\ResponseTrait;
use App\Models\Booking;
use App\Models\PaymentAttempt;
use App\Payments\PaymentAttemptService;
use App\Payments\PaymentFinalizationService;
use App\Payments\PaymentWebhookService;
use App\Payments\VerifiedPayment;
use App\Services\PhonePeService;
use App\Services\VendorWalletRechargeService;
use Illuminate\Contracts\Cache\LockTimeoutException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class PhonepeApiController extends Controller
{
    use MiscellaneousTrait, ResponseTrait;

    private PhonePeService $phonepeService;

    private VendorWalletRechargeService $walletRechargeService;

    private PaymentAttemptService $paymentAttempts;

    private PaymentFinalizationService $paymentFinalizer;

    private PaymentWebhookService $webhooks;

    public function __construct(
        PhonePeService $phonepeService,
        VendorWalletRechargeService $walletRechargeService,
        PaymentAttemptService $paymentAttempts,
        PaymentFinalizationService $paymentFinalizer,
        PaymentWebhookService $webhooks
    ) {
        $this->phonepeService = $phonepeService;
        $this->walletRechargeService = $walletRechargeService;
        $this->paymentAttempts = $paymentAttempts;
        $this->paymentFinalizer = $paymentFinalizer;
        $this->webhooks = $webhooks;
    }

    /**
     * POST /api/v1/payments/phonepe/initiate
     *
     * Returns orderId + token for the Flutter phonepe_payment_sdk.
     */
    public function initiatePayment(Request $request): JsonResponse
    {
        $request->validate([
            'booking_id' => 'required|integer|exists:bookings,id',
            'token' => 'required|exists:app_users,token',
        ]);

        $userId = $this->checkUserByToken($request->token);
        if (! $userId) {
            return $this->addErrorResponse(419, trans('global.token_not_match'), '');
        }

        $bookingId = $request->input('booking_id');
        $bookingData = Booking::where('id', $bookingId)->where('userid', $userId)->first();

        if (! $bookingData) {
            return response()->json([
                'status' => 'error',
                'message' => 'Booking not found.',
            ], 404);
        }

        if ($bookingData->payment_status === 'paid') {
            return response()->json([
                'status' => 'error',
                'message' => 'Booking is already paid.',
            ], 422);
        }

        if ($this->getGeneralSettingValue('phonepe_status') !== 'Active') {
            return response()->json([
                'status' => 'error',
                'message' => 'Payment initiation failed.',
            ], 502);
        }

        if (strtoupper((string) $bookingData->currency_code) !== 'INR') {
            return response()->json([
                'status' => 'error',
                'message' => 'Payment initiation failed.',
            ], 502);
        }

        $attempt = $this->paymentAttempts->forBooking($bookingData, (int) $userId, 'phonepe');
        $merchantOrderId = $attempt->provider_order_id ?: 'TXN_'.Str::ulid();
        $amountInPaise = (int) $attempt->amount_minor;
        $result = $this->phonepeOrder($attempt, $amountInPaise, $merchantOrderId);

        if ($result['status'] === 'error') {
            Log::error('PhonePe initiate failed', ['bookingId' => $bookingId, 'message' => $result['message']]);

            return response()->json([
                'status' => 'error',
                'message' => $result['message'] ?? 'Payment initiation failed.',
            ], 502);
        }

        return response()->json([
            'status' => 200,
            'data' => [
                'orderId' => $result['orderId'],
                'token' => $result['token'],
                'merchantOrderId' => $merchantOrderId,
                'merchantId' => $result['merchantId'],
                'environment' => ($this->getGeneralSettingValue('phonepe_options') ?? 'test') === 'live' ? 'production' : 'sandbox',
            ],
        ]);
    }

    public function initiateWalletRecharge(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'token' => 'required|string',
            'amount' => 'required|numeric|gt:0',
            'currency' => 'required|string|in:INR,inr',
        ]);

        $vendor = $this->walletRechargeService->findVendorByToken($validated['token']);

        if (! $vendor) {
            return $this->addErrorResponse(419, trans('global.token_not_match'), '');
        }

        if ($this->getGeneralSettingValue('phonepe_status') !== 'Active') {
            return response()->json([
                'status' => 'error',
                'message' => 'Payment initiation failed.',
            ], 502);
        }

        $attempt = $this->paymentAttempts->forWallet(
            (int) $vendor->id,
            'vendor_wallet',
            'phonepe',
            $validated['amount'],
            'INR'
        );
        $merchantOrderId = $attempt->provider_order_id ?: $this->walletRechargeService->createReference((int) $vendor->id);
        $amountInPaise = (int) $attempt->amount_minor;
        $result = $this->phonepeOrder($attempt, $amountInPaise, $merchantOrderId);

        if ($result['status'] === 'error') {
            Log::error('PhonePe wallet recharge initiate failed', [
                'vendorId' => $vendor->id,
                'merchantOrderId' => $merchantOrderId,
                'message' => $result['message'],
            ]);

            return response()->json([
                'status' => 'error',
                'message' => $result['message'] ?? 'Payment initiation failed.',
            ], 502);
        }

        return response()->json([
            'status' => 200,
            'data' => [
                'orderId' => $result['orderId'],
                'token' => $result['token'],
                'merchantOrderId' => $merchantOrderId,
                'merchantId' => $result['merchantId'],
                'amount' => $amountInPaise,
                'currency' => 'INR',
                'environment' => ($this->getGeneralSettingValue('phonepe_options') ?? 'test') === 'live'
                    ? 'production'
                    : 'sandbox',
            ],
        ]);
    }

    /**
     * POST /api/v1/payments/phonepe/verify
     *
     * Called by Flutter app after SDK returns a result to confirm payment status.
     */
    public function verifyPayment(Request $request): JsonResponse
    {
        $request->validate([
            'merchantOrderId' => 'required|string',
            'booking_id' => 'required|integer|exists:bookings,id',
            'token' => 'required|exists:app_users,token',
        ]);

        $userId = $this->checkUserByToken($request->token);
        if (! $userId) {
            return $this->addErrorResponse(419, trans('global.token_not_match'), '');
        }

        $merchantOrderId = $request->input('merchantOrderId');
        $bookingId = $request->input('booking_id');

        $attempt = $this->paymentAttempts->findByProviderOrder('phonepe', $merchantOrderId);
        if (! $attempt
            || $attempt->purpose !== 'booking'
            || (int) $attempt->booking_id !== (int) $bookingId
            || (int) $attempt->owner_id !== (int) $userId) {
            return response()->json([
                'status' => 'error',
                'message' => 'Booking not found.',
            ], 404);
        }

        $booking = Booking::where('id', $bookingId)->where('userid', $userId)->first();
        if (! $booking) {
            return response()->json([
                'status' => 'error',
                'message' => 'Booking not found.',
            ], 404);
        }

        $wasPaid = $booking->payment_status === 'paid';

        $statusResult = $this->phonepeService->getOrderStatus($merchantOrderId);

        if ($statusResult['status'] === 'error') {
            Log::error('PhonePe verify failed', ['merchantOrderId' => $merchantOrderId, 'message' => $statusResult['message']]);

            return response()->json([
                'status' => 'error',
                'message' => $statusResult['message'] ?? 'Verification failed.',
            ], 502);
        }

        if ($statusResult['state'] === 'COMPLETED') {
            $verified = $this->verifiedPhonePePayment($attempt, $statusResult);
            if (! $verified) {
                Log::warning('PhonePe verify binding failed', ['attemptId' => $attempt->id]);

                return response()->json([
                    'status' => 'error',
                    'message' => 'Failed to update booking status.',
                ], 500);
            }

            $saveResult = $this->paymentFinalizer->finalize($verified);
            if ($saveResult === PaymentFinalizationService::ALREADY_APPLIED
                || ($saveResult === PaymentFinalizationService::REQUIRES_REVIEW && $wasPaid)) {
                return response()->json([
                    'status' => 'success',
                    'data' => ['result' => 'already_verified'],
                ]);
            }

            if ($saveResult === PaymentFinalizationService::REQUIRES_REVIEW) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Failed to update booking status.',
                ], 500);
            }

            return response()->json([
                'status' => 'success',
                'data' => ['result' => 'success'],
            ]);
        }

        return response()->json([
            'status' => 'success',
            'data' => ['result' => strtolower($statusResult['state'])],
        ]);
    }

    public function verifyWalletRecharge(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'token' => 'required|string',
            'merchantOrderId' => 'required|string',
        ]);

        $vendor = $this->walletRechargeService->findVendorByToken($validated['token']);

        if (! $vendor) {
            return $this->addErrorResponse(419, trans('global.token_not_match'), '');
        }

        $attempt = $this->paymentAttempts->findByProviderOrder('phonepe', $validated['merchantOrderId']);
        if (! $attempt
            || $attempt->purpose !== 'vendor_wallet'
            || (int) $attempt->owner_id !== (int) $vendor->id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Wallet recharge does not belong to this vendor.',
            ], 403);
        }

        $statusResult = $this->phonepeService->getOrderStatus($validated['merchantOrderId']);

        if ($statusResult['status'] === 'error') {
            return response()->json([
                'status' => 'error',
                'message' => $statusResult['message'] ?? 'Verification failed.',
            ], 502);
        }

        if (($statusResult['state'] ?? null) !== 'COMPLETED') {
            return response()->json([
                'status' => 'success',
                'data' => ['result' => strtolower($statusResult['state'] ?? 'pending')],
            ]);
        }

        $verified = $this->verifiedPhonePePayment($attempt, $statusResult);
        if (! $verified) {
            return response()->json([
                'status' => 'error',
                'message' => 'Verification failed.',
            ], 502);
        }

        $creditResult = $this->paymentFinalizer->finalize($verified);
        if ($creditResult === PaymentFinalizationService::REQUIRES_REVIEW) {
            return response()->json([
                'status' => 'error',
                'message' => 'Verification failed.',
            ], 502);
        }

        return response()->json([
            'status' => 'success',
            'data' => [
                'result' => $creditResult === PaymentFinalizationService::APPLIED
                    ? 'credited'
                    : 'already_processed',
            ],
        ]);
    }

    /**
     * POST /api/v1/payments/phonepe/webhook
     *
     * PhonePe calls this server-to-server after payment completes.
     * No Sanctum auth — authenticated via Authorization: SHA256(username:password) header.
     */
    public function handleWebhook(Request $request): JsonResponse
    {
        $authorizationHeader = $request->header('Authorization');

        if (! $this->phonepeService->verifyWebhookAuthorization($authorizationHeader)) {
            Log::warning('PhonePe webhook authorization failed');

            return response()->json(['status' => 'unauthorized'], 401);
        }

        $rawBody = $request->getContent();
        $payload = json_decode($rawBody, true);

        if (! is_array($payload)) {
            Log::warning('PhonePe webhook invalid payload');

            return response()->json(['status' => 'invalid payload'], 400);
        }

        $event = $payload['event'] ?? null;
        $data = $payload['payload'] ?? null;

        if (! is_array($data)) {
            Log::warning('PhonePe webhook missing payload data');

            return response()->json(['status' => 'missing payload'], 400);
        }

        $merchantOrderId = $data['merchantOrderId'] ?? null;

        if (! $merchantOrderId) {
            Log::warning('PhonePe webhook missing merchantOrderId');

            return response()->json(['status' => 'missing merchantOrderId'], 400);
        }

        $attempt = $this->paymentAttempts->findByProviderOrder('phonepe', (string) $merchantOrderId);
        if (! $attempt) {
            Log::warning('PhonePe webhook invalid order', ['merchantOrderId' => $merchantOrderId]);

            return response()->json(['status' => 'invalid orderId'], 400);
        }

        $webhookEvent = $this->webhooks->register(
            'phonepe',
            $request->header('X-PhonePe-Event-Id'),
            $rawBody
        );
        if (! $webhookEvent) {
            return response()->json([
                'status' => $attempt->purpose === 'vendor_wallet'
                    ? 'already_processed'
                    : 'already processed',
            ]);
        }

        if ($event !== 'checkout.order.completed' || ($data['state'] ?? null) !== 'COMPLETED') {
            $result = ($data['state'] ?? null) === 'PENDING' ? 'pending' : 'failed';
            $this->webhooks->processed($webhookEvent, $result);

            return response()->json(['status' => $result]);
        }

        $statusResult = $this->phonepeService->getOrderStatus((string) $merchantOrderId);
        if (($statusResult['status'] ?? null) === 'error') {
            $this->webhooks->retryable($webhookEvent);

            return response()->json(['status' => 'booking update failed'], 500);
        }

        $verified = $this->verifiedPhonePePayment(
            $attempt,
            $statusResult,
            $webhookEvent->provider_event_id
        );
        if (! $verified) {
            $this->webhooks->processed($webhookEvent, 'binding_failed');

            return response()->json(['status' => 'booking update failed'], 500);
        }

        $result = $this->paymentFinalizer->finalize($verified);
        $this->webhooks->processed($webhookEvent, $result);

        if ($result === PaymentFinalizationService::REQUIRES_REVIEW) {
            return $attempt->purpose === 'vendor_wallet'
                ? response()->json(['status' => 'failed'])
                : response()->json(['status' => 'booking update failed'], 500);
        }

        if ($attempt->purpose === 'vendor_wallet') {
            return response()->json([
                'status' => $result === PaymentFinalizationService::APPLIED
                    ? 'credited'
                    : 'already_processed',
            ]);
        }

        return response()->json([
            'status' => $result === PaymentFinalizationService::ALREADY_APPLIED
                ? 'already processed'
                : 'success',
        ]);
    }

    private function phonepeOrder(
        PaymentAttempt $attempt,
        int $amountInPaise,
        string $merchantOrderId
    ): array {
        try {
            return $this->paymentAttempts->withProviderOrderLock(
                $attempt,
                fn (PaymentAttempt $locked) => $this->phonepeOrderLocked(
                    $locked,
                    $amountInPaise,
                    $locked->provider_order_id ?: $merchantOrderId
                )
            );
        } catch (LockTimeoutException) {
            return ['status' => 'error', 'message' => 'Payment initiation failed.'];
        }
    }

    private function phonepeOrderLocked(
        PaymentAttempt $attempt,
        int $amountInPaise,
        string $merchantOrderId
    ): array {
        if ($attempt->provider_order_id
            && isset($attempt->provider_metadata['checkout_order_id'], $attempt->provider_metadata['checkout_token'])) {
            return [
                'status' => 'success',
                'orderId' => $attempt->provider_metadata['checkout_order_id'],
                'token' => $attempt->provider_metadata['checkout_token'],
                'merchantId' => $this->phonepeService->merchantId(),
            ];
        }

        $result = $this->phonepeService->createSdkOrder($amountInPaise, $merchantOrderId);
        if (($result['status'] ?? null) === 'success') {
            $this->paymentAttempts->attachProviderOrder($attempt, $merchantOrderId, [
                'checkout_order_id' => $result['orderId'],
                'checkout_token' => $result['token'],
            ]);
        }

        return $result;
    }

    private function verifiedPhonePePayment(
        PaymentAttempt $attempt,
        array $status,
        ?string $eventId = null
    ): ?VerifiedPayment {
        $paymentDetails = $status['paymentDetails'] ?? [];
        $transactionId = is_array($paymentDetails)
            ? (string) ($paymentDetails[0]['transactionId'] ?? '')
            : '';
        $merchantOrderId = (string) ($status['merchantOrderId'] ?? '');

        if (($status['state'] ?? null) !== 'COMPLETED'
            || $transactionId === ''
            || ! hash_equals((string) $attempt->provider_order_id, $merchantOrderId)
            || (int) ($status['amount'] ?? -1) !== (int) $attempt->amount_minor
            || $attempt->currency !== 'INR') {
            return null;
        }

        return new VerifiedPayment(
            (int) $attempt->id,
            'phonepe',
            (string) $attempt->provider_order_id,
            $transactionId,
            (int) $attempt->amount_minor,
            'INR',
            'completed',
            $eventId
        );
    }
}
