<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Controllers\Traits\MiscellaneousTrait;
use App\Http\Controllers\Traits\ResponseTrait;
use App\Http\Requests\Admin\StoreStaticPageRequest;
use App\Http\Requests\Admin\UpdateStaticPageRequest;
use App\Http\Resources\Admin\StaticPageResource;
use App\Models\StaticPage;
use App\Services\TranslationService;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class StaticPagesApiController extends Controller
{
    use MediaUploadingTrait, MiscellaneousTrait, ResponseTrait;

    public function index()
    {
        abort_if(Gate::denies('static_page_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new StaticPageResource(StaticPage::all());
    }

    public function store(StoreStaticPageRequest $request)
    {
        $data = $request->except(['name', 'content']);
        $data['name'] = TranslationService::valueForDefault($request->name) ?? '';
        $data['content'] = TranslationService::valueForDefault($request->content);
        $staticPage = StaticPage::create($data);

        return (new StaticPageResource($staticPage))
            ->response()
            ->setStatusCode(Response::HTTP_CREATED);
    }

    public function show(StaticPage $staticPage)
    {
        abort_if(Gate::denies('static_page_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new StaticPageResource($staticPage);
    }

    public function update(UpdateStaticPageRequest $request, StaticPage $staticPage)
    {
        $data = $request->except(['name', 'content']);
        $data['name'] = TranslationService::valueForDefault($request->name) ?? '';
        $data['content'] = TranslationService::valueForDefault($request->content);
        $staticPage->update($data);

        return (new StaticPageResource($staticPage))
            ->response()
            ->setStatusCode(Response::HTTP_ACCEPTED);
    }

    public function destroy(StaticPage $staticPage)
    {
        abort_if(Gate::denies('static_page_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $staticPage->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }

    public function StaticPage(Request $request)
    {
        try {
            $pageId = $request->input('id') ?? $request->input('page_id');
            $staticdata = null;

            if ($pageId !== null && $pageId !== '') {
                $staticdata = StaticPage::where('id', $pageId)->first();
            }

            if (! $staticdata && $request->filled('page_name')) {
                $staticdata = StaticPage::where('name', $request->input('page_name'))->first();
            }

            if (! $staticdata) {
                return $this->addErrorResponse(500, trans('global.incorrect_page_name'), '');
            }

            $staticdata->makeHidden('translations');

            return $this->addSuccessResponse(200, trans('general_settings.static_page_data'), ['StaticPage' => $staticdata]);
        } catch (\Exception $e) {
            return $this->addErrorResponse(500, trans('global.something_wrong'), $e->getMessage());
        }

    }
}
