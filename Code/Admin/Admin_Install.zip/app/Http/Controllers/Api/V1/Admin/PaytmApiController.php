<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MiscellaneousTrait;
use App\Http\Controllers\Traits\ResponseTrait;
use App\Models\Booking;
use App\Models\PaymentAttempt;
use App\Payments\PaymentAttemptService;
use App\Payments\PaymentFinalizationService;
use App\Payments\PaymentWebhookService;
use App\Payments\VerifiedPayment;
use App\Services\VendorWalletRechargeService;
use App\Support\Money;
use App\Utilities\PaytmChecksum;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class PaytmApiController extends Controller
{
    use MiscellaneousTrait, ResponseTrait;

    private $merchantId;

    private $merchantKey;

    private $websiteName;

    private $apiURL;

    private $statusURL;

    private VendorWalletRechargeService $walletRechargeService;

    private PaymentAttemptService $paymentAttempts;

    private PaymentFinalizationService $paymentFinalizer;

    private PaymentWebhookService $webhooks;

    public function __construct(
        VendorWalletRechargeService $walletRechargeService,
        PaymentAttemptService $paymentAttempts,
        PaymentFinalizationService $paymentFinalizer,
        PaymentWebhookService $webhooks
    ) {
        $this->walletRechargeService = $walletRechargeService;
        $this->paymentAttempts = $paymentAttempts;
        $this->paymentFinalizer = $paymentFinalizer;
        $this->webhooks = $webhooks;
        $environment = $this->getGeneralSettingValue('paytm_options');
        $isLive = $environment === 'live';

        $host = $isLive ? 'https://secure.paytmpayments.com' : 'https://securestage.paytmpayments.com';

        $this->merchantId = $this->getGeneralSettingValue($isLive ? 'live_paytm_merchant_id' : 'test_paytm_merchant_id');
        $this->merchantKey = $this->getGeneralSettingValue($isLive ? 'live_paytm_merchant_key' : 'test_paytm_merchant_key');
        $this->websiteName = $this->getGeneralSettingValue($isLive ? 'live_paytm_website_name' : 'test_paytm_website_name');

        $this->apiURL = $host.'/theia/api/v1/initiateTransaction?mid='.$this->merchantId;
        $this->statusURL = $host.'/v3/order/status?mid='.$this->merchantId;
    }

    /**
     * POST /api/v1/payments/paytm/initiate
     *
     * Returns txnToken + params needed by the Flutter paytm_allinone SDK.
     */
    public function initiatePayment(Request $request): JsonResponse
    {
        $request->validate([
            'booking_id' => 'required|integer|exists:bookings,id',
            'token' => 'required|exists:app_users,token',
        ]);

        $user_id = $this->checkUserByToken($request->token);
        if (! $user_id) {
            return $this->addErrorResponse(419, trans('global.token_not_match'), '');
        }

        $bookingId = (int) $request->input('booking_id');
        $bookingData = Booking::where('id', $bookingId)->where('userid', $user_id)->first();

        if (! $bookingData) {
            return response()->json([
                'status' => 404,
                'message' => 'Booking not found.',
            ], 404);
        }

        if ($bookingData->payment_status === 'paid') {
            return response()->json([
                'status' => 422,
                'message' => 'Booking is already paid.',
            ], 422);
        }

        if ($this->getGeneralSettingValue('paytm_status') !== 'Active') {
            return response()->json([
                'status' => 502,
                'message' => 'Payment initiation failed.',
            ], 502);
        }

        if (strtoupper((string) $bookingData->currency_code) !== 'INR') {
            return response()->json([
                'status' => 502,
                'message' => 'Payment initiation failed.',
            ], 502);
        }

        $attempt = $this->paymentAttempts->forBooking($bookingData, (int) $user_id, 'paytm');
        $lock = Cache::lock('payment-provider-order:'.$attempt->public_id, 60);

        if (! $lock->get()) {
            return response()->json([
                'status' => 409,
                'message' => 'Payment initiation is already in progress.',
            ], 409);
        }

        try {
            return $this->initiatePaytmTransaction($bookingId, $bookingData, $attempt);
        } finally {
            $lock->release();
        }
    }

    public function initiateWalletRecharge(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'token' => 'required|string',
            'amount' => 'required|numeric|gt:0',
        ]);

        $vendor = $this->walletRechargeService->findVendorByToken($validated['token']);

        if (! $vendor) {
            return $this->addErrorResponse(419, trans('global.token_not_match'), '');
        }

        if ($this->getGeneralSettingValue('paytm_status') !== 'Active') {
            return response()->json([
                'status' => 502,
                'message' => 'Payment initiation failed.',
            ], 502);
        }

        $attempt = $this->paymentAttempts->forWallet(
            (int) $vendor->id,
            'vendor_wallet',
            'paytm',
            $validated['amount'],
            'INR'
        );
        $walletOrderId = $attempt->provider_order_id
            ?: $this->walletRechargeService->createReference((int) $vendor->id);
        $lock = Cache::lock('payment-provider-order:'.$attempt->public_id, 60);

        if (! $lock->get()) {
            return response()->json([
                'status' => 409,
                'message' => 'Payment initiation is already in progress.',
            ], 409);
        }

        try {
            $paytmParams = [
                'body' => [
                    'requestType' => 'Payment',
                    'websiteName' => $this->websiteName,
                    'mid' => $this->merchantId,
                    'orderId' => $walletOrderId,
                    'callbackUrl' => route('paytm.webhook'),
                    'txnAmount' => [
                        'value' => Money::fromMinor((int) $attempt->amount_minor, 'INR'),
                        'currency' => 'INR',
                    ],
                    'userInfo' => [
                        'custId' => (string) $vendor->id,
                    ],
                ],
            ];

            $paytmParams['head'] = [
                'signature' => PaytmChecksum::generateSignature(
                    json_encode($paytmParams['body'], JSON_UNESCAPED_SLASHES),
                    $this->merchantKey
                ),
            ];

            if ($attempt->provider_order_id && isset($attempt->provider_metadata['checkout_token'])) {
                $result = ['body' => [
                    'txnToken' => $attempt->provider_metadata['checkout_token'],
                    'resultInfo' => ['resultStatus' => 'S'],
                ]];
            } else {
                $response = $this->makeCurlRequest(
                    $this->apiURL.'&orderId='.rawurlencode($walletOrderId),
                    $paytmParams
                );

                if ($response['status'] === 'error') {
                    return response()->json([
                        'status' => 502,
                        'message' => $response['message'] ?? 'Payment initiation failed.',
                    ], 502);
                }

                $result = json_decode($response['data'], true);
            }

            if (
                ! is_array($result)
                || ($result['body']['resultInfo']['resultStatus'] ?? null) !== 'S'
            ) {
                return response()->json([
                    'status' => 502,
                    'message' => $result['body']['resultInfo']['resultMsg']
                        ?? 'Payment initiation failed.',
                ], 502);
            }

            if (! $attempt->provider_order_id) {
                $this->paymentAttempts->attachProviderOrder($attempt, $walletOrderId, [
                    'checkout_token' => $result['body']['txnToken'] ?? null,
                ]);
            }

            $environment = $this->getGeneralSettingValue('paytm_options');

            return response()->json([
                'status' => 200,
                'data' => [
                    'txnToken' => $result['body']['txnToken'] ?? null,
                    'mid' => $this->merchantId,
                    'orderId' => $walletOrderId,
                    'amount' => Money::fromMinor((int) $attempt->amount_minor, 'INR'),
                    'currency' => 'INR',
                    'isStaging' => $environment !== 'live',
                ],
            ]);
        } finally {
            $lock->release();
        }
    }

    private function initiatePaytmTransaction(
        int $bookingId,
        Booking $bookingData,
        PaymentAttempt $attempt
    ): JsonResponse {
        $paytmOrderId = $attempt->provider_order_id ?: $this->generatePaytmOrderId($bookingId);

        $paytmParams = [];
        $paytmParams['body'] = [
            'requestType' => 'Payment',
            'websiteName' => $this->websiteName,
            'mid' => $this->merchantId,
            'orderId' => $paytmOrderId,
            'callbackUrl' => route('paytm.webhook'),
            'txnAmount' => [
                'value' => Money::fromMinor((int) $attempt->amount_minor, 'INR'),
                'currency' => 'INR',
            ],
            'userInfo' => [
                'custId' => (string) $bookingData->userid,
            ],
        ];

        $checksum = PaytmChecksum::generateSignature(
            json_encode($paytmParams['body'], JSON_UNESCAPED_SLASHES),
            $this->merchantKey
        );

        $paytmParams['head'] = [
            'signature' => $checksum,
        ];

        if ($attempt->provider_order_id && isset($attempt->provider_metadata['checkout_token'])) {
            $result = ['body' => [
                'txnToken' => $attempt->provider_metadata['checkout_token'],
                'resultInfo' => ['resultStatus' => 'S'],
            ]];
        } else {
            $response = $this->makeCurlRequest(
                $this->apiURL.'&orderId='.rawurlencode($paytmOrderId),
                $paytmParams
            );

            if ($response['status'] === 'error') {
                Log::error('Paytm API initiate failed:', [
                    'bookingId' => $bookingId,
                    'orderId' => $paytmOrderId,
                    'message' => $response['message'],
                ]);

                return response()->json([
                    'status' => 502,
                    'message' => $response['message'] ?? 'Payment initiation failed.',
                ], 502);
            }

            $result = json_decode($response['data'], true);
        }

        if (! is_array($result)) {
            Log::error('Paytm API initiate unparseable response:', [
                'bookingId' => $bookingId,
                'orderId' => $paytmOrderId,
            ]);

            return response()->json([
                'status' => 502,
                'message' => 'Payment initiation failed.',
            ], 502);
        }

        if (isset($result['body']['resultInfo']['resultStatus']) && $result['body']['resultInfo']['resultStatus'] === 'S') {
            if (! $attempt->provider_order_id) {
                $this->paymentAttempts->attachProviderOrder($attempt, $paytmOrderId, [
                    'checkout_token' => $result['body']['txnToken'] ?? null,
                ]);
            }
            $environment = $this->getGeneralSettingValue('paytm_options');

            return response()->json([
                'status' => 200,
                'data' => [
                    'txnToken' => $result['body']['txnToken'] ?? null,
                    'mid' => $this->merchantId,
                    'orderId' => $paytmOrderId,
                    'amount' => Money::fromMinor((int) $attempt->amount_minor, 'INR'),
                    'isStaging' => $environment !== 'live',
                ],
            ]);
        }

        $errorMessage = $result['body']['resultInfo']['resultMsg'] ?? 'Payment initiation failed.';

        Log::error('Paytm API initiate unsuccessful:', [
            'bookingId' => $bookingId,
            'orderId' => $paytmOrderId,
            'providerCode' => $result['body']['resultInfo']['resultCode'] ?? null,
        ]);

        return response()->json([
            'status' => 502,
            'message' => $errorMessage,
        ], 502);
    }

    /**
     * POST /api/payments/paytm/webhook
     *
     * Paytm calls this server-to-server after a transaction completes.
     * No Sanctum auth — authenticated via checksum verification.
     */
    public function handleWebhook(Request $request): JsonResponse
    {
        $params = $request->all();
        $checksum = $params['CHECKSUMHASH'] ?? null;

        if (! $checksum) {
            Log::warning('Paytm webhook missing checksum');

            return response()->json(['status' => 'missing checksum'], 400);
        }

        unset($params['CHECKSUMHASH']);

        $isValidChecksum = PaytmChecksum::verifySignature($params, $this->merchantKey, $checksum);

        if (! $isValidChecksum) {
            Log::warning('Paytm webhook checksum verification failed');

            return response()->json(['status' => 'invalid checksum'], 400);
        }

        $paytmOrderId = (string) ($params['ORDERID'] ?? '');

        if (! $paytmOrderId) {
            Log::warning('Paytm webhook missing ORDERID');

            return response()->json(['status' => 'missing order id'], 400);
        }

        $attempt = $this->paymentAttempts->findByProviderOrder('paytm', $paytmOrderId);
        if (! $attempt) {
            Log::warning('Paytm webhook invalid ORDERID', ['orderId' => $paytmOrderId]);

            return response()->json(['status' => 'invalid order id'], 400);
        }

        $webhookEvent = $this->webhooks->register('paytm', null, $request->getContent());
        if (! $webhookEvent) {
            return response()->json([
                'status' => $attempt->purpose === 'vendor_wallet'
                    ? 'already_processed'
                    : 'already processed',
            ]);
        }

        $statusResult = $this->fetchTransactionStatus($paytmOrderId);

        if ($statusResult['status'] === 'error') {
            $this->webhooks->retryable($webhookEvent);
            Log::error('Paytm webhook status check failed', [
                'attemptId' => $attempt->id,
                'orderId' => $paytmOrderId,
                'message' => $statusResult['message'],
            ]);

            return response()->json(['status' => 'status check failed'], 502);
        }

        $resultStatus = $statusResult['data']['body']['resultInfo']['resultStatus'] ?? null;

        if ($resultStatus === 'TXN_SUCCESS') {
            $txnId = $statusResult['data']['body']['txnId'] ?? ($params['TXNID'] ?? null);
            $verified = $this->verifiedPaytmPayment($attempt, $statusResult['data'], (string) $txnId, $webhookEvent->provider_event_id);
            if (! $verified) {
                $this->webhooks->processed($webhookEvent, 'binding_failed');

                return response()->json(['status' => 500, 'message' => 'booking update failed'], 500);
            }

            $result = $this->paymentFinalizer->finalize($verified);
            $this->webhooks->processed($webhookEvent);
            Log::info('Paytm webhook payment confirmed', ['attemptId' => $attempt->id, 'txnId' => $txnId]);

            if ($result === PaymentFinalizationService::REQUIRES_REVIEW) {
                return $attempt->purpose === 'vendor_wallet'
                    ? response()->json(['status' => 'failed'])
                    : response()->json(['status' => 500, 'message' => 'booking update failed'], 500);
            }

            if ($attempt->purpose === 'vendor_wallet') {
                return response()->json([
                    'status' => $result === PaymentFinalizationService::APPLIED
                        ? 'credited'
                        : 'already_processed',
                ]);
            }

            return response()->json(['status' => 200]);
        }

        if ($resultStatus === 'PENDING') {
            Log::info('Paytm webhook payment pending', ['attemptId' => $attempt->id]);
            $this->webhooks->retryable($webhookEvent);

            return response()->json(['status' => 'pending']);
        }

        Log::info('Paytm webhook payment failed', ['attemptId' => $attempt->id, 'resultStatus' => $resultStatus]);
        $this->webhooks->processed($webhookEvent, 'failed');

        return response()->json(['status' => 'failed']);
    }

    /**
     * POST /api/v1/payments/paytm/verify
     *
     * Calls Paytm's Order Status API in real-time to verify a transaction.
     */
    public function verifyPayment(Request $request): JsonResponse
    {
        $request->validate([
            'booking_id' => 'required|integer|exists:bookings,id',
            'orderId' => 'required|string|max:50',
        ]);

        $bookingId = (int) $request->input('booking_id');
        $paytmOrderId = (string) $request->input('orderId');
        $attempt = $this->paymentAttempts->findByProviderOrder('paytm', $paytmOrderId);
        if (! $attempt || (int) $attempt->booking_id !== $bookingId) {
            return response()->json([
                'success' => false,
                'status' => 'INVALID_ORDER_ID',
            ], 422);
        }

        $userId = $request->user()?->getAuthIdentifier();
        $booking = Booking::where('id', $bookingId)->where('userid', $userId)->first();

        if (! $booking) {
            return response()->json([
                'success' => false,
                'status' => 'BOOKING_NOT_FOUND',
            ], 404);
        }

        $wasPaid = $booking->payment_status === 'paid';

        $statusResult = $this->fetchTransactionStatus($paytmOrderId);

        if ($statusResult['status'] === 'error') {
            Log::error('Paytm verify failed:', [
                'bookingId' => $bookingId,
                'orderId' => $paytmOrderId,
                'message' => $statusResult['message'],
            ]);

            return response()->json([
                'success' => false,
                'status' => 'TXN_FAILURE',
            ]);
        }

        $resultInfo = $statusResult['data']['body']['resultInfo'] ?? [];
        $txnStatus = $resultInfo['resultStatus'] ?? 'TXN_FAILURE';
        $txnId = $statusResult['data']['body']['txnId'] ?? null;

        $transaction = $statusResult['data']['body']['txnAmount'] ?? null;

        if ($txnStatus === 'TXN_SUCCESS') {
            $verified = $this->verifiedPaytmPayment($attempt, $statusResult['data'], (string) $txnId);
            if (! $verified) {
                $txnStatus = 'TXN_FAILURE';
            } else {
                $saveResult = $this->paymentFinalizer->finalize($verified);
                if ($saveResult === PaymentFinalizationService::REQUIRES_REVIEW && ! $wasPaid) {
                    $txnStatus = 'TXN_FAILURE';
                }
            }
        }

        return response()->json([
            'success' => $txnStatus === 'TXN_SUCCESS',
            'status' => $txnStatus,
            'txnId' => $txnId,
            'amount' => $transaction,
        ]);
    }

    public function verifyWalletRecharge(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'token' => 'required|string',
            'orderId' => 'required|string|max:50',
        ]);

        $vendor = $this->walletRechargeService->findVendorByToken($validated['token']);

        if (! $vendor) {
            return $this->addErrorResponse(419, trans('global.token_not_match'), '');
        }

        $attempt = $this->paymentAttempts->findByProviderOrder('paytm', $validated['orderId']);
        if (! $attempt || (int) $attempt->owner_id !== (int) $vendor->id || $attempt->purpose !== 'vendor_wallet') {
            return response()->json([
                'success' => false,
                'status' => 'INVALID_ORDER_ID',
            ], 403);
        }

        $statusResult = $this->fetchTransactionStatus($validated['orderId']);

        if ($statusResult['status'] === 'error') {
            return response()->json([
                'success' => false,
                'status' => 'TXN_FAILURE',
            ], 502);
        }

        $body = $statusResult['data']['body'] ?? [];
        $txnStatus = $body['resultInfo']['resultStatus'] ?? 'TXN_FAILURE';

        if ($txnStatus !== 'TXN_SUCCESS') {
            return response()->json([
                'success' => false,
                'status' => $txnStatus,
            ]);
        }

        $verified = $this->verifiedPaytmPayment(
            $attempt,
            $statusResult['data'],
            (string) ($body['txnId'] ?? '')
        );
        if (! $verified) {
            return response()->json([
                'success' => false,
                'status' => 'TXN_FAILURE',
            ], 502);
        }

        $creditResult = $this->paymentFinalizer->finalize($verified);
        if ($creditResult === PaymentFinalizationService::REQUIRES_REVIEW) {
            return response()->json([
                'success' => false,
                'status' => 'TXN_FAILURE',
            ], 502);
        }

        return response()->json([
            'success' => true,
            'status' => 'TXN_SUCCESS',
            'data' => ['result' => $creditResult === PaymentFinalizationService::APPLIED ? 'credited' : 'already_processed'],
        ]);
    }

    /**
     * Calls Paytm's Order Status API to get an authoritative transaction status.
     */
    private function fetchTransactionStatus(string $paytmOrderId): array
    {
        $body = [
            'mid' => $this->merchantId,
            'orderId' => $paytmOrderId,
        ];

        $checksum = PaytmChecksum::generateSignature(
            json_encode($body, JSON_UNESCAPED_SLASHES),
            $this->merchantKey
        );

        $payload = [
            'body' => $body,
            'head' => [
                'signature' => $checksum,
            ],
        ];

        $response = $this->makeCurlRequest(
            $this->statusURL.'&orderId='.rawurlencode($paytmOrderId),
            $payload
        );

        if ($response['status'] === 'error') {
            return $response;
        }

        $result = json_decode($response['data'], true);

        if (! is_array($result)) {
            return [
                'status' => 'error',
                'message' => 'Unparseable status response.',
            ];
        }

        return [
            'status' => 'success',
            'data' => $result,
        ];
    }

    private function verifiedPaytmPayment(
        PaymentAttempt $attempt,
        array $statusResponse,
        string $transactionId,
        ?string $eventId = null
    ): ?VerifiedPayment {
        $body = $statusResponse['body'] ?? [];
        $resultStatus = $body['resultInfo']['resultStatus'] ?? null;
        $orderId = (string) ($body['orderId'] ?? $body['ORDERID'] ?? '');
        $mid = (string) ($body['mid'] ?? $body['MID'] ?? '');
        $amountValue = $body['txnAmount'] ?? $body['TXNAMOUNT'] ?? null;
        if (is_array($amountValue)) {
            $amountValue = $amountValue['value'] ?? null;
        }
        $currency = strtoupper((string) ($body['currency'] ?? $body['CURRENCY'] ?? 'INR'));

        if ($resultStatus !== 'TXN_SUCCESS'
            || $transactionId === ''
            || ! hash_equals((string) $attempt->provider_order_id, $orderId)
            || ! hash_equals((string) $this->merchantId, $mid)
            || ! hash_equals($attempt->currency, $currency)) {
            return null;
        }

        try {
            $amountMinor = Money::toMinor((string) $amountValue, $currency);
        } catch (\InvalidArgumentException) {
            return null;
        }

        if ($amountMinor !== (int) $attempt->amount_minor) {
            return null;
        }

        return new VerifiedPayment(
            (int) $attempt->id,
            'paytm',
            (string) $attempt->provider_order_id,
            $transactionId,
            $amountMinor,
            $currency,
            'txn_success',
            $eventId
        );
    }

    /**
     * Paytm requires a unique order ID for each payment attempt.
     */
    protected function generatePaytmOrderId(int $bookingId): string
    {
        return 'P'.$bookingId.'_'.Str::ulid();
    }

    /**
     * Generic POST helper for all Paytm API calls.
     */
    private function makeCurlRequest($url, $postFields): array
    {
        $postData = json_encode($postFields, JSON_UNESCAPED_SLASHES);

        if ($postData === false) {
            return [
                'status' => 'error',
                'message' => 'JSON encoding error: '.json_last_error_msg(),
            ];
        }

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);

        $response = curl_exec($ch);
        $httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if (curl_errno($ch)) {
            $error = curl_error($ch);
            curl_close($ch);

            return [
                'status' => 'error',
                'message' => $error,
            ];
        }

        curl_close($ch);

        if ($httpStatus >= 400) {
            return [
                'status' => 'error',
                'message' => "HTTP Error: $httpStatus, Response: $response",
            ];
        }

        return [
            'status' => 'success',
            'data' => $response,
        ];
    }
}
