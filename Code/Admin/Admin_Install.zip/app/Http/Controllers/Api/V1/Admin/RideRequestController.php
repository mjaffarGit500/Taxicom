<?php

// Disabled because MongoDB support has been removed. The previous implementation
// is preserved below as comments for reference only.
//
// namespace App\Http\Controllers\Api\V1\Admin;
//
// use App\Http\Controllers\Controller;
// use App\Http\Controllers\Traits\ResponseTrait;
// use App\Models\RideRequest;
// use Carbon\Carbon;
// use Illuminate\Http\Request;
// use Validator;
//
// class RideRequestController extends Controller
// {
//     use ResponseTrait;
//
//     public function createRide(Request $request)
//     {
//         $validated = $request->validate([
//             'user_id' => 'required|integer',
//             'pickup_location' => 'required|string',
//             'drop_location' => 'required|string',
//         ]);
//
//         $ride = RideRequest::create(array_merge($validated, [
//             'status' => 'pending',
//             'requested_at' => now(),
//         ]));
//
//         return response()->json([
//             'success' => true,
//             'data' => $ride,
//         ]);
//     }
//
//     public function getRides()
//     {
//         $startOfDay = Carbon::today()->startOfDay();
//         $endOfDay = Carbon::today()->endOfDay();
//         $rides = RideRequest::whereBetween('requested_at', [$startOfDay, $endOfDay])->get();
//
//         return response()->json([
//             'success' => true,
//             'data' => $rides,
//         ]);
//     }
//
//     public function updateRideStatus(Request $request, $id)
//     {
//         $validator = Validator::make($request->all(), [
//             'status' => 'required|string|in:pending,accepted,completed,cancelled',
//         ]);
//
//         if ($validator->fails()) {
//             return $this->errorResponse(400, trans('global.validation_error'));
//         }
//
//         $ride = RideRequest::find($id);
//
//         if (! $ride) {
//             return response()->json([
//                 'success' => false,
//                 'message' => 'Ride not found',
//             ], 404);
//         }
//
//         $ride->status = $validator->validated()['status'];
//         $ride->save();
//
//         return response()->json([
//             'success' => true,
//             'data' => $ride,
//             'message' => 'Ride status updated successfully',
//         ]);
//     }
// }
