<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\ResponseTrait;
use App\Models\BootstrapClient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class TokenController extends Controller
{
    use ResponseTrait;

    public function issueBootstrapToken(Request $request)
    {
        $configuredSecret = config('sanctum.bootstrap_secret');

        if (!is_string($configuredSecret) || strlen($configuredSecret) !== 64) {
            Log::critical('Mobile bootstrap token issuance is disabled because SANCTUM_ACCESS_SECRET is not configured correctly.');

            return $this->errorResponse(503, 'Token service is unavailable.')
                ->header('Cache-Control', 'no-store');
        }

        $providedSecret = (string) $request->header('X-RideOn-Bootstrap-Publishable-Key', '');

        if ($providedSecret === '' || !hash_equals($configuredSecret, $providedSecret)) {
            return $this->errorResponse(401, trans('front.Unauthorized'))
                ->header('Cache-Control', 'no-store');
        }

        $bootstrapClient = BootstrapClient::query()
            ->where('name', BootstrapClient::MOBILE_CLIENT)
            ->where('enabled', true)
            ->first();

        if (!$bootstrapClient) {
            Log::critical('Mobile bootstrap token issuance is disabled because the bootstrap client is missing or disabled.');

            return $this->errorResponse(503, 'Token service is unavailable.')
                ->header('Cache-Control', 'no-store');
        }

        $expiration = now()->addMinutes(max(1, (int) config('sanctum.bootstrap_expiration', 30)));
        $tokenInstance = $bootstrapClient->createToken(
            'mobile-bootstrap',
            ['auth:bootstrap', 'settings:read'],
            $expiration
        );
        $tokenInstance->accessToken->called_ip = $request->ip();
        $tokenInstance->accessToken->save();

        return $this->addSuccessResponse(200, trans('front.authorized'), [
            'access_token' => $tokenInstance->plainTextToken,
            'token_type' => 'Bearer',
            'expires_at' => $expiration->toIso8601String(),
        ])->header('Cache-Control', 'no-store');
    }
}