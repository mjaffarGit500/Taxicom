<?php

namespace App\Http\Controllers\Front\WalletRecharge;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Front\PaymentFrontController;
use App\Http\Controllers\Traits\MiscellaneousTrait;
use App\Models\GeneralSetting;
use App\Services\VendorWalletRechargeService;
use App\Strategies\MyFatoorahStrategy;
use App\Strategies\PayduniyaStrategy;
use App\Strategies\PaypalStrategy;
use App\Strategies\PaytmStrategy;
use App\Strategies\StripeStrategy;
use Illuminate\Http\Request;

// Import any other strategies as needed
class WalletRechargeController extends Controller
{
    use MiscellaneousTrait;

    private VendorWalletRechargeService $walletRechargeService;

    public function __construct(VendorWalletRechargeService $walletRechargeService)
    {
        $this->walletRechargeService = $walletRechargeService;
    }

    public function handlePayment(Request $request)
    {
        $validated = $request->validate([
            'userToken' => 'required|string',
            'method' => 'required|string|in:stripe,paypal',
            'amount' => 'required|numeric|gt:0',
            'currency' => 'required|string|size:3',
        ]);
        $userId = $this->checkUserByToken($validated['userToken']);

        if (! $userId) {
            return redirect('/invalid-order')->with('error', 'Invalid user');
        }

        if ($this->getGeneralSettingValue('onlinepayment') !== 'Active'
            || $this->getGeneralSettingValue($validated['method'].'_status') !== 'Active') {
            return redirect('/invalid-order')->with('error', 'Payment method is not available');
        }

        if (
            $validated['method'] === 'paypal'
            && ! $this->walletRechargeService->findVendorByToken($validated['userToken'])
        ) {
            return redirect('/invalid-order')->with('error', 'Invalid vendor');
        }

        $strategy = $this->getPaymentStrategy($validated['method']);

        if (! $strategy) {
            return redirect('/invalid-order')->with('error', 'Invalid user');
        }

        return $strategy->rechargeWallet(
            (int) $userId,
            (string) $validated['amount'],
            strtoupper($validated['currency']),
            $request
        );
    }

    public function startCheckout(Request $request)
    {
        $validated = $request->validate([
            'token' => 'required|string',
            'method' => 'required|string|in:stripe,paypal',
            'amount' => 'required|numeric|gt:0',
            'currency' => 'required|string|size:3',
        ]);
        $vendor = $this->walletRechargeService->findVendorByToken($validated['token']);

        if (! $vendor) {
            return redirect('/invalid-order')->with('error', 'Invalid vendor');
        }

        if ($this->getGeneralSettingValue('onlinepayment') !== 'Active'
            || $this->getGeneralSettingValue($validated['method'].'_status') !== 'Active') {
            return redirect('/invalid-order')->with('error', 'Payment method is not available');
        }

        if ($validated['method'] === 'paypal') {
            return (new PaypalStrategy)->rechargeWallet(
                (int) $vendor->id,
                (string) $validated['amount'],
                strtoupper($validated['currency']),
                $request
            );
        }

        return app(PaymentFrontController::class)->showPaymentPage($request, 'stripe');
    }

    public function handlePaypalReturn(Request $request)
    {
        return (new PaypalStrategy)->returnWalletRecharge($request);
    }

    public function handleReturn(Request $request)
    {
        $bookingId = $request->input('booking');
        $method = $request->input('method');

        $strategy = $this->getPaymentStrategy($method);

        if (! $strategy) {
            return redirect('/invalid-order')->with('error', 'Invalid booking ID');
        }

        // Handle the return process
        $returnURL = $strategy->return($bookingId, $request->all());

        return redirect($returnURL);

    }

    public function handleCallback(Request $request)
    {
        $bookingId = $request->input('booking');
        $method = $request->input('method');
        // $myfile = fopen($_SERVER['DOCUMENT_ROOT'] . "/newfilesana.txt", "w") or die ("Unable to open file!");
        // $txt = "John Doe\n";
        // fwrite($myfile, $txt);
        // $txt = "Jane Doe\n";
        // fwrite($myfile, $txt);
        // fclose($myfile);
        $strategy = $this->getPaymentStrategy($method);

        if (! $strategy) {
            return response()->json(['error' => 'Invalid payment method'], 400);
        }

        // Handle the callback process
        $strategy->callback($bookingId, $request->all());

        return response()->json(['message' => 'Callback processed'], 200);
    }

    public function handleCancel(Request $request)
    {
        $bookingId = $request->input('booking');
        $method = $request->input('method');

        $strategy = $this->getPaymentStrategy($method);

        if (! $strategy) {
            return redirect('/invalid-order')->with('error', 'Invalid booking ID');
        }

        $returnURL = $strategy->cancel($bookingId, $request->all());

        return redirect($returnURL);
    }

    protected function getPaymentStrategy($method)
    {
        switch ($method) {
            case 'paypal':
                return new PaypalStrategy;
            case 'stripe':
                return new StripeStrategy;
            case 'payduniya':
                return new PayduniyaStrategy;
                // case 'myfatoorah':
                //     return new MyFatoorahStrategy;
            case 'paytm':
                return new PaytmStrategy;

            default:
                return null;
        }
    }

    public function showPaymentPage(Request $request)
    {

        $bookingId = $request->booking;
        $userToken = $request->token;

        $keys = [
            'stripe_status',
            'paypal_status',
            'paydunya_status',
            'myfatoorah_status',
        ];

        $settings = GeneralSetting::whereIn('meta_key', $keys)->get()->keyBy('meta_key');
        $stripe_status = $settings->get('stripe_status') ?? null;
        $paypal_status = $settings->get('paypal_status') ?? null;
        $paydunya_status = $settings->get('paydunya_status') ?? null;
        $myfatoorah_status = $settings->get('myfatoorah_status') ?? null;

        if ($stripe_status->meta_value == 'Active') {
            $status_stripe = true;
        } else {
            $status_stripe = false;
        }

        if ($paypal_status->meta_value == 'Active') {
            $status_paypal = true;
        } else {
            $status_paypal = false;
        }

        if ($paydunya_status->meta_value == 'Active') {
            $status_payduniya = true;
        } else {
            $status_payduniya = false;
        }
        if ($myfatoorah_status->meta_value == 'Active') {
            $status_myfatoorah = true;
        } else {
            $status_myfatoorah = false;
        }
        $paymentMethods = [
            'stripe' => [
                'active' => $status_stripe, // or false
                'route' => '#', // Since Stripe uses JavaScript, we use a placeholder
                'image' => '/front/paymentLogo/Stripe.png',
                'id' => 'stripe-link',
                'form' => false, // Stripe doesn't use a form
            ],
            'paypal' => [
                'active' => $status_paypal, // or false
                'route' => route('payment', ['booking' => $bookingId, 'method' => 'paypal']),
                'image' => '/front/paymentLogo/Paypal.png',
                'id' => 'paypal-form',
                'form' => true,
            ],
            'payduniya' => [
                'active' => $status_payduniya, // or false
                'route' => route('payment', ['booking' => $bookingId, 'method' => 'payduniya']),
                'image' => '/front/paymentLogo/Payduniya.png',
                'id' => 'payduniya-form',
                'form' => true,
            ],
            'myfatoorah' => [
                'active' => $status_myfatoorah, // or false
                'route' => route('payment', ['booking' => $bookingId, 'method' => 'myfatoorah']),
                'image' => '/front/paymentLogo/my-fatoorah.png',
                'id' => 'myfatoorah-form',
                'form' => true,
            ],
        ];

        return view('Front.payment', compact('bookingId', 'userToken', 'paymentMethods'));
    }

    public function paymentSuccess(Request $request)
    {
        $usertoken = $request->usertoken;

        return view('Front.WalletRecharge.Success', compact('usertoken'));
    }

    public function paymentFail(Request $request)
    {
        $usertoken = $request->usertoken;

        return view('Front.WalletRecharge.Fail', compact('usertoken'));
    }

    public function handlePaypalIPN(Request $request)
    {
        return response('', 200);
    }
    // public function payment_payduniya(Request $request)
    // {
    //      $bookingId = $request->booking;
    //     return view('Front.payment-process',compact('bookingId'));
    // }
    // public function testing(Request $request)
    // {

    //     return view('Front.testing');
    // }

}
