<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MiscellaneousTrait;
use App\Models\Booking;
use App\Models\GeneralSetting;
use App\Strategies\PayduniyaStrategy;
use App\Strategies\PaypalStrategy;
use App\Strategies\PaytmStrategy;
use App\Strategies\RazorpayStrategy;
use App\Strategies\StripeStrategy;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\URL;

// Import any other strategies as needed
class PaymentFrontController extends Controller
{
    use MiscellaneousTrait;

    public function handlePayment(Request $request)
    {
        $bookingId = $request->input('booking');
        $method = $request->input('method');
        $bookingData = Booking::find($bookingId);

        if (! $bookingData) {
            return redirect('/invalid-order')->with('error', 'Invalid booking ID');
        }
        if ($bookingData->payment_status === 'paid') {
            return redirect('/invalid-order')->with('error', 'Invalid booking ID');
        }

        $statusKey = $method === 'payduniya' ? 'paydunya_status' : $method.'_status';
        if ($this->getGeneralSettingValue('onlinepayment') !== 'Active'
            || $this->getGeneralSettingValue($statusKey) !== 'Active') {
            return redirect('/invalid-order')->with('error', 'Payment method is not available');
        }

        $strategy = $this->getPaymentStrategy($method);

        if (! $strategy) {
            return redirect('/invalid-order')->with('error', 'Invalid booking ID');
        }

        $returnURL = $strategy->process($bookingId, $bookingData, $request);

        return $returnURL;
    }

    public function startCheckout(Request $request)
    {
        $bookingId = $request->integer('booking');
        $method = $request->string('method')->lower()->toString();

        if (! in_array($method, ['stripe', 'paypal'], true)) {
            return redirect('/invalid-order')->with('error', 'Invalid payment method');
        }

        $booking = Booking::find($bookingId);

        if (! $booking || $booking->payment_status === 'paid') {
            return redirect('/invalid-order')->with('error', 'Invalid booking ID');
        }

        if ($this->getGeneralSettingValue('onlinepayment') !== 'Active'
            || $this->getGeneralSettingValue($method.'_status') !== 'Active') {
            return redirect('/invalid-order')->with('error', 'Payment method is not available');
        }

        if ($method === 'paypal') {
            return (new PaypalStrategy)->process($bookingId, $booking, $request);
        }

        return $this->showPaymentPage($request, $method);
    }

    public function handleReturn(Request $request)
    {

        $bookingId = $request->input('booking');
        $method = $request->input('method');

        $strategy = $this->getPaymentStrategy($method);

        if (! $strategy) {
            return redirect('/invalid-order')->with('error', 'Invalid booking ID');
        }
        // $returnURL = $strategy->return($bookingId, $request->all());
        $returnURL = $strategy->return($bookingId, $request);

        return redirect($returnURL);

    }

    public function handleCallback(Request $request)
    {
        $bookingId = $request->input('booking');
        $method = $request->input('method');
        $strategy = $this->getPaymentStrategy($method);

        if (! $strategy) {
            return response()->json(['error' => 'Invalid payment method'], 400);
        }
        $strategy->callback($bookingId, $request->all());

        return response()->json(['message' => 'Callback processed'], 200);
    }

    public function handleCancel(Request $request)
    {
        $bookingId = $request->input('booking');
        $method = $request->input('method');
        $strategy = $this->getPaymentStrategy($method);
        if (! $strategy) {
            return redirect('/invalid-order')->with('error', 'Invalid booking ID');
        }
        $returnURL = $strategy->cancel($bookingId, $request->all());

        return redirect($returnURL);
    }

    protected function getPaymentStrategy($method)
    {
        switch ($method) {
            case 'paypal':
                return new PaypalStrategy;
            case 'stripe':
                return new StripeStrategy;
            case 'payduniya':
                return new PayduniyaStrategy;
            case 'razorpay':
                return new RazorpayStrategy;
            case 'paytm':
                return new PaytmStrategy;

            default:
                return null;
        }
    }

    public function showPaymentPage(Request $request, ?string $directMethod = null)
    {

        $bookingId = $request->booking;
        $isWalletRecharge = in_array(Route::currentRouteName(), [
            'wallet_recharge_form',
            'wallet_recharge_checkout',
        ], true);

        $keys = [
            'stripe_status',
            'paypal_status',
            'paydunya_status',
            'razorpay_status',
        ];

        $settings = GeneralSetting::whereIn('meta_key', $keys)->get()->keyBy('meta_key');
        $stripe_status = $settings->get('stripe_status') ?? null;
        $paypal_status = $settings->get('paypal_status') ?? null;
        $paydunya_status = $settings->get('paydunya_status') ?? null;
        $razorpay_status = $settings->get('razorpay_status') ?? null;

        $stripeMode = $this->getGeneralSettingValue('stripe_options');
        $stripePublicKey = $stripeMode === 'test'
            ? $this->getGeneralSettingValue('test_stripe_public_key')
            : $this->getGeneralSettingValue('live_stripe_public_key');
        $paymentActionUrls = $isWalletRecharge ? [] : [
            'stripe' => URL::temporarySignedRoute('payment', now()->addMinutes(30), [
                'booking' => $bookingId,
                'method' => 'stripe',
            ]),
            'paypal' => URL::temporarySignedRoute('payment', now()->addMinutes(30), [
                'booking' => $bookingId,
                'method' => 'paypal',
            ]),
        ];

        if ($stripe_status?->meta_value == 'Active') {
            $status_stripe = true;
        } else {
            $status_stripe = false;
        }

        if ($paypal_status?->meta_value == 'Active') {
            $status_paypal = true;
        } else {
            $status_paypal = false;
        }
        $paymentMethods = [
            'stripe' => [
                'active' => $status_stripe,
                'route' => '#',
                'image' => '/front/paymentLogo/Stripe.png',
                'id' => 'stripe-link',
                'public_key' => $stripePublicKey,
                'form' => false,
            ],
            'paypal' => [
                'active' => $status_paypal,
                'route' => $isWalletRecharge
                    ? route('wallet_recharge', [
                        'userToken' => $request->query('token'),
                        'method' => 'paypal',
                        'amount' => $request->query('amount'),
                        'currency' => $request->query('currency'),
                    ])
                    : $paymentActionUrls['paypal'],
                'image' => '/front/paymentLogo/Paypal.png',
                'id' => 'paypal-form',
                'form' => true,
            ],
        ];

        return view('Front.payment', compact('bookingId', 'paymentMethods', 'directMethod', 'paymentActionUrls'));
    }

    public function paymentSuccess(Request $request)
    {
        $bookingId = $request->bookingId;

        return view('Front.Success', compact('bookingId'));
    }

    public function paymentFail(Request $request)
    {
        $bookingId = $request->bookingId;

        return view('Front.Fail', compact('bookingId'));
    }

    public function handlePaypalIPN(Request $request)
    {
        Log::warning('Legacy PayPal IPN ignored; REST webhooks are required.');

        return response('', 200);
    }
}
