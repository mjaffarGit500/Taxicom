<?php

namespace App\Http\Controllers;

use App\Models\GeneralSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;

class InstallerController extends Controller
{
    public function index(Request $request)
    {
        $requiresKey = !empty(env('APP_INSTALL_KEY')) && !session('install_key_verified');

        if (!$requiresKey) {
            $this->advanceStep(1);
        }

        return view('installer.index', compact('requiresKey'));
    }

    public function verifyInstallKey(Request $request)
    {
        $request->validate(['install_key' => 'required|string']);

        if ($request->install_key !== env('APP_INSTALL_KEY')) {
            return back()->with('error', 'Invalid installation key.');
        }

        session(['install_key_verified' => true]);
        $this->advanceStep(1);

        return redirect()->route('installer.requirements');
    }

    public function requirements()
    {
        $requirements = $this->serverRequirements();
        $allPassed = $this->requirementsPass($requirements);

        if ($allPassed) {
            $this->advanceStep(2);
        }

        return view('installer.requirements', compact('requirements', 'allPassed'));
    }

    public function permissions()
    {
        if (!$this->requirementsPass($this->serverRequirements())) {
            return redirect()->route('installer.requirements')
                ->with('error', 'Please meet all server requirements before continuing.');
        }

        $permissions = [
            'storage' => is_writable(storage_path()),
            'bootstrap/cache' => is_writable(app()->bootstrapPath('cache')),
            'config/app.php' => is_writable(config_path('app.php')),
        ];

        $allPassed = !in_array(false, $permissions, true);

        if ($allPassed) {
            $this->advanceStep(3);
        }

        return view('installer.permissions', compact('permissions', 'allPassed'));
    }

    public function purchaseValidation()
    {
        return view('installer.purchase-validation');
    }

    public function purchaseValidationStore(Request $request)
    {
        $validatedData = $request->validate([
            'purchase_code' => 'required|string|max:255',
        ]);

        $purchaseCode = $validatedData['purchase_code'];
        $websiteUrl = rtrim(parse_url(url()->current(), PHP_URL_SCHEME) . '://' . parse_url(url()->current(), PHP_URL_HOST), '/');

        $apiUrl = 'https://purchase-validation.unibooker.app/PurchaseValidation/purchase_validation_rideon.php';

        try {
            $response = Http::timeout(15)->post($apiUrl, [
                'purchase_code' => $purchaseCode,
                'website_url' => $websiteUrl,
            ]);

            $responseBody = $response->json();

            if (isset($responseBody['status']) && $responseBody['status'] === 'success') {
                session(['purchase_key' => $purchaseCode]);
                $this->advanceStep(4);

                return redirect()->route('installer.database');
            }
        } catch (\Exception $e) {
        }

        return redirect()->route('installer.purchaseValidation-error');
    }

    public function purchaseValidationError()
    {
        return view('installer.purchaseValidation-error');
    }

    public function databaseForm()
    {
        return view('installer.database');
    }

    public function databaseStore(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'db_host' => 'required',
            'db_port' => 'required|integer',
            'db_name' => 'required',
            'db_username' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->route('installer.database')
                ->withErrors($validator)
                ->withInput($request->except('db_password'));
        }

        if (!self::checkDBConnection($request->db_host, $request->db_name, $request->db_username, $request->db_password, $request->db_port)) {
            return redirect()->route('installer.database')
                ->with('error', 'Could not connect to the database. Please verify your credentials.')
                ->withInput($request->except('db_password'));
        }

        $output = $this->environmentFileContents(
            $request,
            URL::to('/'),
            (string) session('purchase_key', '')
        );

        $file = fopen(base_path('.env'), 'w');
        fwrite($file, $output);
        fclose($file);

        if (file_exists(base_path('.env'))) {
            $this->advanceStep(5);

            return redirect()->route('installer.migrate');
        }

        return redirect()->route('installer.database')
            ->with('error', 'Failed to write .env file. Check file permissions.');
    }

    private function environmentFileContents(Request $request, string $appUrl, string $purchaseCode): string
    {
        return 'APP_NAME=' . $this->dotenvValue('RideOn') . "\n" .
            "APP_ENV=live\n" .
            'APP_KEY=' . $this->currentAppKey() . "\n" .
            "APP_DEBUG=false\n" .
            "APP_INSTALL=true\n" .
            "APP_LOG_LEVEL=debug\n" .
            "APP_MODE=live\n" .
            'APP_URL=' . $this->dotenvValue($appUrl) . "\n\n" .
            "DB_CONNECTION=mysql\n" .
            'DB_HOST=' . $this->dotenvValue($request->db_host) . "\n" .
            'DB_PORT=' . $this->dotenvValue($request->db_port) . "\n" .
            'DB_DATABASE=' . $this->dotenvValue($request->db_name) . "\n" .
            'DB_USERNAME=' . $this->dotenvValue($request->db_username) . "\n" .
            'DB_PASSWORD=' . $this->dotenvValue($request->db_password ?? '') . "\n\n" .
            "BROADCAST_DRIVER=log\n" .
            "CACHE_DRIVER=file\n" .
            "SESSION_DRIVER=file\n" .
            "SESSION_COOKIE=rideon_session\n" .
            "SESSION_LIFETIME=120\n" .
            "QUEUE_DRIVER=sync\n\n" .
            "REDIS_HOST=127.0.0.1\n" .
            "REDIS_PASSWORD=null\n" .
            "REDIS_PORT=6379\n\n" .
            "PUSHER_APP_ID=\n" .
            "PUSHER_APP_KEY=\n" .
            "PUSHER_APP_SECRET=\n" .
            "PUSHER_APP_CLUSTER=mt1\n\n" .
            'PURCHASE_CODE=' . $this->dotenvValue($purchaseCode) . "\n" .
            'SANCTUM_ACCESS_SECRET=' . str_replace(['+', '/'], ['-', '_'], base64_encode(random_bytes(48))) . "\n" .
            "SANCTUM_BOOTSTRAP_EXPIRATION=30\n" .
            "SANCTUM_USER_EXPIRATION=10080\n" .
            "SOCIAL_LOGIN_ENABLED=true\n" .
            "SOCIAL_GOOGLE_CLIENT_IDS=\n" .
            "SOCIAL_APPLE_CLIENT_IDS=\n" .
            "SOCIAL_JWKS_CACHE_SECONDS=21600\n" .
            "SOCIAL_HTTP_TIMEOUT_SECONDS=5\n" .
            "SOCIAL_CLOCK_SKEW_SECONDS=60\n" .
            "QUEUE_CONNECTION=sync\n";
    }

    public function databaseError()
    {
        return view('installer.database-error');
    }

    private function dotenvValue(mixed $value): string
    {
        $value = str_replace(
            ['\\', '"', '$', "\r", "\n"],
            ['\\\\', '\\"', '\\$', '', '\\n'],
            (string) $value
        );

        return '"' . $value . '"';
    }

    public function migrate()
    {
        return view('installer.import-db');
    }

    public function databaseMigration()
    {
        try {
            Artisan::call('db:wipe', ['--force' => true]);
            $sql_path = base_path('installer/rideon.sql');
            DB::unprepared(file_get_contents($sql_path));

            $this->advanceStep(6);

            return redirect()->route('installer.admin');
        } catch (\Exception $exception) {
            session()->flash('error', 'Database import failed. The database may not be clean.');

            return back();
        }
    }

    public function databaseForceMigration()
    {
        try {
            Artisan::call('db:wipe', ['--force' => true]);
            $sql_path = base_path('installer/rideon.sql');
            DB::unprepared(file_get_contents($sql_path));

            $this->advanceStep(6);

            return redirect()->route('installer.admin');
        } catch (\Exception $exception) {
            session()->flash('error', 'Force import also failed: ' . $exception->getMessage());

            return redirect()->route('installer.migrate');
        }
    }

    public function adminForm()
    {
        $modules = DB::table('module')->where('status', 1)->get();

        return view('installer.admin', compact('modules'));
    }

    public function adminStore(Request $request)
    {
        $validator = Validator::make($request->all(), $this->adminRules(), [
            'phone.regex' => 'Please enter a valid phone number.',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput($request->except(['password', 'password_confirmation']));
        }

        $existingUser = DB::table('users')->where('email', $request->email)->first();

        if ($existingUser) {
            $userId = $existingUser->id;
        } else {
            $userId = DB::table('users')->insertGetId([
                'name' => $request->name,
                'email' => $request->email,
                'password' => Hash::make($request->password),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        $adminRoleId = DB::table('roles')->where('title', 'supper admin')->value('id');
        if ($adminRoleId) {
            $roleExists = DB::table('role_user')
                ->where('user_id', $userId)
                ->where('role_id', $adminRoleId)
                ->exists();

            if (!$roleExists) {
                DB::table('role_user')->insert([
                    'user_id' => $userId,
                    'role_id' => $adminRoleId,
                ]);
            }
        }

        $formData = [];
        $formData['general_name'] = $request->site_name ?? '';
        $formData['general_email'] = $request->email ?? '';
        $formData['general_phone'] = $request->phone ?? '';
        $formData['general_description'] = $request->general_description ?? '';

        foreach ($formData as $metaKey => $metaValue) {
            if (!empty($metaValue)) {
                GeneralSetting::updateOrCreate(
                    ['meta_key' => $metaKey],
                    ['meta_value' => $metaValue]
                );
            }
        }

        $this->advanceStep(7);

        try {
            $this->setupStorage();

            Artisan::call('config:cache');
            Artisan::call('route:cache');
            Artisan::call('view:cache');
            Artisan::call('cache:clear');
        } catch (\Throwable $exception) {
            \Log::warning('Installer final cache/storage step failed: ' . $exception->getMessage());
        }

        return redirect()->route('installer.finish');
    }

    public function finish()
    {
        File::ensureDirectoryExists(storage_path('app'));
        File::put(storage_path('app/installed'), now()->toDateTimeString());

        session()->forget(['installer_step', 'install_key_verified', 'purchase_key']);

        return view('installer.finish');
    }

    public function checkDBConnection($DBHost = '', $DBName = '', $DBUser = '', $DBPass = '', $DBPort = ''): bool
    {
        try {
            if (@mysqli_connect($DBHost, $DBUser, $DBPass, $DBName, $DBPort)) {
                return true;
            }

            return false;
        } catch (\Exception $exception) {
            return false;
        }
    }

    private function advanceStep(int $step): void
    {
        $current = (int) session('installer_step', 0);
        if ($step > $current) {
            session(['installer_step' => $step]);
            session()->save();
        }
    }

    /**
     * Keep requirement labels and checks together for the installer views.
     */
    private function serverRequirements(): array
    {
        return [
            ['label' => 'PHP >= 8.2', 'passed' => $this->phpVersionIsSupported(PHP_VERSION)],
            ['label' => 'BCMath Extension', 'passed' => extension_loaded('bcmath')],
            ['label' => 'Ctype Extension', 'passed' => extension_loaded('ctype')],
            ['label' => 'cURL Extension', 'passed' => extension_loaded('curl')],
            ['label' => 'DOM Extension', 'passed' => extension_loaded('dom')],
            ['label' => 'Fileinfo Extension', 'passed' => extension_loaded('fileinfo')],
            ['label' => 'Filter Extension', 'passed' => extension_loaded('filter')],
            ['label' => 'Hash Extension', 'passed' => extension_loaded('hash')],
            ['label' => 'JSON Support', 'passed' => extension_loaded('json')],
            ['label' => 'Mbstring Extension', 'passed' => extension_loaded('mbstring')],
            ['label' => 'OpenSSL Extension', 'passed' => extension_loaded('openssl')],
            ['label' => 'PCRE Extension', 'passed' => extension_loaded('pcre')],
            ['label' => 'PDO Extension', 'passed' => extension_loaded('pdo')],
            ['label' => 'PDO MySQL Driver', 'passed' => extension_loaded('pdo_mysql')],
            ['label' => 'Session Extension', 'passed' => extension_loaded('session')],
            ['label' => 'Tokenizer Extension', 'passed' => extension_loaded('tokenizer')],
            ['label' => 'XML Extension', 'passed' => extension_loaded('xml')],
            ['label' => 'MySQLi Extension', 'passed' => extension_loaded('mysqli')],
            ['label' => 'Symlink Support', 'passed' => function_exists('symlink')],
        ];
    }

    private function requirementsPass(array $requirements): bool
    {
        return collect($requirements)->every(fn(array $requirement): bool => $requirement['passed']);
    }

    private function phpVersionIsSupported(string $version): bool
    {
        return version_compare($version, '8.2.0', '>=');
    }

    private function adminRules(): array
    {
        return [
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'phone' => ['required', 'string', 'min:7', 'max:20', 'regex:/^[0-9+\-\s()]+$/'],
            'password' => ['required', 'confirmed', Password::min(8)->mixedCase()->letters()->numbers()->symbols()],
        ];
    }

    private function currentAppKey(): string
    {
        $key = trim((string) env('APP_KEY'));

        if ($key === '') {
            $key = trim((string) config('app.key'));
        }

        return $key !== '' ? $key : 'base64:' . base64_encode(random_bytes(32));
    }

    private function setupStorage(): void
    {
        $publicStoragePath = public_path('storage');
        if (is_link($publicStoragePath)) {
            @unlink($publicStoragePath);
        } elseif (is_dir($publicStoragePath)) {
            File::deleteDirectory($publicStoragePath);
        }

        foreach ($this->storageDirectories() as $dir) {
            if (!File::exists($dir)) {
                File::makeDirectory($dir, 0755, true);
            }
            @file_put_contents($dir . '/index.php', "<?php\n");
            @file_put_contents($dir . '/.gitignore', "*\n!.gitignore\n");
        }

        if (!file_exists(public_path('storage')) && function_exists('symlink')) {
            Artisan::call('storage:link');
        }
    }

    private function storageDirectories(): array
    {
        return [
            storage_path('app'),
            storage_path('app/public'),
            storage_path('app/profile_images'),
            storage_path('app/signatures'),
            storage_path('framework'),
            storage_path('framework/cache'),
            storage_path('framework/cache/data'),
            storage_path('framework/sessions'),
            storage_path('framework/views'),
            storage_path('framework/testing'),
            storage_path('logs'),
            storage_path('firebase'),
            storage_path('media-library'),
            storage_path('media-library/temp'),
            storage_path('tmp'),
            storage_path('tmp/uploads'),
        ];
    }
}
