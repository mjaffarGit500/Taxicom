<?php

namespace App\Console\Commands;

use App\Models\SocialLoginAssertion;
use Illuminate\Console\Command;
use Laravel\Sanctum\PersonalAccessToken;

class DeleteExpiredTokens extends Command
{
    protected $signature = 'tokens:cleanup';

    protected $description = 'Delete expired Sanctum tokens and social-login assertion hashes';

    public function handle()
    {
        $tokenCount = PersonalAccessToken::whereNotNull('expires_at')
            ->where('expires_at', '<', now())
            ->delete();
        $assertionCount = SocialLoginAssertion::query()
            ->where('expires_at', '<', now())
            ->delete();

        $this->info("Deleted {$tokenCount} expired tokens and {$assertionCount} expired social assertions.");
    }
}
