<?php

namespace App\Services;

use App\Models\GeneralSetting;
use Illuminate\Support\Facades\URL;

class DirectPaymentUrlService
{
    private const SUPPORTED_METHODS = [
        'stripe',
        'paypal',
    ];

    public function create(int $bookingId, ?string $paymentMethod): ?string
    {
        if (! $this->supports($paymentMethod) || ! $this->gatewayIsActive($paymentMethod)) {
            return null;
        }

        return $this->generateUrl($bookingId, $paymentMethod);
    }

    public function createPaymentMethodsUrl(int $bookingId): string
    {
        return URL::temporarySignedRoute(
            'payment_methods',
            now()->addMinutes(30),
            ['booking' => $bookingId]
        );
    }

    public function supports(?string $paymentMethod): bool
    {
        return in_array($paymentMethod, self::SUPPORTED_METHODS, true);
    }

    protected function gatewayIsActive(string $paymentMethod): bool
    {
        $settings = GeneralSetting::whereIn('meta_key', [
            'onlinepayment',
            $paymentMethod.'_status',
        ])->pluck('meta_value', 'meta_key');

        return $settings->get('onlinepayment') === 'Active'
            && $settings->get($paymentMethod.'_status') === 'Active';
    }

    protected function generateUrl(int $bookingId, string $paymentMethod): string
    {
        return URL::temporarySignedRoute(
            'payment.checkout',
            now()->addMinutes(30),
            [
                'booking' => $bookingId,
                'method' => $paymentMethod,
            ]
        );
    }
}
