<?php

namespace App\Services\AdminCaptcha;

final readonly class AdminCaptchaConfiguration
{
    public function __construct(
        public bool $enabled,
        public string $siteKey,
        public string $secretKey
    ) {}
}
