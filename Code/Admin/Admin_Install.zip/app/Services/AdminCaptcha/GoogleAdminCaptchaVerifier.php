<?php

namespace App\Services\AdminCaptcha;

use App\Contracts\AdminCaptchaVerifier;
use App\Models\GeneralSetting;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Throwable;

final class GoogleAdminCaptchaVerifier implements AdminCaptchaVerifier
{
    private const VERIFY_URL = 'https://www.google.com/recaptcha/api/siteverify';

    private const ALLOWED_ERROR_CODES = [
        'missing-input-secret',
        'invalid-input-secret',
        'missing-input-response',
        'invalid-input-response',
        'bad-request',
        'timeout-or-duplicate',
    ];

    public function configuration(): AdminCaptchaConfiguration
    {
        $settings = GeneralSetting::query()
            ->whereIn('meta_key', ['general_captcha', 'site_key', 'private_key'])
            ->pluck('meta_value', 'meta_key');

        $enabled = strtolower(trim((string) $settings->get('general_captcha', ''))) === 'yes';

        return new AdminCaptchaConfiguration(
            $enabled,
            trim((string) $settings->get('site_key', '')),
            trim((string) $settings->get('private_key', ''))
        );
    }

    public function verify(
        AdminCaptchaConfiguration $configuration,
        string $responseToken,
        ?string $ipAddress
    ): AdminCaptchaVerificationResult {
        if (! $configuration->enabled) {
            return AdminCaptchaVerificationResult::success();
        }

        $expectedHostname = $this->expectedHostname();
        if ($configuration->siteKey === '' || $configuration->secretKey === '' || $expectedHostname === null) {
            return $this->failure('configuration');
        }

        try {
            $response = Http::asForm()
                ->connectTimeout(2)
                ->timeout(5)
                ->post(self::VERIFY_URL, [
                    'secret' => $configuration->secretKey,
                    'response' => $responseToken,
                    'remoteip' => $ipAddress,
                ]);
        } catch (ConnectionException) {
            return $this->failure('connection');
        } catch (Throwable) {
            return $this->failure('provider_exception');
        }

        if (! $response->successful()) {
            return $this->failure('provider_status');
        }

        $payload = $response->json();
        if (! is_array($payload)) {
            return $this->failure('malformed_response');
        }

        $errorCodes = $this->allowedErrorCodes($payload['error-codes'] ?? []);
        if (($payload['success'] ?? null) !== true) {
            return $this->failure('rejected', $errorCodes);
        }

        $verifiedHostname = $this->normalizeHostname($payload['hostname'] ?? null);
        if ($verifiedHostname === null || ! hash_equals($expectedHostname, $verifiedHostname)) {
            return $this->failure('hostname_mismatch');
        }

        return AdminCaptchaVerificationResult::success();
    }

    private function expectedHostname(): ?string
    {
        return $this->normalizeHostname(parse_url((string) config('app.url'), PHP_URL_HOST));
    }

    private function normalizeHostname(mixed $hostname): ?string
    {
        if (! is_string($hostname)) {
            return null;
        }

        $hostname = strtolower(rtrim(trim($hostname), '.'));

        return $hostname !== '' ? $hostname : null;
    }

    /**
     * @return list<string>
     */
    private function allowedErrorCodes(mixed $errorCodes): array
    {
        if (! is_array($errorCodes)) {
            return [];
        }

        return array_values(array_filter(
            $errorCodes,
            static fn (mixed $errorCode): bool => is_string($errorCode)
                && in_array($errorCode, self::ALLOWED_ERROR_CODES, true)
        ));
    }

    /**
     * @param  list<string>  $errorCodes
     */
    private function failure(string $category, array $errorCodes = []): AdminCaptchaVerificationResult
    {
        Log::warning('Administrator CAPTCHA verification failed.', [
            'category' => $category,
            'error_codes' => $errorCodes,
        ]);

        return AdminCaptchaVerificationResult::failure($category, $errorCodes);
    }
}
