<?php

namespace App\Services\AdminCaptcha;

final readonly class AdminCaptchaVerificationResult
{
    /**
     * @param  list<string>  $errorCodes
     */
    private function __construct(
        public bool $successful,
        public string $category,
        public array $errorCodes = []
    ) {}

    public static function success(): self
    {
        return new self(true, 'verified');
    }

    /**
     * @param  list<string>  $errorCodes
     */
    public static function failure(string $category, array $errorCodes = []): self
    {
        return new self(false, $category, $errorCodes);
    }
}
