<?php

namespace App\Services\SocialLogin;

use App\Models\AppUser;
use Illuminate\Support\Facades\Log;
use Throwable;

class SocialProfileImageImporter
{
    /**
     * Import a provider-owned image without making authentication depend on it.
     */
    public function importIfMissing(AppUser $user, VerifiedSocialIdentity $verifiedIdentity): void
    {
        if ($verifiedIdentity->provider !== 'google' || $verifiedIdentity->profileImageUrl === null) {
            return;
        }

        try {
            if ($user->getMedia('profile_image')->isNotEmpty()) {
                return;
            }

            $user->addMediaFromUrl(
                $verifiedIdentity->profileImageUrl,
                ['image/jpeg', 'image/png', 'image/webp']
            )->toMediaCollection('profile_image');
        } catch (Throwable $exception) {
            Log::warning('Unable to import social profile image.', [
                'user_id' => $user->getKey(),
                'provider' => $verifiedIdentity->provider,
                'exception' => $exception::class,
            ]);
        }
    }
}
