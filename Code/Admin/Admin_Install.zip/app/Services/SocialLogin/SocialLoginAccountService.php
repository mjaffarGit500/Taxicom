<?php

namespace App\Services\SocialLogin;

use App\Models\AppUser;
use App\Models\AppUserSocialIdentity;
use App\Models\SocialLoginAssertion;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class SocialLoginAccountService
{
    public function __construct(private SocialProfileImageImporter $profileImageImporter) {}

    public function resolve(VerifiedSocialIdentity $verifiedIdentity, ?string $appleDisplayName = null): AppUser
    {
        try {
            $user = DB::transaction(function () use ($verifiedIdentity, $appleDisplayName) {
                SocialLoginAssertion::query()->create([
                    'token_hash' => $verifiedIdentity->assertionHash,
                    'provider' => $verifiedIdentity->provider,
                    'expires_at' => $verifiedIdentity->expiresAt,
                ]);

                $identity = AppUserSocialIdentity::query()
                    ->where('provider', $verifiedIdentity->provider)
                    ->where('provider_subject', $verifiedIdentity->subject)
                    ->lockForUpdate()
                    ->first();

                if ($identity) {
                    return $this->resolveExistingIdentity($identity, $verifiedIdentity);
                }

                if ($verifiedIdentity->email === null || ! $verifiedIdentity->emailVerified) {
                    throw SocialLoginException::recoveryRequired();
                }

                $user = AppUser::withTrashed()
                    ->where('email', $verifiedIdentity->email)
                    ->lockForUpdate()
                    ->first();

                if (! $user) {
                    $user = $this->createUser($verifiedIdentity, $appleDisplayName);
                }

                $this->ensureUserIsAvailable($user);

                $providerAlreadyLinked = AppUserSocialIdentity::query()
                    ->where('app_user_id', $user->id)
                    ->where('provider', $verifiedIdentity->provider)
                    ->lockForUpdate()
                    ->first();

                if ($providerAlreadyLinked) {
                    if (! hash_equals($providerAlreadyLinked->provider_subject, $verifiedIdentity->subject)) {
                        throw SocialLoginException::recoveryRequired();
                    }

                    return $this->resolveExistingIdentity($providerAlreadyLinked, $verifiedIdentity);
                }

                $identity = AppUserSocialIdentity::query()->firstOrCreate(
                    [
                        'provider' => $verifiedIdentity->provider,
                        'provider_subject' => $verifiedIdentity->subject,
                    ],
                    [
                        'app_user_id' => $user->id,
                        'provider_email' => $verifiedIdentity->email,
                        'email_verified_at' => now(),
                    ]
                );

                if ((int) $identity->app_user_id !== (int) $user->id) {
                    return $this->resolveExistingIdentity($identity, $verifiedIdentity);
                }

                $user->forceFill([
                    'login_type' => $verifiedIdentity->provider,
                    'email_verify' => 1,
                    'verified' => 1,
                ])->save();

                return $user->fresh();
            }, 3);
        } catch (SocialLoginException $exception) {
            throw $exception;
        } catch (QueryException $exception) {
            if (in_array((string) $exception->getCode(), ['23000', '23505'], true)) {
                $constraint = strtolower($exception->getMessage());
                if (
                    str_contains($constraint, 'social_login_assertions')
                    || str_contains($constraint, 'token_hash')
                ) {
                    throw SocialLoginException::invalid();
                }

                throw SocialLoginException::recoveryRequired();
            }

            throw SocialLoginException::providerUnavailable();
        }

        $this->profileImageImporter->importIfMissing($user, $verifiedIdentity);
        $user->refresh();

        return $user;
    }

    private function resolveExistingIdentity(
        AppUserSocialIdentity $identity,
        VerifiedSocialIdentity $verifiedIdentity,
    ): AppUser {
        $user = AppUser::withTrashed()->lockForUpdate()->find($identity->app_user_id);
        if (! $user) {
            throw SocialLoginException::accountUnavailable();
        }

        $this->ensureUserIsAvailable($user);

        if ($verifiedIdentity->email !== null && $verifiedIdentity->emailVerified) {
            $identity->forceFill([
                'provider_email' => $verifiedIdentity->email,
                'email_verified_at' => now(),
            ])->save();
        }

        $user->forceFill(['login_type' => $verifiedIdentity->provider])->save();

        return $user->fresh();
    }

    private function createUser(VerifiedSocialIdentity $verifiedIdentity, ?string $appleDisplayName): AppUser
    {
        $displayName = $verifiedIdentity->displayName;
        if ($verifiedIdentity->provider === 'apple' && $displayName === null) {
            $displayName = $appleDisplayName;
        }

        [$firstName, $lastName] = $this->splitName(
            $displayName ?: ucfirst($verifiedIdentity->provider).' User'
        );

        $user = new AppUser;
        $user->forceFill([
            'first_name' => $firstName,
            'last_name' => $lastName,
            'email' => $verifiedIdentity->email,
            'status' => 1,
            'user_type' => 'user',
            'verified' => 1,
            'email_verify' => 1,
            'login_type' => $verifiedIdentity->provider,
        ]);
        $user->save();

        return $user;
    }

    /** @return array{0: string, 1: ?string} */
    private function splitName(string $displayName): array
    {
        $displayName = trim(preg_replace('/\s+/u', ' ', $displayName) ?? '');
        $parts = preg_split('/\s+/u', $displayName, 2) ?: [];

        return [
            mb_substr($parts[0] ?? 'Social', 0, 100),
            isset($parts[1]) ? mb_substr($parts[1], 0, 100) : null,
        ];
    }

    private function ensureUserIsAvailable(AppUser $user): void
    {
        if ($user->trashed() || (int) $user->status !== 1) {
            throw SocialLoginException::accountUnavailable();
        }
    }
}
