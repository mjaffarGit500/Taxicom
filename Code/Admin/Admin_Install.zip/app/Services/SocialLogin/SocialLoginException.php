<?php

namespace App\Services\SocialLogin;

use RuntimeException;

class SocialLoginException extends RuntimeException
{
    public function __construct(
        public readonly int $status,
        public readonly string $errorCode,
        string $message,
    ) {
        parent::__construct($message);
    }

    public static function invalid(): self
    {
        return new self(401, 'SOCIAL_AUTH_INVALID', 'Social authentication failed.');
    }

    public static function accountUnavailable(): self
    {
        return new self(403, 'SOCIAL_ACCOUNT_UNAVAILABLE', 'This account is unavailable.');
    }

    public static function recoveryRequired(): self
    {
        return new self(409, 'SOCIAL_ACCOUNT_RECOVERY_REQUIRED', 'Account recovery is required.');
    }

    public static function providerUnavailable(): self
    {
        return new self(503, 'SOCIAL_PROVIDER_UNAVAILABLE', 'Social authentication is temporarily unavailable.');
    }
}
