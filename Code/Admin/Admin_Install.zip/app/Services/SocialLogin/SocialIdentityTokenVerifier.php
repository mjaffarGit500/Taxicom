<?php

namespace App\Services\SocialLogin;

use Carbon\CarbonImmutable;
use Firebase\JWT\JWK;
use Firebase\JWT\JWT;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Throwable;

class SocialIdentityTokenVerifier
{
    public function verify(string $provider, string $identityToken): VerifiedSocialIdentity
    {
        return match ($provider) {
            'google' => $this->verifyProvider(
                provider: 'google',
                identityToken: $identityToken,
                allowedIssuers: ['accounts.google.com', 'https://accounts.google.com'],
                allowedAudiences: config('services.social_login.google_client_ids', []),
                jwksUrl: (string) config('services.social_login.google_jwks_url'),
                emailRequired: true,
            ),
            'apple' => $this->verifyProvider(
                provider: 'apple',
                identityToken: $identityToken,
                allowedIssuers: ['https://appleid.apple.com'],
                allowedAudiences: config('services.social_login.apple_client_ids', []),
                jwksUrl: (string) config('services.social_login.apple_jwks_url'),
                emailRequired: false,
            ),
            default => throw SocialLoginException::invalid(),
        };
    }

    /**
     * @param  array<int, string>  $allowedIssuers
     * @param  array<int, string>  $allowedAudiences
     */
    private function verifyProvider(
        string $provider,
        string $identityToken,
        array $allowedIssuers,
        array $allowedAudiences,
        string $jwksUrl,
        bool $emailRequired,
    ): VerifiedSocialIdentity {
        if ($allowedAudiences === [] || $jwksUrl === '') {
            throw SocialLoginException::providerUnavailable();
        }

        $header = $this->decodeHeader($identityToken);
        if (($header['alg'] ?? null) !== 'RS256' || ! is_string($header['kid'] ?? null)) {
            throw SocialLoginException::invalid();
        }

        try {
            $jwks = $this->jwks($provider, $jwksUrl);

            if (! $this->containsKey($jwks, $header['kid'])) {
                Cache::forget($this->cacheKey($provider));
                $jwks = $this->jwks($provider, $jwksUrl);
            }

            if (! $this->containsKey($jwks, $header['kid'])) {
                throw SocialLoginException::invalid();
            }

            $previousLeeway = JWT::$leeway;
            JWT::$leeway = max(0, (int) config('services.social_login.clock_skew_seconds', 60));

            try {
                $claims = (array) JWT::decode($identityToken, JWK::parseKeySet($jwks, 'RS256'));
            } finally {
                JWT::$leeway = $previousLeeway;
            }
        } catch (SocialLoginException $exception) {
            throw $exception;
        } catch (ConnectionException) {
            throw SocialLoginException::providerUnavailable();
        } catch (Throwable) {
            throw SocialLoginException::invalid();
        }

        $issuer = $claims['iss'] ?? null;
        $subject = $claims['sub'] ?? null;
        $expiresAt = $claims['exp'] ?? null;
        $issuedAt = $claims['iat'] ?? null;

        if (! is_string($issuer) || ! in_array($issuer, $allowedIssuers, true)) {
            throw SocialLoginException::invalid();
        }

        if (! is_string($subject) || $subject === '' || strlen($subject) > 255) {
            throw SocialLoginException::invalid();
        }

        if (! is_numeric($expiresAt) || ! is_numeric($issuedAt)) {
            throw SocialLoginException::invalid();
        }

        $leeway = max(0, (int) config('services.social_login.clock_skew_seconds', 60));
        if ((int) $issuedAt > time() + $leeway || (int) $expiresAt <= time() - $leeway) {
            throw SocialLoginException::invalid();
        }

        if (! $this->audienceIsAllowed($claims['aud'] ?? null, $allowedAudiences)) {
            throw SocialLoginException::invalid();
        }

        $email = $this->normalizeEmail($claims['email'] ?? null);
        $emailVerified = $this->claimIsTrue($claims['email_verified'] ?? false);

        if (($emailRequired && ($email === null || ! $emailVerified)) || ($email !== null && ! $emailVerified)) {
            throw SocialLoginException::invalid();
        }

        return new VerifiedSocialIdentity(
            provider: $provider,
            subject: $subject,
            email: $email,
            emailVerified: $emailVerified,
            displayName: $this->normalizeDisplayName($claims['name'] ?? null),
            expiresAt: CarbonImmutable::createFromTimestampUTC((int) $expiresAt),
            assertionHash: hash('sha256', $identityToken),
            profileImageUrl: $provider === 'google'
                ? $this->normalizeGoogleProfileImageUrl($claims['picture'] ?? null)
                : null,
        );
    }

    /** @return array<string, mixed> */
    private function decodeHeader(string $identityToken): array
    {
        $segments = explode('.', $identityToken);
        if (count($segments) !== 3) {
            throw SocialLoginException::invalid();
        }

        $encoded = strtr($segments[0], '-_', '+/');
        $padding = strlen($encoded) % 4;
        if ($padding !== 0) {
            $encoded .= str_repeat('=', 4 - $padding);
        }

        $decoded = base64_decode($encoded, true);
        $header = $decoded === false ? null : json_decode($decoded, true);

        if (! is_array($header)) {
            throw SocialLoginException::invalid();
        }

        return $header;
    }

    /** @return array<string, mixed> */
    private function jwks(string $provider, string $jwksUrl): array
    {
        return Cache::remember(
            $this->cacheKey($provider),
            max(60, (int) config('services.social_login.jwks_cache_seconds', 21600)),
            function () use ($jwksUrl) {
                $response = Http::acceptJson()
                    ->timeout(max(1, (int) config('services.social_login.http_timeout_seconds', 5)))
                    ->get($jwksUrl);

                if (! $response->successful()) {
                    throw SocialLoginException::providerUnavailable();
                }

                $jwks = $response->json();
                if (! is_array($jwks) || ! isset($jwks['keys']) || ! is_array($jwks['keys'])) {
                    throw SocialLoginException::providerUnavailable();
                }

                try {
                    JWK::parseKeySet($jwks, 'RS256');
                } catch (Throwable) {
                    throw SocialLoginException::providerUnavailable();
                }

                return $jwks;
            }
        );
    }

    /** @param array<string, mixed> $jwks */
    private function containsKey(array $jwks, string $keyId): bool
    {
        foreach ($jwks['keys'] ?? [] as $key) {
            if (is_array($key) && ($key['kid'] ?? null) === $keyId) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param  array<int, string>  $allowedAudiences
     */
    private function audienceIsAllowed(mixed $audience, array $allowedAudiences): bool
    {
        $tokenAudiences = is_array($audience) ? $audience : [$audience];

        foreach ($tokenAudiences as $tokenAudience) {
            if (is_string($tokenAudience) && in_array($tokenAudience, $allowedAudiences, true)) {
                return true;
            }
        }

        return false;
    }

    private function normalizeEmail(mixed $email): ?string
    {
        if (! is_string($email)) {
            return null;
        }

        $email = strtolower(trim($email));

        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false ? $email : null;
    }

    private function normalizeDisplayName(mixed $displayName): ?string
    {
        if (! is_string($displayName)) {
            return null;
        }

        $displayName = trim(preg_replace('/\s+/u', ' ', $displayName) ?? '');

        return $displayName !== '' ? mb_substr($displayName, 0, 100) : null;
    }

    private function normalizeGoogleProfileImageUrl(mixed $profileImageUrl): ?string
    {
        if (! is_string($profileImageUrl) || filter_var($profileImageUrl, FILTER_VALIDATE_URL) === false) {
            return null;
        }

        $parts = parse_url($profileImageUrl);
        if (! is_array($parts) || strtolower((string) ($parts['scheme'] ?? '')) !== 'https') {
            return null;
        }

        if (isset($parts['user']) || isset($parts['pass'])) {
            return null;
        }

        $host = strtolower(rtrim((string) ($parts['host'] ?? ''), '.'));
        $isGoogleImageHost = $host === 'googleusercontent.com'
            || str_ends_with($host, '.googleusercontent.com')
            || $host === 'ggpht.com'
            || str_ends_with($host, '.ggpht.com');

        if (! $isGoogleImageHost || (isset($parts['port']) && (int) $parts['port'] !== 443)) {
            return null;
        }

        return $profileImageUrl;
    }

    private function claimIsTrue(mixed $claim): bool
    {
        return $claim === true || $claim === 1 || $claim === '1' || $claim === 'true';
    }

    private function cacheKey(string $provider): string
    {
        return 'social-login:jwks:'.$provider;
    }
}
