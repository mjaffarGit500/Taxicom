<?php

namespace App\Services\SocialLogin;

use Carbon\CarbonImmutable;

final readonly class VerifiedSocialIdentity
{
    public function __construct(
        public string $provider,
        public string $subject,
        public ?string $email,
        public bool $emailVerified,
        public ?string $displayName,
        public CarbonImmutable $expiresAt,
        public string $assertionHash,
        public ?string $profileImageUrl = null,
    ) {}
}
