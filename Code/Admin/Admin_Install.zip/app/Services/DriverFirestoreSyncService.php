<?php

namespace App\Services;

use App\Exceptions\FirestoreDocumentNotFoundException;
use App\Models\AppUser;
use App\Models\Modern\Item;
use Closure;
use Illuminate\Support\Facades\Log;
use Throwable;

class DriverFirestoreSyncService
{
    public function __construct(
        private readonly FirestoreService $firestore,
        private readonly DriverFirestoreData $data
    ) {}

    public function syncProfile(AppUser $driver): bool
    {
        return $this->sync(
            $driver,
            'profile',
            fn (): array => $this->data->profile($driver)
        );
    }

    public function syncVehicle(AppUser $driver, Item $item): bool
    {
        $itemId = (int) $item->getKey();

        return $this->sync(
            $driver,
            'vehicle',
            fn (): array => $this->data->vehicle($item),
            $itemId
        );
    }

    /**
     * @param  Closure(): array<string, mixed>  $data
     */
    private function sync(AppUser $driver, string $scope, Closure $data, ?int $itemId = null): bool
    {
        if ($driver->getAttribute('user_type') !== 'driver') {
            Log::warning('Skipped Firestore synchronization for a non-driver user.', [
                'driver_id' => $driver->getKey(),
                'item_id' => $itemId,
                'scope' => $scope,
            ]);

            return false;
        }

        $firestoreId = trim((string) $driver->getAttribute('firestore_id'));

        if ($firestoreId === '') {
            Log::warning('Skipped Firestore synchronization because the driver has no Firestore ID.', [
                'driver_id' => $driver->getKey(),
                'item_id' => $itemId,
                'scope' => $scope,
            ]);

            return false;
        }

        try {
            $this->firestore->updateDocumentOrFail('drivers', $firestoreId, $data());
        } catch (FirestoreDocumentNotFoundException) {
            Log::warning('Skipped Firestore synchronization because the driver document does not exist.', [
                'driver_id' => $driver->getKey(),
                'item_id' => $itemId,
                'firestore_id' => $firestoreId,
                'scope' => $scope,
            ]);

            return false;
        } catch (Throwable $exception) {
            Log::error('Driver Firestore synchronization failed.', [
                'driver_id' => $driver->getKey(),
                'item_id' => $itemId,
                'firestore_id' => $firestoreId,
                'scope' => $scope,
                'error' => $exception->getMessage(),
            ]);

            return false;
        }

        return true;
    }
}
