<?php

namespace App\Services;

use App\Http\Controllers\Traits\MiscellaneousTrait;
use Illuminate\Support\Facades\Log;

class PhonePeService
{
    use MiscellaneousTrait;

    private string $merchantId;

    private string $clientId;

    private string $clientSecret;

    private int $clientVersion;

    private string $baseUrl;

    private string $oauthUrl;

    private ?string $cachedToken = null;

    private ?int $tokenExpiresAt = 0;

    public function __construct()
    {
        $environment = $this->getGeneralSettingValue('phonepe_options') ?? 'test';
        $isLive = $environment === 'live';

        $this->merchantId = $this->getGeneralSettingValue(
            $isLive ? 'live_phonepe_merchant_id' : 'test_phonepe_merchant_id'
        ) ?? '';
        $this->clientId = $this->getGeneralSettingValue(
            $isLive ? 'live_phonepe_client_id' : 'test_phonepe_client_id'
        ) ?? '';
        $this->clientSecret = $this->getGeneralSettingValue(
            $isLive ? 'live_phonepe_client_secret' : 'test_phonepe_client_secret'
        ) ?? '';
        $this->clientVersion = (int) ($this->getGeneralSettingValue($isLive ? 'live_phonepe_client_version' : 'test_phonepe_client_version') ?? 1);

        // OAuth uses a different base path on production (identity-manager vs pg)
        $this->oauthUrl = $isLive
            ? 'https://api.phonepe.com/apis/identity-manager/v1/oauth/token'
            : 'https://api-preprod.phonepe.com/apis/pg-sandbox/v1/oauth/token';

        $this->baseUrl = $isLive
            ? 'https://api.phonepe.com/apis/pg'
            : 'https://api-preprod.phonepe.com/apis/pg-sandbox';
    }

    /**
     * Get OAuth token from PhonePe (cached until expiry).
     */
    public function getAuthToken(): string
    {
        if ($this->cachedToken && $this->tokenExpiresAt && time() < $this->tokenExpiresAt) {
            return $this->cachedToken;
        }

        $response = $this->makeCurlRequest(
            $this->oauthUrl,
            'POST',
            ['Content-Type: application/x-www-form-urlencoded'],
            http_build_query([
                'client_id' => $this->clientId,
                'client_secret' => $this->clientSecret,
                'client_version' => $this->clientVersion,
                'grant_type' => 'client_credentials',
            ])
        );

        if ($response['status'] === 'error') {
            Log::error('PhonePe OAuth failed', ['message' => $response['message']]);

            return '';
        }

        $result = json_decode($response['data'], true);

        if (! isset($result['access_token'])) {
            Log::error('PhonePe OAuth missing access_token');

            return '';
        }

        $this->cachedToken = $result['access_token'];
        $this->tokenExpiresAt = ($result['expires_at'] ?? 0) - 300;

        return $this->cachedToken;
    }

    /**
     * Create a PhonePe SDK order for in-app checkout.
     *
     * @return array{status: string, orderId?: string, token?: string, message?: string}
     */
    public function createSdkOrder(int $amountInPaise, string $merchantOrderId): array
    {
        $token = $this->getAuthToken();

        if (! $token) {
            return ['status' => 'error', 'message' => 'Failed to obtain PhonePe auth token.'];
        }

        $body = json_encode([
            'merchantOrderId' => $merchantOrderId,
            'amount' => $amountInPaise,
            'expireAfter' => 1200,
            'paymentFlow' => [
                'type' => 'PG_CHECKOUT',
            ],
        ], JSON_UNESCAPED_SLASHES);

        $response = $this->makeCurlRequest(
            $this->baseUrl.'/checkout/v2/sdk/order',
            'POST',
            [
                'Content-Type: application/json',
                'Authorization: O-Bearer '.$token,
            ],
            $body
        );

        if ($response['status'] === 'error') {
            Log::error('PhonePe createSdkOrder failed', ['merchantOrderId' => $merchantOrderId, 'message' => $response['message']]);

            return ['status' => 'error', 'message' => $response['message'] ?? 'Order creation failed.'];
        }

        $result = json_decode($response['data'], true);

        if (! isset($result['orderId'], $result['token'])) {
            Log::error('PhonePe createSdkOrder bad response', ['merchantOrderId' => $merchantOrderId]);

            return ['status' => 'error', 'message' => 'Unexpected response from PhonePe.'];
        }

        return [
            'status' => 'success',
            'orderId' => $result['orderId'],
            'token' => $result['token'],
            'state' => $result['state'] ?? null,
            'expireAt' => $result['expireAt'] ?? null,
            'merchantId' => $this->merchantId,
        ];
    }

    /**
     * Get order status from PhonePe.
     *
     * @return array{status: string, state?: string, paymentDetails?: array, message?: string}
     */
    public function getOrderStatus(string $merchantOrderId): array
    {
        $token = $this->getAuthToken();

        if (! $token) {
            return ['status' => 'error', 'message' => 'Failed to obtain PhonePe auth token.'];
        }

        $response = $this->makeCurlRequest(
            $this->baseUrl.'/checkout/v2/order/'.$merchantOrderId.'/status',
            'GET',
            [
                'Authorization: O-Bearer '.$token,
            ]
        );

        if ($response['status'] === 'error') {
            Log::error('PhonePe getOrderStatus failed', ['merchantOrderId' => $merchantOrderId, 'message' => $response['message']]);

            return ['status' => 'error', 'message' => $response['message'] ?? 'Status check failed.'];
        }

        $result = json_decode($response['data'], true);

        if (! isset($result['state'])) {
            Log::error('PhonePe getOrderStatus bad response', ['merchantOrderId' => $merchantOrderId]);

            return ['status' => 'error', 'message' => 'Unexpected response from PhonePe.'];
        }

        return [
            'status' => 'success',
            'state' => $result['state'],
            'merchantOrderId' => $result['merchantOrderId'] ?? $merchantOrderId,
            'orderId' => $result['orderId'] ?? null,
            'paymentDetails' => $result['paymentDetails'] ?? [],
            'amount' => $result['amount'] ?? null,
        ];
    }

    public function merchantId(): string
    {
        return $this->merchantId;
    }

    /**
     * Initiate a refund for a completed order.
     *
     * @return array{status: string, message?: string, refundId?: string}
     */
    public function initiateRefund(string $merchantOrderId, string $merchantRefundId, int $amountInPaise): array
    {
        $token = $this->getAuthToken();

        if (! $token) {
            return ['status' => 'error', 'message' => 'Failed to obtain PhonePe auth token.'];
        }

        $body = json_encode([
            'merchantOrderId' => $merchantOrderId,
            'merchantRefundId' => $merchantRefundId,
            'amount' => $amountInPaise,
            'paymentFlow' => [
                'type' => 'PG_CHECKOUT',
            ],
        ], JSON_UNESCAPED_SLASHES);

        $response = $this->makeCurlRequest(
            $this->baseUrl.'/checkout/v2/refund',
            'POST',
            [
                'Content-Type: application/json',
                'Authorization: O-Bearer '.$token,
            ],
            $body
        );

        if ($response['status'] === 'error') {
            Log::error('PhonePe refund failed', ['merchantOrderId' => $merchantOrderId, 'message' => $response['message']]);

            return ['status' => 'error', 'message' => $response['message'] ?? 'Refund failed.'];
        }

        $result = json_decode($response['data'], true);

        return [
            'status' => 'success',
            'refundId' => $result['refundId'] ?? null,
            'message' => $result['message'] ?? 'Refund initiated.',
        ];
    }

    /**
     * Verify PhonePe webhook Authorization header.
     *
     * PhonePe sends: Authorization: SHA256(username:password)
     */
    public function verifyWebhookAuthorization(?string $authorizationHeader): bool
    {
        $username = $this->getGeneralSettingValue('phonepe_webhook_username');
        $password = $this->getGeneralSettingValue('phonepe_webhook_password');

        if (! $username || ! $password) {
            Log::warning('PhonePe webhook credentials not configured');

            return false;
        }

        $expected = 'SHA256'.hash('sha256', $username.':'.$password);

        return hash_equals($expected, $authorizationHeader ?? '');
    }

    private function makeCurlRequest(string $url, string $method, array $headers, ?string $body = null): array
    {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($body !== null) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
            }
        }

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);
        $httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if (curl_errno($ch)) {
            $error = curl_error($ch);
            curl_close($ch);

            return [
                'status' => 'error',
                'message' => $error,
            ];
        }

        curl_close($ch);

        if ($httpStatus >= 400) {
            return [
                'status' => 'error',
                'message' => "HTTP Error: $httpStatus, Response: $response",
            ];
        }

        return [
            'status' => 'success',
            'data' => $response,
        ];
    }
}
