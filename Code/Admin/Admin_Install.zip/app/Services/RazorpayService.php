<?php

namespace App\Services;

use App\Http\Controllers\Traits\MiscellaneousTrait;
use Illuminate\Support\Facades\Log;

class RazorpayService
{
    use MiscellaneousTrait;

    private string $keyId;

    private string $keySecret;

    private string $webhookSecret;

    private string $baseUrl = 'https://api.razorpay.com/v1';

    public function __construct()
    {
        $environment = $this->getGeneralSettingValue('razorpay_options') ?? 'test';
        $isLive = $environment === 'live';

        $this->keyId = $this->getGeneralSettingValue($isLive ? 'live_razorpay_key_id' : 'test_razorpay_key_id') ?? '';
        $this->keySecret = $this->getGeneralSettingValue($isLive ? 'live_razorpay_secret_key' : 'test_razorpay_secret_key') ?? '';
        $this->webhookSecret = $this->getGeneralSettingValue(
            $isLive ? 'live_razorpay_webhook_secret' : 'test_razorpay_webhook_secret'
        ) ?? '';
    }

    /**
     * Create a Razorpay order for in-app checkout.
     *
     * @return array{status: string, orderId?: string, amount?: int, currency?: string, message?: string}
     */
    public function createOrder(int $amountInPaise, string $currency, string $receipt): array
    {
        $postFields = json_encode([
            'amount' => $amountInPaise,
            'currency' => $currency,
            'receipt' => $receipt,
        ]);

        $response = $this->makeCurlRequest(
            $this->baseUrl.'/orders',
            'POST',
            $postFields
        );

        if ($response['status'] === 'error') {
            Log::error('Razorpay createOrder failed', ['receipt' => $receipt, 'message' => $response['message']]);

            return ['status' => 'error', 'message' => $response['message'] ?? 'Order creation failed.'];
        }

        $result = json_decode($response['data'], true);

        if (! is_array($result) || ! isset($result['id'])) {
            Log::error('Razorpay createOrder bad response', ['receipt' => $receipt]);

            return ['status' => 'error', 'message' => 'Unexpected response from Razorpay.'];
        }

        if (($result['status'] ?? '') !== 'created') {
            Log::error('Razorpay createOrder unexpected status', [
                'receipt' => $receipt,
                'providerStatus' => $result['status'] ?? null,
            ]);

            return ['status' => 'error', 'message' => 'Order creation failed: '.($result['error_description'] ?? 'unknown error')];
        }

        return [
            'status' => 'success',
            'orderId' => $result['id'],
            'amount' => $result['amount'],
            'currency' => $result['currency'],
        ];
    }

    /**
     * Verify Razorpay payment signature using HMAC-SHA256.
     *
     * @param  array{razorpay_order_id: string, razorpay_payment_id: string, razorpay_signature: string}  $params
     */
    public function verifyPaymentSignature(array $params): bool
    {
        $orderId = $params['razorpay_order_id'] ?? '';
        $paymentId = $params['razorpay_payment_id'] ?? '';
        $signature = $params['razorpay_signature'] ?? '';

        if ($orderId === '' || $paymentId === '' || $signature === '') {
            return false;
        }

        $payload = $orderId.'|'.$paymentId;
        $expectedSignature = hash_hmac('sha256', $payload, $this->keySecret);

        return hash_equals($expectedSignature, $signature);
    }

    /**
     * Fetch order details from Razorpay.
     *
     * @return array{status: string, data?: array, message?: string}
     */
    public function fetchOrder(string $orderId): array
    {
        $response = $this->makeCurlRequest(
            $this->baseUrl.'/orders/'.$orderId,
            'GET'
        );

        if ($response['status'] === 'error') {
            Log::error('Razorpay fetchOrder failed', ['orderId' => $orderId, 'message' => $response['message']]);

            return ['status' => 'error', 'message' => $response['message'] ?? 'Order fetch failed.'];
        }

        $result = json_decode($response['data'], true);

        if (! is_array($result) || ! isset($result['id'])) {
            return ['status' => 'error', 'message' => 'Unexpected response from Razorpay.'];
        }

        return ['status' => 'success', 'data' => $result];
    }

    /**
     * @return array{status: string, data?: array, message?: string}
     */
    public function fetchPayment(string $paymentId): array
    {
        $response = $this->makeCurlRequest(
            $this->baseUrl.'/payments/'.$paymentId,
            'GET'
        );

        if ($response['status'] === 'error') {
            Log::error('Razorpay fetchPayment failed', ['paymentId' => $paymentId]);

            return ['status' => 'error', 'message' => 'Payment fetch failed.'];
        }

        $result = json_decode($response['data'], true);
        if (! is_array($result) || ! isset($result['id'])) {
            return ['status' => 'error', 'message' => 'Unexpected response from Razorpay.'];
        }

        return ['status' => 'success', 'data' => $result];
    }

    /**
     * Verify Razorpay webhook signature using HMAC-SHA256.
     */
    public function verifyWebhookSignature(string $rawBody, string $receivedSignature): bool
    {
        if (! $this->webhookSecret) {
            Log::warning('Razorpay webhook secret not configured');

            return false;
        }

        $expectedSignature = hash_hmac('sha256', $rawBody, $this->webhookSecret);

        return hash_equals($expectedSignature, $receivedSignature);
    }

    /**
     * Get the Razorpay key ID (public key, safe to send to clients).
     */
    public function getKeyId(): string
    {
        return $this->keyId;
    }

    private function makeCurlRequest(string $url, string $method, ?string $body = null): array
    {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($body !== null) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
            }
        }

        $apiKey = trim($this->keyId);
        $apiSecret = trim($this->keySecret);

        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Basic '.base64_encode("{$apiKey}:{$apiSecret}"),
        ]);

        $response = curl_exec($ch);
        $httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if (curl_errno($ch)) {
            $error = curl_error($ch);
            curl_close($ch);

            return [
                'status' => 'error',
                'message' => $error,
            ];
        }

        curl_close($ch);

        if ($httpStatus >= 400) {
            return [
                'status' => 'error',
                'message' => "HTTP Error: $httpStatus, Response: $response",
            ];
        }

        return [
            'status' => 'success',
            'data' => $response,
        ];
    }
}
