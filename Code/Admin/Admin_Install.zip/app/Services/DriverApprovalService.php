<?php

namespace App\Services;

use App\Http\Controllers\Traits\FirestoreTrait;
use App\Models\AppUser;
use App\Models\GeneralSetting;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class DriverApprovalService
{
    use FirestoreTrait;

    public const SETTING_KEY = 'driver_auto_approval';

    public const REQUIRED_DOCUMENTS = [
        'driving_licence_front',
        'driving_licence_back',
        'driver_id_front',
        'driver_id_back',
    ];

    public function isAutoApprovalEnabled(): bool
    {
        return GeneralSetting::getMetaValue(self::SETTING_KEY) === '1';
    }

    public function hasRequiredDocuments(AppUser $driver): bool
    {
        $storedDocuments = $this->getStoredRequiredDocuments($driver);

        return array_diff(self::REQUIRED_DOCUMENTS, $storedDocuments) === [];
    }

    /**
     * Query the media relationship instead of using the model's cached media collection.
     *
     * @return array<int, string>
     */
    protected function getStoredRequiredDocuments(AppUser $driver): array
    {
        return $driver->media()
            ->whereIn('collection_name', self::REQUIRED_DOCUMENTS)
            ->distinct()
            ->pluck('collection_name')
            ->all();
    }

    public function autoApproveIfEligible(AppUser $driver): bool
    {
        if (! $this->isAutoApprovalEnabled()
            || $driver->getAttribute('user_type') !== 'driver'
            || ! $this->hasRequiredDocuments($driver)) {
            return false;
        }

        $this->setApproval($driver, true);

        return true;
    }

    public function markPending(AppUser $driver): void
    {
        DB::transaction(function () use ($driver) {
            $driver->update([
                'document_verify' => 0,
                'host_status' => 2,
            ]);

            foreach (self::REQUIRED_DOCUMENTS as $document) {
                $driver->metadata()->updateOrCreate(
                    ['meta_key' => $document.'_status'],
                    ['meta_value' => 'pending']
                );
            }
        });
    }

    public function setApproval(AppUser $driver, bool $approved): void
    {
        DB::transaction(function () use ($driver, $approved) {
            $driver->update([
                'document_verify' => $approved ? 1 : 0,
                'host_status' => $approved ? 1 : 0,
            ]);

            if ($approved) {
                foreach (self::REQUIRED_DOCUMENTS as $document) {
                    $driver->metadata()->updateOrCreate(
                        ['meta_key' => $document.'_status'],
                        ['meta_value' => 'approved']
                    );
                }
            }
        });

        $this->syncFirestore($driver, $approved);
    }

    protected function syncFirestore(AppUser $driver, bool $approved): void
    {
        $approvalStatus = $approved ? 'approved' : 'rejected';

        try {
            $firestoreDocId = (string) ($driver->getAttribute('firestore_id') ?? '');
            $firestoreDocExists = $firestoreDocId !== ''
                && $this->getDocument('drivers', $firestoreDocId) !== null;

            if (! $firestoreDocExists) {
                $firestoreData = $this->generateDriverFirestoreData($driver);
                $firestoreData['docApprovedStatus'] = $approvalStatus;
                $firestoreData['driverStatus'] = $approvalStatus;
                $firestoreDocument = $this->storeDriverInFirestore($firestoreData);

                if ($firestoreDocument) {
                    $firestoreDocId = basename($firestoreDocument);
                    $driver->update(['firestore_id' => $firestoreDocId]);
                }
            }

            if ($firestoreDocId === '') {
                Log::error('Driver approval Firestore document could not be created.', [
                    'driver_id' => $driver->getKey(),
                ]);

                return;
            }

            $result = $this->updateDocument('drivers', $firestoreDocId, [
                'docApprovedStatus' => $approvalStatus,
                'driverStatus' => $approvalStatus,
                'driverId' => $driver->getKey(),
            ]);

            if ($result === null) {
                Log::error('Driver approval Firestore document could not be synchronized.', [
                    'driver_id' => $driver->getKey(),
                    'firestore_id' => $firestoreDocId,
                ]);
            }
        } catch (\Throwable $e) {
            Log::error('Driver approval Firestore sync failed: '.$e->getMessage(), [
                'driver_id' => $driver->getKey(),
            ]);
        }
    }
}
