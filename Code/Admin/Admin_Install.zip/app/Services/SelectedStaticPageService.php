<?php

namespace App\Services;

use App\Models\StaticPage;
use Illuminate\Support\Collection;

class SelectedStaticPageService
{
    public const SETTING_KEY = 'selected_static_page_ids';

    public function decodeIds(mixed $value): array
    {
        if (! is_string($value) || $value === '') {
            return [];
        }

        $decoded = json_decode($value, true);

        if (! is_array($decoded) || ! array_is_list($decoded)) {
            return [];
        }

        $ids = [];

        foreach ($decoded as $id) {
            if (is_int($id) && $id > 0) {
                $ids[] = $id;
            } elseif (is_string($id) && ctype_digit($id) && (int) $id > 0) {
                $ids[] = (int) $id;
            }
        }

        return array_values(array_unique($ids));
    }

    public function activePages(array $ids): Collection
    {
        if ($ids === []) {
            return collect();
        }

        $pages = StaticPage::query()
            ->where('status', '1')
            ->whereIn('id', $ids)
            ->get();

        return $this->orderBySelectedIds($pages, $ids);
    }

    public function orderBySelectedIds(Collection $pages, array $ids): Collection
    {
        $pagesById = $pages->keyBy('id');

        return collect($ids)
            ->map(fn (int $id) => $pagesById->get($id))
            ->filter()
            ->values();
    }

    public function descriptors(array $ids): array
    {
        return $this->toDescriptors($this->activePages($ids));
    }

    public function toDescriptors(Collection $pages): array
    {
        return $pages
            ->map(fn (StaticPage $page) => [
                'id' => $page->getKey(),
                'name' => $page->getTranslation('name'),
                'route_url' => route('api.static-page.show', ['id' => $page->getKey()]),
            ])
            ->all();
    }
}
