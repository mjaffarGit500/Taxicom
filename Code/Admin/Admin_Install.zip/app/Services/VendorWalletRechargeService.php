<?php

namespace App\Services;

use App\Http\Controllers\Traits\VendorWalletTrait;
use App\Models\AppUser;
use App\Models\VendorWallet;
use Closure;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use InvalidArgumentException;
use RuntimeException;

class VendorWalletRechargeService
{
    use VendorWalletTrait;

    public function createReference(int $vendorId): string
    {
        return 'WR' . $vendorId . '_' . Str::ulid();
    }

    public function extractVendorId(string $reference): ?int
    {
        if (preg_match('/^WR([1-9]\d*)_[0-9A-HJKMNP-TV-Z]{26}$/', $reference, $matches) !== 1) {
            return null;
        }

        return (int) $matches[1];
    }

    public function findVendorByToken(string $token): ?AppUser
    {
        return AppUser::where('token', trim($token))
            ->where('status', 1)
            ->where('user_type', '!=', 'user')
            ->first();
    }

    public function credit(
        int $vendorId,
        float $amount,
        string $currency,
        string $gateway,
        string $transactionId,
        array $paymentDetails = []
    ): array {
        if ($amount <= 0) {
            throw new InvalidArgumentException('Recharge amount must be greater than zero.');
        }

        if ($transactionId === '') {
            throw new InvalidArgumentException('Gateway transaction ID is required.');
        }

        if (strlen($currency) !== 3 || $gateway === '') {
            throw new InvalidArgumentException('Gateway and three-letter currency are required.');
        }

        if (!$this->vendorExists($vendorId)) {
            throw new RuntimeException('Vendor not found.');
        }

        $gateway = strtolower($gateway);
        $currency = strtoupper($currency);

        try {
            return $this->runInTransaction(function () use ($vendorId, $amount, $currency, $gateway, $transactionId, $paymentDetails) {
                $existing = $this->findExistingCredit($gateway, $transactionId, true);

                if ($existing) {
                    return $this->existingResult($vendorId, $existing);
                }

                $wallet = $this->createCredit(
                    $vendorId,
                    $amount,
                    $currency,
                    $gateway,
                    $transactionId,
                    $paymentDetails
                );

                return $this->result('credited', $wallet);
            });
        } catch (QueryException $exception) {
            $existing = $this->findExistingCredit($gateway, $transactionId);

            if ($existing) {
                return $this->existingResult($vendorId, $existing);
            }

            throw $exception;
        }
    }

    protected function vendorExists(int $vendorId): bool
    {
        return AppUser::where('id', $vendorId)->where('user_type', '!=', 'user')->exists();
    }

    protected function runInTransaction(Closure $callback): mixed
    {
        return DB::transaction($callback);
    }

    protected function findExistingCredit(
        string $gateway,
        string $transactionId,
        bool $lock = false
    ): ?VendorWallet {
        $query = VendorWallet::where('payment_gateway', $gateway)
            ->where('gateway_transaction_id', $transactionId);

        if ($lock) {
            $query->lockForUpdate();
        }

        return $query->first();
    }

    protected function createCredit(
        int $vendorId,
        float $amount,
        string $currency,
        string $gateway,
        string $transactionId,
        array $paymentDetails
    ) {
        return $this->addVendorWalletTransaction(
            $vendorId,
            $amount,
            'credit',
            null,
            null,
            'Wallet recharge via ' . ucfirst($gateway),
            [
                'payment_gateway' => $gateway,
                'gateway_transaction_id' => $transactionId,
                'currency' => $currency,
                'payment_details' => $paymentDetails,
            ]
        );
    }

    private function result(string $status, VendorWallet $wallet): array
    {
        return [
            'status' => $status,
            'wallet_transaction_id' => $wallet->id,
            'amount' => $wallet->amount,
            'currency' => $wallet->currency,
        ];
    }

    private function existingResult(int $vendorId, VendorWallet $wallet): array
    {
        if ((int) $wallet->vendor_id !== $vendorId) {
            throw new RuntimeException('Gateway transaction belongs to another vendor.');
        }

        return $this->result('already_processed', $wallet);
    }
}
