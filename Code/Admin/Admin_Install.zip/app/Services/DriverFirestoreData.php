<?php

namespace App\Services;

use App\Models\AppUser;
use App\Models\Modern\Item;

class DriverFirestoreData
{
    /**
     * @return array<string, mixed>
     */
    public function profile(AppUser $driver): array
    {
        $name = collect([
            $driver->getAttribute('first_name'),
            $driver->getAttribute('middle'),
            $driver->getAttribute('last_name'),
        ])->map(static fn ($part) => trim((string) $part))
            ->filter(static fn (string $part) => $part !== '')
            ->implode(' ');

        $profileImage = $driver->getLastMedia('profile_image');

        return [
            'driverName' => $name,
            'driverNumber' => trim((string) $driver->getAttribute('phone_country')).trim((string) $driver->getAttribute('phone')),
            'driverImageUrl' => $profileImage?->getUrl() ?? '',
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public function vehicle(?Item $item): array
    {
        if (! $item) {
            return [
                'itemId' => '',
                'itemTypeId' => '',
                'itemTypeName' => '',
                'vehicleMake' => '',
                'vehicleModel' => '',
                'vehicleNumber' => '',
                'vehiclecolor' => '',
                'vehicleyear' => '',
            ];
        }

        $item->loadMissing(['item_Type', 'itemVehicle', 'vehicleMake']);

        return [
            'itemId' => $item->getKey(),
            'itemTypeId' => $item->getAttribute('item_type_id') ?? '',
            'itemTypeName' => $item->item_Type?->name ?? '',
            'vehicleMake' => $item->vehicleMake?->name ?? '',
            'vehicleModel' => $item->getAttribute('model') ?? '',
            'vehicleNumber' => $item->getAttribute('registration_number') ?? '',
            'vehiclecolor' => $item->itemVehicle?->color ?? '',
            'vehicleyear' => $item->itemVehicle?->year ?? '',
        ];
    }
}
