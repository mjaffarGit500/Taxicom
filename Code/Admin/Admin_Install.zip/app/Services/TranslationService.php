<?php

namespace App\Services;

use Illuminate\Database\Eloquent\Model;

class TranslationService
{
    public static function translate(Model $model, string $field, ?string $locale = null): ?string
    {
        if (method_exists($model, 'getTranslation')) {
            return $model->getTranslation($field, $locale);
        }

        $locale = $locale ?? app()->getLocale();
        $defaultLocale = config('global.primary_language', 'en');

        $translation = $model->translations
            ->where('locale', $locale)
            ->where('field', $field)
            ->first();

        if ($translation) {
            return $translation->value;
        }

        if ($locale !== $defaultLocale) {
            $translation = $model->translations
                ->where('locale', $defaultLocale)
                ->where('field', $field)
                ->first();

            if ($translation) {
                return $translation->value;
            }
        }

        return $model->getRawOriginal($field) ?? null;
    }

    public static function translateAll(Model $model, array $fields, ?string $locale = null): array
    {
        $result = [];
        foreach ($fields as $field) {
            $result[$field] = self::translate($model, $field, $locale);
        }

        return $result;
    }

    public static function valueForDefault(array|string|null $value): ?string
    {
        if (is_array($value)) {
            return $value[config('global.primary_language', 'en')] ?? (reset($value) ?: null);
        }

        return $value;
    }
}
