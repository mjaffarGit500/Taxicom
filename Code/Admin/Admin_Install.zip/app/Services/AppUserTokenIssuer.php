<?php

namespace App\Services;

use App\Models\AppUser;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class AppUserTokenIssuer
{
    /**
     * @return array{access_token: string, token_type: string, expires_at: string}
     */
    public function issue(AppUser $user, ?string $ipAddress): array
    {
        return DB::transaction(function () use ($user, $ipAddress) {
            $lockedUser = AppUser::query()->lockForUpdate()->findOrFail($user->getKey());
            $lockedUser->tokens()->delete();
            $lockedUser->forceFill(['token' => Str::random(120)])->save();

            $expiresAt = now()->addMinutes(max(1, (int) config('sanctum.user_expiration', 10080)));
            $newToken = $lockedUser->createToken(
                'mobile-user',
                ['api:user', 'settings:read'],
                $expiresAt
            );

            $newToken->accessToken->called_ip = $ipAddress;
            $newToken->accessToken->save();

            return [
                'access_token' => $newToken->plainTextToken,
                'token_type' => 'Bearer',
                'expires_at' => $expiresAt->toIso8601String(),
            ];
        });
    }
}
