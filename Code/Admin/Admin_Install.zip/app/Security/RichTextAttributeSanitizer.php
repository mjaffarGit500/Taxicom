<?php

namespace App\Security;

use Symfony\Component\HtmlSanitizer\HtmlSanitizerConfig;
use Symfony\Component\HtmlSanitizer\Visitor\AttributeSanitizer\AttributeSanitizerInterface;

final class RichTextAttributeSanitizer implements AttributeSanitizerInterface
{
    /**
     * @param  list<string>  $allowedClasses
     */
    public function __construct(private readonly array $allowedClasses) {}

    public function getSupportedElements(): ?array
    {
        return ['a', 'figure', 'img', 'table'];
    }

    public function getSupportedAttributes(): ?array
    {
        return ['class', 'target'];
    }

    public function sanitizeAttribute(string $element, string $attribute, string $value, HtmlSanitizerConfig $config): ?string
    {
        if ($attribute === 'target') {
            return in_array($value, ['_blank', '_self', '_parent', '_top'], true) ? $value : null;
        }

        $classes = preg_split('/\s+/', trim($value)) ?: [];
        $classes = array_values(array_intersect($classes, $this->allowedClasses));

        return $classes === [] ? null : implode(' ', array_unique($classes));
    }
}
