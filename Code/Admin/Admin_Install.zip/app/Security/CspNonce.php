<?php

namespace App\Security;

use Illuminate\Support\HtmlString;

final class CspNonce
{
    private readonly string $nonce;

    public function __construct()
    {
        $this->nonce = base64_encode(random_bytes(18));
    }

    public function value(): string
    {
        return $this->nonce;
    }

    public function attribute(): HtmlString
    {
        return new HtmlString('nonce="'.e($this->nonce).'"');
    }
}
