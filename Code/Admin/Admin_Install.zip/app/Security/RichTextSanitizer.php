<?php

namespace App\Security;

use Illuminate\Support\HtmlString;
use LengthException;
use Symfony\Component\HtmlSanitizer\HtmlSanitizer;
use Symfony\Component\HtmlSanitizer\HtmlSanitizerConfig;

final class RichTextSanitizer
{
    private readonly HtmlSanitizer $sanitizer;

    private readonly int $maxInputLength;

    public function __construct()
    {
        $this->maxInputLength = (int) config('rich_text.max_input_length', 60_000);
        $appHost = parse_url((string) config('app.url'), PHP_URL_HOST);
        $mediaHosts = is_string($appHost) && $appHost !== '' ? [$appHost] : [];

        $config = (new HtmlSanitizerConfig)
            ->allowElement('p')
            ->allowElement('br')
            ->allowElement('h1')
            ->allowElement('h2')
            ->allowElement('h3')
            ->allowElement('h4')
            ->allowElement('h5')
            ->allowElement('h6')
            ->allowElement('ul')
            ->allowElement('ol')
            ->allowElement('li')
            ->allowElement('blockquote')
            ->allowElement('hr')
            ->allowElement('code')
            ->allowElement('pre')
            ->allowElement('strong')
            ->allowElement('b')
            ->allowElement('em')
            ->allowElement('i')
            ->allowElement('u')
            ->allowElement('s')
            ->allowElement('table', ['class'])
            ->allowElement('thead')
            ->allowElement('tbody')
            ->allowElement('tfoot')
            ->allowElement('tr')
            ->allowElement('th', ['rowspan', 'colspan', 'scope'])
            ->allowElement('td', ['rowspan', 'colspan'])
            ->allowElement('figure', ['class'])
            ->allowElement('figcaption')
            ->allowElement('a', ['href', 'title', 'target'])
            ->allowElement('img', ['src', 'alt', 'title', 'width', 'height', 'class'])
            ->allowLinkSchemes(['https', 'mailto', 'tel'])
            ->allowRelativeLinks()
            ->allowMediaSchemes(['https'])
            ->allowMediaHosts($mediaHosts)
            ->allowRelativeMedias()
            ->forceAttribute('a', 'rel', 'noopener noreferrer')
            ->withAttributeSanitizer(new RichTextAttributeSanitizer(
                array_values(config('rich_text.ckeditor_classes', []))
            ))
            ->withMaxInputLength($this->maxInputLength);

        $this->sanitizer = new HtmlSanitizer($config);
    }

    public function sanitize(?string $html): ?string
    {
        if ($html === null) {
            return null;
        }

        $this->assertWithinLimit($html);

        return $this->sanitizer->sanitize($html);
    }

    public function toHtml(?string $html): HtmlString
    {
        return new HtmlString($this->sanitize($html) ?? '');
    }

    public function assertWithinLimit(string $html): void
    {
        if (strlen($html) > $this->maxInputLength) {
            throw new LengthException("Rich text must not exceed {$this->maxInputLength} bytes.");
        }
    }
}
