<?php

namespace App\Jobs;

use App\Http\Controllers\Traits\PaymentStatusUpdaterTrait;
use App\Models\Booking;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SendBookingPaymentNotificationJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, PaymentStatusUpdaterTrait, Queueable, SerializesModels;

    public function __construct(public int $bookingId) {}

    public function handle(): void
    {
        $booking = Booking::find($this->bookingId);
        if (! $booking) {
            return;
        }

        try {
            $values = $this->createNotificationArray(
                $booking->userid,
                $booking->host_id,
                $booking->itemid,
                $booking->id
            );
            $data = ['message_key' => $booking];
            $this->sendAllNotifications(
                $values,
                $booking->userid,
                14,
                $data,
                $booking->host_id
            );
        } catch (\Throwable $exception) {
            Log::error('Booking payment notification failed', ['bookingId' => $this->bookingId]);
        }
    }
}
