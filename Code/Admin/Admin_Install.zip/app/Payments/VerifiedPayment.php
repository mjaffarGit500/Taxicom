<?php

namespace App\Payments;

use InvalidArgumentException;

final readonly class VerifiedPayment
{
    public function __construct(
        public int $attemptId,
        public string $gateway,
        public string $providerOrderId,
        public string $providerTransactionId,
        public int $amountMinor,
        public string $currency,
        public string $providerStatus,
        public ?string $eventId = null,
        public array $metadata = [],
    ) {
        if ($attemptId < 1 || $amountMinor < 1 || $providerTransactionId === '') {
            throw new InvalidArgumentException('Verified payment identifiers and amount are required.');
        }

        if (! in_array(strtolower($providerStatus), ['captured', 'completed', 'succeeded', 'txn_success'], true)) {
            throw new InvalidArgumentException('Only a terminal successful payment can be finalized.');
        }
    }
}
