<?php

namespace App\Payments;

use App\Jobs\SendBookingPaymentNotificationJob;
use App\Models\AppUser;
use App\Models\Booking;
use App\Models\PaymentAttempt;
use App\Models\Transaction;
use App\Models\VendorWallet;
use App\Models\Wallet;
use App\Support\Money;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use RuntimeException;

class PaymentFinalizationService
{
    public const APPLIED = 'applied';

    public const ALREADY_APPLIED = 'already_applied';

    public const REQUIRES_REVIEW = 'requires_review';

    public function finalize(VerifiedPayment $payment): string
    {
        try {
            return DB::transaction(fn () => $this->finalizeLocked($payment), 3);
        } catch (QueryException $exception) {
            $attempt = PaymentAttempt::find($payment->attemptId);
            if ($attempt?->applied_at !== null
                && hash_equals((string) $attempt->provider_transaction_id, $payment->providerTransactionId)) {
                return self::ALREADY_APPLIED;
            }

            throw $exception;
        } catch (RuntimeException $exception) {
            Log::warning('Payment finalization rejected', [
                'attemptId' => $payment->attemptId,
                'gateway' => $payment->gateway,
                'outcome' => 'binding_or_state_mismatch',
            ]);

            throw $exception;
        }
    }

    private function finalizeLocked(VerifiedPayment $payment): string
    {
        $attempt = PaymentAttempt::query()->lockForUpdate()->findOrFail($payment->attemptId);
        $gateway = strtolower($payment->gateway);
        $currency = strtoupper($payment->currency);

        $this->assertSame('gateway', $attempt->gateway, $gateway);
        $this->assertSame('provider order', (string) $attempt->provider_order_id, $payment->providerOrderId);
        $this->assertSame('currency', $attempt->currency, $currency);

        if ((int) $attempt->amount_minor !== $payment->amountMinor) {
            throw new RuntimeException('Verified payment amount does not match the payment attempt.');
        }

        if ($attempt->applied_at !== null) {
            $this->assertSame(
                'provider transaction',
                (string) $attempt->provider_transaction_id,
                $payment->providerTransactionId
            );

            return self::ALREADY_APPLIED;
        }

        $collision = PaymentAttempt::query()
            ->where('gateway', $gateway)
            ->where('provider_transaction_id', $payment->providerTransactionId)
            ->whereKeyNot($attempt->id)
            ->lockForUpdate()
            ->exists();

        if ($collision) {
            throw new RuntimeException('Provider transaction is already bound to another payment attempt.');
        }

        if (in_array($attempt->status, ['failed', 'cancelled', 'expired', 'succeeded_unapplied'], true)) {
            if ($attempt->provider_transaction_id !== null) {
                $this->assertSame(
                    'provider transaction',
                    (string) $attempt->provider_transaction_id,
                    $payment->providerTransactionId
                );
            }

            $attempt->forceFill([
                'provider_transaction_id' => $payment->providerTransactionId,
                'provider_metadata' => $this->safeMetadata($payment),
                'status' => 'succeeded_unapplied',
                'active_key' => null,
            ])->save();

            return $this->requiresReview($attempt, 'terminal_attempt_received_success');
        }

        if ($attempt->expires_at?->isPast()) {
            $attempt->forceFill([
                'provider_transaction_id' => $payment->providerTransactionId,
                'provider_metadata' => $this->safeMetadata($payment),
                'status' => 'succeeded_unapplied',
                'active_key' => null,
            ])->save();

            return $this->requiresReview($attempt, 'expired_attempt_received_success');
        }

        $attempt->forceFill([
            'provider_transaction_id' => $payment->providerTransactionId,
            'provider_metadata' => $this->safeMetadata($payment),
            'status' => 'succeeded',
            'active_key' => null,
        ])->save();

        $result = match ($attempt->purpose) {
            'booking' => $this->applyBooking($attempt, $payment),
            'user_wallet' => $this->applyUserWallet($attempt),
            'vendor_wallet' => $this->applyVendorWallet($attempt),
            default => throw new RuntimeException('Unsupported payment purpose.'),
        };

        if ($result !== self::APPLIED) {
            return $result;
        }

        $attempt->forceFill([
            'status' => 'succeeded',
            'active_key' => null,
            'applied_at' => now(),
        ])->save();

        return self::APPLIED;
    }

    private function applyBooking(PaymentAttempt $attempt, VerifiedPayment $payment): string
    {
        $booking = Booking::query()->lockForUpdate()->findOrFail($attempt->booking_id);
        if ((int) $booking->userid !== (int) $attempt->owner_id) {
            throw new RuntimeException('Payment attempt owner does not own the booking.');
        }

        if (strtolower((string) $booking->payment_status) === 'paid') {
            $attempt->forceFill([
                'status' => 'succeeded_unapplied',
                'active_key' => null,
            ])->save();

            return $this->requiresReview($attempt, 'booking_already_paid');
        }

        $transaction = Transaction::create([
            'booking_id' => $booking->id,
            'payment_attempt_id' => $attempt->id,
            'transaction_id' => $payment->providerTransactionId,
            'amount' => Money::fromMinor((int) $attempt->amount_minor, $attempt->currency),
            'currency_code' => $attempt->currency,
            'payment_status' => 'completed',
            'gateway_name' => $attempt->gateway,
            'response_data' => json_encode($this->safeMetadata($payment)),
        ]);

        $booking->forceFill([
            'payment_status' => 'paid',
            'payment_method' => $attempt->gateway,
            'transaction' => $transaction->id,
        ])->save();

        DB::afterCommit(static fn () => SendBookingPaymentNotificationJob::dispatch((int) $booking->id));

        return self::APPLIED;
    }

    private function applyUserWallet(PaymentAttempt $attempt): string
    {
        AppUser::query()->lockForUpdate()->findOrFail($attempt->owner_id);
        $amount = Money::fromMinor((int) $attempt->amount_minor, $attempt->currency);

        DB::update(
            'UPDATE app_users SET wallet = COALESCE(wallet, 0) + ? WHERE id = ?',
            [$amount, $attempt->owner_id]
        );

        Wallet::create([
            'user_id' => $attempt->owner_id,
            'payment_attempt_id' => $attempt->id,
            'amount' => $amount,
            'type' => 'credit',
            'description' => 'Wallet recharge via '.ucfirst($attempt->gateway),
            'status' => 1,
            'currency' => $attempt->currency,
        ]);

        return self::APPLIED;
    }

    private function applyVendorWallet(PaymentAttempt $attempt): string
    {
        AppUser::query()->lockForUpdate()->findOrFail($attempt->owner_id);

        VendorWallet::create([
            'vendor_id' => $attempt->owner_id,
            'payment_attempt_id' => $attempt->id,
            'amount' => Money::fromMinor((int) $attempt->amount_minor, $attempt->currency),
            'type' => 'credit',
            'description' => 'Wallet recharge via '.ucfirst($attempt->gateway),
            'payment_gateway' => $attempt->gateway,
            'gateway_transaction_id' => $attempt->provider_transaction_id,
            'currency' => $attempt->currency,
            'payment_details' => $attempt->provider_metadata ?? [],
        ]);

        return self::APPLIED;
    }

    private function assertSame(string $field, string $expected, string $actual): void
    {
        if ($expected === '' || $actual === '' || ! hash_equals($expected, $actual)) {
            throw new RuntimeException("Verified payment {$field} does not match the payment attempt.");
        }
    }

    private function safeMetadata(VerifiedPayment $payment): array
    {
        return [
            'provider_status' => $payment->providerStatus,
            'provider_order_id' => $payment->providerOrderId,
            'provider_transaction_id' => $payment->providerTransactionId,
            'event_id' => $payment->eventId,
        ];
    }

    private function requiresReview(PaymentAttempt $attempt, string $reason): string
    {
        Log::error('Payment requires financial reconciliation', [
            'attemptId' => $attempt->id,
            'gateway' => $attempt->gateway,
            'outcome' => $reason,
        ]);

        return self::REQUIRES_REVIEW;
    }
}
