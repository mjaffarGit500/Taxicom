<?php

namespace App\Payments;

use App\Models\Booking;
use App\Models\PaymentAttempt;
use App\Support\Money;
use Closure;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;

class PaymentAttemptService
{
    public function withProviderOrderLock(PaymentAttempt $attempt, Closure $callback): mixed
    {
        return Cache::lock('payment-provider-order:'.$attempt->public_id, 60)
            ->block(35, fn () => $callback(
                $attempt->fresh() ?? throw new RuntimeException('Payment attempt no longer exists.')
            ));
    }

    public function forBooking(Booking $booking, int $ownerId, string $gateway): PaymentAttempt
    {
        if ((int) $booking->userid !== $ownerId || strtolower((string) $booking->payment_status) === 'paid') {
            throw new RuntimeException('Booking is not eligible for payment.');
        }

        return $this->createOrReuse(
            $ownerId,
            'booking',
            (int) $booking->id,
            $gateway,
            Money::toMinor((string) $booking->amount_to_pay, (string) $booking->currency_code),
            (string) $booking->currency_code
        );
    }

    public function forWallet(
        int $ownerId,
        string $purpose,
        string $gateway,
        int|string $amount,
        string $currency
    ): PaymentAttempt {
        if (! in_array($purpose, ['user_wallet', 'vendor_wallet'], true)) {
            throw new RuntimeException('Invalid wallet payment purpose.');
        }

        $amountMinor = Money::toMinor($amount, $currency);
        if ($amountMinor < 1) {
            throw new RuntimeException('Wallet recharge amount must be greater than zero.');
        }

        return $this->createOrReuse($ownerId, $purpose, null, $gateway, $amountMinor, $currency);
    }

    public function attachProviderOrder(
        PaymentAttempt $attempt,
        string $providerOrderId,
        array $metadata = []
    ): PaymentAttempt {
        if ($providerOrderId === '') {
            throw new RuntimeException('Provider order ID is required.');
        }

        return DB::transaction(function () use ($attempt, $providerOrderId, $metadata) {
            $locked = PaymentAttempt::query()->lockForUpdate()->findOrFail($attempt->id);

            if ($locked->provider_order_id !== null
                && ! hash_equals($locked->provider_order_id, $providerOrderId)) {
                throw new RuntimeException('Payment attempt is already bound to another provider order.');
            }

            $locked->forceFill([
                'provider_order_id' => $providerOrderId,
                'provider_metadata' => $this->safeMetadata($metadata),
                'status' => 'pending',
            ])->save();

            return $locked->fresh();
        });
    }

    public function findByProviderOrder(string $gateway, string $providerOrderId): ?PaymentAttempt
    {
        return PaymentAttempt::query()
            ->where('gateway', strtolower($gateway))
            ->where('provider_order_id', $providerOrderId)
            ->first();
    }

    public function markFailed(PaymentAttempt $attempt, array $metadata = []): void
    {
        $attempt->forceFill([
            'status' => 'failed',
            'active_key' => null,
            'provider_metadata' => $this->safeMetadata($metadata),
        ])->save();
    }

    private function createOrReuse(
        int $ownerId,
        string $purpose,
        ?int $bookingId,
        string $gateway,
        int $amountMinor,
        string $currency
    ): PaymentAttempt {
        $gateway = strtolower(trim($gateway));
        $currency = strtoupper(trim($currency));
        $activeKey = hash('sha256', implode('|', [
            $ownerId,
            $purpose,
            $bookingId ?? 'wallet',
            $gateway,
            $amountMinor,
            $currency,
        ]));

        return DB::transaction(function () use (
            $ownerId,
            $purpose,
            $bookingId,
            $gateway,
            $amountMinor,
            $currency,
            $activeKey
        ) {
            PaymentAttempt::query()
                ->where('active_key', $activeKey)
                ->whereNotNull('expires_at')
                ->where('expires_at', '<=', now())
                ->update(['active_key' => null, 'status' => 'expired']);

            $query = PaymentAttempt::query()
                ->where('owner_id', $ownerId)
                ->where('purpose', $purpose)
                ->where('gateway', $gateway)
                ->where('amount_minor', $amountMinor)
                ->where('currency', $currency)
                ->where('active_key', $activeKey)
                ->whereIn('status', PaymentAttempt::ACTIVE_STATUSES)
                ->where(function ($query) {
                    $query->whereNull('expires_at')->orWhere('expires_at', '>', now());
                });

            $bookingId === null
                ? $query->whereNull('booking_id')
                : $query->where('booking_id', $bookingId);

            $existing = $query->lockForUpdate()->latest('id')->first();
            if ($existing) {
                return $existing;
            }

            try {
                return PaymentAttempt::create([
                    'public_id' => (string) Str::ulid(),
                    'owner_id' => $ownerId,
                    'booking_id' => $bookingId,
                    'purpose' => $purpose,
                    'gateway' => $gateway,
                    'amount_minor' => $amountMinor,
                    'currency' => $currency,
                    'status' => 'created',
                    'active_key' => $activeKey,
                    'expires_at' => now()->addMinutes(30),
                ]);
            } catch (QueryException) {
                return PaymentAttempt::query()->where('active_key', $activeKey)->firstOrFail();
            }
        });
    }

    private function safeMetadata(array $metadata): array
    {
        return array_intersect_key($metadata, array_flip([
            'provider_status',
            'provider_code',
            'checkout_token',
            'checkout_order_id',
            'approval_url',
            'mode',
        ]));
    }
}
