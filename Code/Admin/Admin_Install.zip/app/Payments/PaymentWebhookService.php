<?php

namespace App\Payments;

use App\Models\PaymentWebhookEvent;
use Illuminate\Database\QueryException;
use RuntimeException;

class PaymentWebhookService
{
    public function register(string $gateway, ?string $providerEventId, string $rawBody): ?PaymentWebhookEvent
    {
        $payloadHash = hash('sha256', $rawBody);
        $providerEventId = trim((string) $providerEventId);
        if ($providerEventId === '') {
            $providerEventId = $payloadHash;
        }

        try {
            return PaymentWebhookEvent::create([
                'gateway' => strtolower($gateway),
                'provider_event_id' => $providerEventId,
                'payload_hash' => $payloadHash,
                'processing_status' => 'received',
            ]);
        } catch (QueryException $exception) {
            $existing = PaymentWebhookEvent::query()
                ->where('gateway', strtolower($gateway))
                ->where('provider_event_id', $providerEventId)
                ->first();
            if (! $existing) {
                throw $exception;
            }

            if (! hash_equals($existing->payload_hash, $payloadHash)) {
                throw new RuntimeException('Provider event ID was replayed with a different payload.');
            }

            return null;
        }
    }

    public function processed(PaymentWebhookEvent $event, string $status = 'processed'): void
    {
        $event->forceFill([
            'processing_status' => $status,
            'processed_at' => now(),
        ])->save();
    }

    public function retryable(PaymentWebhookEvent $event): void
    {
        if ($event->processing_status === 'received') {
            $event->delete();
        }
    }
}
