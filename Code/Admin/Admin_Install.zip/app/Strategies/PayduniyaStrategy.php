<?php

namespace App\Strategies;

use App\Http\Controllers\Traits\MiscellaneousTrait;
use App\Models\PaymentAttempt;
use App\Payments\PaymentAttemptService;
use App\Payments\PaymentFinalizationService;
use App\Payments\PaymentWebhookService;
use App\Payments\VerifiedPayment;
use App\Support\Money;
use Illuminate\Contracts\Cache\LockTimeoutException;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\URL;

class PayduniyaStrategy implements PaymentStrategy
{
    use MiscellaneousTrait;

    public function process($bookingId, $bookingData, $request)
    {
        try {
            $attempt = app(PaymentAttemptService::class)->forBooking(
                $bookingData,
                (int) $bookingData->userid,
                'paydunya'
            );
        } catch (\RuntimeException $exception) {
            return redirect('/invalid-order')->with('error', 'Invalid booking ID');
        }

        if ($attempt->currency !== $this->currency()) {
            return redirect('/invalid-order')->with('error', 'Invalid booking ID');
        }

        try {
            $approvalUrl = app(PaymentAttemptService::class)->withProviderOrderLock(
                $attempt,
                fn (PaymentAttempt $locked) => $this->createInvoice($locked, $bookingId, $bookingData)
            );
        } catch (LockTimeoutException) {
            $approvalUrl = null;
        }
        if (! is_string($approvalUrl) || $approvalUrl === '') {
            return redirect('/invalid-order')->with('error', 'Invalid booking ID');
        }

        return redirect($approvalUrl)->with('success', 'Please make payment');
    }

    private function createInvoice(PaymentAttempt $attempt, $bookingId, $bookingData): ?string
    {
        if ($attempt->provider_order_id && isset($attempt->provider_metadata['approval_url'])) {
            return (string) $attempt->provider_metadata['approval_url'];
        }

        $response = Http::withHeaders($this->headers())->post($this->baseUrl().'/checkout-invoice/create', [
            'invoice' => [
                'items' => [
                    'item_0' => ['name' => (string) ($bookingData->prop_title ?? 'Booking')],
                ],
                'total_amount' => Money::fromMinor((int) $attempt->amount_minor, $attempt->currency),
                'description' => '',
            ],
            'store' => [
                'name' => (string) $this->getGeneralSettingValue('general_name'),
            ],
            'custom_data' => [
                'payment_attempt' => $attempt->public_id,
            ],
            'actions' => [
                'cancel_url' => route('handleCancel', ['booking' => $bookingId, 'method' => 'payduniya']),
                'return_url' => route('handleReturn', ['booking' => $bookingId, 'method' => 'payduniya']),
                'callback_url' => route('handleCallback', ['method' => 'payduniya']),
            ],
        ]);
        $result = $response->json();
        if (! is_array($result)) {
            return null;
        }
        $token = (string) ($result['token'] ?? '');
        $approvalUrl = (string) ($result['response_text'] ?? '');

        if (! $response->successful()
            || ($result['response_code'] ?? null) !== '00'
            || $token === ''
            || $approvalUrl === '') {
            return null;
        }

        app(PaymentAttemptService::class)->attachProviderOrder($attempt, $token, [
            'approval_url' => $approvalUrl,
        ]);

        return $approvalUrl;
    }

    public function cancel($bookingId, $bookingData)
    {
        return URL::temporarySignedRoute('payment_methods', now()->addMinutes(30), ['booking' => $bookingId]);
    }

    public function refund($bookingId, $bookingData) {}

    public function return($bookingId, $requestData)
    {
        $token = (string) $requestData->input('token');
        $attempt = app(PaymentAttemptService::class)->findByProviderOrder('paydunya', $token);
        if (! $attempt
            || $attempt->purpose !== 'booking'
            || (int) $attempt->booking_id !== (int) $bookingId) {
            return '/payment_fail';
        }

        return $this->confirmAndFinalize($attempt) ? '/payment_success' : '/payment_fail';
    }

    public function callback($bookingId, $requestData)
    {
        $data = $requestData['data'] ?? null;
        $hash = is_array($data) ? (string) ($data['hash'] ?? '') : '';
        if ($hash === '' || ! hash_equals(hash('sha512', $this->masterKey()), $hash)) {
            return false;
        }

        $token = (string) ($data['invoice']['token'] ?? $data['token'] ?? '');
        $attempt = app(PaymentAttemptService::class)->findByProviderOrder('paydunya', $token);
        $event = app(PaymentWebhookService::class)->register(
            'paydunya',
            null,
            json_encode($requestData, JSON_UNESCAPED_SLASHES) ?: ''
        );
        if (! $event || ! $attempt) {
            return false;
        }

        $result = $this->confirmAndFinalize($attempt, $event->provider_event_id);
        app(PaymentWebhookService::class)->processed($event, $result ? 'applied' : 'binding_failed');

        return $result;
    }

    private function confirmAndFinalize(PaymentAttempt $attempt, ?string $eventId = null): bool
    {
        $response = Http::withHeaders($this->headers())->get(
            $this->baseUrl().'/checkout-invoice/confirm/'.rawurlencode((string) $attempt->provider_order_id)
        );
        $data = $response->json();
        $currency = strtoupper((string) ($data['currency'] ?? $this->currency()));
        $total = $data['invoice']['total_amount'] ?? $data['total_amount'] ?? null;

        try {
            $amountMinor = Money::toMinor((string) $total, $currency);
        } catch (\InvalidArgumentException $exception) {
            return false;
        }

        if (! $response->successful()
            || ($data['response_code'] ?? null) !== '00'
            || ($data['status'] ?? null) !== 'completed'
            || ! hash_equals((string) $attempt->provider_order_id, (string) ($data['invoice']['token'] ?? ''))
            || ! hash_equals($attempt->public_id, (string) ($data['custom_data']['payment_attempt'] ?? ''))
            || ! hash_equals($attempt->currency, $currency)
            || $amountMinor !== (int) $attempt->amount_minor) {
            return false;
        }

        $verified = new VerifiedPayment(
            (int) $attempt->id,
            'paydunya',
            (string) $attempt->provider_order_id,
            (string) $attempt->provider_order_id,
            $amountMinor,
            $currency,
            'completed',
            $eventId
        );
        $result = app(PaymentFinalizationService::class)->finalize($verified);

        return $result !== PaymentFinalizationService::REQUIRES_REVIEW;
    }

    private function headers(): array
    {
        return [
            'PAYDUNYA-MASTER-KEY' => $this->masterKey(),
            'PAYDUNYA-PRIVATE-KEY' => $this->credential('private_key'),
            'PAYDUNYA-TOKEN' => $this->credential('token'),
        ];
    }

    private function masterKey(): string
    {
        return $this->credential('master_key');
    }

    private function settingPrefix(): string
    {
        return ($this->getGeneralSettingValue('payaunya_options') === 'live' ? 'live' : 'test').'_paydunya';
    }

    private function baseUrl(): string
    {
        return $this->getGeneralSettingValue('payaunya_options') === 'live'
            ? 'https://app.paydunya.com/api/v1'
            : 'https://app.paydunya.com/sandbox-api/v1';
    }

    private function currency(): string
    {
        return strtoupper($this->credential('currency') ?: 'XOF');
    }

    private function credential(string $field): string
    {
        $value = (string) $this->getGeneralSettingValue($this->settingPrefix().'_'.$field);
        if ($value !== '') {
            return $value;
        }

        $legacyPrefix = str_replace('paydunya', 'payaunya', $this->settingPrefix());

        return (string) $this->getGeneralSettingValue($legacyPrefix.'_'.$field);
    }
}
