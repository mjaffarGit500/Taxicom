<?php

namespace App\Strategies;

use App\Http\Controllers\Traits\MiscellaneousTrait;
use App\Models\AppUser;
use App\Models\PaymentAttempt;
use App\Payments\PaymentAttemptService;
use App\Payments\PaymentFinalizationService;
use App\Payments\PaymentWebhookService;
use App\Payments\VerifiedPayment;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;
use Stripe\Exception\ApiErrorException;
use Stripe\PaymentIntent;
use Stripe\Stripe;
use Stripe\Webhook;

class StripeStrategy implements PaymentStrategy
{
    use MiscellaneousTrait;

    public function __construct()
    {
        $stripeMode = $this->getGeneralSettingValue('stripe_options');
        $stripeSecretKey = $stripeMode === 'test'
            ? $this->getGeneralSettingValue('test_stripe_secret_key')
            : $this->getGeneralSettingValue('live_stripe_secret_key');
        Stripe::setApiKey($stripeSecretKey);
    }

    public function rechargeWallet($userID, $Amount, $currency, $request)
    {
        $userToken = $request->input('userToken');
        $user = AppUser::find($userID);
        if (! $user) {
            return redirect()->route('wallet_recharge_fail', ['userToken' => $userToken]);
        }

        try {
            $purpose = $user->user_type === 'user' ? 'user_wallet' : 'vendor_wallet';
            $attempt = app(PaymentAttemptService::class)->forWallet(
                (int) $user->id,
                $purpose,
                'stripe',
                (string) $Amount,
                (string) $currency
            );
            $intent = $this->paymentIntent($attempt, (string) $request->input('stripeToken'));
            $verified = $this->verifiedPaymentIntent($attempt, $intent);

            if (! $verified) {
                return redirect()->route('wallet_recharge_fail', ['userToken' => $userToken]);
            }

            $result = app(PaymentFinalizationService::class)->finalize($verified);
            if ($result === PaymentFinalizationService::REQUIRES_REVIEW) {
                return redirect()->route('wallet_recharge_fail', ['userToken' => $userToken]);
            }

            return redirect()->route('wallet_recharge_success', ['userToken' => $userToken]);
        } catch (ApiErrorException|\RuntimeException $exception) {
            return redirect()->route('wallet_recharge_fail', ['userToken' => $userToken]);
        }
    }

    public function process($bookingId, $bookingData, $request)
    {
        try {
            $attempt = app(PaymentAttemptService::class)->forBooking(
                $bookingData,
                (int) $bookingData->userid,
                'stripe'
            );
            $intent = $this->paymentIntent($attempt, (string) $request->input('stripeToken'));
            $verified = $this->verifiedPaymentIntent($attempt, $intent);

            if (! $verified) {
                return redirect()->route('payment_fail', ['bookingId' => $bookingId]);
            }

            $result = app(PaymentFinalizationService::class)->finalize($verified);
            if ($result === PaymentFinalizationService::REQUIRES_REVIEW) {
                return redirect()->route('payment_fail', ['bookingId' => $bookingId]);
            }

            return redirect()->route('payment_success', ['bookingId' => $bookingId]);
        } catch (ApiErrorException|\RuntimeException $exception) {
            return redirect()->route('payment_fail', ['bookingId' => $bookingId]);
        }
    }

    public function cancel($bookingId, $bookingData)
    {
        return URL::temporarySignedRoute('payment_methods', now()->addMinutes(30), ['booking' => $bookingId]);
    }

    public function return($bookingId, $requestData) {}

    public function callback($bookingId, $requestData) {}

    public function refund($bookingId, $bookingData) {}

    public function handleWebhook(Request $request): JsonResponse
    {
        $mode = $this->getGeneralSettingValue('stripe_options') === 'live' ? 'live' : 'test';
        $secret = (string) $this->getGeneralSettingValue($mode.'_stripe_webhook_secret');
        if ($secret === '') {
            return response()->json(['status' => 'unauthorized'], 401);
        }

        try {
            $event = Webhook::constructEvent(
                $request->getContent(),
                (string) $request->header('Stripe-Signature'),
                $secret
            );
        } catch (\Throwable $exception) {
            return response()->json(['status' => 'invalid signature'], 400);
        }

        $webhook = app(PaymentWebhookService::class)->register(
            'stripe',
            (string) $event->id,
            $request->getContent()
        );
        if (! $webhook) {
            return response()->json(['status' => 'already processed']);
        }

        if ($event->type !== 'payment_intent.succeeded') {
            app(PaymentWebhookService::class)->processed($webhook, 'recorded_only');

            return response()->json(['status' => 'recorded']);
        }

        $intentId = (string) ($event->data->object->id ?? '');
        $attempt = app(PaymentAttemptService::class)->findByProviderOrder('stripe', $intentId);
        try {
            $intent = $intentId === '' ? null : PaymentIntent::retrieve($intentId);
        } catch (ApiErrorException $exception) {
            app(PaymentWebhookService::class)->retryable($webhook);

            return response()->json(['status' => 'verification failed'], 502);
        }
        $verified = $attempt && $intent ? $this->verifiedPaymentIntent($attempt, $intent) : null;

        if (! $verified) {
            app(PaymentWebhookService::class)->processed($webhook, 'binding_failed');

            return response()->json(['status' => 'invalid payment'], 400);
        }

        $result = app(PaymentFinalizationService::class)->finalize($verified);
        app(PaymentWebhookService::class)->processed($webhook, $result);

        return response()->json(['status' => 'success']);
    }

    private function paymentIntent(PaymentAttempt $attempt, string $token): PaymentIntent
    {
        if ($attempt->provider_order_id) {
            return PaymentIntent::retrieve($attempt->provider_order_id);
        }

        if ($token === '') {
            throw new \RuntimeException('Stripe token is required.');
        }

        $intent = PaymentIntent::create([
            'amount' => (int) $attempt->amount_minor,
            'currency' => strtolower($attempt->currency),
            'confirm' => true,
            'payment_method_types' => ['card'],
            'payment_method_data' => [
                'type' => 'card',
                'card' => ['token' => $token],
            ],
            'metadata' => [
                'payment_attempt' => $attempt->public_id,
            ],
        ], [
            'idempotency_key' => $attempt->public_id,
        ]);

        app(PaymentAttemptService::class)->attachProviderOrder($attempt, $intent->id, [
            'provider_status' => $intent->status,
        ]);
        $attempt->refresh();

        return $intent;
    }

    private function verifiedPaymentIntent(
        PaymentAttempt $attempt,
        PaymentIntent $intent
    ): ?VerifiedPayment {
        if ($intent->status !== PaymentIntent::STATUS_SUCCEEDED
            || ! hash_equals((string) $attempt->provider_order_id, (string) $intent->id)
            || (int) $intent->amount_received !== (int) $attempt->amount_minor
            || ! hash_equals(strtolower($attempt->currency), strtolower((string) $intent->currency))
            || ! hash_equals($attempt->public_id, (string) ($intent->metadata->payment_attempt ?? ''))) {
            return null;
        }

        return new VerifiedPayment(
            (int) $attempt->id,
            'stripe',
            (string) $intent->id,
            (string) $intent->id,
            (int) $attempt->amount_minor,
            $attempt->currency,
            'succeeded'
        );
    }
}
