<?php

namespace App\Strategies;

use App\Http\Controllers\Traits\MiscellaneousTrait;
use App\Models\PaymentAttempt;
use App\Payments\PaymentAttemptService;
use App\Payments\PaymentFinalizationService;
use App\Payments\VerifiedPayment;
use App\Services\RazorpayService;
use Illuminate\Support\Facades\URL;

class RazorpayStrategy implements PaymentStrategy
{
    use MiscellaneousTrait;

    public function process($bookingId, $bookingData, $request)
    {
        $attempt = app(PaymentAttemptService::class)->forBooking(
            $bookingData,
            (int) $bookingData->userid,
            'razorpay'
        );
        $service = app(RazorpayService::class);
        $result = app(PaymentAttemptService::class)->withProviderOrderLock(
            $attempt,
            function (PaymentAttempt $locked) use ($service) {
                if ($locked->provider_order_id) {
                    return $service->fetchOrder($locked->provider_order_id)['data'] ?? null;
                }

                $order = $service->createOrder(
                    (int) $locked->amount_minor,
                    $locked->currency,
                    'pay_'.$locked->public_id
                );
                if ($order['status'] !== 'success') {
                    return null;
                }

                $result = [
                    'id' => $order['orderId'],
                    'amount' => $order['amount'],
                    'currency' => $order['currency'],
                    'status' => 'created',
                ];
                app(PaymentAttemptService::class)->attachProviderOrder(
                    $locked,
                    (string) $result['id']
                );

                return $result;
            }
        );

        if (! is_array($result)) {
            return redirect('/invalid-order')->with('error', 'Payment initiation failed.');
        }

        return view('Front.razorpay-payment', [
            'bookingId' => $bookingId,
            'orderDetails' => $result,
            'apiKey' => $service->getKeyId(),
        ]);
    }

    public function return($bookingId, $request)
    {
        $orderId = (string) $request->input('razorpay_order_id');
        $paymentId = (string) $request->input('razorpay_payment_id');
        $attempt = app(PaymentAttemptService::class)->findByProviderOrder('razorpay', $orderId);

        if (! $attempt
            || $attempt->purpose !== 'booking'
            || (int) $attempt->booking_id !== (int) $bookingId) {
            return '/payment_fail';
        }

        $service = app(RazorpayService::class);
        if (! $service->verifyPaymentSignature([
            'razorpay_order_id' => (string) $attempt->provider_order_id,
            'razorpay_payment_id' => $paymentId,
            'razorpay_signature' => (string) $request->input('razorpay_signature'),
        ])) {
            return '/payment_fail';
        }

        $verified = $this->verifiedPayment($attempt, $paymentId, $service);
        if (! $verified) {
            return '/payment_fail';
        }

        $result = app(PaymentFinalizationService::class)->finalize($verified);
        if ($result === PaymentFinalizationService::REQUIRES_REVIEW) {
            return '/payment_fail';
        }

        return '/payment_success';
    }

    public function callback($bookingId, $request)
    {
        return '/payment_fail';
    }

    public function refund($bookingId, $bookingData) {}

    public function paymentError()
    {
        return view('Front.Fail');
    }

    public function cancel($bookingId, $bookingData)
    {
        return URL::temporarySignedRoute('payment_methods', now()->addMinutes(30), ['booking' => $bookingId]);
    }

    private function verifiedPayment(
        PaymentAttempt $attempt,
        string $paymentId,
        RazorpayService $service
    ): ?VerifiedPayment {
        $orderResult = $service->fetchOrder((string) $attempt->provider_order_id);
        $paymentResult = $service->fetchPayment($paymentId);
        if (($orderResult['status'] ?? null) !== 'success'
            || ($paymentResult['status'] ?? null) !== 'success') {
            return null;
        }

        $order = $orderResult['data'];
        $payment = $paymentResult['data'];
        $amount = (int) ($payment['amount'] ?? -1);
        $currency = strtoupper((string) ($payment['currency'] ?? ''));

        if (($payment['status'] ?? null) !== 'captured'
            || ! hash_equals((string) $attempt->provider_order_id, (string) ($order['id'] ?? ''))
            || ! hash_equals((string) $attempt->provider_order_id, (string) ($payment['order_id'] ?? ''))
            || $amount !== (int) $attempt->amount_minor
            || ! hash_equals($attempt->currency, $currency)) {
            return null;
        }

        return new VerifiedPayment(
            (int) $attempt->id,
            'razorpay',
            (string) $attempt->provider_order_id,
            $paymentId,
            $amount,
            $currency,
            'captured'
        );
    }
}
