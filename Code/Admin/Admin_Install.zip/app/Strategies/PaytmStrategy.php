<?php

namespace App\Strategies;

use Illuminate\Support\Facades\URL;

/**
 * The browser Paytm integration used unsigned booking query parameters and is
 * intentionally non-mutating. Mobile clients use the attempt-bound Paytm API.
 */
class PaytmStrategy implements PaymentStrategy
{
    public function process($bookingId, $bookingData, $request)
    {
        return redirect('/invalid-order')->with('error', 'Payment method is not available');
    }

    public function return($bookingId, $requestData)
    {
        return '/payment_fail';
    }

    public function callback($bookingId, $requestData)
    {
        return false;
    }

    public function cancel($bookingId, $bookingData)
    {
        return URL::temporarySignedRoute('payment_methods', now()->addMinutes(30), ['booking' => $bookingId]);
    }

    public function refund($bookingId, $bookingData) {}
}
