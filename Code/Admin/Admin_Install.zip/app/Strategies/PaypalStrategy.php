<?php

namespace App\Strategies;

use App\Http\Controllers\Traits\MiscellaneousTrait;
use App\Models\PaymentAttempt;
use App\Payments\PaymentAttemptService;
use App\Payments\PaymentFinalizationService;
use App\Payments\PaymentWebhookService;
use App\Payments\VerifiedPayment;
use App\Services\VendorWalletRechargeService;
use App\Support\Money;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\URL;
use PaypalServerSdkLib\ApiHelper;
use PaypalServerSdkLib\Authentication\ClientCredentialsAuthCredentialsBuilder;
use PaypalServerSdkLib\Environment;
use PaypalServerSdkLib\Exceptions\ApiException;
use PaypalServerSdkLib\Models\Builders\AmountWithBreakdownBuilder;
use PaypalServerSdkLib\Models\Builders\OrderApplicationContextBuilder;
use PaypalServerSdkLib\Models\Builders\OrderRequestBuilder;
use PaypalServerSdkLib\Models\Builders\PurchaseUnitRequestBuilder;
use PaypalServerSdkLib\Models\CheckoutPaymentIntent;
use PaypalServerSdkLib\Models\Order;
use PaypalServerSdkLib\PaypalServerSdkClient;
use PaypalServerSdkLib\PaypalServerSdkClientBuilder;

class PaypalStrategy implements PaymentStrategy
{
    use MiscellaneousTrait;

    private PaypalServerSdkClient $client;

    private string $clientId;

    private string $clientSecret;

    private bool $sandbox;

    public function __construct()
    {
        $this->sandbox = $this->getGeneralSettingValue('paypal_options') === 'test';
        $this->clientId = (string) $this->getGeneralSettingValue(
            $this->sandbox ? 'test_paypal_client_id' : 'live_paypal_client_id'
        );
        $this->clientSecret = (string) $this->getGeneralSettingValue(
            $this->sandbox ? 'test_paypal_secret_key' : 'live_paypal_secret_key'
        );
        $this->client = PaypalServerSdkClientBuilder::init()
            ->clientCredentialsAuthCredentials(
                ClientCredentialsAuthCredentialsBuilder::init($this->clientId, $this->clientSecret)
            )
            ->environment($this->sandbox ? Environment::SANDBOX : Environment::PRODUCTION)
            ->build();
    }

    public function process($bookingId, $bookingData, $request)
    {
        try {
            $attempt = app(PaymentAttemptService::class)->forBooking(
                $bookingData,
                (int) $bookingData->userid,
                'paypal'
            );

            return redirect($this->createOrder(
                $attempt,
                route('handleReturn', ['booking' => $bookingId, 'method' => 'paypal']),
                route('handleCancel', ['booking' => $bookingId, 'method' => 'paypal']),
                'Payment for booking: '.$bookingId
            ))->with('success', 'Please make payment');
        } catch (ApiException|\RuntimeException $exception) {
            return redirect('/invalid-order')->with('error', 'Invalid booking ID');
        }
    }

    public function rechargeWallet($userId, $amount, $currency, $request)
    {
        $vendor = app(VendorWalletRechargeService::class)->findVendorByToken(
            (string) $request->input('userToken', $request->input('token'))
        );
        if (! $vendor || (int) $vendor->id !== (int) $userId) {
            return redirect()->route('wallet_recharge_fail');
        }

        try {
            $attempt = app(PaymentAttemptService::class)->forWallet(
                (int) $vendor->id,
                'vendor_wallet',
                'paypal',
                (string) $amount,
                (string) $currency
            );

            return redirect($this->createOrder(
                $attempt,
                route('wallet_recharge_paypal_return'),
                route('wallet_recharge_fail'),
                'Vendor wallet recharge'
            ));
        } catch (ApiException|\RuntimeException $exception) {
            return redirect()->route('wallet_recharge_fail');
        }
    }

    public function returnWalletRecharge(Request $request)
    {
        $attempt = $this->attemptFromToken((string) $request->input('token'), 'vendor_wallet');
        if (! $attempt || ! $this->captureAndFinalize($attempt)) {
            return redirect()->route('wallet_recharge_fail');
        }

        return redirect()->route('wallet_recharge_success');
    }

    public function cancel($bookingId, $bookingData)
    {
        return URL::temporarySignedRoute('payment_methods', now()->addMinutes(30), ['booking' => $bookingId]);
    }

    public function return($bookingId, $requestData)
    {
        $attempt = $this->attemptFromToken((string) $requestData->input('token'), 'booking');
        if (! $attempt || (int) $attempt->booking_id !== (int) $bookingId) {
            return '/payment_fail';
        }

        return $this->captureAndFinalize($attempt) ? '/payment_success' : '/payment_fail';
    }

    public function callback($bookingId, $requestData) {}

    public function refund($bookingId, $bookingData) {}

    public function handleWebhook(Request $request): JsonResponse
    {
        $payload = $request->json()->all();
        if (! $this->verifyWebhook($request, $payload)) {
            return response()->json(['status' => 'invalid signature'], 400);
        }

        $event = app(PaymentWebhookService::class)->register(
            'paypal',
            (string) ($payload['id'] ?? ''),
            $request->getContent()
        );
        if (! $event) {
            return response()->json(['status' => 'success']);
        }

        if (($payload['event_type'] ?? null) !== 'PAYMENT.CAPTURE.COMPLETED') {
            app(PaymentWebhookService::class)->processed($event, 'recorded_only');

            return response()->json(['status' => 'success']);
        }

        $orderId = (string) ($payload['resource']['supplementary_data']['related_ids']['order_id'] ?? '');
        $attempt = app(PaymentAttemptService::class)->findByProviderOrder('paypal', $orderId);
        if (! $attempt) {
            app(PaymentWebhookService::class)->processed($event, 'binding_failed');

            return response()->json(['status' => 'success']);
        }

        try {
            $result = $this->getOrder($orderId);
            $verified = $this->verifiedOrder($attempt, $result, $event->provider_event_id);
            if ($verified) {
                $outcome = app(PaymentFinalizationService::class)->finalize($verified);
                app(PaymentWebhookService::class)->processed($event, $outcome);
            } else {
                app(PaymentWebhookService::class)->processed($event, 'binding_failed');
            }
        } catch (ApiException $exception) {
            app(PaymentWebhookService::class)->retryable($event);

            return response()->json(['status' => 'verification failed'], 502);
        }

        return response()->json(['status' => 'success']);
    }

    private function createOrder(
        PaymentAttempt $attempt,
        string $returnUrl,
        string $cancelUrl,
        string $description
    ): string {
        return app(PaymentAttemptService::class)->withProviderOrderLock(
            $attempt,
            fn (PaymentAttempt $locked) => $this->createOrderLocked(
                $locked,
                $returnUrl,
                $cancelUrl,
                $description
            )
        );
    }

    private function createOrderLocked(
        PaymentAttempt $attempt,
        string $returnUrl,
        string $cancelUrl,
        string $description
    ): string {
        if ($attempt->provider_order_id && isset($attempt->provider_metadata['approval_url'])) {
            return (string) $attempt->provider_metadata['approval_url'];
        }

        $response = $this->client->getOrdersController()->createOrder([
            'body' => OrderRequestBuilder::init(
                CheckoutPaymentIntent::CAPTURE,
                [
                    PurchaseUnitRequestBuilder::init(
                        AmountWithBreakdownBuilder::init(
                            $attempt->currency,
                            Money::fromMinor((int) $attempt->amount_minor, $attempt->currency)
                        )->build()
                    )
                        ->customId($attempt->public_id)
                        ->invoiceId($attempt->public_id)
                        ->description($description)
                        ->build(),
                ]
            )
                ->applicationContext(
                    OrderApplicationContextBuilder::init()
                        ->returnUrl($returnUrl)
                        ->cancelUrl($cancelUrl)
                        ->build()
                )
                ->build(),
            'prefer' => 'return=representation',
        ]);
        $approvalUrl = '';
        $order = $this->orderResult($response->getResult());
        foreach ($order->getLinks() ?? [] as $link) {
            if ($link->getRel() === 'approve') {
                $approvalUrl = $link->getHref();
            }
        }
        if ($approvalUrl === '' || ! $order->getId()) {
            throw new \RuntimeException('PayPal approval URL is missing.');
        }

        app(PaymentAttemptService::class)->attachProviderOrder(
            $attempt,
            $order->getId(),
            ['approval_url' => $approvalUrl]
        );

        return $approvalUrl;
    }

    private function attemptFromToken(string $token, string $purpose): ?PaymentAttempt
    {
        if ($token === '') {
            return null;
        }

        $attempt = app(PaymentAttemptService::class)->findByProviderOrder('paypal', $token);

        return $attempt && $attempt->purpose === $purpose ? $attempt : null;
    }

    private function captureAndFinalize(PaymentAttempt $attempt): bool
    {
        try {
            try {
                $this->client->getOrdersController()->captureOrder([
                    'id' => (string) $attempt->provider_order_id,
                    'prefer' => 'return=representation',
                ]);
            } catch (ApiException $exception) {
                // A replayed browser return may find an order already captured.
                // The authoritative GET below decides whether it is valid.
            }
            $result = $this->getOrder((string) $attempt->provider_order_id);
            $verified = $this->verifiedOrder($attempt, $result);
            if (! $verified) {
                return false;
            }

            $result = app(PaymentFinalizationService::class)->finalize($verified);

            return $result !== PaymentFinalizationService::REQUIRES_REVIEW;
        } catch (ApiException $exception) {
            return false;
        }
    }

    private function getOrder(string $orderId): Order
    {
        return $this->orderResult(
            $this->client->getOrdersController()->getOrder(['id' => $orderId])->getResult()
        );
    }

    /**
     * Normalize the Server SDK response, which may be a typed Order or decoded JSON array.
     *
     * @param  mixed  $result
     */
    private function orderResult($result): Order
    {
        if ($result instanceof Order) {
            return $result;
        }

        if (is_array($result) || $result instanceof \stdClass) {
            $mapped = ApiHelper::getJsonHelper()->mapClass(
                json_decode(json_encode($result, JSON_THROW_ON_ERROR), false, 512, JSON_THROW_ON_ERROR),
                Order::class
            );

            if ($mapped instanceof Order) {
                return $mapped;
            }
        }

        throw new \RuntimeException('PayPal returned an invalid order response.');
    }

    private function verifiedOrder(
        PaymentAttempt $attempt,
        Order $order,
        ?string $eventId = null
    ): ?VerifiedPayment {
        $unit = $order->getPurchaseUnits()[0] ?? null;
        $capture = $unit?->getPayments()?->getCaptures()[0] ?? null;
        $mode = $this->sandbox ? 'test' : 'live';
        $merchantId = (string) $this->getGeneralSettingValue($mode.'_paypal_merchant_id');
        $actualMerchant = (string) ($unit?->getPayee()?->getMerchantId() ?? '');
        $currency = strtoupper((string) ($capture?->getAmount()?->getCurrencyCode() ?? ''));

        try {
            $amountMinor = Money::toMinor((string) ($capture?->getAmount()?->getValue() ?? ''), $currency);
        } catch (\InvalidArgumentException $exception) {
            return null;
        }

        if ($order->getStatus() !== 'COMPLETED'
            || $capture?->getStatus() !== 'COMPLETED'
            || ! $capture?->getId()
            || ! hash_equals((string) $attempt->provider_order_id, (string) $order->getId())
            || ! hash_equals($attempt->public_id, (string) $unit?->getCustomId())
            || ! hash_equals($attempt->public_id, (string) $unit?->getInvoiceId())
            || $merchantId === ''
            || ! hash_equals($merchantId, $actualMerchant)
            || ! hash_equals($attempt->currency, $currency)
            || $amountMinor !== (int) $attempt->amount_minor) {
            return null;
        }

        return new VerifiedPayment(
            (int) $attempt->id,
            'paypal',
            (string) $order->getId(),
            $capture->getId(),
            $amountMinor,
            $currency,
            'completed',
            $eventId
        );
    }

    private function verifyWebhook(Request $request, array $payload): bool
    {
        $mode = $this->sandbox ? 'test' : 'live';
        $webhookId = (string) $this->getGeneralSettingValue($mode.'_paypal_webhook_id');
        if ($webhookId === '') {
            return false;
        }

        $baseUrl = $this->sandbox ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com';
        $token = Http::asForm()
            ->withBasicAuth($this->clientId, $this->clientSecret)
            ->post($baseUrl.'/v1/oauth2/token', ['grant_type' => 'client_credentials'])
            ->json('access_token');
        if (! is_string($token) || $token === '') {
            return false;
        }

        $response = Http::withToken($token)->post(
            $baseUrl.'/v1/notifications/verify-webhook-signature',
            [
                'auth_algo' => $request->header('PAYPAL-AUTH-ALGO'),
                'cert_url' => $request->header('PAYPAL-CERT-URL'),
                'transmission_id' => $request->header('PAYPAL-TRANSMISSION-ID'),
                'transmission_sig' => $request->header('PAYPAL-TRANSMISSION-SIG'),
                'transmission_time' => $request->header('PAYPAL-TRANSMISSION-TIME'),
                'webhook_id' => $webhookId,
                'webhook_event' => $payload,
            ]
        );

        return $response->successful() && $response->json('verification_status') === 'SUCCESS';
    }
}
