<?php

namespace App\Exceptions;

use RuntimeException;

class FirestoreDocumentNotFoundException extends RuntimeException {}
