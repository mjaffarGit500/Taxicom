<?php

namespace App\Policies;

use App\Models\Module;
use App\Models\User;

class ModulePolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasPermission('module_access');
    }

    public function view(User $user, Module $module): bool
    {
        return $user->hasPermission('module_show');
    }

    public function create(User $user): bool
    {
        return $user->hasPermission('module_create');
    }

    public function update(User $user, Module $module): bool
    {
        return $user->hasPermission('module_edit');
    }

    public function delete(User $user, Module $module): bool
    {
        return $user->hasPermission('module_delete');
    }

    public function deleteAny(User $user): bool
    {
        return $user->hasPermission('module_delete');
    }

    public function uploadMedia(User $user): bool
    {
        return $user->hasPermission('module_create');
    }

    public function updateStatus(User $user): bool
    {
        return $user->hasPermission('module_status_edit');
    }
}
