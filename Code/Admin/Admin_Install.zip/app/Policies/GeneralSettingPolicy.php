<?php

namespace App\Policies;

use App\Models\User;

class GeneralSettingPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasPermission('general_setting_access');
    }

    public function updateAny(User $user): bool
    {
        return $user->hasPermission('general_setting_edit');
    }

    public function viewSensitive(User $user): bool
    {
        return $user->hasPermission('general_setting_sensitive_access');
    }

    public function updateSensitive(User $user): bool
    {
        return $user->hasPermission('general_setting_sensitive_edit');
    }

    public function sendPushNotifications(User $user): bool
    {
        return $user->hasPermission('push_notification_send');
    }

    public function viewProjectSetup(User $user): bool
    {
        return $user->hasPermission('project_setup_access');
    }

    public function runProjectSetup(User $user): bool
    {
        return $user->hasPermission('project_setup_run');
    }

    public function runProjectCleanup(User $user): bool
    {
        return $user->hasPermission('project_cleanup_run');
    }
}
