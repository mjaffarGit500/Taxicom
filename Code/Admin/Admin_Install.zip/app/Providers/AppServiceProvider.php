<?php

namespace App\Providers;

use App\Contracts\AdminCaptchaVerifier;
use App\Models\GeneralSetting;
use App\Models\Language;
use App\Models\Module;
use App\Models\PersonalAccessToken;
use App\Services\AdminCaptcha\GoogleAdminCaptchaVerifier;
use App\Services\FirestoreService;
use App\Security\CspNonce;
use App\Security\RichTextSanitizer;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\ServiceProvider;
use Laravel\Sanctum\Sanctum;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        Sanctum::usePersonalAccessTokenModel(PersonalAccessToken::class);

        $this->app->bind(AdminCaptchaVerifier::class, GoogleAdminCaptchaVerifier::class);

        $this->app->singleton(FirestoreService::class, function ($app) {
            return new FirestoreService;
        });

        $this->app->singleton(RichTextSanitizer::class);
        $this->app->scoped(CspNonce::class);
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Blade::directive('cspNonce', static function (): string {
            return '<?php echo app(\\App\\Security\\CspNonce::class)->attribute(); ?>';
        });

        if ($this->isInstallerRequest()) {
            return;
        }

        try {
            DB::connection()->getPdo();
        } catch (\Exception $e) {
            return; // Stop executing further code if DB not available
        }

        app()->singleton('currentModule', function () {
            return Cache::remember('current_module_default', 6000, function () {
                return Module::where('default_module', '1')->first();
            });
        });

        try {
            $settings = Cache::rememberForever('general_settings', function () {
                return GeneralSetting::pluck('meta_value', 'meta_key')->toArray();
            });

            foreach ($settings as $key => $value) {
                Config::set("general.$key", $value);
            }
        } catch (\Exception $e) {
            // silently skip if settings cannot be loaded
        }

        try {
            $activeLanguages = Cache::remember('active_languages', 86400, function () {
                return Language::where('language_status', 1)
                    ->pluck('name', 'short_name')
                    ->toArray();
            });

            if (! empty($activeLanguages)) {
                Config::set('global.available_languages', $activeLanguages);
            }
        } catch (\Exception $e) {
            // silently skip if languages cannot be loaded
        }
    }

    private function isInstallerRequest(): bool
    {
        if ($this->app->runningInConsole()) {
            return false;
        }

        return request()->is('install') || request()->is('install/*');
    }
}
