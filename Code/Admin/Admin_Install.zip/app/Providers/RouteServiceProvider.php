<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Str;

class RouteServiceProvider extends ServiceProvider
{
    /**
     * The path to the "home" route for your application.
     *
     * This is used by Laravel authentication to redirect users after login.
     *
     * @var string
     */
    public const HOME = '/home';

    /**
     * The controller namespace for the application.
     *
     * When present, controller route declarations will automatically be prefixed with this namespace.
     *
     * @var string|null
     */
    protected $namespace = 'App\\Http\\Controllers';

    /**
     * Define your route model bindings, pattern filters, etc.
     */
    public function boot(): void
    {
        $this->configureRateLimiting();

        $this->routes(function () {
            Route::prefix('api')
                ->middleware('api')
                ->namespace($this->namespace)
                ->group(base_path('routes/api.php'));

            Route::middleware('web')
                ->namespace($this->namespace)
                ->group(base_path('routes/web.php'));

            Route::middleware('web')
                ->namespace($this->namespace)
                ->group(base_path('routes/admin.php'));
        });
    }

    /**
     * Configure the rate limiters for the application.
     */
    protected function configureRateLimiting(): void
    {
        RateLimiter::for('api', function (Request $request) {
            return Limit::perMinute(60)->by($request->user()?->getAuthIdentifier() ?: $request->ip());
        });

        RateLimiter::for('bootstrap-token', function (Request $request) {
            return Limit::perMinute(10)->by($request->ip());
        });

        RateLimiter::for('social-login', function (Request $request) {
            $accessToken = $request->user()?->currentAccessToken();
            $tokenId = $accessToken && method_exists($accessToken, 'getKey')
                ? $accessToken->getKey()
                : null;

            return Limit::perMinute(10)->by($request->ip().'|'.($tokenId ?: 'anonymous'));
        });

        RateLimiter::for('admin-login', function (Request $request) {
            return $this->adminAuthenticationLimits(
                $request,
                'admin-login',
                Limit::perMinutes(5, 20),
                Limit::perMinutes(5, 5)
            );
        });

        RateLimiter::for('admin-password-email', function (Request $request) {
            return $this->adminAuthenticationLimits(
                $request,
                'admin-password-email',
                Limit::perHour(10),
                Limit::perHour(3)
            );
        });

        RateLimiter::for('admin-password-reset', function (Request $request) {
            return $this->adminAuthenticationLimits(
                $request,
                'admin-password-reset',
                Limit::perMinutes(15, 20),
                Limit::perMinutes(15, 5)
            );
        });
    }

    /**
     * @return list<Limit>
     */
    private function adminAuthenticationLimits(
        Request $request,
        string $scope,
        Limit $ipLimit,
        Limit $accountLimit
    ): array {
        $limits = [
            $this->withAuthenticationLimitResponse(
                $ipLimit->by($scope.':ip:'.($request->ip() ?: 'unknown'))
            ),
        ];

        $accountKey = $this->adminAccountRateLimitKey($request, $scope);
        if ($accountKey !== null) {
            $limits[] = $this->withAuthenticationLimitResponse($accountLimit->by($accountKey));
        }

        return $limits;
    }

    private function adminAccountRateLimitKey(Request $request, string $scope): ?string
    {
        $email = $request->input('email');
        if (! is_string($email)) {
            return null;
        }

        $email = Str::lower(trim($email));
        if ($email === '' || strlen($email) > 255 || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            return null;
        }

        return $scope.':account:'.hash_hmac('sha256', $email, (string) config('app.key'));
    }

    private function withAuthenticationLimitResponse(Limit $limit): Limit
    {
        return $limit->response(function (Request $request, array $headers) {
            $message = 'Too many attempts. Please try again later.';

            return $request->expectsJson()
                ? response()->json(['message' => $message], 429, $headers)
                : response($message, 429, $headers);
        });
    }
}
