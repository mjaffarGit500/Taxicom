<?php

namespace App\Support;

use InvalidArgumentException;

final class Money
{
    private const EXPONENTS = [
        'BHD' => 3, 'IQD' => 3, 'JOD' => 3, 'KWD' => 3, 'LYD' => 3, 'OMR' => 3, 'TND' => 3,
        'BIF' => 0, 'CLP' => 0, 'DJF' => 0, 'GNF' => 0, 'ISK' => 0, 'JPY' => 0, 'KMF' => 0,
        'KRW' => 0, 'PYG' => 0, 'RWF' => 0, 'UGX' => 0, 'UYI' => 0, 'VND' => 0, 'VUV' => 0,
        'XAF' => 0, 'XOF' => 0, 'XPF' => 0,
        'CLF' => 4, 'UYW' => 4,
    ];

    public static function exponent(string $currency): int
    {
        $currency = strtoupper(trim($currency));
        if (preg_match('/^[A-Z]{3}$/', $currency) !== 1) {
            throw new InvalidArgumentException('A three-letter ISO-4217 currency is required.');
        }

        return self::EXPONENTS[$currency] ?? 2;
    }

    public static function toMinor(int|string $amount, string $currency): int
    {
        $value = trim((string) $amount);
        if (preg_match('/^(\d+)(?:\.(\d+))?$/', $value, $matches) !== 1) {
            throw new InvalidArgumentException('Payment amount must be a non-negative decimal value.');
        }

        $exponent = self::exponent($currency);
        $fraction = $matches[2] ?? '';
        if (strlen($fraction) > $exponent && trim(substr($fraction, $exponent), '0') !== '') {
            throw new InvalidArgumentException('Payment amount exceeds the currency precision.');
        }

        $fraction = str_pad(substr($fraction, 0, $exponent), $exponent, '0');
        $minor = ltrim($matches[1].$fraction, '0');
        $minor = $minor === '' ? '0' : $minor;

        if (strlen($minor) > 18 || (strlen($minor) === 18 && strcmp($minor, (string) PHP_INT_MAX) > 0)) {
            throw new InvalidArgumentException('Payment amount is too large.');
        }

        return (int) $minor;
    }

    public static function fromMinor(int $amountMinor, string $currency): string
    {
        if ($amountMinor < 0) {
            throw new InvalidArgumentException('Payment amount cannot be negative.');
        }

        $exponent = self::exponent($currency);
        if ($exponent === 0) {
            return (string) $amountMinor;
        }

        $digits = str_pad((string) $amountMinor, $exponent + 1, '0', STR_PAD_LEFT);

        return substr($digits, 0, -$exponent).'.'.substr($digits, -$exponent);
    }
}
