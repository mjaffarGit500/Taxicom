<?php

namespace App\Contracts;

use App\Services\AdminCaptcha\AdminCaptchaConfiguration;
use App\Services\AdminCaptcha\AdminCaptchaVerificationResult;

interface AdminCaptchaVerifier
{
    public function configuration(): AdminCaptchaConfiguration;

    public function verify(
        AdminCaptchaConfiguration $configuration,
        string $responseToken,
        ?string $ipAddress
    ): AdminCaptchaVerificationResult;
}
