<?php

/*
|--------------------------------------------------------------------------
| Ensure The Writable Directories Exist
|--------------------------------------------------------------------------
|
| The distributed package intentionally ships without empty directories, so
| the storage tree has to be recreated before the framework boots. Laravel
| needs its compiled views, sessions, cache and log directories from the
| very first request, including the first page of the installer, and this
| runs too early for the container or the File facade to be available.
|
*/

$basePath = dirname(__DIR__);

$directories = [
    'storage/app',
    'storage/app/profile_images',
    'storage/app/signatures',
    'storage/firebase',
    'storage/framework',
    'storage/framework/cache',
    'storage/framework/cache/data',
    'storage/framework/sessions',
    'storage/framework/testing',
    'storage/framework/views',
    'storage/logs',
    'storage/media-library',
    'storage/media-library/temp',
    'storage/tmp',
    'storage/tmp/uploads',
];

foreach ($directories as $directory) {
    $path = $basePath.'/'.$directory;

    if (! is_dir($path)) {
        @mkdir($path, 0755, true);
    }

    if (is_dir($path) && ! is_file($path.'/index.php')) {
        @file_put_contents($path.'/index.php', "<?php\n");
    }
}
