<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
        'endpoint' => env('MAILGUN_ENDPOINT', 'api.mailgun.net'),
        'scheme' => 'https',
    ],

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'social_login' => [
        'enabled' => filter_var(env('SOCIAL_LOGIN_ENABLED', false), FILTER_VALIDATE_BOOL),
        'google_client_ids' => array_values(array_filter(array_map(
            'trim',
            explode(',', (string) env('SOCIAL_GOOGLE_CLIENT_IDS', ''))
        ))),
        'apple_client_ids' => array_values(array_filter(array_map(
            'trim',
            explode(',', (string) env('SOCIAL_APPLE_CLIENT_IDS', ''))
        ))),
        'google_jwks_url' => 'https://www.googleapis.com/oauth2/v3/certs',
        'apple_jwks_url' => 'https://appleid.apple.com/auth/keys',
        'jwks_cache_seconds' => (int) env('SOCIAL_JWKS_CACHE_SECONDS', 21600),
        'http_timeout_seconds' => (int) env('SOCIAL_HTTP_TIMEOUT_SECONDS', 5),
        'clock_skew_seconds' => (int) env('SOCIAL_CLOCK_SKEW_SECONDS', 60),
    ],

    'firestore' => [
        'connect_timeout_seconds' => (float) env('FIRESTORE_CONNECT_TIMEOUT_SECONDS', 2),
        'request_timeout_seconds' => (float) env('FIRESTORE_REQUEST_TIMEOUT_SECONDS', 5),
    ],

];
