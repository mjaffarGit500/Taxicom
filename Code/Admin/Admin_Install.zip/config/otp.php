<?php

return [
    'rate_limit_max_attempts' => env('OTP_RATE_LIMIT_MAX_ATTEMPTS', 3),
    'rate_limit_window_minutes' => env('OTP_RATE_LIMIT_WINDOW_MINUTES', 15),
];
