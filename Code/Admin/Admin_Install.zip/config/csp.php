<?php

$defaultMode = in_array(env('APP_ENV'), ['local', 'testing'], true) ? 'off' : 'enforce';

return [
    'admin_mode' => env('CSP_ADMIN_MODE', $defaultMode),

    'script_hosts' => [
        'https://ajax.googleapis.com',
        'https://cdn.ckeditor.com',
        'https://cdn.datatables.net',
        'https://cdn.jsdelivr.net',
        'https://cdn.onesignal.com',
        'https://cdnjs.cloudflare.com',
        'https://code.jquery.com',
        'https://maps.googleapis.com',
        'https://www.google.com',
        'https://www.gstatic.com',
    ],

    'style_hosts' => [
        'https://cdn.datatables.net',
        'https://cdn.jsdelivr.net',
        'https://cdnjs.cloudflare.com',
        'https://fonts.googleapis.com',
        'https://maps.googleapis.com',
    ],
];
