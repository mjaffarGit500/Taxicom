<?php

return [
    // Measured in bytes to match Symfony's sanitizer ceiling and MySQL TEXT limits.
    'max_input_length' => 60_000,

    'ckeditor_classes' => [
        'image',
        'image_resized',
        'image-style-align-center',
        'image-style-align-left',
        'image-style-align-right',
        'image-style-block-align-left',
        'image-style-block-align-right',
        'image-style-side',
        'table',
    ],
];
