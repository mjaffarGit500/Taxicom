<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (
            Schema::hasTable('role_user') &&
            Schema::hasColumn('role_user', 'role_id') &&
            Schema::hasTable('roles') &&
            Schema::hasColumn('roles', 'id') &&
            !$this->foreignKeyExists('role_id_fk_8655798')
        ) {
            Schema::table('role_user', function (Blueprint $table) {
                $table->foreign(['role_id'], 'role_id_fk_8655798')->references(['id'])->on('roles')->onUpdate('no action')->onDelete('cascade');
            });
        }
        if (
            Schema::hasTable('role_user') &&
            Schema::hasColumn('role_user', 'user_id') &&
            Schema::hasTable('users') &&
            Schema::hasColumn('users', 'id') &&
            !$this->foreignKeyExists('user_id_fk_8655798')
        ) {
            Schema::table('role_user', function (Blueprint $table) {
                $table->foreign(['user_id'], 'user_id_fk_8655798')->references(['id'])->on('users')->onUpdate('no action')->onDelete('cascade');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('role_user') && $this->foreignKeyExists('role_id_fk_8655798')) {
            Schema::table('role_user', function (Blueprint $table) {
                $table->dropForeign('role_id_fk_8655798');
            });
        }
        if (Schema::hasTable('role_user') && $this->foreignKeyExists('user_id_fk_8655798')) {
            Schema::table('role_user', function (Blueprint $table) {
                $table->dropForeign('user_id_fk_8655798');
            });
        }
    }

    private function foreignKeyExists(string $constraint): bool
    {
        return DB::table('information_schema.TABLE_CONSTRAINTS')
            ->where('CONSTRAINT_SCHEMA', DB::raw('DATABASE()'))
            ->where('CONSTRAINT_TYPE', 'FOREIGN KEY')
            ->where('CONSTRAINT_NAME', $constraint)
            ->exists();
    }
};