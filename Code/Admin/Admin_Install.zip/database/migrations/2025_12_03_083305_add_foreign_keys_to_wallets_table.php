<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (
            Schema::hasTable('wallets') &&
            Schema::hasColumn('wallets', 'user_id') &&
            Schema::hasTable('app_users') &&
            Schema::hasColumn('app_users', 'id') &&
            !$this->foreignKeyExists('fk_wallets_user_id')
        ) {
            Schema::table('wallets', function (Blueprint $table) {
                $table->foreign(['user_id'], 'fk_wallets_user_id')->references(['id'])->on('app_users')->onUpdate('no action')->onDelete('cascade');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('wallets') && $this->foreignKeyExists('fk_wallets_user_id')) {
            Schema::table('wallets', function (Blueprint $table) {
                $table->dropForeign('fk_wallets_user_id');
            });
        }
    }

    private function foreignKeyExists(string $constraint): bool
    {
        return DB::table('information_schema.TABLE_CONSTRAINTS')
            ->where('CONSTRAINT_SCHEMA', DB::raw('DATABASE()'))
            ->where('CONSTRAINT_TYPE', 'FOREIGN KEY')
            ->where('CONSTRAINT_NAME', $constraint)
            ->exists();
    }
};