<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (
            Schema::hasTable('rental_items') &&
            Schema::hasColumn('rental_items', 'userid_id') &&
            Schema::hasTable('app_users') &&
            Schema::hasColumn('app_users', 'id') &&
            !$this->foreignKeyExists('fk_rental_items_userid_id')
        ) {
            Schema::table('rental_items', function (Blueprint $table) {
                $table->foreign(['userid_id'], 'fk_rental_items_userid_id')->references(['id'])->on('app_users')->onUpdate('no action')->onDelete('set null');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('rental_items') && $this->foreignKeyExists('fk_rental_items_userid_id')) {
            Schema::table('rental_items', function (Blueprint $table) {
                $table->dropForeign('fk_rental_items_userid_id');
            });
        }
    }

    private function foreignKeyExists(string $constraint): bool
    {
        return DB::table('information_schema.TABLE_CONSTRAINTS')
            ->where('CONSTRAINT_SCHEMA', DB::raw('DATABASE()'))
            ->where('CONSTRAINT_TYPE', 'FOREIGN KEY')
            ->where('CONSTRAINT_NAME', $constraint)
            ->exists();
    }
};