<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (
            Schema::hasTable('app_users') &&
            Schema::hasColumn('app_users', 'package_id') &&
            Schema::hasTable('all_packages') &&
            Schema::hasColumn('all_packages', 'id') &&
            !$this->foreignKeyExists('package_fk_8713947')
        ) {
            Schema::table('app_users', function (Blueprint $table) {
                $table->foreign(['package_id'], 'package_fk_8713947')->references(['id'])->on('all_packages')->onUpdate('no action')->onDelete('no action');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('app_users') && $this->foreignKeyExists('package_fk_8713947')) {
            Schema::table('app_users', function (Blueprint $table) {
                $table->dropForeign('package_fk_8713947');
            });
        }
    }

    private function foreignKeyExists(string $constraint): bool
    {
        return DB::table('information_schema.TABLE_CONSTRAINTS')
            ->where('CONSTRAINT_SCHEMA', DB::raw('DATABASE()'))
            ->where('CONSTRAINT_TYPE', 'FOREIGN KEY')
            ->where('CONSTRAINT_NAME', $constraint)
            ->exists();
    }
};