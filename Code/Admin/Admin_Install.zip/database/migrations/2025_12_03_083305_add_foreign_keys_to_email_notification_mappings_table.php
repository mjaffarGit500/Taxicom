<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (
            Schema::hasTable('email_notification_mappings') &&
            Schema::hasColumn('email_notification_mappings', 'email_sms_notification_id') &&
            Schema::hasTable('email_sms_notification') &&
            Schema::hasColumn('email_sms_notification', 'id') &&
            !$this->foreignKeyExists('fk_email_sms_notification')
        ) {
            Schema::table('email_notification_mappings', function (Blueprint $table) {
                $table->foreign(['email_sms_notification_id'], 'fk_email_sms_notification')->references(['id'])->on('email_sms_notification')->onUpdate('cascade')->onDelete('cascade');
            });
        }
        if (
            Schema::hasTable('email_notification_mappings') &&
            Schema::hasColumn('email_notification_mappings', 'email_type_id') &&
            Schema::hasTable('email_type') &&
            Schema::hasColumn('email_type', 'id') &&
            !$this->foreignKeyExists('fk_email_type')
        ) {
            Schema::table('email_notification_mappings', function (Blueprint $table) {
                $table->foreign(['email_type_id'], 'fk_email_type')->references(['id'])->on('email_type')->onUpdate('cascade')->onDelete('cascade');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('email_notification_mappings') && $this->foreignKeyExists('fk_email_sms_notification')) {
            Schema::table('email_notification_mappings', function (Blueprint $table) {
                $table->dropForeign('fk_email_sms_notification');
            });
        }
        if (Schema::hasTable('email_notification_mappings') && $this->foreignKeyExists('fk_email_type')) {
            Schema::table('email_notification_mappings', function (Blueprint $table) {
                $table->dropForeign('fk_email_type');
            });
        }
    }

    private function foreignKeyExists(string $constraint): bool
    {
        return DB::table('information_schema.TABLE_CONSTRAINTS')
            ->where('CONSTRAINT_SCHEMA', DB::raw('DATABASE()'))
            ->where('CONSTRAINT_TYPE', 'FOREIGN KEY')
            ->where('CONSTRAINT_NAME', $constraint)
            ->exists();
    }
};