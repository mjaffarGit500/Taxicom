<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (
            Schema::hasTable('rental_item_type_service_type') &&
            Schema::hasColumn('rental_item_type_service_type', 'rental_item_type_id') &&
            Schema::hasTable('rental_item_types') &&
            Schema::hasColumn('rental_item_types', 'id') &&
            !$this->foreignKeyExists('rental_item_type_service_type_ibfk_1')
        ) {
            Schema::table('rental_item_type_service_type', function (Blueprint $table) {
                $table->foreign(['rental_item_type_id'], 'rental_item_type_service_type_ibfk_1')->references(['id'])->on('rental_item_types')->onUpdate('no action')->onDelete('cascade');
            });
        }
        if (
            Schema::hasTable('rental_item_type_service_type') &&
            Schema::hasColumn('rental_item_type_service_type', 'rental_item_service_type_id') &&
            Schema::hasTable('rental_item_service_types') &&
            Schema::hasColumn('rental_item_service_types', 'id') &&
            !$this->foreignKeyExists('rental_item_type_service_type_ibfk_2')
        ) {
            Schema::table('rental_item_type_service_type', function (Blueprint $table) {
                $table->foreign(['rental_item_service_type_id'], 'rental_item_type_service_type_ibfk_2')->references(['id'])->on('rental_item_service_types')->onUpdate('no action')->onDelete('cascade');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('rental_item_type_service_type') && $this->foreignKeyExists('rental_item_type_service_type_ibfk_1')) {
            Schema::table('rental_item_type_service_type', function (Blueprint $table) {
                $table->dropForeign('rental_item_type_service_type_ibfk_1');
            });
        }
        if (Schema::hasTable('rental_item_type_service_type') && $this->foreignKeyExists('rental_item_type_service_type_ibfk_2')) {
            Schema::table('rental_item_type_service_type', function (Blueprint $table) {
                $table->dropForeign('rental_item_type_service_type_ibfk_2');
            });
        }
    }

    private function foreignKeyExists(string $constraint): bool
    {
        return DB::table('information_schema.TABLE_CONSTRAINTS')
            ->where('CONSTRAINT_SCHEMA', DB::raw('DATABASE()'))
            ->where('CONSTRAINT_TYPE', 'FOREIGN KEY')
            ->where('CONSTRAINT_NAME', $constraint)
            ->exists();
    }
};