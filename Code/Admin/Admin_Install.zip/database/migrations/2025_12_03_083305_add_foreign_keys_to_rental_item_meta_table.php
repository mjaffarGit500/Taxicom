<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (
            Schema::hasTable('rental_item_meta') &&
            Schema::hasColumn('rental_item_meta', 'item_id') &&
            Schema::hasTable('rental_items') &&
            Schema::hasColumn('rental_items', 'id') &&
            !$this->foreignKeyExists('fk_rental_item_meta_item_id')
        ) {
            Schema::table('rental_item_meta', function (Blueprint $table) {
                $table->foreign(['item_id'], 'fk_rental_item_meta_item_id')->references(['id'])->on('rental_items')->onUpdate('no action')->onDelete('cascade');
            });
        }
        if (
            Schema::hasTable('rental_item_meta') &&
            Schema::hasColumn('rental_item_meta', 'item_id') &&
            Schema::hasTable('rental_items') &&
            Schema::hasColumn('rental_items', 'id') &&
            !$this->foreignKeyExists('rental_item_meta_ibfk_1')
        ) {
            Schema::table('rental_item_meta', function (Blueprint $table) {
                $table->foreign(['item_id'], 'rental_item_meta_ibfk_1')->references(['id'])->on('rental_items')->onUpdate('cascade')->onDelete('no action');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('rental_item_meta') && $this->foreignKeyExists('fk_rental_item_meta_item_id')) {
            Schema::table('rental_item_meta', function (Blueprint $table) {
                $table->dropForeign('fk_rental_item_meta_item_id');
            });
        }
        if (Schema::hasTable('rental_item_meta') && $this->foreignKeyExists('rental_item_meta_ibfk_1')) {
            Schema::table('rental_item_meta', function (Blueprint $table) {
                $table->dropForeign('rental_item_meta_ibfk_1');
            });
        }
    }

    private function foreignKeyExists(string $constraint): bool
    {
        return DB::table('information_schema.TABLE_CONSTRAINTS')
            ->where('CONSTRAINT_SCHEMA', DB::raw('DATABASE()'))
            ->where('CONSTRAINT_TYPE', 'FOREIGN KEY')
            ->where('CONSTRAINT_NAME', $constraint)
            ->exists();
    }
};