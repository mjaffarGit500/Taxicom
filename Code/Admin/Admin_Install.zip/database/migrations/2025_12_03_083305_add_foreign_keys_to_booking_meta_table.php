<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (
            Schema::hasTable('booking_meta') &&
            Schema::hasColumn('booking_meta', 'booking_id') &&
            Schema::hasTable('bookings') &&
            Schema::hasColumn('bookings', 'id') &&
            !$this->foreignKeyExists('fk_booking_meta_booking_id')
        ) {
            Schema::table('booking_meta', function (Blueprint $table) {
                $table->foreign(['booking_id'], 'fk_booking_meta_booking_id')->references(['id'])->on('bookings')->onUpdate('no action')->onDelete('cascade');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('booking_meta') && $this->foreignKeyExists('fk_booking_meta_booking_id')) {
            Schema::table('booking_meta', function (Blueprint $table) {
                $table->dropForeign('fk_booking_meta_booking_id');
            });
        }
    }

    private function foreignKeyExists(string $constraint): bool
    {
        return DB::table('information_schema.TABLE_CONSTRAINTS')
            ->where('CONSTRAINT_SCHEMA', DB::raw('DATABASE()'))
            ->where('CONSTRAINT_TYPE', 'FOREIGN KEY')
            ->where('CONSTRAINT_NAME', $constraint)
            ->exists();
    }
};