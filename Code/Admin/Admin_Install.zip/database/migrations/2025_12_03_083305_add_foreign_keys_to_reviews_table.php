<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (
            Schema::hasTable('reviews') &&
            Schema::hasColumn('reviews', 'bookingid') &&
            Schema::hasTable('bookings') &&
            Schema::hasColumn('bookings', 'id') &&
            !$this->foreignKeyExists('fk_reviews_bookingid')
        ) {
            Schema::table('reviews', function (Blueprint $table) {
                $table->foreign(['bookingid'], 'fk_reviews_bookingid')->references(['id'])->on('bookings')->onUpdate('no action')->onDelete('cascade');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('reviews') && $this->foreignKeyExists('fk_reviews_bookingid')) {
            Schema::table('reviews', function (Blueprint $table) {
                $table->dropForeign('fk_reviews_bookingid');
            });
        }
    }

    private function foreignKeyExists(string $constraint): bool
    {
        return DB::table('information_schema.TABLE_CONSTRAINTS')
            ->where('CONSTRAINT_SCHEMA', DB::raw('DATABASE()'))
            ->where('CONSTRAINT_TYPE', 'FOREIGN KEY')
            ->where('CONSTRAINT_NAME', $constraint)
            ->exists();
    }
};