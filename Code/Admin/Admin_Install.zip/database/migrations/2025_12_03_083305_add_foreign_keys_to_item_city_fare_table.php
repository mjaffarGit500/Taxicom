<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (
            Schema::hasTable('item_city_fare') &&
            Schema::hasColumn('item_city_fare', 'item_type_id') &&
            Schema::hasTable('rental_item_types') &&
            Schema::hasColumn('rental_item_types', 'id') &&
            !$this->foreignKeyExists('item_city_fare_ibfk_1')
        ) {
            Schema::table('item_city_fare', function (Blueprint $table) {
                $table->foreign(['item_type_id'], 'item_city_fare_ibfk_1')->references(['id'])->on('rental_item_types')->onUpdate('no action')->onDelete('cascade');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('item_city_fare') && $this->foreignKeyExists('item_city_fare_ibfk_1')) {
            Schema::table('item_city_fare', function (Blueprint $table) {
                $table->dropForeign('item_city_fare_ibfk_1');
            });
        }
    }

    private function foreignKeyExists(string $constraint): bool
    {
        return DB::table('information_schema.TABLE_CONSTRAINTS')
            ->where('CONSTRAINT_SCHEMA', DB::raw('DATABASE()'))
            ->where('CONSTRAINT_TYPE', 'FOREIGN KEY')
            ->where('CONSTRAINT_NAME', $constraint)
            ->exists();
    }
};