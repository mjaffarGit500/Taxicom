<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (
            Schema::hasTable('app_user_meta') &&
            Schema::hasColumn('app_user_meta', 'user_id') &&
            Schema::hasTable('app_users') &&
            Schema::hasColumn('app_users', 'id') &&
            !$this->foreignKeyExists('fk_meta_user')
        ) {
            Schema::table('app_user_meta', function (Blueprint $table) {
                $table->foreign(['user_id'], 'fk_meta_user')->references(['id'])->on('app_users')->onUpdate('cascade')->onDelete('cascade');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('app_user_meta') && $this->foreignKeyExists('fk_meta_user')) {
            Schema::table('app_user_meta', function (Blueprint $table) {
                $table->dropForeign('fk_meta_user');
            });
        }
    }

    private function foreignKeyExists(string $constraint): bool
    {
        return DB::table('information_schema.TABLE_CONSTRAINTS')
            ->where('CONSTRAINT_SCHEMA', DB::raw('DATABASE()'))
            ->where('CONSTRAINT_TYPE', 'FOREIGN KEY')
            ->where('CONSTRAINT_NAME', $constraint)
            ->exists();
    }
};
