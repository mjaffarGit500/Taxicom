<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (
            Schema::hasTable('permission_role') &&
            Schema::hasColumn('permission_role', 'permission_id') &&
            Schema::hasTable('permissions') &&
            Schema::hasColumn('permissions', 'id') &&
            !$this->foreignKeyExists('permission_id_fk_8655789')
        ) {
            Schema::table('permission_role', function (Blueprint $table) {
                $table->foreign(['permission_id'], 'permission_id_fk_8655789')->references(['id'])->on('permissions')->onUpdate('no action')->onDelete('cascade');
            });
        }
        if (
            Schema::hasTable('permission_role') &&
            Schema::hasColumn('permission_role', 'role_id') &&
            Schema::hasTable('roles') &&
            Schema::hasColumn('roles', 'id') &&
            !$this->foreignKeyExists('role_id_fk_8655789')
        ) {
            Schema::table('permission_role', function (Blueprint $table) {
                $table->foreign(['role_id'], 'role_id_fk_8655789')->references(['id'])->on('roles')->onUpdate('no action')->onDelete('cascade');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('permission_role') && $this->foreignKeyExists('permission_id_fk_8655789')) {
            Schema::table('permission_role', function (Blueprint $table) {
                $table->dropForeign('permission_id_fk_8655789');
            });
        }
        if (Schema::hasTable('permission_role') && $this->foreignKeyExists('role_id_fk_8655789')) {
            Schema::table('permission_role', function (Blueprint $table) {
                $table->dropForeign('role_id_fk_8655789');
            });
        }
    }

    private function foreignKeyExists(string $constraint): bool
    {
        return DB::table('information_schema.TABLE_CONSTRAINTS')
            ->where('CONSTRAINT_SCHEMA', DB::raw('DATABASE()'))
            ->where('CONSTRAINT_TYPE', 'FOREIGN KEY')
            ->where('CONSTRAINT_NAME', $constraint)
            ->exists();
    }
};