<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (
            Schema::hasTable('make_type_relation') &&
            Schema::hasColumn('make_type_relation', 'make_id') &&
            Schema::hasTable('rental_item_make') &&
            Schema::hasColumn('rental_item_make', 'id') &&
            !$this->foreignKeyExists('fk_make_type_make_id')
        ) {
            Schema::table('make_type_relation', function (Blueprint $table) {
                $table->foreign(['make_id'], 'fk_make_type_make_id')->references(['id'])->on('rental_item_make')->onUpdate('no action')->onDelete('cascade');
            });
        }
        if (
            Schema::hasTable('make_type_relation') &&
            Schema::hasColumn('make_type_relation', 'type_id') &&
            Schema::hasTable('rental_item_types') &&
            Schema::hasColumn('rental_item_types', 'id') &&
            !$this->foreignKeyExists('fk_make_type_type_id')
        ) {
            Schema::table('make_type_relation', function (Blueprint $table) {
                $table->foreign(['type_id'], 'fk_make_type_type_id')->references(['id'])->on('rental_item_types')->onUpdate('no action')->onDelete('cascade');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('make_type_relation') && $this->foreignKeyExists('fk_make_type_make_id')) {
            Schema::table('make_type_relation', function (Blueprint $table) {
                $table->dropForeign('fk_make_type_make_id');
            });
        }
        if (Schema::hasTable('make_type_relation') && $this->foreignKeyExists('fk_make_type_type_id')) {
            Schema::table('make_type_relation', function (Blueprint $table) {
                $table->dropForeign('fk_make_type_type_id');
            });
        }
    }

    private function foreignKeyExists(string $constraint): bool
    {
        return DB::table('information_schema.TABLE_CONSTRAINTS')
            ->where('CONSTRAINT_SCHEMA', DB::raw('DATABASE()'))
            ->where('CONSTRAINT_TYPE', 'FOREIGN KEY')
            ->where('CONSTRAINT_NAME', $constraint)
            ->exists();
    }
};