<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (
            Schema::hasTable('payouts') &&
            Schema::hasColumn('payouts', 'vendorid') &&
            Schema::hasTable('app_users') &&
            Schema::hasColumn('app_users', 'id') &&
            !$this->foreignKeyExists('fk_payouts_vendorid')
        ) {
            Schema::table('payouts', function (Blueprint $table) {
                $table->foreign(['vendorid'], 'fk_payouts_vendorid')->references(['id'])->on('app_users')->onUpdate('no action')->onDelete('cascade');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('payouts') && $this->foreignKeyExists('fk_payouts_vendorid')) {
            Schema::table('payouts', function (Blueprint $table) {
                $table->dropForeign('fk_payouts_vendorid');
            });
        }
    }

    private function foreignKeyExists(string $constraint): bool
    {
        return DB::table('information_schema.TABLE_CONSTRAINTS')
            ->where('CONSTRAINT_SCHEMA', DB::raw('DATABASE()'))
            ->where('CONSTRAINT_TYPE', 'FOREIGN KEY')
            ->where('CONSTRAINT_NAME', $constraint)
            ->exists();
    }
};