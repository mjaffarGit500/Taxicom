<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (
            Schema::hasTable('rental_item_extension') &&
            Schema::hasColumn('rental_item_extension', 'item_id') &&
            Schema::hasTable('rental_items') &&
            Schema::hasColumn('rental_items', 'id') &&
            !$this->foreignKeyExists('fk_rental_item_extension_item_id')
        ) {
            Schema::table('rental_item_extension', function (Blueprint $table) {
                $table->foreign(['item_id'], 'fk_rental_item_extension_item_id')->references(['id'])->on('rental_items')->onUpdate('no action')->onDelete('cascade');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('rental_item_extension') && $this->foreignKeyExists('fk_rental_item_extension_item_id')) {
            Schema::table('rental_item_extension', function (Blueprint $table) {
                $table->dropForeign('fk_rental_item_extension_item_id');
            });
        }
    }

    private function foreignKeyExists(string $constraint): bool
    {
        return DB::table('information_schema.TABLE_CONSTRAINTS')
            ->where('CONSTRAINT_SCHEMA', DB::raw('DATABASE()'))
            ->where('CONSTRAINT_TYPE', 'FOREIGN KEY')
            ->where('CONSTRAINT_NAME', $constraint)
            ->exists();
    }
};